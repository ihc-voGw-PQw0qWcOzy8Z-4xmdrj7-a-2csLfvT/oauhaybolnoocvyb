#!/bin/bash
#
# smo_lib/srcoptim.sh - SOCS generation + source optimization (bsub/LSF)
#

# 永続 SOCS パス解決:
# - USE_SOCS_TARXZ=1 → ${socs_dir}.tar.xz を返す
# - それ以外          → ${socs_dir} をそのまま返す
resolve_socs_path() {
    local socs_dir="$1"
    if [ "$USE_SOCS_TARXZ" = "1" ]; then
        echo "${socs_dir}.tar.xz"
    else
        echo "$socs_dir"
    fi
}

# 永続 SOCS の存在チェック (tarxz / 通常 dir 両対応)
# 判定は **.ready マーカー** で行う:
#   - run_make_socs が成功した最後に touch される
#   - これにより「生成中で $socs_dir/ が中途半端に存在する」状態を
#     "完了済み" と誤判定するのを防ぐ (生成中は .ready が無い)
socs_exists() {
    local socs_dir="$1"
    if [ "$USE_SOCS_TARXZ" = "1" ]; then
        [ -f "${socs_dir}.tar.xz" ] && [ -f "${socs_dir}.tar.xz.ready" ]
    else
        [ -f "$socs_dir/.ready" ]
    fi
}

# NA 単位の展開済み SOCS cache を確保し、srcOptim に渡せるディレクトリを stdout に返す。
# - USE_SOCS_HALF=0 かつ USE_SOCS_TARXZ=0 → 何もせず $socs_dir をそのまま返す
# - それ以外 → $cache_parent/extracted/<socs_set>/ に socs_archive.sh prepare で
#              展開 (1 回だけ)。lock + .ready マーカーで並行 SMO 安全。
#              成果物は SMO 全期間共有 (cycle 跨ぎ・seed 跨ぎで再利用)。
ensure_extracted_socs() {
    local socs_dir="$1"

    # 展開不要モード
    if [ "$USE_SOCS_HALF" != "1" ] && [ "$USE_SOCS_TARXZ" != "1" ]; then
        echo "$socs_dir"
        return 0
    fi

    local cache_parent
    cache_parent=$(dirname "$socs_dir")              # = $SOCS_CACHE_DIR/na_${na}/
    local extracted_root="$cache_parent/extracted"   # 展開先ルート
    local marker="$extracted_root/.ready"
    local path_file="$extracted_root/.path"
    local lock_dir="$cache_parent/extracted_lock"

    # 既に展開済み: path を返す
    if [ -f "$marker" ] && [ -f "$path_file" ]; then
        cat "$path_file"
        return 0
    fi

    if mkdir "$lock_dir" 2>/dev/null; then
        # === 自プロセスで展開 ===
        # holder 情報 (NFS 上の waiter が stale 検出に使う)
        echo "$(hostname):$$:$(date +%s)" > "$lock_dir/holder" 2>/dev/null || true

        # trap: 異常終了時に partial 展開と lock を確実に掃除
        local _extract_cleanup="rm -rf '$extracted_root' '$lock_dir'"
        trap "$_extract_cleanup" INT TERM HUP

        local persistent
        persistent=$(resolve_socs_path "$socs_dir")
        if [ ! -e "$persistent" ]; then
            rm -rf "$lock_dir"
            trap - INT TERM HUP
            echo "ERROR: persistent SOCS missing: $persistent" >&2
            return 1
        fi
        # 前回の partial 展開を完全に破棄 (.work 残骸対策)
        rm -rf "$extracted_root"
        mkdir -p "$extracted_root"
        log_info "  [SOCS] extracting (NA-shared cache): $persistent -> $extracted_root"
        local out
        if ! out=$("$SOCS_ARCHIVE_TOOL" prepare "$persistent" "$extracted_root"); then
            rm -rf "$extracted_root"
            rm -rf "$lock_dir"
            trap - INT TERM HUP
            echo "ERROR: socs_archive.sh prepare failed for $persistent" >&2
            return 1
        fi
        echo "$out" > "$path_file"
        # marker は最後に touch (consumer が atomic に判定できる)
        : > "$marker"
        rm -rf "$lock_dir"
        trap - INT TERM HUP
        echo "$out"
        return 0
    fi

    # === 別プロセスが展開中: marker を待つ ===
    local holder_info="(unknown)"
    [ -f "$lock_dir/holder" ] && holder_info=$(cat "$lock_dir/holder" 2>/dev/null || echo "(unknown)")
    log_info "  [SOCS] another process is extracting (holder=$holder_info), waiting on $marker ..."

    local waited=0
    local wait_max=3600   # 1 時間上限
    local poll_interval=5
    while true; do
        # NFS dentry cache flush
        ls -la "$cache_parent" >/dev/null 2>&1 || true

        # 完了: marker + path_file が揃ったら成功
        if [ -f "$marker" ] && [ -f "$path_file" ]; then
            cat "$path_file"
            return 0
        fi

        # lock 解放されたが marker 無し → 失敗
        if [ ! -d "$lock_dir" ]; then
            echo "ERROR: extract lock released without marker (generator failed?)" >&2
            echo "ERROR: holder was: $holder_info" >&2
            return 1
        fi

        sleep "$poll_interval"
        waited=$((waited + poll_interval))

        if [ $((waited % 300)) -eq 0 ]; then
            local cur_holder="(unknown)"
            [ -f "$lock_dir/holder" ] && cur_holder=$(cat "$lock_dir/holder" 2>/dev/null || echo "(unknown)")
            log_info "  [SOCS] still waiting on extraction (${waited}s, holder=$cur_holder)"
        fi

        if [ "$waited" -ge "$wait_max" ]; then
            echo "ERROR: timeout (${wait_max}s) waiting for extracted SOCS cache: $marker" >&2
            echo "ERROR: holder was: $holder_info" >&2
            echo "HINT: holder プロセスが既に死んでいる場合は手動で rm -rf $lock_dir" >&2
            return 1
        fi
    done
}

# SOCS 生成 (USE_SOCS_HALF=1 で半数間引き、USE_SOCS_TARXZ=1 で生成後 tar.xz)
#
# 信頼性のために以下を行う:
#   1. 開始時に $socs_dir / ${socs_dir}.tar.xz / .ready をすべて rm -rf
#      (前回 SIGKILL や .work 残骸を確実に一掃)
#   2. 生成 & tar.xz 化に成功した **最後** に .ready マーカーを touch
#      (socs_exists() がこれを完了シグナルとして使う)
#   3. 途中で失敗したら .ready を作らずに return 1
#      → 次回呼び出しで socs_exists が false となり再生成される
run_make_socs() {
    local na_val="$1"
    local ini_file="$2"
    local socs_dir="$3"

    # 1) 開始前にクリーンアップ (前回の partial state や .work を完全破棄)
    rm -rf "$socs_dir" "${socs_dir}.tar.xz" "${socs_dir}.tar.xz.ready"

    local m3d_opts=""
    if [ "$M3D_SO" = "1" ]; then
        m3d_opts="--m3d --mask_kikaku $MASK_KIKAKU"
    fi

    local half_opts=""
    if [ "$USE_SOCS_HALF" = "1" ]; then
        half_opts="--socs_skip_y_gt_x"
    fi

    if ! python3 "$MAKE_SOCS" \
        --source "$SOURCE_CONFIG" \
        --pwc "$PWC_CONFIG" \
        --ini "$ini_file" \
        -o "$socs_dir" \
        --kernel_num "$KERNEL_NUM" \
        -j 1 \
        -q OPCALL \
        --parallel \
        --max_jobs 16 \
        $m3d_opts \
        $half_opts \
        --debug; then
        echo "  ERROR: make_socs_set_v2.py failed for NA=$na_val" >&2
        # 失敗時は partial state を再度クリーン (.work 残骸対策)
        rm -rf "$socs_dir" "${socs_dir}.tar.xz"
        return 1
    fi

    # tar.xz 圧縮 (元 socs_dir/ は pack によって削除される)
    if [ "$USE_SOCS_TARXZ" = "1" ]; then
        if [ ! -x "$SOCS_ARCHIVE_TOOL" ] && [ ! -f "$SOCS_ARCHIVE_TOOL" ]; then
            echo "  ERROR: SOCS_ARCHIVE_TOOL not found: $SOCS_ARCHIVE_TOOL" >&2
            rm -rf "$socs_dir"
            return 1
        fi
        log_info "  [SOCS] packing: $socs_dir -> ${socs_dir}.tar.xz"
        if ! "$SOCS_ARCHIVE_TOOL" pack "$socs_dir"; then
            echo "  ERROR: socs_archive.sh pack failed for $socs_dir" >&2
            rm -rf "$socs_dir" "${socs_dir}.tar.xz"
            return 1
        fi
        # 2) 完了マーカー: tarxz は sibling ファイルとして配置
        : > "${socs_dir}.tar.xz.ready"
    else
        # 2) 完了マーカー: dir 内に配置
        : > "$socs_dir/.ready"
    fi

    return 0
}

# Generate the shell script used to run srcOptim inside ONE LSF job (single seed)
# 各 bsub ジョブが 1 ホスト 1 MPI プロセスモデルを維持するため、seed ごとに
# 別ジョブとして投入する設計（案 A）。run_srcoptim() が seed ごとに本関数を呼ぶ。
#
# 注: USE_SOCS_HALF=1 / USE_SOCS_TARXZ=1 のときの展開は run_srcoptim() が
# bsub 投入前に submit ホスト側で 1 回だけ行う (NA 単位の共有 cache)。
# 本関数が受け取る $socs_dir は既に「srcOptim にそのまま渡せる展開済みパス」。
_generate_srcoptim_script() {
    local script_path="$1"
    local socs_dir="$2"
    local layout="$3"
    local input_source="$4"
    local output_source="$5"
    local cost_csv="$6"
    local log_csv="$7"
    local sa_seed="${8:-1}"

    # ====== EXTRA_OPTS: tolerance / NILS / BT / BFS / regularization ======
    # setup.sh で定義された SO_* 変数を見て、設定があるものだけ追加する。
    # 空文字 / 0 / "none" の場合は CLI に何も渡さない（C++ 側のデフォルト値を使う）。
    local EXTRA_OPTS=""

    # tolerance: 空ならスキップ（evp.csv の tolerance 列を使う）
    # 注: heredoc 内で展開される変数値は再エスケープされないので、
    # 行継続用バックスラッシュは 1 文字 (\\) で書く (\\\\ だと 2 文字になる)
    if [ -n "$SO_TOLERANCE" ]; then
        EXTRA_OPTS="${EXTRA_OPTS}    --tolerance \"$SO_TOLERANCE\" \\
"
    fi

    # NILS penalty: weight > 0 のときだけ有効化
    if [ -n "$SO_WEIGHT_NILS" ] && awk -v w="$SO_WEIGHT_NILS" 'BEGIN{exit !(w>0)}'; then
        EXTRA_OPTS="${EXTRA_OPTS}    --weight_nils \"$SO_WEIGHT_NILS\" \\
    --nils_min \"$SO_NILS_MIN\" \\
    --nils_cd_ref \"$SO_NILS_CD_REF\" \\
"
    fi

    # Bossung Tilt penalty
    if [ -n "$SO_WEIGHT_BT" ] && awk -v w="$SO_WEIGHT_BT" 'BEGIN{exit !(w>0)}'; then
        EXTRA_OPTS="${EXTRA_OPTS}    --weight_bt \"$SO_WEIGHT_BT\" \\
    --bt_power \"$SO_BT_POWER\" \\
"
    fi

    # Best Focus Shift penalty
    if [ -n "$SO_WEIGHT_BFS" ] && awk -v w="$SO_WEIGHT_BFS" 'BEGIN{exit !(w>0)}'; then
        EXTRA_OPTS="${EXTRA_OPTS}    --weight_bfs \"$SO_WEIGHT_BFS\" \\
    --bfs_power \"$SO_BFS_POWER\" \\
"
    fi

    # BT ペア: "Fp,Fn;Fp,Fn;..." 空なら defocus 極値ペア自動検出
    if [ -n "$SO_BT_PAIRS" ]; then
        EXTRA_OPTS="${EXTRA_OPTS}    --bt_pairs \"$SO_BT_PAIRS\" \\
"
    fi
    # BFS ペア: "Fp,Fn[,Nom];..." 3つ組指定可。Nom 省略時は SO_BFS_PWC_NOM 共通値
    if [ -n "$SO_BFS_PAIRS" ]; then
        EXTRA_OPTS="${EXTRA_OPTS}    --bfs_pairs \"$SO_BFS_PAIRS\" \\
"
    fi
    # BFS 共通 Nom PWC index (BFS_PAIRS の Nom 省略時または単一 BFS の Nom)
    if [ -n "$SO_BFS_PWC_NOM" ]; then
        EXTRA_OPTS="${EXTRA_OPTS}    --bfs_pwc_nom \"$SO_BFS_PWC_NOM\" \\
"
    fi

    # Pair clips (BT/BFS の三つ組検出に必要): 空ならスキップ
    if [ -n "$SO_PAIR_CLIPS" ]; then
        EXTRA_OPTS="${EXTRA_OPTS}    --pair_clips \"$SO_PAIR_CLIPS\" \\
"
    fi

    # Regularization (none/L1/L2 等)
    if [ -n "$SO_REGULARIZATION" ] && [ "$SO_REGULARIZATION" != "none" ]; then
        EXTRA_OPTS="${EXTRA_OPTS}    --regularization \"$SO_REGULARIZATION\" \\
    --regularization_weight \"$SO_REGULARIZATION_WEIGHT\" \\
"
    fi

    cat > "$script_path" << SCRIPT_EOF
#!/bin/bash
set -e

# Build the MPI run command
if [ -n "\$LSB_DJOB_HOSTFILE" ]; then
    NP=\$(cat "\$LSB_DJOB_HOSTFILE" | wc -l)
    RUNCMD="mpirun -bootstrap lsf -np \$NP $SRCOPTIM"
elif [ "$MPI_NP" -gt 1 ]; then
    RUNCMD="mpirun -np $MPI_NP $SRCOPTIM"
else
    RUNCMD="$SRCOPTIM"
fi

\$RUNCMD \\
    -l "$layout" \\
    -s "$socs_dir" \\
    -g "$SOURCE_CONFIG" \\
    -f "$input_source" \\
    -p "$PWC_CONFIG" \\
    -e "$EVP" \\
    -o "$output_source" \\
    --brightfield \\
    --cost_output "$cost_csv" \\
    --log_output "$log_csv" \\
    --optimizer "$OPTIMIZER" \\
    --max_iter "$MAX_ITER" \\
    --gradient_method "$GRADIENT_METHOD" \\
    --layer "$LAYOUT_LAYER" \\
    --epe_power_schedule "$SO_EPE_POWER_SCHEDULE" \\
    --adaptive_weight_p_schedule "$SO_ADAPTIVE_WEIGHT_P_SCHEDULE" \\
    --adaptive_weight_floor_schedule "$SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE" \\
    --sa_amplitude_init "$SO_SA_AMPLITUDE_INIT" \\
    --sa_cooling "$SO_SA_COOLING" \\
    --sa_max_rounds "$SO_SA_MAX_ROUNDS" \\
    --sa_all_stages "$SO_SA_ALL_STAGES" \\
    --sa_seed "$sa_seed" \\
    --slice_method "$SO_SLICE_METHOD" \\
    --slice_objective "$SO_SLICE_OBJECTIVE" \\
    --slice_pwc_mode "$SO_SLICE_PWC_MODE" \\
    --sliceLevelRounds "$SO_SLICELEVEL_ROUNDS" \\
    --round_conv_window "$SO_ROUND_CONV_WINDOW" \\
    --round_conv_tol "$SO_ROUND_CONV_TOL" \\
    --lbfgs_memory "$SO_LBFGS_MEMORY" \\
    --lbfgs_window "$SO_LBFGS_WINDOW" \\
    --lbfgs_rel_tol "$SO_LBFGS_REL_TOL" \\
    --lbfgs_min_iter "$SO_LBFGS_MIN_ITER" \\
    --early_stop_patience "$SO_EARLY_STOP_PATIENCE" \\
    --early_stop_tol "$SO_EARLY_STOP_TOL" \\
    --grad_tol "$SO_GRAD_TOL" \\
    --min_intensity "$SO_MIN_INTENSITY" \\
    --max_intensity "$SO_MAX_INTENSITY" \\
    --min_fill_ratio "$SO_MIN_FILL_RATIO" \\
    --weight_fill "$SO_WEIGHT_FILL" \\
    --exp_fill_penalty \\
    --fill_penalty_k "$SO_FILL_PENALTY_K" \\
${EXTRA_OPTS}    -j "$OPENMP_NUM" \\
    --verbose

SCRIPT_EOF
    chmod +x "$script_path"
}

# Extract the LSF job id from bsub output
_extract_jobid() {
    # bsub output looks like: "Job <12345> is submitted to queue <OPCALL>."
    sed -n 's/.*Job <\([0-9]*\)>.*/\1/p'
}

# Wait for the LSF job to finish, printing periodic progress updates
_wait_for_job() {
    local jobid="$1"
    local tag="$2"

    local start_epoch
    start_epoch=$(date +%s)
    echo "  [$tag] job submitted: JobID=$jobid, waiting for completion..." >&2

    local last_report=0
    local report_interval=30  # progress interval in seconds
    # UNKNOWN/empty を「完了」と解釈するのは、job が一度でも実状態
    # (PEND/RUN/DONE 等) で観測された後だけに限定する。
    # 投入直後のスケジューラ登録遅延で UNKNOWN が返っても
    # 早期に return しないようにするため。
    local job_seen=false
    local unknown_since=0
    local unknown_grace=60  # job_seen 前に UNKNOWN 継続を許容する秒数
    while true; do
        local status
        status=$(bjobs -noheader -o "stat" "$jobid" 2>/dev/null || echo "UNKNOWN")
        case "$status" in
            DONE)
                local elapsed=$(( $(date +%s) - start_epoch ))
                echo "  [$tag] job DONE: JobID=$jobid (elapsed $((elapsed/60))m $((elapsed%60))s)" >&2
                return 0
                ;;
            EXIT)
                echo "  [$tag] job EXIT (failed): JobID=$jobid" >&2
                return 1
                ;;
            UNKNOWN|"")
                if [ "$job_seen" = true ]; then
                    # 実状態観測済み → 履歴から flush された完了と解釈
                    echo "  [$tag] job status UNKNOWN after seen: JobID=$jobid (assuming done)" >&2
                    return 0
                fi
                # まだ一度も観測できていない: スケジューラ登録遅延の可能性あり
                if [ "$unknown_since" -eq 0 ]; then
                    unknown_since=$(date +%s)
                fi
                local unknown_elapsed=$(( $(date +%s) - unknown_since ))
                if [ "$unknown_elapsed" -ge "$unknown_grace" ]; then
                    echo "  [$tag] job never seen by bjobs within ${unknown_grace}s: JobID=$jobid" >&2
                    echo "  [$tag] (assuming flushed-done; will verify output file)" >&2
                    return 0
                fi
                # grace 期間中は sleep して再試行
                ;;
            *)
                job_seen=true
                unknown_since=0
                ;;
        esac

        # Periodic progress update
        local now elapsed
        now=$(date +%s)
        elapsed=$((now - start_epoch))
        if [ $((elapsed - last_report)) -ge "$report_interval" ]; then
            echo "  [$tag] ... $status  (elapsed $((elapsed/60))m $((elapsed%60))s)  JobID=$jobid" >&2
            last_report=$elapsed
        fi

        sleep 10
    done
}

# 単一 seed の bsub ジョブを投入し jobid を返す
_submit_one_srcoptim() {
    local sd="$1"             # この seed の作業ディレクトリ
    local socs_dir="$2"
    local layout="$3"
    local input_source="$4"
    local seed="$5"
    local tag="$6"

    mkdir -p "$sd"
    local out="$sd/optimized_source.illum"
    local cost="$sd/cost.csv"
    local log="$sd/log.csv"
    local rs="$sd/run_srcoptim.sh"
    local bsub_log="$sd/srcoptim_bsub.log"

    _generate_srcoptim_script "$rs" "$socs_dir" "$layout" "$input_source" \
        "$out" "$cost" "$log" "$seed"

    local out_msg
    out_msg=$(bsub \
        -n "$MPI_NP" \
        -R "span[ptile=1]" \
        -q OPCALL \
        -J "smo_so_${tag}_seed${seed}" \
        -o "$bsub_log" \
        "$rs" 2>&1)

    local jobid
    jobid=$(echo "$out_msg" | _extract_jobid)

    if [ -z "$jobid" ]; then
        echo "  [seed=$seed] ERROR: bsub failed: $out_msg" >&2
        return 1
    fi

    echo "$jobid"
    return 0
}

# Run source optimization
# - SO_NUM_STARTS=1 (default): 単発 bsub（従来動作）
# - SO_NUM_STARTS>=2: seed ごとに独立した bsub ジョブを N 並列投入
#   各ジョブは 1 host 1 MPI プロセス（span[ptile=1]）を維持。
#   全ジョブ完了後、最良 maxAbsEPE の解を最終出力にコピー。
run_srcoptim() {
    local socs_dir="$1"
    local layout="$2"
    local input_source="$3"
    local output_source="$4"
    local cost_csv="$5"
    local log_csv="$6"
    local tag="${7:-srcOptim}"
    local cycle="${8:-1}"

    # ====== Per-cycle parameter resolution ======
    # *_PER_CYCLE が設定されていれば cycle 番目を取り出して
    # function-local に shadow (bash の dynamic scoping により
    # _generate_srcoptim_script のヒアドキュメント展開時にも見える)
    local _v
    _v=$(get_cycle_value "$MAX_ITER_PER_CYCLE" "$cycle")
    if [ -n "$_v" ]; then local MAX_ITER="$_v"; log_info "  [SO][cycle=$cycle] MAX_ITER=$_v"; fi
    _v=$(get_cycle_value "$SO_NUM_STARTS_PER_CYCLE" "$cycle")
    if [ -n "$_v" ]; then local SO_NUM_STARTS="$_v"; log_info "  [SO][cycle=$cycle] SO_NUM_STARTS=$_v"; fi
    _v=$(get_cycle_value "$SO_SA_MAX_ROUNDS_PER_CYCLE" "$cycle")
    if [ -n "$_v" ]; then local SO_SA_MAX_ROUNDS="$_v"; log_info "  [SO][cycle=$cycle] SO_SA_MAX_ROUNDS=$_v"; fi
    _v=$(get_cycle_value "$SO_SLICELEVEL_ROUNDS_PER_CYCLE" "$cycle")
    if [ -n "$_v" ]; then local SO_SLICELEVEL_ROUNDS="$_v"; log_info "  [SO][cycle=$cycle] SO_SLICELEVEL_ROUNDS=$_v"; fi
    _v=$(get_cycle_value "$SO_LBFGS_MIN_ITER_PER_CYCLE" "$cycle")
    if [ -n "$_v" ]; then local SO_LBFGS_MIN_ITER="$_v"; log_info "  [SO][cycle=$cycle] SO_LBFGS_MIN_ITER=$_v"; fi
    _v=$(get_cycle_value "$SO_SA_AMPLITUDE_INIT_PER_CYCLE" "$cycle")
    if [ -n "$_v" ]; then local SO_SA_AMPLITUDE_INIT="$_v"; log_info "  [SO][cycle=$cycle] SO_SA_AMPLITUDE_INIT=$_v"; fi
    _v=$(get_cycle_value "$SO_SA_COOLING_PER_CYCLE" "$cycle")
    if [ -n "$_v" ]; then local SO_SA_COOLING="$_v"; log_info "  [SO][cycle=$cycle] SO_SA_COOLING=$_v"; fi
    # CSV-of-CSV (cycle 区切りは ';')
    _v=$(get_cycle_value "$SO_EPE_POWER_SCHEDULE_PER_CYCLE" "$cycle" ";")
    if [ -n "$_v" ]; then local SO_EPE_POWER_SCHEDULE="$_v"; log_info "  [SO][cycle=$cycle] SO_EPE_POWER_SCHEDULE=$_v"; fi
    _v=$(get_cycle_value "$SO_ADAPTIVE_WEIGHT_P_SCHEDULE_PER_CYCLE" "$cycle" ";")
    if [ -n "$_v" ]; then local SO_ADAPTIVE_WEIGHT_P_SCHEDULE="$_v"; log_info "  [SO][cycle=$cycle] SO_ADAPTIVE_WEIGHT_P_SCHEDULE=$_v"; fi
    _v=$(get_cycle_value "$SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE_PER_CYCLE" "$cycle" ";")
    if [ -n "$_v" ]; then local SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE="$_v"; log_info "  [SO][cycle=$cycle] SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE=$_v"; fi

    local work_dir
    work_dir=$(dirname "$output_source")

    # ====== SOCS の事前展開 (NA 単位の共有 cache) ======
    # USE_SOCS_HALF=1 / USE_SOCS_TARXZ=1 のときのみ展開作業が走り、共有 FS 上に
    # 1 度だけ展開する。全 seed・全 cycle がこの cache を再利用するため、
    # 同 NA で N 回 (seed×cycle) 展開していたのが 1 回になる。
    # 0/0 のとき socs_dir はそのまま srcOptim へ渡る (透過動作)。
    local socs_for_so
    if ! socs_for_so=$(ensure_extracted_socs "$socs_dir"); then
        echo "  ERROR: ensure_extracted_socs failed for $socs_dir" >&2
        return 1
    fi
    if [ "$socs_for_so" != "$socs_dir" ]; then
        log_info "  [SO] using extracted SOCS: $socs_for_so"
    fi

    # seed リストを構築
    # SO_START_SEEDS が設定されていれば優先するが、SO_NUM_STARTS で長さを切り詰める
    # (per-cycle で SO_NUM_STARTS が変化しても seeds 数を追従させるため)
    local seeds=()
    if [ -n "$SO_START_SEEDS" ]; then
        IFS=',' read -ra seeds <<< "$SO_START_SEEDS"
    fi
    local desired_n="${SO_NUM_STARTS:-1}"
    if [ "${#seeds[@]}" -eq 0 ] && [ "$desired_n" -ge 2 ]; then
        local i
        for ((i=1; i<=desired_n; i++)); do
            seeds+=("$i")
        done
    fi
    # SO_NUM_STARTS が seeds リストより小さければ先頭から truncate
    if [ "${#seeds[@]}" -gt "$desired_n" ]; then
        seeds=("${seeds[@]:0:$desired_n}")
    fi

    # ===== single-start (従来動作) =====
    if [ "${#seeds[@]}" -le 1 ]; then
        local single_seed="${seeds[0]:-1}"
        local rs="$work_dir/run_srcoptim.sh"
        local bsub_log="$work_dir/srcoptim_bsub.log"

        _generate_srcoptim_script "$rs" "$socs_for_so" "$layout" "$input_source" \
            "$output_source" "$cost_csv" "$log_csv" "$single_seed"

        local out_msg
        out_msg=$(bsub \
            -n "$MPI_NP" \
            -R "span[ptile=1]" \
            -q OPCALL \
            -J "smo_srcoptim_${tag}" \
            -o "$bsub_log" \
            "$rs" 2>&1)

        local jobid
        jobid=$(echo "$out_msg" | _extract_jobid)

        if [ -z "$jobid" ]; then
            echo "  ERROR: bsub failed: $out_msg" >&2
            return 1
        fi

        _wait_for_job "$jobid" "$tag"

        # NFS sync 対応の出力ファイルチェック
        local check_retries=30
        local check_interval=2
        local attempt
        for (( attempt = 0; attempt < check_retries; ++attempt )); do
            [ -f "$output_source" ] && break
            ls -la "$work_dir" >/dev/null 2>&1 || true
            sleep "$check_interval"
        done

        if [ ! -f "$output_source" ]; then
            echo "  ERROR: optimized source not found: $output_source" >&2
            echo "  check log: $bsub_log" >&2
            return 1
        fi
        return 0
    fi

    # ===== Multi-Start (N seeds, 各 seed 独立 bsub) =====
    echo "  Multi-Start: ${#seeds[@]} seeds = ${seeds[*]}"

    # 全 seed の bsub を投入し、(jobid, seed, sd) を記録
    local jobids=()
    local seedlist_for_wait=()
    local sd_for_seed=()
    local seed
    for seed in "${seeds[@]}"; do
        local sd="$work_dir/start_seed${seed}"
        local jid
        jid=$(_submit_one_srcoptim "$sd" "$socs_for_so" "$layout" "$input_source" \
                                    "$seed" "$tag")
        if [ -z "$jid" ]; then
            echo "  [seed=$seed] failed to submit, skipping"
            continue
        fi
        jobids+=("$jid")
        seedlist_for_wait+=("$seed")
        sd_for_seed+=("$sd")
        echo "  [seed=$seed] submitted: jobid=$jid, dir=$sd"
    done

    if [ "${#jobids[@]}" -eq 0 ]; then
        echo "  ERROR: no Multi-Start job was submitted" >&2
        return 1
    fi

    # 全 jobid の完了を待つ
    local i
    for ((i=0; i<${#jobids[@]}; i++)); do
        local jid="${jobids[$i]}"
        local sd="${sd_for_seed[$i]}"
        local s="${seedlist_for_wait[$i]}"
        _wait_for_job "$jid" "${tag}_seed${s}"
        # NFS sync wait
        local out="$sd/optimized_source.illum"
        local check_retries=30
        local check_interval=2
        local attempt
        for (( attempt = 0; attempt < check_retries; ++attempt )); do
            [ -f "$out" ] && break
            ls -la "$sd" >/dev/null 2>&1 || true
            sleep "$check_interval"
        done
    done

    # 結果集計と最良解選択 (total_cost 基準: BT/BFS/NILS/fill を含めた総合判断)
    local summary="$work_dir/multi_start_summary.csv"
    echo "seed,total_cost,maxAbsEPE,source_fill_cost,sliceLevel" > "$summary"
    local best_seed=""
    local best_val="1e30"
    for ((i=0; i<${#sd_for_seed[@]}; i++)); do
        local sd="${sd_for_seed[$i]}"
        local s="${seedlist_for_wait[$i]}"
        local cf="$sd/cost.csv"
        local tc="NaN"; local mx="NaN"; local fill="NaN"; local sl="NaN"
        if [ -f "$cf" ]; then
            tc=$(grep '^total_cost,' "$cf" | head -1 | cut -d, -f2)
            mx=$(grep '^maxAbsEPE,' "$cf" | head -1 | cut -d, -f2)
            fill=$(grep '^source_fill_cost,' "$cf" | head -1 | cut -d, -f2)
            sl=$(grep '^sliceLevel,' "$cf" | head -1 | cut -d, -f2)
        fi
        echo "$s,$tc,$mx,$fill,$sl" >> "$summary"
        if [ "$tc" != "NaN" ] && [ -n "$tc" ]; then
            if awk -v a="$tc" -v b="$best_val" 'BEGIN{exit !(a<b)}'; then
                best_val="$tc"
                best_seed="$s"
            fi
        fi
    done

    echo "  Multi-Start summary:"
    column -t -s, "$summary" 2>/dev/null | sed 's/^/    /' || cat "$summary"

    if [ -z "$best_seed" ]; then
        echo "  ERROR: no Multi-Start seed produced a valid result" >&2
        return 1
    fi

    # 最良 seed の出力を最終出力にコピー
    local bd="$work_dir/start_seed${best_seed}"
    cp "$bd/optimized_source.illum" "$output_source"
    cp "$bd/cost.csv" "$cost_csv"
    cp "$bd/log.csv" "$log_csv"
    [ -f "$bd/optimized_source.ppm" ] && \
        cp "$bd/optimized_source.ppm" "${output_source%.illum}.ppm"

    echo "  BEST seed=$best_seed, total_cost=$best_val"
    return 0
}
