/*!
 * @file main.cpp
 * @brief srcOptim - Source Optimization Tool
 *
 * L-BFGS or Adam を使用してピクセル化光源の強度を最適化し、
 * EPEコストを最小化する。
 */

#include <getopt.h>
#include <unistd.h>
#include <fcntl.h>

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

#include <so/source_grid.h>
#include <so/source_data.h>
#include <so/source_corrector.h>
#include <so/socs_config.h>
#include <so/process_config.h>
#include <so/evp_data.h>
#include <so/image_calculator.h>
#include <so/source_contribution_set.h>
#include <so/cost_calculator.h>
#include <so/source_optimizer.h>
#include <so/types.h>

void printHelp(const char* programName) {
    std::cerr << "srcOptim - Source Optimization Tool\n";
    std::cerr << "\n";
    std::cerr << "Usage:\n";
    std::cerr << "  " << programName << " -s <socs_set_dir> -g <source_grid> -p <process_config>\n";
    std::cerr << "                -f <source_file> -e <evp_csv> -l <layout_file> -o <output_source>\n";
    std::cerr << "                [options]\n";
    std::cerr << "\n";
    std::cerr << "Required arguments:\n";
    std::cerr << "  -s, --socs_set <dir>       SOCS set directory\n";
    std::cerr << "  -g, --source_config <file> source_config.txt file\n";
    std::cerr << "  -p, --process <file>       process_config.txt file\n";
    std::cerr << "  -f, --source <file>        Initial source intensity file (.illum)\n";
    std::cerr << "  -e, --evp <file>           evp.csv file\n";
    std::cerr << "  -l, --layout <file>        OASIS/GDS layout file\n";
    std::cerr << "  -o, --output <file>        Output optimized source file (.illum)\n";
    std::cerr << "\n";
    std::cerr << "Optimization options:\n";
    std::cerr << "  --optimizer <lbfgs|adam>   Optimizer type (default: lbfgs)\n";
    std::cerr << "  --max_iter <int>           Maximum iterations (default: 100)\n";
    std::cerr << "  --grad_tol <double>        Gradient tolerance (default: 1e-6)\n";
    std::cerr << "  --cost_tol <double>        Cost tolerance (default: 1e-8)\n";
    std::cerr << "  --min_intensity <double>   Minimum intensity constraint (default: 0.0)\n";
    std::cerr << "  --max_intensity <double>   Maximum intensity constraint (default: 1.0)\n";
    std::cerr << "  --min_fill_ratio <double>  Minimum source fill ratio (default: 0.07)\n";
    std::cerr << "  --weight_fill <double>     Weight for source fill penalty (default: 1.0)\n";
    std::cerr << "  --exp_fill_penalty         Use exponential fill penalty (default: quadratic)\n";
    std::cerr << "  --fill_penalty_k <double>  Exponent k for exponential penalty (default: 100)\n";
    std::cerr << "  --weight_nils <double>     Weight for NILS penalty (default: 0=disabled)\n";
    std::cerr << "  --nils_min <double>        NILS lower bound; below this value is penalized (default: 2.0)\n";
    std::cerr << "  --nils_cd_ref <double>     Reference CD [um] for NILS normalization (default: 0.022)\n";
    std::cerr << "  --early_stop_patience <int>   Early stop patience iterations (default: 3, 0=disabled)\n";
    std::cerr << "  --early_stop_tol <double>     Early stop tolerance (default: 1e-4)\n";
    std::cerr << "  --max_cost_reduction <double> Max cost reduction per round (default: -1=disabled, e.g. 0.3=30%)\n";
    std::cerr << "  --round_conv_tol <double>     Round convergence tolerance (default: 1e-6)\n";
    std::cerr << "  --round_conv_window <int>     Round convergence window size (default: 1, >=2 for window-based)\n";
    std::cerr << "\n";
    std::cerr << "L-BFGS options:\n";
    std::cerr << "  --lbfgs_memory <int>       L-BFGS memory size (default: 10)\n";
    std::cerr << "  --lbfgs_window <int>       Convergence window size (default: 10)\n";
    std::cerr << "  --lbfgs_rel_tol <double>   Relative improvement tolerance (default: 1e-6)\n";
    std::cerr << "  --lbfgs_min_iter <int>     Minimum iterations before convergence check (default: 0)\n";
    std::cerr << "\n";
    std::cerr << "Adam options:\n";
    std::cerr << "  --adam_lr <double>         Adam learning rate (default: 0.01)\n";
    std::cerr << "  --adam_beta1 <double>      Adam beta1 (default: 0.9)\n";
    std::cerr << "  --adam_beta2 <double>      Adam beta2 (default: 0.999)\n";
    std::cerr << "\n";
    std::cerr << "Cost calculation options:\n";
    std::cerr << "  --sliceLevel <double>      Threshold value (auto if not specified)\n";
    std::cerr << "  --sliceLevelHint <double>  Initial hint for slice level search\n";
    std::cerr << "  --sliceLevelRounds <int>   Number of optimization rounds with sliceLevel recalculation (default: 1)\n";
    std::cerr << "  --anchor_clips <ids>       Anchor clip IDs (comma-separated, default: 0)\n";
    std::cerr << "\n";
    std::cerr << "Two-stage optimization (recommended):\n";
    std::cerr << "  --enable_two_stage         Enable two-stage optimization (Stage1: EPE², Stage2: EPE^n)\n";
    std::cerr << "  --epe_power <int>          EPE power for single-stage or Stage 1 (default: 2)\n";
    std::cerr << "  --epe_power_stage2 <int>   EPE power for Stage 2 (default: 4)\n";
    std::cerr << "\n";
    std::cerr << "Gradient calculation options:\n";
    std::cerr << "  --gradient_method <1-4>    Gradient calculation method (default: 2)\n";
    std::cerr << "                             1: QEPE + analytical gradient\n";
    std::cerr << "                             2: EPE + analytical gradient (recommended)\n";
    std::cerr << "                             3: QEPE + numerical gradient (slow)\n";
    std::cerr << "                             4: EPE + numerical gradient (very slow)\n";
    std::cerr << "  --numerical_epsilon <d>    Epsilon for numerical gradient (default: 1e-6)\n";
    std::cerr << "\n";
    std::cerr << "Regularization options:\n";
    std::cerr << "  --regularization <type>    Regularization type (default: none)\n";
    std::cerr << "                             none: No regularization\n";
    std::cerr << "                             laplacian: Spatial smoothness (penalize deviation from neighbors)\n";
    std::cerr << "                             l2: Tikhonov regularization (penalize large intensities)\n";
    std::cerr << "                             tv: Total Variation (edge-preserving smoothness)\n";
    std::cerr << "                             isolated: Isolated point penalty (penalize isolated bright points)\n";
    std::cerr << "  --regularization_weight <d>  Regularization weight lambda (default: 0.0)\n";
    std::cerr << "\n";
    std::cerr << "Image calculation options:\n";
    std::cerr << "  --resistModel <file>       Base resistModel file\n";
    std::cerr << "  --dim0 <int>               Calculation dimension (small)\n";
    std::cerr << "  --dim <int>                Calculation dimension (large)\n";
    std::cerr << "  --kernel <int>             Number of SOCS kernels\n";
    std::cerr << "  --layer <L/D,...>          Layer/datatype pairs (default: 0/0)\n";
    std::cerr << "  --cellname <n>             Cell name\n";
    std::cerr << "  --brightfield              Bright field mode\n";
    std::cerr << "  --darkfield                Dark field mode (default)\n";
    std::cerr << "\n";
    std::cerr << "Source correction options:\n";
    std::cerr << "  --interpolation <method>   Interpolation method: nearest or bilinear (default: nearest)\n";
    std::cerr << "  --debug_source <path>      Output corrected source file for debugging\n";
    std::cerr << "\n";
    std::cerr << "Output options:\n";
    std::cerr << "  --cost_output <file>       Output final cost.csv file\n";
    std::cerr << "  --log_output <file>        Output optimization log.csv file\n";
    std::cerr << "  --round_output <prefix>    Output source PPM for each round (prefix_roundN.ppm)\n";
    std::cerr << "  --verify_gradient          Verify gradient against numerical gradient\n";
    std::cerr << "  --verbose                  Verbose output\n";
    std::cerr << "  -j, --jobs <int>           Number of threads (default: 1)\n";
    std::cerr << "  -h, --help                 Show this help message\n";
}

void writeLog(const std::string& filepath, const so::OptimizationResult& result) {
    std::ofstream ofs(filepath);
    if (!ofs.is_open()) {
        std::cerr << "Warning: Cannot open log file: " << filepath << std::endl;
        return;
    }

    ofs << "stage,round,iteration,cost,stageBestCost,stageBestSliceLevel,epeCost,sourceFillCost,nilsCost,nonConvergedCount,gradientNorm,stepSize,sourceFillRatio,sliceLevel\n";
    for (const auto& entry : result.log) {
        ofs << entry.stage << ","
            << entry.round << ","
            << entry.iteration << ","
            << entry.cost << ","
            << entry.stageBestCost << ","
            << entry.stageBestSliceLevel << ","
            << entry.epeCost << ","
            << entry.sourceFillCost << ","
            << entry.nilsCost << ","
            << entry.nonConvergedCount << ","
            << entry.gradientNorm << ","
            << entry.stepSize << ","
            << entry.sourceFillRatio << ","
            << entry.sliceLevel << "\n";
    }
}

std::string formatDuration(double seconds) {
    std::ostringstream oss;
    if (seconds < 60.0) {
        oss << std::fixed << std::setprecision(2) << seconds << " sec";
    } else if (seconds < 3600.0) {
        int min = static_cast<int>(seconds) / 60;
        double sec = seconds - min * 60;
        oss << min << " min " << std::fixed << std::setprecision(1) << sec << " sec";
    } else {
        int hour = static_cast<int>(seconds) / 3600;
        int min = (static_cast<int>(seconds) % 3600) / 60;
        double sec = seconds - hour * 3600 - min * 60;
        oss << hour << " hour " << min << " min " << std::fixed << std::setprecision(0) << sec << " sec";
    }
    return oss.str();
}

int main(int argc, char** argv) {
#ifdef HAVE_MPI_H
    MPI_Init(&argc, &argv);
    int mpiRank = 0, mpiSize = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &mpiRank);
    MPI_Comm_size(MPI_COMM_WORLD, &mpiSize);

    // 全ランクのノード情報を表示
    {
        char hostname[256];
        gethostname(hostname, sizeof(hostname));

        // ホスト名の最大長を揃える
        int nameLen = static_cast<int>(strlen(hostname)) + 1;
        int maxLen = 0;
        MPI_Allreduce(&nameLen, &maxLen, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);

        std::vector<char> myName(maxLen, 0);
        std::vector<char> allNames(mpiSize * maxLen, 0);
        strncpy(myName.data(), hostname, maxLen);
        MPI_Allgather(myName.data(), maxLen, MPI_CHAR,
                      allNames.data(), maxLen, MPI_CHAR, MPI_COMM_WORLD);

        if (mpiRank == 0) {
            std::cerr << "=== MPI Node Configuration ===" << std::endl;
            std::map<std::string, std::vector<int>> nodeMap;
            for (int i = 0; i < mpiSize; ++i) {
                std::string name(allNames.data() + i * maxLen);
                nodeMap[name].push_back(i);
            }
            for (const auto& [node, ranks] : nodeMap) {
                std::cerr << "  " << node << ": ranks ";
                for (size_t i = 0; i < ranks.size(); ++i) {
                    if (i > 0) std::cerr << ",";
                    std::cerr << ranks[i];
                }
                std::cerr << " (" << ranks.size() << " processes)" << std::endl;
            }
            std::cerr << "  Total: " << nodeMap.size() << " node(s), "
                      << mpiSize << " process(es)" << std::endl;
            std::cerr << "===============================" << std::endl;
        }
        MPI_Barrier(MPI_COMM_WORLD);
    }
#else
    int mpiRank = 0, mpiSize = 1;
#endif

    // rank 0以外はstderr/stdoutを抑制（ログ重複防止）
    // C++ストリーム(std::cerr)とCストリーム(fprintf)の両方を抑制するため、
    // ファイルディスクリプタレベルでリダイレクト
    int savedStderr = -1, savedStdout = -1;
    if (mpiRank != 0) {
        savedStderr = dup(STDERR_FILENO);
        savedStdout = dup(STDOUT_FILENO);
        int devNull = open("/dev/null", O_WRONLY);
        dup2(devNull, STDERR_FILENO);
        dup2(devNull, STDOUT_FILENO);
        close(devNull);
    }

#ifdef HAVE_MPI_H
    MPI_Comm workComm = MPI_COMM_WORLD;
#endif

    auto totalStartTime = std::chrono::high_resolution_clock::now();

    // 出力精度を6桁に設定
    std::cerr << std::fixed << std::setprecision(6);
    std::cout << std::fixed << std::setprecision(6);

    if (mpiRank == 0) {
        std::cerr << "===============================================" << std::endl;
        std::cerr << "srcOptim - Source Optimization Tool" << std::endl;
        std::cerr << "===============================================" << std::endl;
    }

    // 引数
    std::string socsSetDir;
    std::string sourceGridFile;
    std::string processConfigFile;
    std::string sourceFile;
    std::string evpFile;
    std::string layoutFile;
    std::string outputFile;
    std::string resistModelFile;
    std::string costOutputFile;
    std::string logOutputFile;

    so::CalcOptions imgOptions;
    so::OptimizationOptions optimOptions;
    so::CorrectionOptions correctionOptions;

    int flagBrightfield = 0;
    int flagVerifyGradient = 0;

    static struct option longopts[] = {
        {"help", no_argument, nullptr, 'h'},
        {"socs_set", required_argument, nullptr, 's'},
        {"source_config", required_argument, nullptr, 'g'},
        {"process", required_argument, nullptr, 'p'},
        {"source", required_argument, nullptr, 'f'},
        {"evp", required_argument, nullptr, 'e'},
        {"layout", required_argument, nullptr, 'l'},
        {"output", required_argument, nullptr, 'o'},
        {"jobs", required_argument, nullptr, 'j'},
        // Optimization options
        {"optimizer", required_argument, nullptr, 0},
        {"max_iter", required_argument, nullptr, 0},
        {"grad_tol", required_argument, nullptr, 0},
        {"cost_tol", required_argument, nullptr, 0},
        {"min_intensity", required_argument, nullptr, 0},
        {"max_intensity", required_argument, nullptr, 0},
        {"min_fill_ratio", required_argument, nullptr, 0},
        {"weight_fill", required_argument, nullptr, 0},
        {"exp_fill_penalty", no_argument, nullptr, 0},
        {"fill_penalty_k", required_argument, nullptr, 0},
        {"weight_nils", required_argument, nullptr, 0},
        {"nils_min", required_argument, nullptr, 0},
        {"nils_cd_ref", required_argument, nullptr, 0},
        {"early_stop_patience", required_argument, nullptr, 0},
        {"early_stop_tol", required_argument, nullptr, 0},
        {"max_cost_reduction", required_argument, nullptr, 0},
        {"round_conv_tol", required_argument, nullptr, 0},
        {"round_conv_window", required_argument, nullptr, 0},
        {"lbfgs_memory", required_argument, nullptr, 0},
        {"lbfgs_window", required_argument, nullptr, 0},
        {"lbfgs_rel_tol", required_argument, nullptr, 0},
        {"lbfgs_min_iter", required_argument, nullptr, 0},
        {"adam_lr", required_argument, nullptr, 0},
        {"adam_beta1", required_argument, nullptr, 0},
        {"adam_beta2", required_argument, nullptr, 0},
        // Cost calculation options
        {"sliceLevel", required_argument, nullptr, 0},
        {"sliceLevelHint", required_argument, nullptr, 0},
        {"sliceLevelRounds", required_argument, nullptr, 0},
        {"anchor_clips", required_argument, nullptr, 0},
        // Two-stage optimization options
        {"enable_two_stage", no_argument, nullptr, 0},
        {"epe_power", required_argument, nullptr, 0},
        {"epe_power_stage2", required_argument, nullptr, 0},
        // Gradient calculation options
        {"gradient_method", required_argument, nullptr, 0},
        {"numerical_epsilon", required_argument, nullptr, 0},
        // Regularization options
        {"regularization", required_argument, nullptr, 0},
        {"regularization_weight", required_argument, nullptr, 0},
        // Image calculation options
        {"resistModel", required_argument, nullptr, 0},
        {"dim0", required_argument, nullptr, 0},
        {"dim", required_argument, nullptr, 0},
        {"kernel", required_argument, nullptr, 0},
        {"layer", required_argument, nullptr, 0},
        {"cellname", required_argument, nullptr, 0},
        {"brightfield", no_argument, &flagBrightfield, 1},
        {"darkfield", no_argument, &flagBrightfield, 0},
        // Source correction options
        {"interpolation", required_argument, nullptr, 0},
        {"debug_source", required_argument, nullptr, 0},
        // Output options
        {"cost_output", required_argument, nullptr, 0},
        {"log_output", required_argument, nullptr, 0},
        {"round_output", required_argument, nullptr, 0},
        {"verify_gradient", no_argument, &flagVerifyGradient, 1},
        {"verbose", no_argument, nullptr, 'v'},
        {nullptr, 0, nullptr, 0}
    };

    int ch, optionIndex;
    while ((ch = getopt_long(argc, argv, "hs:g:p:f:e:l:o:j:v", longopts, &optionIndex)) != -1) {
        switch (ch) {
            case 'h':
                printHelp(argv[0]);
                return 0;
            case 's':
                socsSetDir = optarg;
                break;
            case 'g':
                sourceGridFile = optarg;
                break;
            case 'p':
                processConfigFile = optarg;
                break;
            case 'f':
                sourceFile = optarg;
                break;
            case 'e':
                evpFile = optarg;
                break;
            case 'l':
                layoutFile = optarg;
                break;
            case 'o':
                outputFile = optarg;
                break;
            case 'j':
                imgOptions.numThreads = std::atoi(optarg);
                optimOptions.numThreads = std::atoi(optarg);
                break;
            case 'v':
                optimOptions.verbose = true;
                break;
            case 0:
                // Optimization options
                if (strcmp(longopts[optionIndex].name, "optimizer") == 0) {
                    std::string opt = optarg;
                    if (opt == "adam" || opt == "Adam" || opt == "ADAM") {
                        optimOptions.optimizer = so::OptimizerType::Adam;
                    } else {
                        optimOptions.optimizer = so::OptimizerType::LBFGS;
                    }
                } else if (strcmp(longopts[optionIndex].name, "max_iter") == 0) {
                    optimOptions.maxIterations = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "grad_tol") == 0) {
                    optimOptions.gradientTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "cost_tol") == 0) {
                    optimOptions.costTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "min_intensity") == 0) {
                    optimOptions.minIntensity = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "max_intensity") == 0) {
                    optimOptions.maxIntensity = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "min_fill_ratio") == 0) {
                    optimOptions.minSourceFillRatio = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "weight_fill") == 0) {
                    optimOptions.weightFillPenalty = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "exp_fill_penalty") == 0) {
                    optimOptions.useExponentialFillPenalty = true;
                } else if (strcmp(longopts[optionIndex].name, "fill_penalty_k") == 0) {
                    optimOptions.fillPenaltyExponent = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "weight_nils") == 0) {
                    optimOptions.weightNilsPenalty = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "nils_min") == 0) {
                    optimOptions.nilsMin = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "nils_cd_ref") == 0) {
                    optimOptions.nilsCdReference = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "early_stop_patience") == 0) {
                    optimOptions.earlyStopPatience = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "early_stop_tol") == 0) {
                    optimOptions.earlyStopTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "max_cost_reduction") == 0) {
                    optimOptions.maxCostReduction = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "round_conv_tol") == 0) {
                    optimOptions.roundConvergenceTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "round_conv_window") == 0) {
                    optimOptions.roundConvergenceWindow = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_memory") == 0) {
                    optimOptions.lbfgsMemorySize = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_window") == 0) {
                    optimOptions.lbfgsConvergenceWindow = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_rel_tol") == 0) {
                    optimOptions.lbfgsRelativeTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_min_iter") == 0) {
                    optimOptions.lbfgsMinIterations = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adam_lr") == 0) {
                    optimOptions.adamLearningRate = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adam_beta1") == 0) {
                    optimOptions.adamBeta1 = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adam_beta2") == 0) {
                    optimOptions.adamBeta2 = std::atof(optarg);
                }
                // Cost calculation options
                else if (strcmp(longopts[optionIndex].name, "sliceLevel") == 0) {
                    optimOptions.sliceLevel = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sliceLevelHint") == 0) {
                    optimOptions.sliceLevelHint = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sliceLevelRounds") == 0) {
                    optimOptions.sliceLevelOptimizationRounds = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "anchor_clips") == 0) {
                    optimOptions.anchorClips.clear();
                    std::stringstream ss(optarg);
                    std::string token;
                    while (std::getline(ss, token, ',')) {
                        optimOptions.anchorClips.push_back(std::stoi(token));
                    }
                }
                // Two-stage optimization options
                else if (strcmp(longopts[optionIndex].name, "enable_two_stage") == 0) {
                    optimOptions.enableTwoStage = true;
                } else if (strcmp(longopts[optionIndex].name, "epe_power") == 0) {
                    optimOptions.epePower = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "epe_power_stage2") == 0) {
                    optimOptions.epePowerStage2 = std::atoi(optarg);
                }
                // Gradient calculation options
                else if (strcmp(longopts[optionIndex].name, "gradient_method") == 0) {
                    optimOptions.gradientMethod = so::parseGradientMethod(optarg);
                } else if (strcmp(longopts[optionIndex].name, "numerical_epsilon") == 0) {
                    optimOptions.numericalEpsilon = std::atof(optarg);
                }
                // Regularization options
                else if (strcmp(longopts[optionIndex].name, "regularization") == 0) {
                    std::string regType = optarg;
                    if (regType == "laplacian" || regType == "Laplacian" || regType == "LAPLACIAN") {
                        optimOptions.regularization = so::RegularizationType::Laplacian;
                    } else if (regType == "l2" || regType == "L2" || regType == "tikhonov" || regType == "Tikhonov") {
                        optimOptions.regularization = so::RegularizationType::L2;
                    } else if (regType == "tv" || regType == "TV" || regType == "totalvariation") {
                        optimOptions.regularization = so::RegularizationType::TV;
                    } else if (regType == "isolated" || regType == "Isolated" || regType == "ISOLATED") {
                        optimOptions.regularization = so::RegularizationType::Isolated;
                    } else {
                        optimOptions.regularization = so::RegularizationType::None;
                    }
                } else if (strcmp(longopts[optionIndex].name, "regularization_weight") == 0) {
                    optimOptions.regularizationWeight = std::atof(optarg);
                }
                // Image calculation options
                else if (strcmp(longopts[optionIndex].name, "resistModel") == 0) {
                    resistModelFile = optarg;
                } else if (strcmp(longopts[optionIndex].name, "dim0") == 0) {
                    imgOptions.dimx0 = imgOptions.dimy0 = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "dim") == 0) {
                    imgOptions.dimx = imgOptions.dimy = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "kernel") == 0) {
                    imgOptions.kernelNum = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "cellname") == 0) {
                    imgOptions.cellname = optarg;
                } else if (strcmp(longopts[optionIndex].name, "layer") == 0) {
                    std::stringstream ss(optarg);
                    std::string layerDatatype;
                    while (std::getline(ss, layerDatatype, ',')) {
                        size_t pos = layerDatatype.find('/');
                        if (pos != std::string::npos) {
                            int L = std::stoi(layerDatatype.substr(0, pos));
                            int D = std::stoi(layerDatatype.substr(pos + 1));
                            imgOptions.layers.emplace_back(L, D);
                        }
                    }
                }
                // Source correction options
                else if (strcmp(longopts[optionIndex].name, "interpolation") == 0) {
                    std::string method = optarg;
                    if (method == "bilinear" || method == "Bilinear" || method == "BILINEAR") {
                        correctionOptions.interpolation = so::InterpolationMethod::Bilinear;
                    } else {
                        correctionOptions.interpolation = so::InterpolationMethod::Nearest;
                    }
                } else if (strcmp(longopts[optionIndex].name, "debug_source") == 0) {
                    correctionOptions.debugOutputPath = optarg;
                }
                // Output options
                else if (strcmp(longopts[optionIndex].name, "cost_output") == 0) {
                    costOutputFile = optarg;
                } else if (strcmp(longopts[optionIndex].name, "log_output") == 0) {
                    logOutputFile = optarg;
                } else if (strcmp(longopts[optionIndex].name, "round_output") == 0) {
                    optimOptions.roundOutputPrefix = optarg;
                }
                break;
            case '?':
            default:
                printHelp(argv[0]);
                return 1;
        }
    }

    imgOptions.brightfield = (flagBrightfield == 1);
    correctionOptions.verbose = optimOptions.verbose;

    // 必須引数チェック
    if (socsSetDir.empty() || sourceGridFile.empty() || processConfigFile.empty() ||
        sourceFile.empty() || evpFile.empty() || layoutFile.empty() || outputFile.empty()) {
        std::cerr << "Error: Missing required arguments\n" << std::endl;
        printHelp(argv[0]);
        return 1;
    }

    try {
        // 入力ファイル読み込み
        if (mpiRank == 0) std::cerr << "Loading source_config: " << sourceGridFile << std::endl;
        so::SourceGrid sourceGrid;
        sourceGrid.load(sourceGridFile);

        if (mpiRank == 0) std::cerr << "Loading source_data: " << sourceFile << std::endl;
        so::SourceData sourceData;
        sourceData.load(sourceFile);

        if (mpiRank == 0) std::cerr << "Loading process_config: " << processConfigFile << std::endl;
        so::ProcessConfig processConfig;
        processConfig.load(processConfigFile);

        if (mpiRank == 0) std::cerr << "Loading evp_data: " << evpFile << std::endl;
        so::EvpData evpData;
        evpData.load(evpFile);

        // MPI並列数がclip数を超える場合、余剰ランクをスキップ
#ifdef HAVE_MPI_H
        bool isWorker = true;
        int numClips = evpData.showClipCount();
        if (mpiSize > 1 && mpiSize > numClips) {
            if (mpiRank == 0) {
                std::cerr << "Warning: MPI ranks (" << mpiSize << ") > clips ("
                          << numClips << "). Using only " << numClips << " ranks." << std::endl;
            }
            int color = (mpiRank < numClips) ? 0 : MPI_UNDEFINED;
            MPI_Comm_split(MPI_COMM_WORLD, color, mpiRank, &workComm);
            if (mpiRank >= numClips) {
                isWorker = false;
            } else {
                MPI_Comm_rank(workComm, &mpiRank);
                MPI_Comm_size(workComm, &mpiSize);
            }
        }
        if (!isWorker) {
            // 余剰ランク: stderr/stdoutを復元してfinalize
            if (savedStderr >= 0) {
                dup2(savedStderr, STDERR_FILENO);
                close(savedStderr);
                dup2(savedStdout, STDOUT_FILENO);
                close(savedStdout);
            }
            MPI_Finalize();
            return 0;
        }
#endif

        // 入力検証と自動修正
        if (mpiRank == 0) std::cerr << "Validating and correcting source data..." << std::endl;

        so::CorrectionResult correctionResult =
            so::validateAndCorrect(sourceData, sourceGrid, correctionOptions);

        if (mpiRank == 0) {
            if (correctionResult.hasCorrections()) {
                std::cerr << "Source data was corrected:" << std::endl;
                for (const auto& warning : correctionResult.warnings) {
                    std::cerr << "  " << warning << std::endl;
                }
            } else {
                std::cerr << "Source data validation passed." << std::endl;
            }
        }

        // SOCSファイル存在確認
        auto uniqueDefocuses = processConfig.showUniqueDefocuses();
        auto validPoints = sourceGrid.generateValidGridPoints();
        const auto& gridConfig = sourceGrid.showConfig();

        for (double defocus : uniqueDefocuses) {
            for (const auto& [gx, gy] : validPoints) {
                if (gridConfig.isD2Symmetry()) {
                    if (gx < 0 || gy < 0) continue;
                }

                std::string sourceID = so::SourceGrid::makeSourceID(std::abs(gx), std::abs(gy));
                if (!so::SocsFile::exists(socsSetDir, sourceID, defocus)) {
                    std::cerr << "Error: SOCS file not found for sourceID=" << sourceID
                              << ", defocus=" << defocus << std::endl;
                    return 1;
                }
            }
        }

        if (mpiRank == 0) std::cerr << "Validation passed." << std::endl;

        // Step 1: 光学像計算
        auto step1StartTime = std::chrono::high_resolution_clock::now();
        if (mpiRank == 0) {
            std::cerr << "===============================================" << std::endl;
            std::cerr << "Step 1: Calculating images in memory..." << std::endl;
            std::cerr << "  Clips: " << evpData.showClipCount() << std::endl;
            std::cerr << "  PWC conditions: " << processConfig.size() << std::endl;
            std::cerr << "  Threads: " << imgOptions.numThreads << std::endl;
            if (mpiSize > 1) {
                std::cerr << "  Image calculation distributed across " << mpiSize << " MPI ranks" << std::endl;
            }
        }

        so::ImageCalculator imageCalculator;
        imageCalculator.setSourceGrid(&sourceGrid);
        imageCalculator.setSourceData(&sourceData);
        imageCalculator.setProcessConfig(&processConfig);
        imageCalculator.setSocsSetDir(socsSetDir);
        imageCalculator.setOasisFile(layoutFile);
        imageCalculator.setResistModelFile(resistModelFile);
        imageCalculator.setOptions(imgOptions);
        imageCalculator.setMPI(mpiRank, mpiSize);

        std::string resistModelOutputDir = std::filesystem::path(outputFile).parent_path().string();
        if (resistModelOutputDir.empty()) {
            resistModelOutputDir = ".";
        }
        std::filesystem::create_directories(resistModelOutputDir);

        // resist modelファイル生成（rank 0のみ）+ バリアで同期
        if (mpiRank == 0) {
            auto uniqueMaskBiases = processConfig.showUniqueMaskBiases();
            so::ResistModelGenerator::generateAll(resistModelFile, resistModelOutputDir, uniqueMaskBiases);

            // デフォルトresistModelファイルを作成（resistModelFileが空/存在しない場合のフォールバック用）
            std::string defaultResistModelPath = resistModelOutputDir + "/resistModel_default.info";
            if (!std::filesystem::exists(defaultResistModelPath)) {
                if (!resistModelFile.empty() && std::filesystem::exists(resistModelFile)) {
                    std::filesystem::copy_file(resistModelFile, defaultResistModelPath);
                } else {
                    std::ofstream ofs(defaultResistModelPath);
                    ofs << "IntensityWeight 1" << std::endl;
                }
            }
        }
#ifdef HAVE_MPI_H
        MPI_Barrier(workComm);
#endif

        so::CalcResult calcResult = imageCalculator.calcImages(evpData, resistModelOutputDir);

        if (calcResult.sourceContributions.empty()) {
            std::cerr << "Error: No images calculated" << std::endl;
            return 1;
        }

        if (mpiRank == 0) std::cerr << "Calculated " << calcResult.sourceContributions.size() << " contribution sets." << std::endl;

        // MPI: 各ランクは自分の担当clipのcontribution setのみ保持。
        // 勾配・コストはMPI_Allreduceで集約されるため、データの共有は不要。

        // 座標系はμm単位で統一（calcCost, calcCostDirectと同じ）

        auto step1EndTime = std::chrono::high_resolution_clock::now();
        double step1Duration = std::chrono::duration<double>(step1EndTime - step1StartTime).count();
        if (mpiRank == 0) std::cerr << "Step 1 completed in " << formatDuration(step1Duration) << std::endl;

        // Step 2: 最適化
        auto step2StartTime = std::chrono::high_resolution_clock::now();
        if (mpiRank == 0) {
            std::cerr << "===============================================" << std::endl;
            std::cerr << "Step 2: Optimizing source..." << std::endl;
            std::cerr << "  Optimizer: " << (optimOptions.optimizer == so::OptimizerType::LBFGS ? "L-BFGS" : "Adam") << std::endl;
            std::cerr << "  Max iterations: " << optimOptions.maxIterations << std::endl;
            std::cerr << "  Gradient method: " << so::gradientMethodToString(optimOptions.gradientMethod)
                      << " (" << static_cast<int>(optimOptions.gradientMethod) << ")" << std::endl;
            if (optimOptions.gradientMethod == so::GradientMethod::QEPE_Numerical ||
                optimOptions.gradientMethod == so::GradientMethod::EPE_Numerical) {
                std::cerr << "  Numerical epsilon: " << optimOptions.numericalEpsilon << std::endl;
            }
            if (optimOptions.regularization != so::RegularizationType::None &&
                optimOptions.regularizationWeight > 0.0) {
                std::string regName;
                switch (optimOptions.regularization) {
                    case so::RegularizationType::Laplacian: regName = "Laplacian"; break;
                    case so::RegularizationType::L2: regName = "L2 (Tikhonov)"; break;
                    case so::RegularizationType::TV: regName = "TV (Total Variation)"; break;
                    default: regName = "None"; break;
                }
                std::cerr << "  Regularization: " << regName << " (weight=" << optimOptions.regularizationWeight << ")" << std::endl;
            }
            if (mpiSize > 1) {
                std::cerr << "  MPI ranks: " << mpiSize << std::endl;
            }
        }
        so::SourceOptimizer optimizer;
        optimizer.setOptions(optimOptions);
        optimizer.setSourceGrid(&sourceGrid);
        optimizer.setSourceData(&sourceData);
        optimizer.setEvpData(&evpData);
        optimizer.setProcessConfig(&processConfig);
        optimizer.setSourceContributions(&calcResult.sourceContributions);
        optimizer.setNA(calcResult.opticalParams.NA);
#ifdef HAVE_MPI_H
        optimizer.setMPIComm(workComm);
#endif

        // 勾配検証（オプション、rank 0のみ表示）
        if (flagVerifyGradient) {
            if (mpiRank == 0) {
                std::cerr << "-----------------------------------------------" << std::endl;
                std::cerr << "Verifying gradient..." << std::endl;
            }
            double maxRelError = optimizer.verifyGradient(1e-6);
            if (mpiRank == 0) {
                std::cerr << "Max relative error: " << std::scientific << std::setprecision(6) << maxRelError << std::endl;
                if (maxRelError > 1e-3) {
                    std::cerr << "Warning: Gradient verification failed!" << std::endl;
                } else {
                    std::cerr << "Gradient verification passed." << std::endl;
                }
                std::cerr << "-----------------------------------------------" << std::endl;
            }
            // verifyGradient内でストリームフォーマットが変更されるのでリセット
            std::cerr << std::fixed << std::setprecision(6);
        }

        // 初期コストを計算
        double initEpeCost, initFillCost;
        double initCost = optimizer.calculateCurrentCost(&initEpeCost, &initFillCost);
        if (mpiRank == 0) {
            std::cerr << "Initial cost: " << initCost
                      << " (EPE=" << initEpeCost << ", Fill=" << initFillCost << ")" << std::endl;
        }

        so::OptimizationResult result = optimizer.optimize();

        auto step2EndTime = std::chrono::high_resolution_clock::now();
        double step2Duration = std::chrono::duration<double>(step2EndTime - step2StartTime).count();

        // 結果出力（rank 0のみ）
        if (mpiRank == 0) {
            std::cerr << "\n===============================================" << std::endl;
            std::cerr << "Optimization completed!" << std::endl;
            std::cerr << "-----------------------------------------------" << std::endl;
            std::cerr << "  Converged:         " << (result.converged ? "Yes" : "No") << std::endl;
            std::cerr << "  Iterations:        " << result.iterations << std::endl;
            std::cerr << "  Termination:       " << result.terminationReason << std::endl;
            std::cerr << "  Final Cost:        " << result.finalCost << std::endl;
            std::cerr << "  Final EPE Cost:    " << result.finalEpeCost << std::endl;
            std::cerr << "  Final Fill Cost:   " << result.finalSourceFillCost << std::endl;
            std::cerr << "  Final Gradient:    " << result.finalGradientNorm << std::endl;
            std::cerr << "  Slice Level:       " << result.finalSliceLevel << std::endl;
            std::cerr << "  Source Fill Ratio: " << result.finalSourceFillRatio << std::endl;
            std::cerr << "-----------------------------------------------" << std::endl;

            // 最適化された光源を保存（stage-best復元済み）
            std::cerr << "Writing optimized source to: " << outputFile << std::endl;
            sourceData.save(outputFile);

            // PPMも同時に出力（outputFileの拡張子を.ppmに置き換え）
            std::string ppmFile = std::filesystem::path(outputFile).replace_extension(".ppm").string();
            try {
                std::cerr << "Writing optimized source PPM to: " << ppmFile << std::endl;
                sourceData.savePpm(ppmFile, sourceGrid);
            } catch (const std::exception& e) {
                std::cerr << "Warning: Failed to save PPM: " << e.what() << std::endl;
            }

            // ログ出力
            if (!logOutputFile.empty()) {
                std::cerr << "Writing optimization log to: " << logOutputFile << std::endl;
                writeLog(logOutputFile, result);
            }
        }

        // 最終コスト計算（optimizer経由、MPI分散対応）
        if (!costOutputFile.empty()) {
            if (mpiRank == 0) std::cerr << "Calculating final costs..." << std::endl;

            double epeCost = 0.0, sourceFillCost = 0.0;
            double totalCost = optimizer.calculateCurrentCost(&epeCost, &sourceFillCost);

            if (mpiRank == 0) {
                (void)sourceData;

                // srcOptimのcost.csvは最終stage（two-stage無効時はstage1）の
                // コスト関数で計算した値を出力する。QEPE_cost / total_cost_QEPE は
                // srcOptim側では算出しないので空欄とする。
                std::cerr << "Writing cost results to: " << costOutputFile << std::endl;
                std::ofstream cofs(costOutputFile);
                if (!cofs.is_open()) {
                    std::cerr << "Warning: Cannot open cost file: " << costOutputFile << std::endl;
                } else {
                    cofs << "# Summary\n";
                    cofs << "sliceLevel," << optimizer.sliceLevel() << "\n";
                    cofs << "EPE_cost," << epeCost << "\n";
                    cofs << "QEPE_cost,\n";
                    cofs << "source_fill_cost," << sourceFillCost << "\n";
                    cofs << "total_cost," << totalCost << "\n";
                    cofs << "total_cost_QEPE,\n";
                }

                std::cerr << "-----------------------------------------------" << std::endl;
                std::cerr << "  EPE Cost:          " << epeCost << std::endl;
                std::cerr << "  Source Fill Cost:  " << sourceFillCost << std::endl;
                std::cerr << "  Total Cost:        " << totalCost << std::endl;
            }
        }

        auto totalEndTime = std::chrono::high_resolution_clock::now();
        double totalDuration = std::chrono::duration<double>(totalEndTime - totalStartTime).count();

        if (mpiRank == 0) {
            std::cerr << "===============================================" << std::endl;
            std::cerr << "Execution Time Summary:" << std::endl;
            std::cerr << "  Step 1 (Image calc):   " << formatDuration(step1Duration) << std::endl;
            std::cerr << "  Step 2 (Optimization): " << formatDuration(step2Duration) << std::endl;
            std::cerr << "  Total:                 " << formatDuration(totalDuration) << std::endl;
            std::cerr << "===============================================" << std::endl;
        }

    } catch (const std::exception& e) {
        // エラー時はstderr/stdoutを復元してからメッセージ出力
        if (savedStderr >= 0) {
            dup2(savedStderr, STDERR_FILENO);
            close(savedStderr);
            dup2(savedStdout, STDOUT_FILENO);
            close(savedStdout);
        }
        std::cerr << "Error: " << e.what() << std::endl;
#ifdef HAVE_MPI_H
        MPI_Finalize();
#endif
        return 1;
    }

    // stderr/stdoutを復元
    if (savedStderr >= 0) {
        dup2(savedStderr, STDERR_FILENO);
        close(savedStderr);
        dup2(savedStdout, STDOUT_FILENO);
        close(savedStdout);
    }

#ifdef HAVE_MPI_H
    if (workComm != MPI_COMM_WORLD) {
        MPI_Comm_free(&workComm);
    }
    MPI_Finalize();
#endif
    return 0;
}
