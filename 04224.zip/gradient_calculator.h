/*!
 * @file gradient_calculator.h
 * @brief コスト勾配の計算
 */

#ifndef SO_GRADIENT_CALCULATOR_H
#define SO_GRADIENT_CALCULATOR_H

#include <so/types.h>
#include "variable_mapping.h"
#include <so/source_data.h>
#include <so/source_grid.h>
#include <so/source_contribution_set.h>
#include <so/evp_data.h>
#include <so/process_config.h>
#include <vector>
#include <map>
#include <string>

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

namespace so {

/*!
 * @brief 勾配計算のための中間結果
 */
struct GradientIntermediates {
    double totalWeight = 0.0;       ///< 全重みの合計 W = Σ(norm_i * s_i)
    std::map<std::pair<double, double>, double> weightPerSource;  ///< 各光源の重み w_j = norm_j * s_j
};

/*!
 * @brief コスト勾配計算クラス
 *
 * QEPE近似に基づく解析的勾配を計算:
 * ∂cost/∂s_j = 2 × Σ(QEPE_i × w_i × ∂QEPE_i/∂s_j) / Σ(w_i)
 *            + weightFill × ∂source_fill_cost/∂s_j
 */
class GradientCalculator {
public:
    GradientCalculator();
    ~GradientCalculator();

    /*!
     * @brief 変数マッピングを設定
     */
    void setVariableMapping(const VariableMapping* mapping);

    /*!
     * @brief オプションを設定
     */
    void setOptions(const OptimizationOptions& options);

    /*!
     * @brief 勾配計算方法を変更
     */
    void setGradientMethod(GradientMethod method) { m_options.gradientMethod = method; }

    /*!
     * @brief 光学パラメータを設定（NA値が必要）
     */
    void setNA(double NA);

    /*!
     * @brief 全光源寄与を設定
     * @param sourceContributions クリップ→光源寄与セットのマップ
     */
    void setSourceContributions(
        const std::map<std::string, SourceContributionSet>* sourceContributions);

    /*!
     * @brief 勾配を計算（GradientMethodに基づいて計算方法を選択）
     * @param sourceData 現在の光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @param epePower EPEのべき乗（EPE系メソッドのみ有効、デフォルト: 2）
     * @return 最適化変数に対する勾配ベクトル
     */
    std::vector<double> calculateGradient(
        SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        int epePower = 2) const;

    /*!
     * @brief コストを計算（GradientMethodに基づいてQEPE/EPEを選択）
     * @param sourceData 光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @param epePower EPEのべき乗（EPE系メソッドのみ有効、デフォルト: 2）
     * @param outEpeCost EPEコストの出力（nullptr可）
     * @param outSourceFillCost Source Fill Costの出力（nullptr可）
     * @return 総コスト
     */
    double calculateCostByMethod(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        int epePower = 2,
        double* outEpeCost = nullptr,
        double* outSourceFillCost = nullptr) const;

    /*!
     * @brief 勾配を計算（QEPE近似）
     * @param sourceData 現在の光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @return 最適化変数に対する勾配ベクトル
     */
    std::vector<double> calculate(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel) const;

    /*!
     * @brief 勾配を計算（厳密EPE、EPE^n）
     * @param sourceData 現在の光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @param epePower EPEのべき乗（デフォルト: 4）
     * @return 最適化変数に対する勾配ベクトル
     */
    std::vector<double> calculateEpeAnalytical(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        int epePower = 4) const;

    /*!
     * @brief 数値勾配を計算（検証用、素朴な実装）
     * @param sourceData 現在の光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @param epsilon 差分幅
     * @return 数値計算による勾配ベクトル
     */
    std::vector<double> calculateNumerical(
        SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        double epsilon = 1e-6) const;

    /*!
     * @brief 数値勾配を計算（効率版、GradientMethodに基づいて選択）
     * @param sourceData 現在の光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @param epePower EPEのべき乗（EPE系のみ有効）
     * @return 数値計算による勾配ベクトル
     */
    std::vector<double> calculateNumericalEfficient(
        SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        int epePower = 2) const;

    /*!
     * @brief コストを計算（QEPE²）
     * @param sourceData 光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @param outEpeCost EPEコストの出力（nullptr可）
     * @param outSourceFillCost Source Fill Costの出力（nullptr可）
     * @return 総コスト
     */
    double calculateCost(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        double* outEpeCost = nullptr,
        double* outSourceFillCost = nullptr) const;

    /*!
     * @brief コストを計算（厳密EPE^n）
     * @param sourceData 光源強度データ
     * @param evpData 評価点データ
     * @param processConfig プロセス条件
     * @param sliceLevel 閾値
     * @param epePower EPEのべき乗（デフォルト: 4）
     * @param outEpeCost EPEコストの出力（nullptr可）
     * @param outSourceFillCost Source Fill Costの出力（nullptr可）
     * @return 総コスト
     */
    double calculateCostEpe(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        int epePower = 4,
        double* outEpeCost = nullptr,
        double* outSourceFillCost = nullptr) const;

    /*!
     * @brief MPIランク情報を設定
     * @param rank MPIランク（0-indexed）
     * @param size MPI総ランク数
     */
    void setMPI(int rank, int size) { m_mpiRank = rank; m_mpiSize = size; }

#ifdef HAVE_MPI_H
    /*!
     * @brief MPIコミュニケータを設定
     * @param comm 使用するMPIコミュニケータ
     */
    void setMPIComm(MPI_Comm comm) { m_mpiComm = comm; }
#endif

private:
    int m_mpiRank = 0;   ///< MPIランク（0-indexed）
    int m_mpiSize = 1;   ///< MPI総ランク数
#ifdef HAVE_MPI_H
    MPI_Comm m_mpiComm = MPI_COMM_WORLD;  ///< MPIコミュニケータ
#endif

    const VariableMapping* m_mapping = nullptr;
    const std::map<std::string, SourceContributionSet>* m_sourceContributions = nullptr;
    OptimizationOptions m_options;
    double m_NA = 1.35;

    /*!
     * @brief 各光源点の重みを計算
     */
    GradientIntermediates calcIntermediates(
        const SourceContributionSet& contribSet,
        const SourceData& sourceData) const;

    /*!
     * @brief ある評価点でのQEPE勾配を計算
     * @param delta_dose ドーズ補正値
     * @return 光源座標 -> 勾配値のマップ
     */
    std::map<std::pair<double, double>, double> calcQepeGradientAtPoint(
        const SourceContributionSet& contribSet,
        const SourceData& sourceData,
        const GradientIntermediates& inter,
        double px, double py, double degree,
        double sliceLevel,
        double delta_dose) const;

    /*!
     * @brief ある評価点での厳密EPE勾配を計算
     *
     * Newton 法が収束した場合はコントア位置での解析勾配を返す。
     * 非収束時は evp 位置での QEPE 勾配にフォールバックし、
     * cost 側でも同じ QEPE を effective EPE として使えるようにする。
     * これにより cost と gradient が常に同じ量の微分関係を保つ。
     *
     * @param outEpe 計算されたEPE (収束時) または QEPE (非収束時) の出力
     * @param outConverged Newton が収束したか否かを出力
     * @return 光源座標 -> 勾配値のマップ（|G|<MIN_GRADIENT の極端な場合のみ空）
     */
    std::map<std::pair<double, double>, double> calcStrictEpeGradientAtPoint(
        const SourceContributionSet& contribSet,
        const SourceData& sourceData,
        const GradientIntermediates& inter,
        double px, double py, double degree,
        double sliceLevel,
        double delta_dose,
        double* outEpe = nullptr,
        bool* outConverged = nullptr,
        int debugClipID = -1,
        int debugPwcIdx = -1,
        double debugMaskBias = 0.0) const;

    /*!
     * @brief コントア位置を求める（ニュートン法）
     * @param contribSet 光源寄与セット
     * @param sourceData 光源強度データ
     * @param px 評価点X座標
     * @param py 評価点Y座標
     * @param degree 法線方向（度）
     * @param sliceLevel 閾値
     * @param delta_dose ドーズ補正値 [%]
     * @param outConverged 収束したかどうかの出力（nullptr可）
     * @return EPE値（コントア位置 = (px, py) + EPE * (nx, ny)）
     */
    double findContourPosition(
        const SourceContributionSet& contribSet,
        const SourceData& sourceData,
        double px, double py, double degree,
        double sliceLevel,
        double delta_dose,
        bool* outConverged = nullptr,
        int debugClipID = -1,
        int debugPwcIdx = -1,
        double debugMaskBias = 0.0) const;

    /*!
     * @brief コントア位置をニュートン法で探し、詳細結果を返す
     *
     * cost/gradient 両方で同一の収束判定と QEPE 値を使うために存在する。
     * 戻り値の EpeCalcResult.converged, .epe, .qepe, .intensity, .gradient を
     * 呼び出し側で QEPE フォールバックに利用する。
     */
    EpeCalcResult findContourPositionFull(
        const SourceContributionSet& contribSet,
        const SourceData& sourceData,
        double px, double py, double degree,
        double sliceLevel,
        double delta_dose) const;

    /*!
     * @brief ある評価点での NILS = cdRef × |G| / slice_level を計算
     *
     * @param combinedImg 合成画像（delta_dose 適用済み）
     * @param px,py 評価点座標
     * @param degree 法線方向（度）
     * @param sliceLevel 閾値
     * @param outG 法線方向勾配 G = ∂I/∂n の出力（nullptr可、gradient 計算で再利用）
     */
    double calcNilsAtPoint(
        const FrequencyImage& combinedImg,
        double px, double py, double degree,
        double sliceLevel,
        double* outG = nullptr) const;

    /*!
     * @brief source_fill_costの勾配を計算
     */
    std::vector<double> calcSourceFillGradient(
        const SourceData& sourceData) const;

    /*!
     * @brief source_fill_ratioを計算
     */
    double calcSourceFillRatio(const SourceData& sourceData) const;

    /*!
     * @brief source_fill_costを計算
     */
    double calcSourceFillCost(double sourceFillRatio) const;

    /*!
     * @brief NILS ペナルティコストの集計値を計算
     *
     * cost_nils = Σ_{c,p,i} max(0, nilsMin - NILS_i)^2 × w_i / Σ w_i
     * weightNilsPenalty が 0 のとき即座に 0 を返す。
     */
    double calcNilsCostTotal(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel) const;

    /*!
     * @brief NILS ペナルティ勾配の集計ベクトルを計算
     *
     * weightNilsPenalty が 0 のときはゼロベクトルを返す。
     */
    std::vector<double> calcNilsGradientTotal(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel) const;

    /*!
     * @brief ラプラシアン正則化コストを計算
     * R_Lap = λ × Σ_i (s_i - avg(N_i))²
     * @param sourceData 光源強度データ
     * @return ラプラシアンコスト（重み適用済み）
     */
    double calcLaplacianCost(const SourceData& sourceData) const;

    /*!
     * @brief ラプラシアン正則化の勾配を計算
     * ∂R_Lap/∂s_k = 2λ × [(s_k - avg(N_k)) - Σ_{i: k∈N_i} (s_i - avg(N_i)) / |N_i|]
     * @param sourceData 光源強度データ
     * @return 最適化変数に対する勾配ベクトル
     */
    std::vector<double> calcLaplacianGradient(const SourceData& sourceData) const;

    /*!
     * @brief グリッド点の隣接点を取得
     * @param gx X座標
     * @param gy Y座標
     * @return 隣接点の座標リスト（上下左右の4近傍）
     */
    std::vector<std::pair<double, double>> getNeighbors(double gx, double gy) const;

    /*!
     * @brief L2正則化コストを計算
     * R_L2 = λ × Σ_i s_i²
     * @param sourceData 光源強度データ
     * @return L2コスト（重み適用済み）
     */
    double calcL2Cost(const SourceData& sourceData) const;

    /*!
     * @brief L2正則化の勾配を計算
     * ∂R_L2/∂s_k = 2λ × s_k
     * @param sourceData 光源強度データ
     * @return 最適化変数に対する勾配ベクトル
     */
    std::vector<double> calcL2Gradient(const SourceData& sourceData) const;

    /*!
     * @brief TV正則化コストを計算
     * R_TV = λ × Σ_i Σ_{j∈N_i} |s_i - s_j|
     * @param sourceData 光源強度データ
     * @return TVコスト（重み適用済み）
     */
    double calcTVCost(const SourceData& sourceData) const;

    /*!
     * @brief TV正則化の勾配を計算（smooth approximation）
     * 微分可能な近似を使用: sqrt((s_i - s_j)² + ε)
     * @param sourceData 光源強度データ
     * @return 最適化変数に対する勾配ベクトル
     */
    std::vector<double> calcTVGradient(const SourceData& sourceData) const;

    /*!
     * @brief 孤立点ペナルティコストを計算
     * R_isolated = λ × Σ_i max(0, s_i - max(s_neighbors))²
     * まとまりのある分布を促進し、孤立した点にペナルティを与える
     * @param sourceData 光源強度データ
     * @return 孤立点ペナルティコスト（重み適用済み）
     */
    double calcIsolatedCost(const SourceData& sourceData) const;

    /*!
     * @brief 孤立点ペナルティの勾配を計算
     * @param sourceData 光源強度データ
     * @return 最適化変数に対する勾配ベクトル
     */
    std::vector<double> calcIsolatedGradient(const SourceData& sourceData) const;


    /*!
     * @brief QEPE + 数値差分（選択肢3）
     */
    std::vector<double> calculateQepeNumerical(
        SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel) const;

    /*!
     * @brief EPE + 数値差分（選択肢4）
     */
    std::vector<double> calculateEpeNumerical(
        SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        int epePower) const;

    /*!
     * @brief 効率的なQEPE数値差分（差分計算による高速化版）
     */
    std::vector<double> calculateQepeNumericalEfficient(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel) const;

    /*!
     * @brief 効率的なEPE数値差分（差分計算による高速化版）
     */
    std::vector<double> calculateEpeNumericalEfficient(
        const SourceData& sourceData,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel,
        int epePower) const;
};

} // namespace so

#endif // SO_GRADIENT_CALCULATOR_H
