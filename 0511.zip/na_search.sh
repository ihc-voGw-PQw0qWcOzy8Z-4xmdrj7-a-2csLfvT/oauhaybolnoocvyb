#!/bin/bash
#
# smo_lib/na_search.sh - NA ternary search
#

# Round NA to the nearest NA_PRECISION grid
round_na() {
    local val="$1"
    echo "$val $NA_PRECISION" | awk '{n=sprintf("%.0f", $1/$2); printf "%f\n", n*$2}'
}

# Run source optimization for the given NA and store the resulting cost
evaluate_na() {
    local na_val="$1"
    local cycle="$2"
    local layout="$3"
    local input_source="$4"
    local tag="$5"

    local na_str=$(printf "%.6f" "$na_val")
    local na_dir="$LAYOUT_WORK_DIR/cycle${cycle}/na_${na_str}"
    mkdir -p "$na_dir"

    # Generate ini (cycle 用・srcOptim の入力となる)
    local ini_file="$na_dir/ini.txt"
    generate_ini "$na_val" "$ini_file"

    # SOCS generation (レイアウト・cycle 横断でキャッシュ)
    local cache_parent="$SOCS_CACHE_DIR/na_${na_str}"
    local socs_dir="$cache_parent/socs_set"
    local lock_dir="$cache_parent/lock"
    mkdir -p "$cache_parent"

    # 永続 SOCS の存在チェックは .ready マーカーを基準にする (socs_exists)
    # NFS 環境では mkdir は原子的だが、dentry cache の影響で他ホストから
    # ファイル変化が即座に見えないことがあるため、wait loop で明示的に
    # cache を flush する。
    if ! socs_exists "$socs_dir"; then
        if mkdir "$lock_dir" 2>/dev/null; then
            # === 自プロセスで生成 ===
            # holder 情報を記録 (waiter が stale 検出に使う)
            echo "$(hostname):$$:$(date +%s)" > "$lock_dir/holder" 2>/dev/null || true

            # trap: SIGINT/TERM/EXIT のいずれでも lock_dir と partial state を掃除する
            # これにより LSF kill / Ctrl-C / シェル異常終了でも .work が残らない
            local _lock_cleanup_trap="rm -rf '$socs_dir' '${socs_dir}.tar.xz' '${socs_dir}.tar.xz.ready'; rm -rf '$lock_dir'"
            trap "$_lock_cleanup_trap" INT TERM HUP

            local cache_ini="$cache_parent/ini.txt"
            generate_ini "$na_val" "$cache_ini"
            local t0
            t0=$(date +%s)
            local socs_persistent
            socs_persistent=$(resolve_socs_path "$socs_dir")
            banner_start "SOCS generation [cycle=$cycle tag=$tag]" \
                "NA     = $na_val" \
                "output = $socs_persistent"
            if ! run_make_socs "$na_val" "$cache_ini" "$socs_dir" >&2; then
                rm -rf "$socs_dir" "${socs_dir}.tar.xz" "${socs_dir}.tar.xz.ready"
                rm -rf "$lock_dir"
                trap - INT TERM HUP
                echo "  ERROR: SOCS generation failed for NA=$na_val" >&2
                return 1
            fi
            banner_end "SOCS generation [cycle=$cycle tag=$tag NA=$na_val]" "$t0"
            # 成功: lock を解放 (.ready は run_make_socs が touch 済み)
            rm -rf "$lock_dir"
            trap - INT TERM HUP
        else
            # === 別プロセスが生成中: 完了を待つ ===
            local holder_info="(unknown)"
            [ -f "$lock_dir/holder" ] && holder_info=$(cat "$lock_dir/holder" 2>/dev/null || echo "(unknown)")
            log_info "  [SOCS] another process is generating NA=$na_val (holder=$holder_info), waiting..."

            local wait_elapsed=0
            local wait_max=7200  # 2 時間上限
            local poll_interval=10
            while true; do
                # NFS dentry cache を flush (親ディレクトリを ls で叩く)
                ls -la "$cache_parent" >/dev/null 2>&1 || true

                # 完了判定: .ready マーカーが見えたら成功
                if socs_exists "$socs_dir"; then
                    log_info "  [SOCS] cache ready: $(resolve_socs_path "$socs_dir")"
                    break
                fi

                # lock が解放されたが .ready が無い → 生成失敗
                if [ ! -d "$lock_dir" ]; then
                    echo "  ERROR: SOCS lock released without .ready marker (generator failed?)" >&2
                    echo "  ERROR: holder was: $holder_info" >&2
                    return 1
                fi

                sleep "$poll_interval"
                wait_elapsed=$((wait_elapsed + poll_interval))

                # 異常に長い場合は holder を再表示して状況を可視化
                if [ $((wait_elapsed % 300)) -eq 0 ]; then
                    local cur_holder="(unknown)"
                    [ -f "$lock_dir/holder" ] && cur_holder=$(cat "$lock_dir/holder" 2>/dev/null || echo "(unknown)")
                    log_info "  [SOCS] still waiting (${wait_elapsed}s, holder=$cur_holder)"
                fi

                if [ "$wait_elapsed" -ge "$wait_max" ]; then
                    echo "  ERROR: timeout (${wait_max}s) waiting for SOCS cache lock: $lock_dir" >&2
                    echo "  ERROR: holder was: $holder_info" >&2
                    echo "  HINT: もし holder プロセスが既に死んでいる場合は手動で rm -rf $lock_dir" >&2
                    return 1
                fi
            done
        fi
    else
        log_info "  [skip] SOCS cache hit: $(resolve_socs_path "$socs_dir")"
    fi

    # Source optimization
    local output_source="$na_dir/optimized_source.illum"
    local cost_csv="$na_dir/cost.csv"
    local log_csv="$na_dir/log.csv"

    # srcOptim キャッシュ: 最適化済み illum と final_cost が両方あればスキップ
    if [ -f "$output_source" ] && [ -f "$na_dir/final_cost.txt" ]; then
        local cached_cost
        cached_cost=$(cat "$na_dir/final_cost.txt")
        log_info "  [skip] srcOptim cache hit: $output_source (cost=$cached_cost)"
        return 0
    fi

    local t1
    t1=$(date +%s)
    banner_start "srcOptim [cycle=$cycle tag=$tag]" \
        "NA            = $na_val" \
        "layout        = $layout" \
        "input source  = $input_source" \
        "output source = $output_source"
    run_srcoptim "$socs_dir" "$layout" "$input_source" "$output_source" "$cost_csv" "$log_csv" "$tag" "$cycle" >&2

    # Fetch cost
    local cost
    cost=$(get_final_cost "$cost_csv")
    if [ -z "$cost" ]; then
        echo "  ERROR: failed to extract total_cost from $cost_csv" >&2
        return 1
    fi
    banner_end "srcOptim [cycle=$cycle tag=$tag NA=$na_val]" "$t1" \
        "cost = $cost"

    echo "$cost" > "$na_dir/final_cost.txt"
}

# Ternary search for the optimal NA
search_optimal_na() {
    local cycle="$1"
    local layout="$2"
    local input_source="$3"

    local lo="$NA_MIN"
    local hi="$NA_MAX"
    local iteration=0

    log_info ""
    log_info "================================================================"
    log_info "  NA ternary search START: [$lo, $hi], precision=$NA_PRECISION"
    log_info "================================================================"

    while true; do
        # Convergence check
        local range
        range=$(echo "$hi - $lo" | bc -l)
        local converged
        converged=$(echo "$range <= $NA_TOL" | bc -l)
        if [ "$converged" -eq 1 ]; then
            log_info "  --- NA converged: range=$range <= $NA_TOL ---"
            break
        fi

        iteration=$((iteration + 1))

        # Compute the two interior trisection points and round to NA_PRECISION
        local m1 m2
        m1=$(round_na "$(echo "$lo + ($hi - $lo) / 3.0" | bc -l)")
        m2=$(round_na "$(echo "$hi - ($hi - $lo) / 3.0" | bc -l)")

        # If m1 == m2 we can no longer narrow the search
        local same
        same=$(echo "$m1 == $m2" | bc -l)
        if [ "$same" -eq 1 ]; then
            log_info "  --- NA converged: m1 == m2 == $m1 (precision limit) ---"
            break
        fi

        log_info ""
        log_info "  --- NA search iteration $iteration: lo=$lo, m1=$m1, m2=$m2, hi=$hi ---"

        # Evaluate cost at m1
        evaluate_na "$m1" "$cycle" "$layout" "$input_source" "NA-search-m1"
        local m1_str=$(printf "%.6f" "$m1")
        local cost_m1
        cost_m1=$(cat "$LAYOUT_WORK_DIR/cycle${cycle}/na_${m1_str}/final_cost.txt")

        # Evaluate cost at m2
        evaluate_na "$m2" "$cycle" "$layout" "$input_source" "NA-search-m2"
        local m2_str=$(printf "%.6f" "$m2")
        local cost_m2
        cost_m2=$(cat "$LAYOUT_WORK_DIR/cycle${cycle}/na_${m2_str}/final_cost.txt")

        log_info "  cost(m1=$m1) = $cost_m1"
        log_info "  cost(m2=$m2) = $cost_m2"

        # Narrow the search range based on cost comparison
        local m1_better
        m1_better=$(echo "$cost_m1 < $cost_m2" | bc -l)
        if [ "$m1_better" -eq 1 ]; then
            hi="$m2"
            log_info "  -> range update: [$lo, $m2]"
        else
            lo="$m1"
            log_info "  -> range update: [$m1, $hi]"
        fi
    done

    # Best NA = midpoint of the final range (rounded)
    local best_na
    best_na=$(round_na "$(echo "($lo + $hi) / 2.0" | bc -l)")
    echo "$best_na"
}
