#!/bin/bash
#
# make_socs_one.sh - 単一 NA に対する SOCS cache を生成
#
# 使い方:
#   ./make_socs_one.sh <NA> <output_socs_dir> [options]
#
# 例:
#   ./make_socs_one.sh 1.20 ./socs_set
#   ./make_socs_one.sh 1.25 ./socs_set --kernel_num 30 --half
#
# 動作:
#   1. 既存の output_socs_dir を rm -rf でクリーン
#   2. ini ファイルを NA で書き換えて output_socs_dir/.ini.txt に出力
#   3. make_socs_set_v2.py を実行 (内部で LSF queue OPCALL を使用)
#   4. 成功時に output_socs_dir/.ready を touch
#
# 注意:
#   - make_socs_set_v2.py 自身は LSF queue (OPCALL) にジョブを投げます
#   - 出力は無圧縮ディレクトリです。tar.xz 化したい場合は別途
#     ./socs_archive.sh pack <output_socs_dir> を呼んでください
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ===== Defaults =====
INI_TEMPLATE="$SCRIPT_DIR/in/ini.txt"
SOURCE_CONFIG="$SCRIPT_DIR/in/source_config.txt"
PWC_CONFIG="$SCRIPT_DIR/in/pwc_config.txt"
MAKE_SOCS="$PROJECT_ROOT/mkSocsSet/make_socs_set_v2.py"
KERNEL_NUM=30
MAX_JOBS=16
QUEUE="OPCALL"
M3D=0
MASK_KIKAKU="4kikaku"
USE_HALF=0

usage() {
    cat << EOF
Usage: $0 <NA> <output_socs_dir> [options]

Required:
  <NA>                    NA value (e.g. 1.20)
  <output_socs_dir>       output SOCS directory path

Options:
  -i, --ini-template FILE   ini template (default: in/ini.txt)
  -s, --source FILE         source config (default: in/source_config.txt)
  -p, --pwc FILE            pwc config (default: in/pwc_config.txt)
  -k, --kernel_num N        SOCS kernel count (default: 30)
  -j, --max_jobs N          make_socs parallel jobs (default: 16)
  -q, --queue NAME          LSF queue (default: OPCALL)
      --m3d                 enable M3D (default: off)
      --mask_kikaku NAME    M3D mask spec (default: 4kikaku)
      --half                use --socs_skip_y_gt_x (D2 symmetry, ~half size)
  -h, --help                show this help
EOF
}

# ===== Parse args =====
if [ $# -lt 2 ]; then usage; exit 1; fi
NA_VAL="$1"; shift
OUT_DIR="$1"; shift

while [ $# -gt 0 ]; do
    case "$1" in
        -i|--ini-template) INI_TEMPLATE="$2"; shift 2;;
        -s|--source)       SOURCE_CONFIG="$2"; shift 2;;
        -p|--pwc)          PWC_CONFIG="$2"; shift 2;;
        -k|--kernel_num)   KERNEL_NUM="$2"; shift 2;;
        -j|--max_jobs)     MAX_JOBS="$2"; shift 2;;
        -q|--queue)        QUEUE="$2"; shift 2;;
        --m3d)             M3D=1; shift;;
        --mask_kikaku)     MASK_KIKAKU="$2"; shift 2;;
        --half)            USE_HALF=1; shift;;
        -h|--help)         usage; exit 0;;
        *) echo "ERROR: unknown option: $1" >&2; usage; exit 1;;
    esac
done

# ===== Validate =====
for f in "$INI_TEMPLATE" "$SOURCE_CONFIG" "$PWC_CONFIG" "$MAKE_SOCS"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: required file not found: $f" >&2
        exit 1
    fi
done

# ===== Clean & generate ini =====
echo "[make_socs_one] NA=$NA_VAL  output=$OUT_DIR"
echo "[make_socs_one] cleaning previous state..."
rm -rf "$OUT_DIR" "${OUT_DIR}.tar.xz" "${OUT_DIR}.tar.xz.ready"
mkdir -p "$OUT_DIR"

INI_FILE="$OUT_DIR/.ini.txt"
sed "s/^NA .*/NA ${NA_VAL}/" "$INI_TEMPLATE" > "$INI_FILE"
echo "[make_socs_one] ini generated: $INI_FILE"

# ===== Build option flags =====
M3D_OPTS=""
[ "$M3D" = "1" ] && M3D_OPTS="--m3d --mask_kikaku $MASK_KIKAKU"

HALF_OPTS=""
[ "$USE_HALF" = "1" ] && HALF_OPTS="--socs_skip_y_gt_x"

# ===== Run make_socs_set_v2.py =====
echo "[make_socs_one] launching make_socs_set_v2.py (queue=$QUEUE, kernel=$KERNEL_NUM)..."
T0=$(date +%s)
if ! python3 "$MAKE_SOCS" \
        --source "$SOURCE_CONFIG" \
        --pwc "$PWC_CONFIG" \
        --ini "$INI_FILE" \
        -o "$OUT_DIR" \
        --kernel_num "$KERNEL_NUM" \
        -j 1 \
        -q "$QUEUE" \
        --parallel \
        --max_jobs "$MAX_JOBS" \
        $M3D_OPTS \
        $HALF_OPTS \
        --debug; then
    echo "[make_socs_one] ERROR: make_socs_set_v2.py failed" >&2
    rm -rf "$OUT_DIR"
    exit 1
fi

# ===== Mark ready =====
: > "$OUT_DIR/.ready"
ELAPSED=$(( $(date +%s) - T0 ))
echo "[make_socs_one] DONE in ${ELAPSED}s : $OUT_DIR (.ready marker created)"
