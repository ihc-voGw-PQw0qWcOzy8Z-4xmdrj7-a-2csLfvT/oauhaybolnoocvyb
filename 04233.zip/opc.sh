#!/bin/bash
#
# smo_lib/opc.sh - MSOCS generation + OPC run
#

# MSOCS generation
run_make_msocs() {
    local illum_file="$1"
    local ini_file="$2"
    local na_val="$3"
    local output_msocs="$4"

    log_info "  [MSOCS] generate: illum=$illum_file, ini=$ini_file, NA=$na_val -> $output_msocs"
    mkdir -p "$output_msocs"

    # 3番目の位置引数は「ファイル接頭辞(prefix)」で、
    # ツールが <prefix>.socs / <prefix>.log/ などを sibling として生成する。
    # prefix を絶対パスにするとパス長の都合でツールが正常動作しないため、
    # 出力ディレクトリに cd してから相対 prefix を渡す。
    # illum / ini は絶対パスで渡されている前提。
    if [ "$M3D_OPC" = "1" ]; then
        (
            cd "$output_msocs"
            "$MAKETCC_M3DMTCC3" \
                -n 8 \
                -o 16 \
                -q OPCALL \
                -s "$illum_file" "$ini_file" "srcOptim.msocs" "$CGRP"
        )
    else
        (
            cd "$output_msocs"
            "$MAKETCC_MTCC3" \
                -n 8 \
                -o 16 \
                -q OPCALL \
                -s "$illum_file" "$ini_file" "srcOptim.msocs"
        )
    fi
}

# OPC run
# Copy the template dir, patch M3D on/off + layout name, drop MSOCS in place, then execute
run_opc() {
    local msocs_dir="$1"
    local layout_out="$2"
    local loop="$3"

    local opc_dir="$OPC_WORK_DIR/$LAYOUT_ORG_NAME_DASH"
    local try_dir="$opc_dir/try_${loop}"
    local template_src="$OPC_WORK_DIR/org/mytry"
    local opc_output="$try_dir/tko_sub_dir1/tk_lcc.oas"

    # 既存の try_dir + 出力ファイルがあれば run.csh をスキップして結果だけ使う
    if [ -d "$try_dir" ] && [ -f "$opc_output" ]; then
        log_info "  [OPC] cache hit: $opc_output already exists -> skip ./run.csh"
        log_info "  [OPC] output: $opc_output -> $layout_out"
        cp "$opc_output" "$layout_out"
        return 0
    fi

    # try_dir はあるが出力ファイルが無い → 中途半端な状態。掃除して作り直す。
    if [ -d "$try_dir" ]; then
        log_info "  [OPC] WARNING: try_dir exists but output is missing, removing: $try_dir"
        rm -rf "$try_dir"
    fi

    log_info "  [OPC] copy template: $template_src -> $try_dir"
    mkdir -p "$opc_dir"
    cp -r "$template_src" "$try_dir"

    # M3D on/off の切り替え
    if [ "$M3D_OPC" = "1" ]; then
        log_info "  [OPC] enable M3D in $try_dir"
        find "$try_dir" -type f -exec sed -i 's/M3D off/M3D on/g' {} \;
    else
        log_info "  [OPC] disable M3D in $try_dir"
        find "$try_dir" -type f -exec sed -i 's/M3D on/M3D off/g' {} \;
    fi

    # レイアウト文字列置換 (hoge.gds -> $LAYOUT_ORG_NAME)
    # LAYOUT_ORG_NAME にスラッシュが含まれる可能性があるため sed 区切り文字は | を使う
    log_info "  [OPC] replace layout: hoge.gds -> $LAYOUT_ORG_NAME"
    find "$try_dir" -type f -exec sed -i "s|hoge.gds|$LAYOUT_ORG_NAME|g" {} \;

    # MSOCS コピー (単一ファイル srcOptim.msocs)
    log_info "  [OPC] copy MSOCS: $msocs_dir/srcOptim.msocs -> $try_dir/TCC/srcOptim.msocs"
    cp "$msocs_dir/srcOptim.msocs" "$try_dir/TCC/srcOptim.msocs"

    # OPC 実行 (OPC_MODE で分岐)
    case "${OPC_MODE:-wait}" in
        wait)   _run_opc_wait "$try_dir" "$opc_output" "$layout_out" ;;
        kill)   _run_opc_poll "$try_dir" "$opc_output" "$layout_out" "kill" ;;
        detach) _run_opc_poll "$try_dir" "$opc_output" "$layout_out" "detach" ;;
        *)
            echo "  ERROR: unknown OPC_MODE: '$OPC_MODE' (valid: wait|kill|detach)" >&2
            return 1
            ;;
    esac
}

# OPC 実行: wait モード
# ./run.csh の終了を待ち、その後で出力ファイルを確認する。
# ./run.csh が非0終了しても即停止せず、出力ファイルがあれば続行する。
_run_opc_wait() {
    local try_dir="$1"
    local opc_output="$2"
    local layout_out="$3"

    log_info "  [OPC] mode=wait: cd $try_dir && ./run.csh"
    local run_csh_status=0
    (
        cd "$try_dir"
        ./run.csh
    ) || run_csh_status=$?

    if [ "$run_csh_status" -ne 0 ]; then
        log_info "  [OPC] WARNING: ./run.csh exited with status $run_csh_status"
        log_info "  [OPC] checking output file regardless..."
    fi

    if [ ! -f "$opc_output" ]; then
        echo "  ERROR: OPC output not found: $opc_output" >&2
        if [ "$run_csh_status" -ne 0 ]; then
            echo "  (./run.csh failed with status $run_csh_status and produced no output)" >&2
        fi
        return 1
    fi

    if [ "$run_csh_status" -ne 0 ]; then
        log_info "  [OPC] output file exists despite ./run.csh failure -> continuing"
    fi

    log_info "  [OPC] output: $opc_output -> $layout_out"
    cp "$opc_output" "$layout_out"
}

# OPC 実行: kill / detach モード
# ./run.csh をバックグラウンド起動し、出力ファイルの出現をポーリング。
# 出現したら kill (process tree ごと止める) または detach (放置) して次へ進む。
_run_opc_poll() {
    local try_dir="$1"
    local opc_output="$2"
    local layout_out="$3"
    local mode="$4"  # kill or detach

    local poll_interval="${OPC_POLL_INTERVAL:-5}"
    local poll_timeout="${OPC_POLL_TIMEOUT:-7200}"

    log_info "  [OPC] mode=$mode: cd $try_dir && ./run.csh & (background)"
    # exec で subshell を ./run.csh 自身に置換 → $! が ./run.csh の pid を指す
    (
        cd "$try_dir"
        exec ./run.csh
    ) &
    local run_pid=$!

    log_info "  [OPC] background pid=$run_pid, polling output (interval=${poll_interval}s, timeout=${poll_timeout}s)"

    local elapsed=0
    while true; do
        if [ -f "$opc_output" ]; then
            log_info "  [OPC] output appeared after ${elapsed}s: $opc_output"
            break
        fi
        # ./run.csh がファイル出現前に終わった場合
        if ! kill -0 "$run_pid" 2>/dev/null; then
            wait "$run_pid" 2>/dev/null
            local run_csh_status=$?
            log_info "  [OPC] ./run.csh exited (status=$run_csh_status) before output appeared"
            if [ -f "$opc_output" ]; then
                break
            fi
            echo "  ERROR: OPC output not found and ./run.csh has exited" >&2
            return 1
        fi
        sleep "$poll_interval"
        elapsed=$((elapsed + poll_interval))
        if [ "$elapsed" -ge "$poll_timeout" ]; then
            echo "  ERROR: timeout (${poll_timeout}s) waiting for OPC output: $opc_output" >&2
            pkill -P "$run_pid" 2>/dev/null || true
            kill "$run_pid" 2>/dev/null || true
            return 1
        fi
    done

    if [ "$mode" = "kill" ]; then
        if kill -0 "$run_pid" 2>/dev/null; then
            log_info "  [OPC] killing ./run.csh (pid=$run_pid) and its children"
            pkill -P "$run_pid" 2>/dev/null || true
            kill "$run_pid" 2>/dev/null || true
            wait "$run_pid" 2>/dev/null || true
        fi
    else
        # detach: バックグラウンドで放置。disown で SMO 終了時の SIGHUP も抑制。
        if kill -0 "$run_pid" 2>/dev/null; then
            log_info "  [OPC] leaving ./run.csh (pid=$run_pid) running in background"
            disown "$run_pid" 2>/dev/null || true
        fi
    fi

    log_info "  [OPC] output: $opc_output -> $layout_out"
    cp "$opc_output" "$layout_out"
}
