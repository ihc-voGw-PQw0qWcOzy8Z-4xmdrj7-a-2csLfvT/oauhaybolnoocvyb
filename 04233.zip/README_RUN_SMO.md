# run_smo.sh - SMO (Source-Mask Optimization) ドライバ

光源最適化 (Source Optimization) と OPC (Optical Proximity Correction) を交互に反復し、各サイクルで NA を三分探索で選定する SMO のメインドライバスクリプト。

---

## 1. 構成

```
test/tmp0128/
├── run_smo.sh                ← 本スクリプト
├── smo_lib/                  ← 内部ライブラリ
│   ├── setup.sh              ← 既定値、入力ファイル、ツールパス、ディレクトリ
│   ├── helpers.sh            ← ユーティリティ (banner, log_info, generate_ini など)
│   ├── srcoptim.sh           ← SOCS 生成 / srcOptim 実行 (LSF bsub)
│   ├── opc.sh                ← MSOCS 生成 / OPC 実行
│   └── na_search.sh          ← NA 三分探索 (evaluate_na, search_optimal_na)
└── README_RUN_SMO.md         ← この文書
```

各ライブラリは `run_smo.sh` 内で `source` され、関数群と既定値を提供する。

---

## 2. 処理フロー

```
[初期化]
  ├─ プリパース (--config だけ先に拾う)
  ├─ setup.sh を source
  ├─ --config が指定されていればそれを source して上書き
  ├─ 他ライブラリを source
  ├─ CLI 本パース
  ├─ 派生変数 (LAYOUT_ORIGINAL, LAYOUT_ORG_NAME_DASH, LAYOUT_WORK_DIR) を再計算
  └─ OPC_MODE 妥当性チェック

[メインループ] for cycle in 1..NUM_CYCLES
  ├─ LAYOUT_LAYER を切替 (cycle=1 → LAYOUT_LAYER_INI, それ以外 → LAYOUT_LAYER)
  │
  ├─ Step 1: NA 三分探索 + ソース最適化
  │     search_optimal_na がレンジ [NA_MIN, NA_MAX] で内部点を評価
  │     各 NA で evaluate_na (ini 生成 → SOCS 生成 → srcOptim) を実行
  │     最良 NA で optimized_source.illum と final_cost を確定
  │
  ├─ Step 2: MSOCS 生成
  │     blur が設定されていれば生成、そうでなければ optimized_source をそのまま使用
  │     run_make_msocs (M2D = maketcc_mtcc3.py / M3D = maketcc_m3dmtcc3) を呼ぶ
  │
  ├─ Step 3: OPC 実行
  │     run_opc (テンプレートコピー → sed 置換 → MSOCS 配置 → ./run.csh)
  │
  └─ smo_log.csv に [cycle,na,cost,illum,opc_layout] を追記
     CURRENT_LAYOUT を OPC 出力に、CURRENT_SOURCE を最適化結果に更新

[終了]
  smo_log.csv 全行を表示
```

---

## 3. CLI オプション

```
./run_smo.sh [options]
```

### 基本

| オプション | 既定値 | 説明 |
|-----------|--------|------|
| `--num_cycles <N>` | 3 | SO/OPC の反復回数 |
| `--na_min <val>` | 1.0 | NA 探索下限 |
| `--na_max <val>` | 1.35 | NA 探索上限 |
| `--na_tol <val>` | 0.05 | NA 収束判定 (range ≤ tol で打ち切り) |
| `--na_precision <val>` | 0.01 | NA 値を丸めるグリッド幅 |
| `--max_iter <N>` | 16 | srcOptim の最大反復回数 |
| `--gradient_method <N>` | 2 | srcOptim の勾配計算手法 |
| `--optimizer <str>` | lbfgs | srcOptim のオプティマイザ (`lbfgs`, `adam` など) |
| `-j <N>` | 8 | OpenMP スレッド数 |
| `--np <N>` | 2 | MPI ランク数 |
| `--kernel_num <N>` | 100 | SOCS のカーネル数 |

### M3D 関連

| オプション | 既定値 | 説明 |
|-----------|--------|------|
| `--m3d_so` | (off) | ソース最適化を M3D モードで実行 (`make_socs_set_v2.py` に `--m3d` を渡す) |
| `--m3d_opc` | (off) | OPC を M3D モードで実行 (MSOCS 生成に `maketcc_m3dmtcc3` を使う) |
| `--cgrp <file>` | "" | coherent-group ファイル (M3D_OPC のとき必須) |
| `--mask_kikaku <str>` | 4kikaku | マスク仕様 (M3D 時の引数) |

### レイアウト・評価点

| オプション | 既定値 | 説明 |
|-----------|--------|------|
| `--layout_org_dir <d>` | `/home/hoge/Layout` | レイアウトの基底ディレクトリ |
| `--layout_org_name <n>` | `AAA/BBB.gds` | 基底からの相対パス (`<DIR>/<NAME>` がフルパス) |
| `--evp <file>` | `in/evp_0_6.csv` | 評価点 CSV |

### OPC 実行モード

| オプション | 既定値 | 説明 |
|-----------|--------|------|
| `--opc_mode <m>` | wait | `wait` / `kill` / `detach` (詳細は §10) |

### 設定ファイル

| オプション | 既定値 | 説明 |
|-----------|--------|------|
| `--config <file>` | (なし) | `setup.sh` を source した後に追加で source される上書きファイル |

---

## 4. 設定の優先順位

```
setup.sh の既定値
       ↓
--config で指定したファイル (任意のシェルスクリプト)
       ↓
CLI オプション (--num_cycles, --layout_org_name など)
       ↓
[最後に派生変数 (LAYOUT_ORIGINAL, LAYOUT_ORG_NAME_DASH, LAYOUT_WORK_DIR) を計算]
```

`--config` には**変えたい変数だけ**書けばよい。例:

```bash
# my_proj.cfg
LAYOUT_ORG_NAME="proj_X/target.gds"
EVP="$SCRIPT_DIR/in/evp_proj_X.csv"
NA_MIN=1.05
NA_MAX=1.40
KERNEL_NUM=128
OPC_MODE="detach"
```

```bash
./run_smo.sh --config ./my_proj.cfg
./run_smo.sh --config ./my_proj.cfg --num_cycles 5    # CLI で更に上書き
```

派生変数 (`LAYOUT_ORIGINAL` など) は CLI パース後に必ず再計算されるので、`--config` 側に書く必要はない。

---

## 5. ディレクトリ構造

### 出力 (smo_work)

```
smo_work/                                   ← WORK_DIR
├── socs_cache/                             ← SOCS_CACHE_DIR (レイアウト・cycle 横断)
│   └── na_<X.XXXXXX>/
│       ├── ini.txt                         ← キャッシュ用 ini (NA だけに依存)
│       ├── socs_set/                       ← make_socs_set_v2.py の出力一式
│       │   ├── <sourceID>.illum
│       │   ├── <sourceID>_<defocus>.socs   (M2D=ファイル / M3D=ディレクトリ)
│       │   └── debug_info.txt
│       └── lock/                           ← 生成中だけ存在 (排他制御)
└── <LAYOUT_ORG_NAME_DASH>/                 ← LAYOUT_WORK_DIR (レイアウト別)
    ├── smo_log.csv                         ← cycle ごとの結果サマリ
    └── cycle<N>/
        ├── na_<X.XXXXXX>/                  ← cycle 内で評価された各 NA
        │   ├── ini.txt
        │   ├── optimized_source.illum
        │   ├── cost.csv
        │   ├── log.csv
        │   └── final_cost.txt
        ├── msocs/
        │   └── srcOptim.msocs              ← maketcc 系の出力 (prefix 固定)
        ├── optimized_source_blurred.illum  ← src_blur 設定時のみ
        └── opc_output.oas                  ← OPC 結果のコピー
```

### OPC 実行ディレクトリ (smo_work の外)

```
$OPC_WORK_DIR/                              ← 既定: /home/opchoge
├── org/mytry/                              ← OPC テンプレート (固定パス)
└── <LAYOUT_ORG_NAME_DASH>/
    └── try_<cycle>/                        ← run_opc が cycle ごとに作成
        ├── ... (テンプレートからコピー、sed 置換済み)
        ├── TCC/srcOptim.msocs              ← MSOCS をここにコピー
        └── tko_sub_dir1/tk_lcc.oas         ← OPC 出力 (smo_work 側にもコピー)
```

---

## 6. M3D モードの扱い

M3D には 2 つの独立フラグがある:

| フラグ | 影響範囲 | 結果 |
|--------|----------|------|
| `M3D_SO=1` (`--m3d_so`) | ソース最適化の SOCS 生成 | `make_socs_set_v2.py --m3d --mask_kikaku <K>` |
| `M3D_OPC=1` (`--m3d_opc`) | MSOCS 生成 + OPC | MSOCS は `maketcc_m3dmtcc3` で生成。OPC テンプレートに `sed 's/M3D off/M3D on/g'` を適用 |

`M3D_OPC=1` のとき:
- `CGRP` 変数が `maketcc_m3dmtcc3 ... <CGRP>` に渡される
- 空のままだと失敗する

`MASK_KIKAKU` は M3D_SO / M3D_OPC のどちらかが有効なら参照される。

---

## 7. NA 三分探索の挙動

### アルゴリズム

`smo_lib/na_search.sh` の `search_optimal_na` が `[NA_MIN, NA_MAX]` をレンジとして三分探索する:

```
m1 = lo + (hi - lo) / 3
m2 = hi - (hi - lo) / 3
両方とも NA_PRECISION のグリッドに丸める
cost(m1), cost(m2) を比較し、悪い側を捨てて狭める
range <= NA_TOL または m1 == m2 で打ち切り
best_na = round((lo + hi) / 2)
```

### 評価される NA の範囲

**境界 `NA_MIN` / `NA_MAX` 自体は決して評価されない**。三分探索は内部点 `m1`, `m2` だけを試すため。

実質的に評価されるのは概ね:
- 最大値: `NA_MAX - NA_PRECISION`
- 最小値: `NA_MIN + NA_PRECISION`

### 真の最良値が境界付近のとき

例: `NA_MIN=1.0, NA_MAX=1.35, NA_PRECISION=0.05` で真の最良が `1.35` の場合、`1.30` で止まる。

**回避策**: `NA_MAX` を 1 グリッド広く取る (例: `NA_MAX=1.40`) と `1.35` が評価される。

---

## 8. SOCS キャッシュとロック

### キャッシュキー

NA のみ。`source_config` / `pwc_config` を変えてもキャッシュは再利用されてしまうので、それらを変更したら手動で破棄すること。

```bash
rm -rf smo_work/socs_cache
```

### 排他制御 (mkdir ベース)

```
[キャッシュ確認]
  socs_set/ がある? → そのまま使う (cache hit)
                   → なければ次へ

[ロック取得]
  mkdir lock/ → 成功 (自分が生成担当)
            → 失敗 (他プロセスが生成中、待機)

[生成]
  ini.txt を書き出し
  run_make_socs (make_socs_set_v2.py) を呼ぶ
  失敗時: socs_set/ と lock/ を削除して return 1
  成功時: rmdir lock/

[待機側]
  lock/ が消えるまで OPC_POLL_INTERVAL ごとにポーリング
  上限 OPC_POLL_TIMEOUT で諦める (ただし SOCS 用ではなく ※下記参照)
```

※ SOCS キャッシュのポーリング設定は別: `na_search.sh` 内に固定値 `sleep 10`、上限 7200 秒 (2 時間)。

### ロック残留時の対処

プロセスが強制終了 (kill -9 等) すると `lock/` が残り、待機側が 2 時間ハングする。手動で削除:

```bash
rm -rf smo_work/socs_cache/na_*/lock
```

---

## 9. OPC 実行 (run_opc)

### 処理手順 (1 cycle 分)

1. **キャッシュチェック**: `try_<cycle>/` と `tko_sub_dir1/tk_lcc.oas` 両方あれば `./run.csh` をスキップして既存結果を使う
2. **不完全状態の掃除**: `try_<cycle>/` だけあって出力が無ければ `try_<cycle>/` を削除
3. **テンプレートコピー**: `$OPC_WORK_DIR/org/mytry` → `$OPC_WORK_DIR/$LAYOUT_ORG_NAME_DASH/try_<cycle>`
4. **M3D on/off の sed 置換**: `M3D_OPC=1` なら `M3D off` → `M3D on`、それ以外なら逆
5. **レイアウト名置換**: `hoge.gds` → `$LAYOUT_ORG_NAME` (sed 区切りは `|`)
6. **MSOCS コピー**: `<msocs_dir>/srcOptim.msocs` → `try_<cycle>/TCC/srcOptim.msocs`
7. **`./run.csh` 実行**: モード別 (§10)
8. **結果コピー**: `try_<cycle>/tko_sub_dir1/tk_lcc.oas` → `$CYCLE_DIR/opc_output.oas`

### 注意

- step 4-5 の `sed -i` は `try_<cycle>/` 配下の **全ファイル**に適用される。テンプレートにバイナリが含まれる場合は壊れる
- step 5 の `hoge.gds` はテンプレート内のプレースホルダ。固定文字列で扱う

---

## 10. OPC_MODE (3 モード)

`./run.csh` の扱いを切り替えられる。

| モード | `./run.csh` の挙動 | 出力検知 | 用途 |
|--------|-------------------|---------|------|
| `wait` (既定) | 終了まで待機 | 終了後に確認 | 安定運用 |
| `kill` | バックグラウンド起動 → 出力出現で kill (子プロセスごと) | ポーリング | 後処理不要・即進めたい |
| `detach` | バックグラウンド起動 → 出力出現で disown して放置 | ポーリング | run.csh を完走させる/並列累積 OK |

### 共通仕様

`./run.csh` が非 0 終了しても**出力ファイル `tk_lcc.oas` が存在すれば続行**する。失敗かつ出力なしのときだけエラー停止。

### kill / detach 時のポーリング設定

```bash
OPC_POLL_INTERVAL=5      # 既定 5 秒間隔
OPC_POLL_TIMEOUT=7200    # 既定 2 時間で諦める
```

### 注意

- **出力ファイルの完全性**: 出現直後にコピーする。`tk_lcc.oas` が atomic に書き出される前提。書き込み途中の壊れたファイルを掴むリスクがある
- **detach モードの累積**: cycle ごとに `./run.csh` プロセスが残るので、リソース消費に注意
- **kill モードの後処理**: `./run.csh` 内の後始末 (クリーンアップ・ログ書き出し) が飛ぶ可能性

---

## 11. LAYOUT_LAYER の切り替え

cycle ごとにレイヤ指定を変えられる:

| cycle | 使われる変数 | 既定値 |
|-------|-------------|--------|
| 1 | `LAYOUT_LAYER_INI` | `2/1,60/0` |
| 2..N | `LAYOUT_LAYER` | `0/0,60/0` |

1 ループ目は元レイアウト (GDS) のレイヤ、2 ループ目以降は OPC 出力のレイヤを使う想定。

---

## 12. 並行実行 (複数レイアウト)

同じ `smo_work/` を共有しつつ、レイアウト別の出力ディレクトリで並行実行できる:

```bash
./run_smo.sh --layout_org_name "AAA/BBB.gds" --evp "in/evp_BBB.csv" &
./run_smo.sh --layout_org_name "AAA/CCC.gds" --evp "in/evp_CCC.csv" &
wait
```

- 出力は `smo_work/BBB/` と `smo_work/CCC/` に分かれる
- 同じ NA は SOCS キャッシュを共有するため重複計算は走らない
- 同 NA に同時ヒットした場合、後発プロセスは lock/ を見て待機

---

## 13. 使用例

### 標準実行

```bash
./run_smo.sh
```

### NA レンジを変更

```bash
./run_smo.sh --na_min 1.05 --na_max 1.40 --na_tol 0.02
```

### M3D で実行 (SO 側だけ)

```bash
./run_smo.sh --m3d_so
```

### M3D で実行 (OPC も)

```bash
./run_smo.sh --m3d_so --m3d_opc --cgrp /path/to/cgrp.txt
```

### OPC を出力即進める (kill モード)

```bash
./run_smo.sh --opc_mode kill
```

### config ファイルでまとめて指定

```bash
cat > my_proj.cfg <<EOF
LAYOUT_ORG_NAME="proj_X/target.gds"
EVP="\$SCRIPT_DIR/in/evp_proj_X.csv"
NA_MIN=1.05
NA_MAX=1.40
OPC_MODE="detach"
EOF

./run_smo.sh --config my_proj.cfg
```

### 複数レイアウト並行

```bash
./run_smo.sh --config configs/proj_A.cfg &
./run_smo.sh --config configs/proj_B.cfg &
./run_smo.sh --config configs/proj_C.cfg &
wait
```

---

## 14. smo_log.csv のフォーマット

```csv
cycle,na,cost,illum,opc_layout
1,1.250000,0.0234,/path/to/optimized_source.illum,/path/to/opc_output.oas
2,1.300000,0.0189,...
3,1.300000,0.0162,...
```

各 cycle の Step 3 (OPC) 完了後に 1 行追記される。途中で OPC 等が失敗すると、その cycle の行は書かれない。

---

## 15. 失敗時の挙動

`run_smo.sh` 冒頭の `set -e` により、以下の場合スクリプトは即停止する:

| 失敗箇所 | 結果 |
|---------|------|
| SOCS 生成失敗 | キャッシュをクリーンアップ後に停止 |
| srcOptim 失敗 (bsub job EXIT) | 停止 |
| MSOCS 生成失敗 | 停止 |
| OPC: `./run.csh` 失敗 + 出力なし | 停止 |
| OPC: `./run.csh` 失敗 + 出力あり | **続行** (warning ログのみ) |
| 不正な `OPC_MODE` 値 | 起動時に exit 1 |

`smo_log.csv` には**成功した cycle の行だけ**が残る (ヘッダー行は初期化時に必ず書かれる)。

---

## 16. 既知の制約

| 制約 | 備考 |
|------|------|
| NA 端点 `NA_MIN` / `NA_MAX` は評価されない | `NA_MAX` を 1 グリッド広く取る |
| SOCS キャッシュキーは NA のみ | `source_config` / `pwc_config` を変えたら手動で `socs_cache/` を削除 |
| SOCS ロック残留 | 強制終了時は `socs_cache/na_*/lock` を手動削除 |
| OPC テンプレート全ファイルに sed -i | バイナリファイルが含まれていると壊れる |
| OPC キャッシュは出力ファイル有無のみ判定 | NA や MSOCS が変わっていても古い結果を使い回す。意図的に再実行したい場合は `try_<cycle>/` を手動削除 |
| `tk_lcc.oas` の atomic 書き出し前提 | kill / detach モードで書き込み途中のファイルを掴むリスクあり |
| LSF (`bsub`) 前提 | srcOptim と (M3D の) MSOCS は LSF キューに投入される |

---

## 17. 主要パスの参照表

| 変数 | 既定値 | 用途 |
|------|--------|------|
| `WORK_DIR` | `$SCRIPT_DIR/smo_work` | smo 全体の作業ディレクトリ |
| `SOCS_CACHE_DIR` | `$WORK_DIR/socs_cache` | SOCS キャッシュ |
| `LAYOUT_WORK_DIR` | `$WORK_DIR/$LAYOUT_ORG_NAME_DASH` | レイアウト別作業ディレクトリ |
| `OPC_WORK_DIR` | `/home/opchoge` | OPC 実行の親ディレクトリ |
| `LAYOUT_ORG_DIR` | `/home/hoge/Layout` | レイアウト基底ディレクトリ |
| `LAYOUT_ORG_NAME` | `AAA/BBB.gds` | レイアウト相対パス |
| `LAYOUT_ORIGINAL` | `$LAYOUT_ORG_DIR/$LAYOUT_ORG_NAME` | レイアウトフルパス (派生) |
| `LAYOUT_ORG_NAME_DASH` | `BBB` | LAYOUT_ORG_NAME のファイル名 (拡張子なし、派生) |
| `EVP` | `$SCRIPT_DIR/in/evp_0_6.csv` | 評価点 CSV |
| `INI_TEMPLATE` | `$SCRIPT_DIR/in/ini.txt` | NA を埋め込むテンプレート ini |
| `SOURCE_CONFIG` | `$SCRIPT_DIR/in/source_config_32.txt` | 光源コンフィグ |
| `PWC_CONFIG` | `$SCRIPT_DIR/in/pwc_config.txt` | PWC コンフィグ |
| `INITIAL_SOURCE` | `$SCRIPT_DIR/in/initial_source.illum` | 初回ソース最適化の入力 illum |

---

## 18. 関連ツール

| ツール | パス | 用途 |
|--------|------|------|
| `srcOptim` | `$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim` | ソース最適化本体 (LSF 経由) |
| `make_socs_set_v2.py` | `$PROJECT_ROOT/mkSocsSet/make_socs_set_v2.py` | SOCS 生成 |
| `blur_illum.py` | `$PROJECT_ROOT/mkSocsSet/blur_illum.py` | illum のぼかし (src_blur 設定時) |
| `maketcc_mtcc3.py` | (PATH 経由) | M2D 用 MSOCS 生成 |
| `maketcc_m3dmtcc3` | (PATH 経由) | M3D 用 MSOCS 生成 |
