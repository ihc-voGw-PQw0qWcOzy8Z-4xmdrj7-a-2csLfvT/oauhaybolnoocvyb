#!/bin/csh -f
#
# tko_template/run.csh - Vishamon を介さない OPC エントリ
#
# - tko_sub_dir1/tko_job_main.csh_pre を直接実行する。
# - 入力 OAS は run_smo.sh により flow01_in.param.tkl の Oasis 行が
#   絶対パスに書き換えられている前提（このディレクトリ配下にコピーは置かない）。
# - MSOCS は flow*_in.param.* の socs 行が絶対パスに書き換えられている前提。
# - 出力は ./tko_sub_dir1/tk_opc.oas (run_smo.sh が回収する)。
#

setenv RULESPLIT_RUNVER 1.0.0
setenv TK_OMP_QUEUE OPCALL
setenv TK_OMP_NUM_THREADS 32
setenv TK_OMP_NUM_HOSTS 1

# 浮動小数点再現性
setenv MKL_CBWR AVX

### 共通環境 (calibre / lavis / fvexa の PATH 等)
source /tools/mdp/vishamon/setup_vis_latest.csh
setenv FILTERVIS /tools/mdp/fvexa/5.14.2
set path = ($FILTERVIS $path)

### Calibre (flow07_sraf_mod / flow08_mrc_mod)
setenv SCSDIR /tools/calibre/calibre_home
setenv MGC_HOME $SCSDIR
setenv MGLS_HOME $SCSDIR
source /tools/calibre/setup_mgclic.csh
setenv MGC_TMPDIR .
setenv MGC_CGI A
set SCSPATH = ( $SCSDIR/bin $SCSDIR/pkgs/icv/bin )
set path = ( $SCSPATH $path )

### Python3
setenv PATH "/tools/open_source/miniconda/miniconda3_rhel7/envs/py39_latest_v2/bin:$PATH"

### lavis (lvoasishand: flow06 / flow13)
source /tools/mdp/TOOL/.lavis_env

setenv TOPV_FORCE_SKIP

# ==========================================
# OPC 実行 (flow01〜flow12 を順次)
# ==========================================
echo "=== run.csh start ===" `/bin/date`

./tko_sub_dir1/tko_job_main.csh_pre
set st = $status
if ($st != 0) then
    echo "ERROR: tko_job_main.csh_pre exited with status $st"
    exit $st
endif

echo "=== run.csh end ===" `/bin/date`
exit 0
