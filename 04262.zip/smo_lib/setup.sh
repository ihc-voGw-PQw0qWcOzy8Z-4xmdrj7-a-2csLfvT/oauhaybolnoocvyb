#!/bin/bash
#
# smo_lib/setup.sh - defaults, input files, tool paths
#

# ========== Defaults ==========
NUM_CYCLES=2
NA_MIN=1.2
NA_MAX=1.3
NA_TOL=0.05
NA_PRECISION=0.05
MAX_ITER=8
GRADIENT_METHOD=2
OPTIMIZER="lbfgs"
OPENMP_NUM=16
MPI_NP=1
KERNEL_NUM=30
M3D_SO=0
M3D_OPC=0
CGRP=""
MASK_KIKAKU="4kikaku"

# TKO 収束パラメータ (cycle 1 とそれ以降を分けて指定可)
# 空文字なら tko_template 側の既定値 (Optimizer.info: MaxEpoch 500、
# flow03_in.param.tko_pre / flow10_in.param.tko: ConvergenceCriterion 0.0002) を維持する。
# 注意: flow11/12 の tkv 系 ConvergenceCriterion は対象外（変更しない）。
TKO_MAX_EPOCH_INI=""        # cycle 1 の Optimizer.info MaxEpoch を上書き
TKO_MAX_EPOCH=""            # cycle 2+ の Optimizer.info MaxEpoch を上書き
TKO_CONV_INI=""             # cycle 1 の flow*.tko / flow*.tko_pre ConvergenceCriterion を上書き
TKO_CONV=""                 # cycle 2+ の同 ConvergenceCriterion を上書き

# ========== Input files ==========
SOURCE_CONFIG="$SCRIPT_DIR/in/source_config.txt"
PWC_CONFIG="$SCRIPT_DIR/in/pwc_config.txt"
INITIAL_SOURCE="$SCRIPT_DIR/in/initial_source.illum"
EVP="$SCRIPT_DIR/Layout/arrayPitch/ah_ax5000_ay5000_mx64_my64_rx64_ry64_cx150_crx75_cry150_ep.csv"

INI_TEMPLATE="$SCRIPT_DIR/in/ini.txt"

# ========== Layout ==========
LAYOUT_ORG_DIR="$SCRIPT_DIR/Layout"
LAYOUT_ORG_NAME="arrayPitch/ah_ax5000_ay5000_mx64_my64_rx64_ry64_cx150_crx75_cry150.gds"
LAYOUT_ORIGINAL="$LAYOUT_ORG_DIR/$LAYOUT_ORG_NAME"
# cycle 1 で no-vis OPC (flow01) の入力に直接渡す OAS ファイル
# 空なら LAYOUT_ORIGINAL の .gds → .oas で導出
LAYOUT_OAS=""
# LAYOUT_ORG_NAME からディレクトリ部分と拡張子を除いた文字列（AAA/BBB.gds -> BBB）
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME##*/}"
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME_DASH%.*}"
# 1ループ目のソース最適化用レイヤ
LAYOUT_LAYER_INI="2/1,60/0"
# 2ループ目以降のソース最適化用レイヤ
LAYOUT_LAYER="1/1,60/0"


# ========== Tools ==========
SRCOPTIM="$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim"
MAKE_SOCS="$PROJECT_ROOT/mkSocsSet/make_socs_set_v2.py"
BLUR_ILLUM="$PROJECT_ROOT/mkSocsSet/blur_illum.py"
MAKETCC_MTCC3="maketcc_mtcc3"
MAKETCC_M3DMTCC3="maketcc_m3dmtcc3"
MAKETCC_CGRP="maketcc_cgrp"

# ========== OPC ==========
# OPC テンプレート (run.csh + tko_sub_dir1/ のみのフラット構成)
# run_smo.sh が cycle ごとに smo_work/<L>/cycle<N>/opc/ にコピーする
OPC_TEMPLATE_DIR="$SCRIPT_DIR/tko_template"
# OPC 実行モード:
#   wait   = ./run.csh の終了を待ってから出力ファイルをチェック (デフォルト)
#   kill   = 出力ファイル出現を検知したら ./run.csh を kill して次へ
#   detach = 出力ファイル出現を検知したら ./run.csh を放置 (バックグラウンド継続) して次へ
OPC_MODE="wait"
# kill/detach モード時の出力ポーリング設定
OPC_POLL_INTERVAL=5
OPC_POLL_TIMEOUT=7200

# ========== Work directory ==========
WORK_DIR="$SCRIPT_DIR/smo_work"
# レイアウト別の作業ディレクトリ（LAYOUT_ORG_NAME_DASH 単位）
LAYOUT_WORK_DIR="$WORK_DIR/$LAYOUT_ORG_NAME_DASH"
# SOCS キャッシュ（レイアウト・cycle 横断、NA のみでキー付け）
SOCS_CACHE_DIR="$WORK_DIR/socs_cache"


