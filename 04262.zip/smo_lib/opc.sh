#!/bin/bash
#
# smo_lib/opc.sh - MSOCS generation + OPC run
#

# MSOCS generation
run_make_msocs() {
    local illum_file="$1"
    local ini_file="$2"
    local na_val="$3"
    local output_msocs="$4"

    log_info "  [MSOCS] generate: illum=$illum_file, ini=$ini_file, NA=$na_val -> $output_msocs"
    mkdir -p "$output_msocs"

    # 3番目の位置引数は「ファイル接頭辞(prefix)」で、
    # ツールが <prefix>.socs / <prefix>.log/ などを sibling として生成する。
    # prefix を絶対パスにするとパス長の都合でツールが正常動作しないため、
    # 出力ディレクトリに cd してから相対 prefix を渡す。
    # illum / ini は絶対パスで渡されている前提。
    if [ "$M3D_OPC" = "1" ]; then
        # CGRP が未指定なら illum から自動生成して使う
        local cgrp_file="$CGRP"
        if [ -z "$cgrp_file" ]; then
            cgrp_file="$output_msocs/srcOptim.cgrp"
            log_info "  [CGRP] auto-generate: $illum_file -> $cgrp_file"
            "$MAKETCC_CGRP" "$illum_file" "$cgrp_file" --x 0.5 --y 0.5 --xy 0.5:0.5
        fi
        (
            cd "$output_msocs"
            "$MAKETCC_M3DMTCC3" \
                -n 1 \
                -o 16 \
                -q OPCALL \
                -s "$illum_file" "$ini_file" "srcOptim.msocs" "$cgrp_file"
        )
    else
        (
            cd "$output_msocs"
            "$MAKETCC_MTCC3" \
                -n 1 \
                -o 16 \
                -q OPCALL \
                -s "$illum_file" "$ini_file" "srcOptim.msocs"
        )
    fi
}

# OPC run (Vishamon を介さない構成)
# テンプレート ($OPC_TEMPLATE_DIR) を cycle ディレクトリ ($cycle_dir/opc/) にコピーし、
# flow01 の入力 OAS と flow*_in.param.* の socs パスを書き換えてから ./run.csh を実行する。
# MSOCS は cycle_dir/msocs/ に既に置かれている前提（cp ではなく直接参照する）。
run_opc() {
    local msocs_dir="$1"
    local layout_out="$2"
    local loop="$3"
    local input_oas="$4"   # flow01 が読む OAS の絶対パス
    local cycle_dir="$5"   # smo_work/<L>/cycle<N>/

    local opc_dir="$cycle_dir/opc"
    local opc_output="$opc_dir/tko_sub_dir1/tk_opc.oas"

    # 既存の opc/ + 出力ファイルがあれば run.csh をスキップして結果だけ使う
    if [ -d "$opc_dir" ] && [ -f "$opc_output" ]; then
        log_info "  [OPC] cache hit: $opc_output already exists -> skip ./run.csh"
        log_info "  [OPC] output: $opc_output -> $layout_out"
        cp "$opc_output" "$layout_out"
        return 0
    fi

    # opc/ はあるが出力ファイルが無い → 中途半端な状態。掃除して作り直す。
    if [ -d "$opc_dir" ]; then
        log_info "  [OPC] WARNING: opc dir exists but output is missing, removing: $opc_dir"
        rm -rf "$opc_dir"
    fi

    # ========== Step 1: テンプレートをコピー ==========
    log_info "  [OPC] copy template: $OPC_TEMPLATE_DIR -> $opc_dir"
    cp -r "$OPC_TEMPLATE_DIR" "$opc_dir"

    # ========== Step 2: M3D on/off の切り替え ==========
    if [ "$M3D_OPC" = "1" ]; then
        log_info "  [OPC] enable M3D in $opc_dir"
        find "$opc_dir/tko_sub_dir1" -type f -name 'flow*' \
            -exec sed -i 's/M3D off/M3D on/g' {} \;
    else
        log_info "  [OPC] disable M3D in $opc_dir"
        find "$opc_dir/tko_sub_dir1" -type f -name 'flow*' \
            -exec sed -i 's/M3D on/M3D off/g' {} \;
    fi

    # ========== Step 3: flow01 入力 OAS パスを書換 ==========
    if [ -z "$input_oas" ]; then
        echo "  ERROR: input_oas (4th arg to run_opc) is empty" >&2
        return 1
    fi
    if [ ! -f "$input_oas" ]; then
        echo "  ERROR: input_oas not found: $input_oas" >&2
        return 1
    fi
    local input_oas_abs
    input_oas_abs=$(readlink -f "$input_oas")
    log_info "  [OPC] set flow01 input OAS: $input_oas_abs"
    sed -i "s|^Oasis .*|Oasis $input_oas_abs|" \
        "$opc_dir/tko_sub_dir1/flow01_in.param.tkl"

    # ========== Step 4: flow*_in.param.* の socs パスを MSOCS 絶対パスに書換 ==========
    local msocs_file="$msocs_dir/srcOptim.msocs"
    if [ ! -f "$msocs_file" ]; then
        echo "  ERROR: MSOCS not found: $msocs_file" >&2
        return 1
    fi
    local msocs_abs
    msocs_abs=$(readlink -f "$msocs_file")
    log_info "  [OPC] set socs path -> $msocs_abs"
    # "socs <path> [index]" の <path> 部分のみ置換 (末尾のインデックス等は保持)
    find "$opc_dir/tko_sub_dir1" -type f -name 'flow*' \
        -exec sed -i "s|^\(socs \)[^ ]*|\1$msocs_abs|" {} \;

    # ========== Step 5: flow10 の sliceLevel スイープ (5 本) を削除 ==========
    # tko_template には PWC 5 変種は同梱しないが、tko_job_main.csh_pre 側に
    # まだ起動行が残っているのでここで削除する (テンプレ側で削っても良い)
    log_info "  [OPC] strip flow10 sliceLevel sweep (keep main only)"
    sed -i '/flow10_in\.param_01[0-9]*\.tko/d' \
        "$opc_dir/tko_sub_dir1/tko_job_main.csh_pre"

    # ========== Step 6: cycle に応じた MaxEpoch / ConvergenceCriterion 上書き ==========
    # cycle 1 は INI 値、cycle 2+ は通常値を使う。空文字ならテンプレ既定を維持。
    local max_epoch_val="" conv_val=""
    if [ "$loop" -eq 1 ]; then
        max_epoch_val="$TKO_MAX_EPOCH_INI"
        conv_val="$TKO_CONV_INI"
    else
        max_epoch_val="$TKO_MAX_EPOCH"
        conv_val="$TKO_CONV"
    fi

    if [ -n "$max_epoch_val" ]; then
        log_info "  [OPC] override MaxEpoch -> $max_epoch_val (Optimizer.info)"
        sed -i "s/^MaxEpoch .*/MaxEpoch $max_epoch_val/" \
            "$opc_dir/tko_sub_dir1/Optimizer.info"
    fi

    if [ -n "$conv_val" ]; then
        log_info "  [OPC] override ConvergenceCriterion -> $conv_val (flow*.tko / *.tko_pre)"
        # flow*.tko と flow*.tko_pre のみ対象 (flow*.tkv 系は触らない)
        find "$opc_dir/tko_sub_dir1" -type f \
            \( -name 'flow*.tko' -o -name 'flow*.tko_pre' \) \
            -exec sed -i "s/^ConvergenceCriterion .*/ConvergenceCriterion $conv_val/" {} \;
    fi

    # ========== Step 7: OPC 実行 ==========
    case "${OPC_MODE:-wait}" in
        wait)   _run_opc_wait "$opc_dir" "$opc_output" "$layout_out" ;;
        kill)   _run_opc_poll "$opc_dir" "$opc_output" "$layout_out" "kill" ;;
        detach) _run_opc_poll "$opc_dir" "$opc_output" "$layout_out" "detach" ;;
        *)
            echo "  ERROR: unknown OPC_MODE: '$OPC_MODE' (valid: wait|kill|detach)" >&2
            return 1
            ;;
    esac
}

# OPC 実行: wait モード
# ./run.csh の終了を待ち、その後で出力ファイルを確認する。
# ./run.csh が非0終了しても即停止せず、出力ファイルがあれば続行する。
_run_opc_wait() {
    local opc_dir="$1"
    local opc_output="$2"
    local layout_out="$3"

    log_info "  [OPC] mode=wait: cd $opc_dir && ./run.csh"
    local run_csh_status=0
    (
        cd "$opc_dir"
        ./run.csh
    ) || run_csh_status=$?

    if [ "$run_csh_status" -ne 0 ]; then
        log_info "  [OPC] WARNING: ./run.csh exited with status $run_csh_status"
        log_info "  [OPC] checking output file regardless..."
    fi

    if [ ! -f "$opc_output" ]; then
        echo "  ERROR: OPC output not found: $opc_output" >&2
        if [ "$run_csh_status" -ne 0 ]; then
            echo "  (./run.csh failed with status $run_csh_status and produced no output)" >&2
        fi
        return 1
    fi

    if [ "$run_csh_status" -ne 0 ]; then
        log_info "  [OPC] output file exists despite ./run.csh failure -> continuing"
    fi

    log_info "  [OPC] output: $opc_output -> $layout_out"
    cp "$opc_output" "$layout_out"
}

# OPC 実行: kill / detach モード
# ./run.csh をバックグラウンド起動し、出力ファイルの出現をポーリング。
# 出現したら kill (process tree ごと止める) または detach (放置) して次へ進む。
_run_opc_poll() {
    local opc_dir="$1"
    local opc_output="$2"
    local layout_out="$3"
    local mode="$4"  # kill or detach

    local poll_interval="${OPC_POLL_INTERVAL:-5}"
    local poll_timeout="${OPC_POLL_TIMEOUT:-7200}"

    log_info "  [OPC] mode=$mode: cd $opc_dir && ./run.csh & (background)"
    # exec で subshell を ./run.csh 自身に置換 → $! が ./run.csh の pid を指す
    (
        cd "$opc_dir"
        exec ./run.csh
    ) &
    local run_pid=$!

    log_info "  [OPC] background pid=$run_pid, polling output (interval=${poll_interval}s, timeout=${poll_timeout}s)"

    local elapsed=0
    while true; do
        if [ -f "$opc_output" ]; then
            log_info "  [OPC] output appeared after ${elapsed}s: $opc_output"
            break
        fi
        # ./run.csh がファイル出現前に終わった場合
        if ! kill -0 "$run_pid" 2>/dev/null; then
            wait "$run_pid" 2>/dev/null
            local run_csh_status=$?
            log_info "  [OPC] ./run.csh exited (status=$run_csh_status) before output appeared"
            if [ -f "$opc_output" ]; then
                break
            fi
            echo "  ERROR: OPC output not found and ./run.csh has exited" >&2
            return 1
        fi
        sleep "$poll_interval"
        elapsed=$((elapsed + poll_interval))
        if [ "$elapsed" -ge "$poll_timeout" ]; then
            echo "  ERROR: timeout (${poll_timeout}s) waiting for OPC output: $opc_output" >&2
            pkill -P "$run_pid" 2>/dev/null || true
            kill "$run_pid" 2>/dev/null || true
            return 1
        fi
    done

    if [ "$mode" = "kill" ]; then
        if kill -0 "$run_pid" 2>/dev/null; then
            log_info "  [OPC] killing ./run.csh (pid=$run_pid) and its children"
            pkill -P "$run_pid" 2>/dev/null || true
            kill "$run_pid" 2>/dev/null || true
            wait "$run_pid" 2>/dev/null || true
        fi
    else
        # detach: バックグラウンドで放置。disown で SMO 終了時の SIGHUP も抑制。
        if kill -0 "$run_pid" 2>/dev/null; then
            log_info "  [OPC] leaving ./run.csh (pid=$run_pid) running in background"
            disown "$run_pid" 2>/dev/null || true
        fi
    fi

    log_info "  [OPC] output: $opc_output -> $layout_out"
    cp "$opc_output" "$layout_out"
}
