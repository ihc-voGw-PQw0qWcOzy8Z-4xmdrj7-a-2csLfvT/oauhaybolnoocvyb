#!/bin/csh -f

#== TKO version設定


set intlist = ( 0.110 0.115 0.120 0.125 0.13 )

foreach int ($intlist)
#set intname = `echo "scale=0; $int * 1000" | bc | xargs printf "%04d"`
    set intname = `echo "scale=0; $int * 1000" | bc | sed 's/\..*//' | xargs printf "%04d"`
    set inparam = "flow10_in.param_${intname}.tko"
    set outoas  = "tk_opc_${intname}.oas"
    echo $inparam
    echo $inparam
    sed -e "s/sliceLevel 0.128/sliceLevel ${int}/g" \
        -e "s/tk_opc.oas/${outoas}/g" \
    flow10_in.param.tko > $inparam
    end
