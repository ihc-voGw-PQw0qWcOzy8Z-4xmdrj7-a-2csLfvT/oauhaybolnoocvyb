#!/bin/csh -f
#
# Vishamon を介さず TKO を直接実行するための run.csh
#
# - run_cp.csh (オリジナル) は bsub -K fvexa <recipe>.vis ... を経由して
#   Vishamon が tko_job_main.csh を起動するが、本ファイルは tko_job_main.csh_pre
#   (暗号化前のオリジナル csh) を直接呼ぶ。
# - HPS / MDP / VSB / MEBES / OASIS 出力 等の Vishamon 段はすべてスキップ。
# - 入力 tko_job_input1.oas は事前に配置されている前提（このディレクトリ直下）。
# - 出力 ./tko_sub_dir1/tk_opc.oas → ../tko_job_output1.oas に ln -s される
#   (これは _pre の末尾で実施されている)。
#

setenv VIS_HOSTLIST ./hostlist

setenv RULESPLIT_RUNVER 1.0.0
setenv TK_OMP_QUEUE OPCALL
setenv TK_OMP_NUM_THREADS 32
setenv TK_OMP_NUM_HOSTS 8

# 浮動小数点再現性 (TKO 内部で参照)
setenv MKL_CBWR AVX

### fvexa (calibre/vishamon 環境を一部共有 — _pre 内部で fvexa は呼ばないが、
###  共通環境変数を継承するために setup_vis_latest.csh は source する)
source /tools/mdp/vishamon/setup_vis_latest.csh
setenv FILTERVIS /tools/mdp/fvexa/5.14.2
set path = ($FILTERVIS $path)

### Calibre (flow07_sraf_mod / flow08_mrc_mod / tko_sub_dir2_mrc で使用)
setenv SCSDIR /tools/calibre/calibre_home
setenv MGC_HOME $SCSDIR
setenv MGLS_HOME $SCSDIR
source /tools/calibre/setup_mgclic.csh
setenv MGC_TMPDIR .
setenv MGC_CGI A
set SCSPATH = ( $SCSDIR/bin $SCSDIR/pkgs/icv/bin )
set path = ( $SCSPATH $path )

### Python3
setenv PATH "/tools/open_source/miniconda/miniconda3_rhel7/envs/py39_latest_v2/bin:$PATH"

### lavis (lvoasishand / lvoasisdump 等)
source /tools/mdp/TOOL/.lavis_env

setenv TOPV_FORCE_SKIP

# ==========================================
# OPC 本体: tko_sub_dir1 の _pre を直接実行
# ==========================================
echo "=== run.csh (no-vishamon) start ===" `/bin/date`

./tko_sub_dir1/tko_job_main.csh_pre
set st = $status
if ($st != 0) then
    echo "ERROR: tko_job_main.csh_pre exited with status $st"
    exit $st
endif

# ==========================================
# 補助: MRC (任意。元々 Vishamon は同時に tko_sub_dir2_mrc も走らせていた)
# tko_job_input2.oas が無い構成なら自動でスキップされる。
# ==========================================
if ( -f tko_job_input2.oas ) then
    echo "=== running tko_sub_dir2_mrc ===" `/bin/date`
    ./tko_sub_dir2_mrc/tko_job_main.csh_pre
    set st = $status
    if ($st != 0) then
        echo "WARNING: tko_sub_dir2_mrc exited with status $st (continuing)"
    endif
else
    echo "skip tko_sub_dir2_mrc (no tko_job_input2.oas)"
endif

echo "=== run.csh (no-vishamon) end ===" `/bin/date`
exit 0
