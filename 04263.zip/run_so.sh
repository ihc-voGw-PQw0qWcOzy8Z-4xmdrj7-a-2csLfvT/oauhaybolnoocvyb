#!/bin/bash
#
# run_so.sh - Single source optimization run
#
# run_smo.sh の SO 部分のみを取り出し、SOCS 生成 → srcOptim 1 回実行までを
# 行うシンプルなドライバ。NA は固定（既定 1.30）、layout/source/ini も固定。
#
# Usage: ./run_so.sh [options]
#   --na <val>            NA value (default: 1.30)
#   --max_iter <N>        srcOptim max iterations per stage (default: 80)
#   --gradient_method <N> gradient method (default: 2)
#   --optimizer <str>     lbfgs (default: lbfgs)
#   --kernel_num <N>      SOCS kernel count (default: 30)
#   -j <N>                OpenMP threads (default: 16)
#   --np <N>              MPI ranks (default: 1)
#   --layer <L/D,...>     mask layer/datatype (default: 2/1,60/0)
#   --layout <file>       layout file (default: example layout)
#   --source <file>       initial source illum
#   --evp <file>          evaluation points csv
#   --workdir <dir>       output directory (default: ./work)
#   --skip_socs           reuse existing SOCS in <workdir>/socs_set
#   --num_starts <N>      Multi-Start: 並列に N 個の srcOptim を異なる SA seed で実行 (default: 1)
#   --start_seeds "..."   seed リスト (e.g. "11,22,33,44") (default: 1,2,...,N)
#   --start_jobs <M>      各 start の OpenMP スレッド数 (default: max(1, OPENMP_NUM/N))
#   -h, --help            show this help
#

set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_ROOT=$(cd "$SCRIPT_DIR/../../.." && pwd)
TMP0423_DIR=$(cd "$SCRIPT_DIR/.." && pwd)

# ========== Defaults ==========
NA=1
MAX_ITER=200
GRADIENT_METHOD=2
OPTIMIZER="lbfgs"
KERNEL_NUM=30
OPENMP_NUM=16
MPI_NP=1
LAYOUT_LAYER="2/1,60/0"

#LAYOUT="$TMP0423_DIR/Layout/arrayPitch/ah_ax5000_ay5000_mx64_my64_rx64_ry64_cx150_crx75_cry150.gds"
LAYOUT="$TMP0423_DIR/in/opc910result.oas"
SOURCE_INIT="$TMP0423_DIR/in/initial_source.illum"
#EVP="$TMP0423_DIR/Layout/arrayPitch/ah_ax5000_ay5000_mx64_my64_rx64_ry64_cx150_crx75_cry150_ep.csv"
EVP="$TMP0423_DIR/in/LMH_1_ep.csv"
SOURCE_CONFIG="$TMP0423_DIR/in/source_config.txt"
PWC_CONFIG="$TMP0423_DIR/in/pwc_config.txt"
INI_TEMPLATE="$TMP0423_DIR/in/ini.txt"
WORKDIR="$SCRIPT_DIR/work"
SKIP_SOCS=0
NUM_STARTS=1
START_SEEDS=""
START_JOBS=""

SRCOPTIM="$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim"
MAKE_SOCS="$PROJECT_ROOT/mkSocsSet/make_socs_set_v2.py"

# ========== Parse options ==========
while [[ $# -gt 0 ]]; do
    case $1 in
        --na)              NA="$2";              shift 2 ;;
        --max_iter)        MAX_ITER="$2";        shift 2 ;;
        --gradient_method) GRADIENT_METHOD="$2"; shift 2 ;;
        --optimizer)       OPTIMIZER="$2";       shift 2 ;;
        --kernel_num)      KERNEL_NUM="$2";      shift 2 ;;
        -j)                OPENMP_NUM="$2";      shift 2 ;;
        --np)              MPI_NP="$2";          shift 2 ;;
        --layer)           LAYOUT_LAYER="$2";    shift 2 ;;
        --layout)          LAYOUT="$2";          shift 2 ;;
        --source)          SOURCE_INIT="$2";     shift 2 ;;
        --evp)             EVP="$2";             shift 2 ;;
        --workdir)         WORKDIR="$2";         shift 2 ;;
        --skip_socs)       SKIP_SOCS=1;          shift   ;;
        --num_starts)      NUM_STARTS="$2";      shift 2 ;;
        --start_seeds)     START_SEEDS="$2";     shift 2 ;;
        --start_jobs)      START_JOBS="$2";      shift 2 ;;
        -h|--help)
            sed -n '2,25p' "$0"
            exit 0
            ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

NA_STR=$(printf "%.6f" "$NA")
mkdir -p "$WORKDIR"

echo "=============================================="
echo "Single source optimization run"
echo "=============================================="
echo "  NA:               $NA"
echo "  Optimizer:        $OPTIMIZER"
echo "  Gradient method:  $GRADIENT_METHOD"
echo "  Max iterations:   $MAX_ITER (per stage)"
echo "  Kernel num:       $KERNEL_NUM"
echo "  OpenMP threads:   $OPENMP_NUM"
echo "  MPI ranks:        $MPI_NP"
echo "  Layer:            $LAYOUT_LAYER"
echo "  Layout:           $LAYOUT"
echo "  Initial source:   $SOURCE_INIT"
echo "  EVP:              $EVP"
echo "  Workdir:          $WORKDIR"
echo "=============================================="

# ========== Step 1: Generate ini.txt with the requested NA ==========
INI_FILE="$WORKDIR/ini.txt"
echo ""
echo "=== Step 1: Generating ini.txt (NA=$NA) ==="
sed -E "s/^NA[[:space:]]+.*/NA $NA_STR/" "$INI_TEMPLATE" > "$INI_FILE"
echo "  Wrote: $INI_FILE"

# ========== Step 2: SOCS generation ==========
SOCS_DIR="$WORKDIR/socs_set"
if [ "$SKIP_SOCS" -eq 1 ] && [ -d "$SOCS_DIR" ]; then
    echo ""
    echo "=== Step 2: Reusing existing SOCS at $SOCS_DIR ==="
else
    echo ""
    echo "=== Step 2: SOCS generation ==="
    rm -rf "$SOCS_DIR"
    python3 "$MAKE_SOCS" \
        --source "$SOURCE_CONFIG" \
        --pwc "$PWC_CONFIG" \
        --ini "$INI_FILE" \
        -o "$SOCS_DIR" \
        --kernel_num "$KERNEL_NUM" \
        -j 1 \
        --parallel \
        --max_jobs 16 \
        --debug
fi

# ========== Step 3: srcOptim (Multi-Start 対応) ==========
echo ""
echo "=== Step 3: srcOptim ==="

# seed リストを構築
if [ -n "$START_SEEDS" ]; then
    IFS=',' read -ra SEED_ARRAY <<< "$START_SEEDS"
    NUM_STARTS=${#SEED_ARRAY[@]}
else
    SEED_ARRAY=()
    for ((i=1; i<=NUM_STARTS; i++)); do
        SEED_ARRAY+=("$i")
    done
fi

# 各 start の OpenMP スレッド数を決定
if [ -z "$START_JOBS" ]; then
    if [ "$NUM_STARTS" -gt 1 ]; then
        START_JOBS=$(( OPENMP_NUM / NUM_STARTS ))
        [ "$START_JOBS" -lt 1 ] && START_JOBS=1
    else
        START_JOBS=$OPENMP_NUM
    fi
fi

echo "  Multi-Start config:"
echo "    num_starts:  $NUM_STARTS"
echo "    seeds:       ${SEED_ARRAY[*]}"
echo "    start_jobs:  $START_JOBS (per start)"

if [ "$MPI_NP" -gt 1 ]; then
    RUNCMD_BASE=(mpirun -np "$MPI_NP" "$SRCOPTIM")
else
    RUNCMD_BASE=("$SRCOPTIM")
fi

# srcOptim 共通オプション
COMMON_OPTS=(
    -l "$LAYOUT"
    -s "$SOCS_DIR"
    -g "$SOURCE_CONFIG"
    -f "$SOURCE_INIT"
    -p "$PWC_CONFIG"
    -e "$EVP"
    --brightfield
    --optimizer "$OPTIMIZER"
    --max_iter "$MAX_ITER"
    --gradient_method "$GRADIENT_METHOD"
    --layer "$LAYOUT_LAYER"
    --epe_power_schedule "2,4,6,8"
    --adaptive_weight_p_schedule "1.0,3.0,5.0,7.0"
    --adaptive_weight_floor_schedule "0.5,0.1,0.01,0.001"
    --sa_amplitude_init 0.03
    --sa_cooling 0.85
    --sa_max_rounds 20
    --sa_all_stages 1
    --slice_method minmax
    --slice_objective max_abs_epe
    --slice_pwc_mode all
    --sliceLevelRounds 30
    --round_conv_window 3
    --round_conv_tol 1e-6
    --lbfgs_memory 20
    --lbfgs_window 15
    --lbfgs_rel_tol 1e-6
    --lbfgs_min_iter 20
    --early_stop_patience 20
    --early_stop_tol 1e-6
    --grad_tol 1e-4
    --min_intensity 0.0
    --max_intensity 2.0
    --min_fill_ratio 0.07
    --weight_fill 10
    --exp_fill_penalty
    --fill_penalty_k 10
    -j "$START_JOBS"
    --verbose
)

# 各 start を並列実行
PIDS=()
for seed in "${SEED_ARRAY[@]}"; do
    START_DIR="$WORKDIR/start_seed${seed}"
    mkdir -p "$START_DIR"
    # SOCS は共通の WORKDIR/socs_set を再利用（コピー不要、--socs_set でパス指定）
    OUT="$START_DIR/optimized_source.illum"
    COST="$START_DIR/cost.csv"
    LOG="$START_DIR/log.csv"
    RUN_LOG="$START_DIR/run.log"

    echo "  [start seed=$seed] launching..."
    (
        "${RUNCMD_BASE[@]}" \
            "${COMMON_OPTS[@]}" \
            --sa_seed "$seed" \
            -o "$OUT" \
            --cost_output "$COST" \
            --log_output "$LOG" \
            > "$RUN_LOG" 2>&1
        echo $? > "$START_DIR/exit_code"
    ) &
    PIDS+=($!)
done

# 全 start の完了を待つ
echo "  Waiting for $NUM_STARTS starts to complete..."
for pid in "${PIDS[@]}"; do
    wait "$pid" || true
done

# 結果集計
SUMMARY="$WORKDIR/multi_start_summary.csv"
echo "seed,maxAbsEPE,source_fill_cost,sliceLevel,exit_code,elapsed_log" > "$SUMMARY"
BEST_SEED=""
BEST_VAL="1e30"
for seed in "${SEED_ARRAY[@]}"; do
    START_DIR="$WORKDIR/start_seed${seed}"
    COST="$START_DIR/cost.csv"
    EC=$(cat "$START_DIR/exit_code" 2>/dev/null || echo "?")
    if [ -f "$COST" ]; then
        MX=$(grep '^maxAbsEPE,' "$COST" | head -1 | cut -d, -f2)
        FILL=$(grep '^source_fill_cost,' "$COST" | head -1 | cut -d, -f2)
        SL=$(grep '^sliceLevel,' "$COST" | head -1 | cut -d, -f2)
    else
        MX="NaN"; FILL="NaN"; SL="NaN"
    fi
    echo "$seed,$MX,$FILL,$SL,$EC" >> "$SUMMARY"
    # 最良判定（数値比較）
    if [ "$MX" != "NaN" ] && [ "$MX" != "" ]; then
        if awk -v a="$MX" -v b="$BEST_VAL" 'BEGIN{exit !(a<b)}'; then
            BEST_VAL=$MX
            BEST_SEED=$seed
        fi
    fi
done

echo ""
echo "=== Multi-Start summary ==="
column -t -s, "$SUMMARY"

# 最良 seed の結果を WORKDIR にコピー
if [ -n "$BEST_SEED" ]; then
    BEST_DIR="$WORKDIR/start_seed${BEST_SEED}"
    cp "$BEST_DIR/optimized_source.illum" "$WORKDIR/optimized_source.illum"
    cp "$BEST_DIR/cost.csv" "$WORKDIR/cost.csv"
    cp "$BEST_DIR/log.csv" "$WORKDIR/log.csv"
    [ -f "$BEST_DIR/optimized_source.ppm" ] && cp "$BEST_DIR/optimized_source.ppm" "$WORKDIR/optimized_source.ppm"
    echo ""
    echo "  BEST seed=$BEST_SEED, maxAbsEPE=$BEST_VAL"
    echo "  Copied best result to $WORKDIR/"
else
    echo ""
    echo "  ERROR: no successful start found"
fi

echo ""
echo "=============================================="
echo "Done."
echo "  Optimized source: $WORKDIR/optimized_source.illum"
echo "  Cost CSV:         $WORKDIR/cost.csv"
echo "  Log CSV:          $WORKDIR/log.csv"
echo "  Summary:          $SUMMARY"
echo "=============================================="
