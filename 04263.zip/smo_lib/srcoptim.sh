#!/bin/bash
#
# smo_lib/srcoptim.sh - SOCS generation + source optimization (bsub/LSF)
#

# SOCS generation
run_make_socs() {
    local na_val="$1"
    local ini_file="$2"
    local socs_dir="$3"

    local m3d_opts=""
    if [ "$M3D_SO" = "1" ]; then
        m3d_opts="--m3d --mask_kikaku $MASK_KIKAKU"
    fi

    python3 "$MAKE_SOCS" \
        --source "$SOURCE_CONFIG" \
        --pwc "$PWC_CONFIG" \
        --ini "$ini_file" \
        -o "$socs_dir" \
        --kernel_num "$KERNEL_NUM" \
        -j 1 \
        -q OPCALL \
        --parallel \
        --max_jobs 16 \
        $m3d_opts \
        --debug
}

# Generate the shell script used to run srcOptim inside ONE LSF job (single seed)
# 各 bsub ジョブが 1 ホスト 1 MPI プロセスモデルを維持するため、seed ごとに
# 別ジョブとして投入する設計（案 A）。run_srcoptim() が seed ごとに本関数を呼ぶ。
_generate_srcoptim_script() {
    local script_path="$1"
    local socs_dir="$2"
    local layout="$3"
    local input_source="$4"
    local output_source="$5"
    local cost_csv="$6"
    local log_csv="$7"
    local sa_seed="${8:-1}"

    cat > "$script_path" << SCRIPT_EOF
#!/bin/bash
set -e

# Build the MPI run command
if [ -n "\$LSB_DJOB_HOSTFILE" ]; then
    NP=\$(cat "\$LSB_DJOB_HOSTFILE" | wc -l)
    RUNCMD="mpirun -bootstrap lsf -np \$NP $SRCOPTIM"
elif [ "$MPI_NP" -gt 1 ]; then
    RUNCMD="mpirun -np $MPI_NP $SRCOPTIM"
else
    RUNCMD="$SRCOPTIM"
fi

\$RUNCMD \\
    -l "$layout" \\
    -s "$socs_dir" \\
    -g "$SOURCE_CONFIG" \\
    -f "$input_source" \\
    -p "$PWC_CONFIG" \\
    -e "$EVP" \\
    -o "$output_source" \\
    --brightfield \\
    --cost_output "$cost_csv" \\
    --log_output "$log_csv" \\
    --optimizer "$OPTIMIZER" \\
    --max_iter "$MAX_ITER" \\
    --gradient_method "$GRADIENT_METHOD" \\
    --layer "$LAYOUT_LAYER" \\
    --epe_power_schedule "$SO_EPE_POWER_SCHEDULE" \\
    --adaptive_weight_p_schedule "$SO_ADAPTIVE_WEIGHT_P_SCHEDULE" \\
    --adaptive_weight_floor_schedule "$SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE" \\
    --sa_amplitude_init "$SO_SA_AMPLITUDE_INIT" \\
    --sa_cooling "$SO_SA_COOLING" \\
    --sa_max_rounds "$SO_SA_MAX_ROUNDS" \\
    --sa_all_stages "$SO_SA_ALL_STAGES" \\
    --sa_seed "$sa_seed" \\
    --slice_method "$SO_SLICE_METHOD" \\
    --slice_objective "$SO_SLICE_OBJECTIVE" \\
    --slice_pwc_mode "$SO_SLICE_PWC_MODE" \\
    --sliceLevelRounds "$SO_SLICELEVEL_ROUNDS" \\
    --round_conv_window "$SO_ROUND_CONV_WINDOW" \\
    --round_conv_tol "$SO_ROUND_CONV_TOL" \\
    --lbfgs_memory "$SO_LBFGS_MEMORY" \\
    --lbfgs_window "$SO_LBFGS_WINDOW" \\
    --lbfgs_rel_tol "$SO_LBFGS_REL_TOL" \\
    --lbfgs_min_iter "$SO_LBFGS_MIN_ITER" \\
    --early_stop_patience "$SO_EARLY_STOP_PATIENCE" \\
    --early_stop_tol "$SO_EARLY_STOP_TOL" \\
    --grad_tol "$SO_GRAD_TOL" \\
    --min_intensity "$SO_MIN_INTENSITY" \\
    --max_intensity "$SO_MAX_INTENSITY" \\
    --min_fill_ratio "$SO_MIN_FILL_RATIO" \\
    --weight_fill "$SO_WEIGHT_FILL" \\
    --exp_fill_penalty \\
    --fill_penalty_k "$SO_FILL_PENALTY_K" \\
    -j "$OPENMP_NUM" \\
    --verbose

SCRIPT_EOF
    chmod +x "$script_path"
}

# Extract the LSF job id from bsub output
_extract_jobid() {
    # bsub output looks like: "Job <12345> is submitted to queue <OPCALL>."
    sed -n 's/.*Job <\([0-9]*\)>.*/\1/p'
}

# Wait for the LSF job to finish, printing periodic progress updates
_wait_for_job() {
    local jobid="$1"
    local tag="$2"

    local start_epoch
    start_epoch=$(date +%s)
    echo "  [$tag] job submitted: JobID=$jobid, waiting for completion..." >&2

    local last_report=0
    local report_interval=30  # progress interval in seconds
    # UNKNOWN/empty を「完了」と解釈するのは、job が一度でも実状態
    # (PEND/RUN/DONE 等) で観測された後だけに限定する。
    # 投入直後のスケジューラ登録遅延で UNKNOWN が返っても
    # 早期に return しないようにするため。
    local job_seen=false
    local unknown_since=0
    local unknown_grace=60  # job_seen 前に UNKNOWN 継続を許容する秒数
    while true; do
        local status
        status=$(bjobs -noheader -o "stat" "$jobid" 2>/dev/null || echo "UNKNOWN")
        case "$status" in
            DONE)
                local elapsed=$(( $(date +%s) - start_epoch ))
                echo "  [$tag] job DONE: JobID=$jobid (elapsed $((elapsed/60))m $((elapsed%60))s)" >&2
                return 0
                ;;
            EXIT)
                echo "  [$tag] job EXIT (failed): JobID=$jobid" >&2
                return 1
                ;;
            UNKNOWN|"")
                if [ "$job_seen" = true ]; then
                    # 実状態観測済み → 履歴から flush された完了と解釈
                    echo "  [$tag] job status UNKNOWN after seen: JobID=$jobid (assuming done)" >&2
                    return 0
                fi
                # まだ一度も観測できていない: スケジューラ登録遅延の可能性あり
                if [ "$unknown_since" -eq 0 ]; then
                    unknown_since=$(date +%s)
                fi
                local unknown_elapsed=$(( $(date +%s) - unknown_since ))
                if [ "$unknown_elapsed" -ge "$unknown_grace" ]; then
                    echo "  [$tag] job never seen by bjobs within ${unknown_grace}s: JobID=$jobid" >&2
                    echo "  [$tag] (assuming flushed-done; will verify output file)" >&2
                    return 0
                fi
                # grace 期間中は sleep して再試行
                ;;
            *)
                job_seen=true
                unknown_since=0
                ;;
        esac

        # Periodic progress update
        local now elapsed
        now=$(date +%s)
        elapsed=$((now - start_epoch))
        if [ $((elapsed - last_report)) -ge "$report_interval" ]; then
            echo "  [$tag] ... $status  (elapsed $((elapsed/60))m $((elapsed%60))s)  JobID=$jobid" >&2
            last_report=$elapsed
        fi

        sleep 10
    done
}

# 単一 seed の bsub ジョブを投入し jobid を返す
_submit_one_srcoptim() {
    local sd="$1"             # この seed の作業ディレクトリ
    local socs_dir="$2"
    local layout="$3"
    local input_source="$4"
    local seed="$5"
    local tag="$6"

    mkdir -p "$sd"
    local out="$sd/optimized_source.illum"
    local cost="$sd/cost.csv"
    local log="$sd/log.csv"
    local rs="$sd/run_srcoptim.sh"
    local bsub_log="$sd/srcoptim_bsub.log"

    _generate_srcoptim_script "$rs" "$socs_dir" "$layout" "$input_source" \
        "$out" "$cost" "$log" "$seed"

    local out_msg
    out_msg=$(bsub \
        -n "$MPI_NP" \
        -R "span[ptile=1]" \
        -q OPCALL \
        -J "smo_so_${tag}_seed${seed}" \
        -o "$bsub_log" \
        "$rs" 2>&1)

    local jobid
    jobid=$(echo "$out_msg" | _extract_jobid)

    if [ -z "$jobid" ]; then
        echo "  [seed=$seed] ERROR: bsub failed: $out_msg" >&2
        return 1
    fi

    echo "$jobid"
    return 0
}

# Run source optimization
# - SO_NUM_STARTS=1 (default): 単発 bsub（従来動作）
# - SO_NUM_STARTS>=2: seed ごとに独立した bsub ジョブを N 並列投入
#   各ジョブは 1 host 1 MPI プロセス（span[ptile=1]）を維持。
#   全ジョブ完了後、最良 maxAbsEPE の解を最終出力にコピー。
run_srcoptim() {
    local socs_dir="$1"
    local layout="$2"
    local input_source="$3"
    local output_source="$4"
    local cost_csv="$5"
    local log_csv="$6"
    local tag="${7:-srcOptim}"

    local work_dir
    work_dir=$(dirname "$output_source")

    # seed リストを構築
    local seeds=()
    if [ -n "$SO_START_SEEDS" ]; then
        IFS=',' read -ra seeds <<< "$SO_START_SEEDS"
    elif [ "${SO_NUM_STARTS:-1}" -ge 2 ]; then
        local i
        for ((i=1; i<=SO_NUM_STARTS; i++)); do
            seeds+=("$i")
        done
    fi

    # ===== single-start (従来動作) =====
    if [ "${#seeds[@]}" -le 1 ]; then
        local single_seed="${seeds[0]:-1}"
        local rs="$work_dir/run_srcoptim.sh"
        local bsub_log="$work_dir/srcoptim_bsub.log"

        _generate_srcoptim_script "$rs" "$socs_dir" "$layout" "$input_source" \
            "$output_source" "$cost_csv" "$log_csv" "$single_seed"

        local out_msg
        out_msg=$(bsub \
            -n "$MPI_NP" \
            -R "span[ptile=1]" \
            -q OPCALL \
            -J "smo_srcoptim_${tag}" \
            -o "$bsub_log" \
            "$rs" 2>&1)

        local jobid
        jobid=$(echo "$out_msg" | _extract_jobid)

        if [ -z "$jobid" ]; then
            echo "  ERROR: bsub failed: $out_msg" >&2
            return 1
        fi

        _wait_for_job "$jobid" "$tag"

        # NFS sync 対応の出力ファイルチェック
        local check_retries=30
        local check_interval=2
        local attempt
        for (( attempt = 0; attempt < check_retries; ++attempt )); do
            [ -f "$output_source" ] && break
            ls -la "$work_dir" >/dev/null 2>&1 || true
            sleep "$check_interval"
        done

        if [ ! -f "$output_source" ]; then
            echo "  ERROR: optimized source not found: $output_source" >&2
            echo "  check log: $bsub_log" >&2
            return 1
        fi
        return 0
    fi

    # ===== Multi-Start (N seeds, 各 seed 独立 bsub) =====
    echo "  Multi-Start: ${#seeds[@]} seeds = ${seeds[*]}"

    # 全 seed の bsub を投入し、(jobid, seed, sd) を記録
    local jobids=()
    local seedlist_for_wait=()
    local sd_for_seed=()
    local seed
    for seed in "${seeds[@]}"; do
        local sd="$work_dir/start_seed${seed}"
        local jid
        jid=$(_submit_one_srcoptim "$sd" "$socs_dir" "$layout" "$input_source" \
                                    "$seed" "$tag")
        if [ -z "$jid" ]; then
            echo "  [seed=$seed] failed to submit, skipping"
            continue
        fi
        jobids+=("$jid")
        seedlist_for_wait+=("$seed")
        sd_for_seed+=("$sd")
        echo "  [seed=$seed] submitted: jobid=$jid, dir=$sd"
    done

    if [ "${#jobids[@]}" -eq 0 ]; then
        echo "  ERROR: no Multi-Start job was submitted" >&2
        return 1
    fi

    # 全 jobid の完了を待つ
    local i
    for ((i=0; i<${#jobids[@]}; i++)); do
        local jid="${jobids[$i]}"
        local sd="${sd_for_seed[$i]}"
        local s="${seedlist_for_wait[$i]}"
        _wait_for_job "$jid" "${tag}_seed${s}"
        # NFS sync wait
        local out="$sd/optimized_source.illum"
        local check_retries=30
        local check_interval=2
        local attempt
        for (( attempt = 0; attempt < check_retries; ++attempt )); do
            [ -f "$out" ] && break
            ls -la "$sd" >/dev/null 2>&1 || true
            sleep "$check_interval"
        done
    done

    # 結果集計と最良解選択
    local summary="$work_dir/multi_start_summary.csv"
    echo "seed,maxAbsEPE,source_fill_cost,sliceLevel" > "$summary"
    local best_seed=""
    local best_val="1e30"
    for ((i=0; i<${#sd_for_seed[@]}; i++)); do
        local sd="${sd_for_seed[$i]}"
        local s="${seedlist_for_wait[$i]}"
        local cf="$sd/cost.csv"
        local mx="NaN"; local fill="NaN"; local sl="NaN"
        if [ -f "$cf" ]; then
            mx=$(grep '^maxAbsEPE,' "$cf" | head -1 | cut -d, -f2)
            fill=$(grep '^source_fill_cost,' "$cf" | head -1 | cut -d, -f2)
            sl=$(grep '^sliceLevel,' "$cf" | head -1 | cut -d, -f2)
        fi
        echo "$s,$mx,$fill,$sl" >> "$summary"
        if [ "$mx" != "NaN" ] && [ -n "$mx" ]; then
            if awk -v a="$mx" -v b="$best_val" 'BEGIN{exit !(a<b)}'; then
                best_val="$mx"
                best_seed="$s"
            fi
        fi
    done

    echo "  Multi-Start summary:"
    column -t -s, "$summary" 2>/dev/null | sed 's/^/    /' || cat "$summary"

    if [ -z "$best_seed" ]; then
        echo "  ERROR: no Multi-Start seed produced a valid result" >&2
        return 1
    fi

    # 最良 seed の出力を最終出力にコピー
    local bd="$work_dir/start_seed${best_seed}"
    cp "$bd/optimized_source.illum" "$output_source"
    cp "$bd/cost.csv" "$cost_csv"
    cp "$bd/log.csv" "$log_csv"
    [ -f "$bd/optimized_source.ppm" ] && \
        cp "$bd/optimized_source.ppm" "${output_source%.illum}.ppm"

    echo "  BEST seed=$best_seed, maxAbsEPE=$best_val"
    return 0
}
