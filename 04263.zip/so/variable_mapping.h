/*!
 * @file variable_mapping.h
 * @brief D2対称性を考慮した最適化変数マッピング
 */

#ifndef SO_VARIABLE_MAPPING_H
#define SO_VARIABLE_MAPPING_H

#include <so/types.h>
#include <so/source_data.h>
#include <so/source_grid.h>
#include <vector>
#include <map>
#include <utility>

namespace so {

/*!
 * @brief D2対称性を考慮した最適化変数マッピング
 *
 * D2対称時は第1象限（gx>=0, gy>=0）の点のみを変数として扱い、
 * 対称点の寄与を集約する（multiplier: 1, 2, or 4）
 */
class VariableMapping {
public:
    VariableMapping();
    ~VariableMapping();

    /*!
     * @brief マッピングを初期化
     * @param sourceGrid 光源グリッド設定
     * @param sourceData 初期光源強度データ
     */
    void initialize(const SourceGrid& sourceGrid,
                    const SourceData& sourceData);

    /*!
     * @brief 変数ベクトルから光源データを更新
     * @param variables 最適化変数ベクトル（長さ = numVariables()）
     * @param sourceData 更新先の光源データ
     */
    void variablesToSource(const std::vector<double>& variables,
                           SourceData& sourceData) const;

    /*!
     * @brief 光源データから変数ベクトルを取得
     * @param sourceData 光源強度データ
     * @return 最適化変数ベクトル
     */
    std::vector<double> sourceToVariables(const SourceData& sourceData) const;

    /*!
     * @brief 勾配マップを変数ベクトルに変換
     * @param gradientMap 光源座標(gx, gy)をキーとする勾配マップ
     * @return 最適化変数インデックスに対応する勾配ベクトル
     *
     * D2対称SOCSの場合、gradientMapには第1象限の座標のみが含まれる。
     * 各座標を対応する変数インデックスにマッピングして変換する。
     */
    std::vector<double> gradientMapToVector(const std::map<std::pair<double, double>, double>& gradientMap) const;

    // アクセサ
    size_t numVariables() const { return m_variableInfos.size(); }
    const std::vector<VariableInfo>& variableInfos() const { return m_variableInfos; }
    const SourceGridConfig& gridConfig() const { return m_gridConfig; }
    bool isD2Symmetry() const { return m_gridConfig.isD2Symmetry(); }

private:
    SourceGridConfig m_gridConfig;
    std::vector<VariableInfo> m_variableInfos;
    std::map<std::pair<double, double>, int> m_coordToVarIndex;  ///< 座標 -> 変数インデックス

    /*!
     * @brief D2対称性における重みを計算
     * @param gx X座標
     * @param gy Y座標
     * @return 重み（1: 軸上, 2: 軸上だが原点以外, 4: 一般点）
     */
    int calcMultiplier(double gx, double gy) const;

    /*!
     * @brief 座標をキー化（浮動小数点の丸め）
     */
    static std::pair<double, double> makeKey(double x, double y);
};

} // namespace so

#endif // SO_VARIABLE_MAPPING_H
