#ifndef SO_WRITER_H
#define SO_WRITER_H

#include <so/types.h>
#include <string>
#include <vector>

namespace so {

/**
 * @brief 評価点リストをCSV形式でファイルに出力する
 * @param filename 出力ファイルパス
 * @param points 評価点のリスト
 * @throws std::runtime_error ファイルが作成できない場合
 */
void writeCSV(const std::string& filename, const std::vector<EvalPoint>& points);

} // namespace so

#endif // SO_WRITER_H
