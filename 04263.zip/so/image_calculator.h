/*!
 * @file image_calculator.h
 * @brief 光学像計算・積分
 */

#ifndef SO_IMAGE_CALCULATOR_H
#define SO_IMAGE_CALCULATOR_H

#include <so/types.h>
#include "source_contribution_set.h"
#include <so/source_grid.h>
#include <so/source_data.h>
#include <so/socs_config.h>
#include <so/process_config.h>
#include <so/evp_data.h>
#include <vector>
#include <string>
#include <map>

namespace so {

/*!
 * @brief 光学像計算クラス
 * 
 * 点光源ごとの光学像計算と、全点光源の積分を行う
 * 出力は周波数空間（SourceContributionSet）
 */
class ImageCalculator {
private:
    const SourceGrid* m_sourceGrid = nullptr;
    const SourceData* m_sourceData = nullptr;
    const ProcessConfig* m_processConfig = nullptr;
    std::string m_socsSetDir;
    std::string m_oasisFile;
    std::string m_resistModelFile;
    CalcOptions m_options;
    int m_mpiRank = 0;   ///< MPIランク（ファイル書き込み制御用）
    int m_mpiSize = 1;   ///< MPI総ランク数

    /*!
     * @brief 光学像計算の内部実装
     * @param evpData 評価点データ
     * @param resistModelDir resistModelファイルの出力先ディレクトリ
     * @return CalcResult（周波数空間画像と光学パラメータ）
     */
    CalcResult calcImagesInternal(const EvpData& evpData,
                                   const std::string& resistModelDir) const;

public:
    ImageCalculator();
    ~ImageCalculator();

    /// 光源グリッドを設定
    void setSourceGrid(const SourceGrid* grid);
    
    /// 光源データを設定
    void setSourceData(const SourceData* data);
    
    /// プロセス設定を設定
    void setProcessConfig(const ProcessConfig* config);
    
    /// SOCSセットディレクトリを設定
    void setSocsSetDir(const std::string& dir);
    
    /// OASISファイルを設定
    void setOasisFile(const std::string& file);
    
    /// resistModelファイルを設定
    void setResistModelFile(const std::string& file);
    
    /// 計算オプションを設定
    void setOptions(const CalcOptions& options);

    /// MPIランクとサイズを設定
    void setMPI(int rank, int size) { m_mpiRank = rank; m_mpiSize = size; }

    /// MPIランクを設定（後方互換）
    void setMPIRank(int rank) { m_mpiRank = rank; }

    /*!
     * @brief 全clip × 全pwc条件の光学像を計算（周波数空間）
     * @param evpData 評価点データ
     * @param resistModelOutputDir resistModelファイルの出力先（空の場合は一時ディレクトリを使用し削除）
     * @return CalcResult（周波数空間画像マップと光学パラメータ）
     *
     * 各光源点の周波数空間画像を保存。
     * コスト計算時に光源強度を指定して合成する。
     */
    CalcResult calcImages(const EvpData& evpData,
                          const std::string& resistModelOutputDir = "") const;

    /*!
     * @brief 全clip × 全pwc条件の光学像を計算してファイルに保存
     * @param evpData 評価点データ
     * @param outputDir 出力ディレクトリ
     * @param saveAsFrequency trueなら周波数空間(.freq)、falseなら実空間(.out)
     * 
     * saveAsFrequency=falseの場合、光源強度で重み付け合成後IFFTして保存。
     * saveAsFrequency=trueの場合、各光源点の周波数空間データをそのまま保存。
     */
    void calcAndSaveImages(const EvpData& evpData,
                           const std::string& outputDir,
                           bool saveAsFrequency = false) const;
};

/*!
 * @brief resistModelファイル生成クラス
 */
class ResistModelGenerator {
public:
    /*!
     * @brief mask_bias を適用したresistModelファイルを生成
     * @param baseFile 元となるresistModelファイル（空の場合はデフォルト生成）
     * @param outputFile 出力ファイル
     * @param maskBiasNm マスクバイアス値 [nm]
     */
    static void generate(const std::string& baseFile,
                         const std::string& outputFile,
                         double maskBiasNm);

    /*!
     * @brief 全mask_bias値に対するresistModelファイルを生成
     * @param baseFile 元となるresistModelファイル
     * @param outputDir 出力ディレクトリ
     * @param maskBiases マスクバイアス値リスト [nm]
     */
    static void generateAll(const std::string& baseFile,
                            const std::string& outputDir,
                            const std::vector<double>& maskBiases);

    /*!
     * @brief mask_bias用のresistModelファイル名を生成
     * @param maskBiasNm マスクバイアス値 [nm]
     * @return ファイル名 (例: "resistModel_mb0.5.info")
     */
    static std::string makeFileName(double maskBiasNm);
};

} // namespace so

#endif // SO_IMAGE_CALCULATOR_H
