/*!
 * @file evp_data.h
 * @brief evp.csv 読み込み・管理
 */

#ifndef SO_EVP_DATA_H
#define SO_EVP_DATA_H

#include <so/types.h>
#include <string>
#include <vector>
#include <map>

namespace so {

/*!
 * @brief クリップ情報（cx, cyでグループ化）
 */
struct ClipInfo {
    int clipID = 0;
    double cx = 0.0;
    double cy = 0.0;
    std::vector<const EvalPoint*> evalPoints;
};

/*!
 * @brief Cutlineペア（EPE1, EPE2の対応）
 */
struct CutlinePair {
    int clipID = 0;
    std::string direction;        ///< "X" or "Y"
    const EvalPoint* point1 = nullptr;  ///< cl_xl or cl_yb
    const EvalPoint* point2 = nullptr;  ///< cl_xr or cl_yt
    double CD = 0.0;              ///< cutline長さ
};

/*!
 * @brief evp.csv データ管理クラス
 */
class EvpData {
private:
    std::vector<EvalPoint> m_evalPoints;
    std::vector<ClipInfo> m_clips;
    std::vector<CutlinePair> m_cutlinePairs;
    
    /// クリップ情報を構築
    void buildClipInfo();
    
    /// Cutlineペアを構築
    void buildCutlinePairs();

public:
    EvpData();
    ~EvpData();

    /*!
     * @brief evp.csv を読み込む
     * @param filepath ファイルパス
     * @throw std::runtime_error ファイルが開けない、またはパースエラー
     */
    void load(const std::string& filepath);

    /// クリップ情報リストを取得
    const std::vector<ClipInfo>& showClips() const;

    /// Cutlineペアリストを取得
    const std::vector<CutlinePair>& showCutlinePairs() const;

    /*!
     * @brief clipIDからClipInfoを取得
     * @param clipID クリップID
     * @return ClipInfoへのポインタ（見つからなければnullptr）
     */
    const ClipInfo* getClip(int clipID) const;

    /// クリップ数を取得
    size_t showClipCount() const;

    /// ユニークなclipIDリストを取得
    std::vector<int> showClipIDs() const;

    /// 評価点数を取得
    size_t showEvalPointCount() const;

    /*!
     * @brief 各評価点の weight を index でセット（IRLS / adaptive weighting 用）
     * @param newWeights m_evalPoints と同じサイズの重みベクトル
     *
     * ClipInfo::evalPoints は m_evalPoints へのポインタなので、
     * weight 書き換えは ClipInfo 経由でも参照される。
     */
    void setEvalPointWeights(const std::vector<double>& newWeights);

    /// 全評価点（読み取り専用）。インデックスは setEvalPointWeights と一致。
    const std::vector<EvalPoint>& showEvalPoints() const { return m_evalPoints; }
};

} // namespace so

#endif // SO_EVP_DATA_H
