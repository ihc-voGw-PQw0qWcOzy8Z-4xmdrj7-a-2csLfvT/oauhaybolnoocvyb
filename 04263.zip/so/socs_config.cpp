/*!
 * @file socs_config.cpp
 * @brief socs_config.txt パーサー
 */

#include "socs_config.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <cmath>
#include <cctype>
#include <filesystem>
#include <regex>
#include <iostream>

namespace so {

namespace {
    constexpr double DEFOCUS_ROUND_PRECISION = 1e3;
}

double SocsConfig::roundDefocus(double defocus) {
    return std::round(defocus * DEFOCUS_ROUND_PRECISION) / DEFOCUS_ROUND_PRECISION;
}

SocsConfig::SocsConfig() {}

SocsConfig::~SocsConfig() {}

void SocsConfig::load(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open socs_config file: " + filepath);
    }

    m_normEntries.clear();
    m_normMap.clear();

    std::string line;
    bool inNormSection = false;

    while (std::getline(file, line)) {
        // 空行をスキップ
        if (line.empty()) {
            continue;
        }

        // コメント行をスキップ
        if (line[0] == '#') {
            continue;
        }

        // セクション終了
        if (line.find("</norm>") != std::string::npos) {
            inNormSection = false;
            continue;
        }

        // セクション開始
        if (line.find("<norm>") != std::string::npos) {
            inNormSection = true;
            continue;
        }

        if (inNormSection) {
            // norm行をパース: "defocus sourceID norm_real+norm_imag*i"
            std::istringstream iss(line);
            NormEntry entry;
            std::string normStr;
            
            if (iss >> entry.defocus >> entry.sourceID >> normStr) {
                // 複素数をパース (例: "0.523+0.087i" または "0.523-0.087i")
                std::regex complexRegex(R"(([+-]?[\d.]+)([+-][\d.]+)i)");
                std::smatch match;
                
                if (std::regex_match(normStr, match, complexRegex)) {
                    entry.norm_real = std::stod(match[1].str());
                    entry.norm_imag = std::stod(match[2].str());
                } else {
                    // 実数のみの場合
                    entry.norm_real = std::stod(normStr);
                    entry.norm_imag = 0.0;
                }
                
                // 虚部が0でない場合は警告
                if (std::abs(entry.norm_imag) > 1e-10) {
                    std::cerr << "Warning: norm has non-zero imaginary part for "
                              << entry.sourceID << " at defocus=" << entry.defocus
                              << " (imag=" << entry.norm_imag << ")" << std::endl;
                }
                
                m_normEntries.push_back(entry);
                
                double roundedDefocus = roundDefocus(entry.defocus);
                m_normMap[{entry.sourceID, roundedDefocus}] = entry.norm_real;
            }
        } else {
            // 光学パラメータ行をパース
            std::istringstream iss(line);
            std::string key;
            iss >> key;

            if (key == "lambda") {
                iss >> m_opticalParams.lambda;
            } else if (key == "NA") {
                iss >> m_opticalParams.NA;
            } else if (key == "Lx") {
                iss >> m_opticalParams.Lx;
            } else if (key == "Ly") {
                iss >> m_opticalParams.Ly;
            }
        }
    }
}

const OpticalParams& SocsConfig::showOpticalParams() const {
    return m_opticalParams;
}

const std::vector<NormEntry>& SocsConfig::showNormEntries() const {
    return m_normEntries;
}

double SocsConfig::getNorm(const std::string& sourceID, double defocus) const {
    double roundedDefocus = roundDefocus(defocus);
    auto key = std::make_pair(sourceID, roundedDefocus);
    
    auto it = m_normMap.find(key);
    if (it != m_normMap.end()) {
        return it->second;
    }
    
    throw std::runtime_error("Norm not found for sourceID=" + sourceID + 
                            ", defocus=" + std::to_string(defocus));
}

bool SocsConfig::hasNorm(const std::string& sourceID, double defocus) const {
    double roundedDefocus = roundDefocus(defocus);
    auto key = std::make_pair(sourceID, roundedDefocus);
    return m_normMap.find(key) != m_normMap.end();
}

int SocsConfig::calcDefaultDim() const {
    double L_max = m_opticalParams.maxL();
    double val = L_max * 2.0 * m_opticalParams.NA / m_opticalParams.lambda;
    return 4 * static_cast<int>(std::floor(val)) + 2;
}

// SocsFile

std::string SocsFile::makePath(const std::string& socsSetDir,
                                const std::string& sourceID,
                                double defocus) {
    std::ostringstream oss;
    oss << socsSetDir << "/" << sourceID << "_d" << static_cast<int>(defocus) << ".socs";
    return oss.str();
}

bool SocsFile::exists(const std::string& socsSetDir,
                      const std::string& sourceID,
                      double defocus) {
    std::string path = makePath(socsSetDir, sourceID, defocus);
    return std::filesystem::exists(path);
}

OpticalParams SocsFile::readOpticalParamsFromFile(const std::string& socsFilePath) {
    OpticalParams params;

    std::ifstream ifs(socsFilePath);
    if (!ifs.is_open()) {
        throw std::runtime_error("Cannot open SOCS file: " + socsFilePath);
    }

    std::string line;
    while (std::getline(ifs, line)) {
        // DATA行でヘッダ終了
        if (line == "DATA") break;

        std::istringstream iss(line);
        std::string key;
        iss >> key;

        if (iss.fail()) continue;

        // 大文字に変換して比較
        std::string keyUpper = key;
        for (auto& c : keyUpper) c = static_cast<char>(std::toupper(static_cast<unsigned char>(c)));

        if (keyUpper == "NA") {
            iss >> params.NA;
        } else if (keyUpper == "LAMBDA") {
            iss >> params.lambda;
        } else if (keyUpper == "LX") {
            iss >> params.Lx;
        } else if (keyUpper == "LY") {
            iss >> params.Ly;
        } else if (keyUpper == "L") {
            // L は Lx = Ly の場合
            iss >> params.Lx;
            params.Ly = params.Lx;
        } else if (keyUpper == "NORM") {
            // normは複素数: (real,imag) 形式
            // 残りの行を読み込んで手動でパース
            std::string rest;
            std::getline(iss, rest);

            // 括弧とカンマの位置を探す
            size_t openParen = rest.find('(');
            size_t comma = rest.find(',');
            size_t closeParen = rest.find(')');

            if (openParen != std::string::npos && comma != std::string::npos && closeParen != std::string::npos) {
                std::string realPart = rest.substr(openParen + 1, comma - openParen - 1);
                std::string imagPart = rest.substr(comma + 1, closeParen - comma - 1);

                try {
                    params.norm_real = std::stod(realPart);
                    params.norm_imag = std::stod(imagPart);
                } catch (...) {
                    // パース失敗時は0のまま
                }
            }
        }
    }

    return params;
}

OpticalParams SocsFile::readOpticalParamsFromDir(const std::string& socsDirPath) {
    OpticalParams params;

    // m3dinfoからnorm合計を計算
    std::string m3dinfoPath = socsDirPath + "/m3dinfo";
    std::ifstream m3difs(m3dinfoPath);
    if (!m3difs.is_open()) {
        throw std::runtime_error("Cannot open m3dinfo: " + m3dinfoPath);
    }

    double normSum = 0.0;
    std::string firstSocsFile;
    std::string line;
    while (std::getline(m3difs, line)) {
        if (line.empty() || line[0] == '#') continue;

        // m3dinfo形式: M3Doption\tcgrp_index\tsx\tsy\tsocsfilename\tnorm
        std::istringstream iss(line);
        std::string m3doption, socsfilename;
        int cgrpIndex;
        double sx, sy, norm;
        if (iss >> m3doption >> cgrpIndex >> sx >> sy >> socsfilename >> norm) {
            normSum += norm;
            if (firstSocsFile.empty()) {
                firstSocsFile = socsfilename;
            }
        }
    }

    if (firstSocsFile.empty()) {
        throw std::runtime_error("No SOCS entries found in m3dinfo: " + m3dinfoPath);
    }

    // 最初のSOCSファイルからlambda, NA, Lx, Lyを取得
    std::string firstSocsPath = socsDirPath + "/" + firstSocsFile;
    params = readOpticalParamsFromFile(firstSocsPath);

    // normを全偏光コンポーネントの合計に設定
    params.norm_real = normSum;
    params.norm_imag = 0.0;

    return params;
}

OpticalParams SocsFile::readOpticalParams(const std::string& socsPath) {
    if (std::filesystem::is_directory(socsPath)) {
        // M3D: ディレクトリ形式
        return readOpticalParamsFromDir(socsPath);
    } else {
        // M2D: 単一ファイル形式
        return readOpticalParamsFromFile(socsPath);
    }
}

} // namespace so
