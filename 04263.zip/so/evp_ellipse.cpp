#include "evp_ellipse.h"
#include <cmath>
#include <string>

namespace so {

namespace {

/// 円周率
constexpr double PI = 3.14159265358979323846;

/**
 * @brief 度をラジアンに変換する
 * @param degrees 度
 * @return ラジアン
 */
double toRadians(double degrees) {
    return degrees * PI / 180.0;
}

/**
 * @brief ラジアンを度に変換する
 * @param radians ラジアン
 * @return 度
 */
double toDegrees(double radians) {
    return radians * 180.0 / PI;
}

/**
 * @brief 角度が水平または垂直方向かどうかを判定する
 * @param angleDegrees 角度（度）
 * @return 水平または垂直ならtrue
 */
bool isHorizontalOrVertical(double angleDegrees) {
    // 浮動小数点の誤差を考慮して判定
    constexpr double epsilon = 1e-9;
    double normalized = std::fmod(angleDegrees + 360.0, 360.0);
    
    return (std::abs(normalized - 0.0) < epsilon ||
            std::abs(normalized - 90.0) < epsilon ||
            std::abs(normalized - 180.0) < epsilon ||
            std::abs(normalized - 270.0) < epsilon ||
            std::abs(normalized - 360.0) < epsilon);
}

/**
 * @brief 角度からカットラインIDを決定する
 * @param angleDegrees 角度（度）
 * @return カットラインID
 */
std::string determineCutlineID(double angleDegrees) {
    constexpr double epsilon = 1e-9;
    double normalized = std::fmod(angleDegrees + 360.0, 360.0);
    
    if (std::abs(normalized - 0.0) < epsilon || std::abs(normalized - 360.0) < epsilon) {
        return "cl_xr";  // 右（X正方向）
    } else if (std::abs(normalized - 90.0) < epsilon) {
        return "cl_yt";  // 上（Y正方向）
    } else if (std::abs(normalized - 180.0) < epsilon) {
        return "cl_xl";  // 左（X負方向）
    } else if (std::abs(normalized - 270.0) < epsilon) {
        return "cl_yb";  // 下（Y負方向）
    } else {
        return "nan";
    }
}

} // anonymous namespace

double roundCoordinate(double value, int d) {
    return std::round(value * d) / d;
}

double calculateNormalAngle(double theta, double a, double b) {
    // 楕円上の点 (a*cos(theta), b*sin(theta)) における法線ベクトルは
    // (cos(theta)/a, sin(theta)/b) に比例する
    double nx = std::cos(theta) / a;
    double ny = std::sin(theta) / b;
    
    // 法線角度を計算（X軸正方向を0°として反時計回り）
    double angle = std::atan2(ny, nx);
    double angleDegrees = toDegrees(angle);
    
    // 角度を0-360の範囲に正規化
    if (angleDegrees < 0) {
        angleDegrees += 360.0;
    }
    
    return angleDegrees;
}

std::vector<EvalPoint> calculateEvalPoints(const Rectangle& rect, int clipID, const EvpConfig& config) {
    std::vector<EvalPoint> points;
    
    // 楕円のパラメータを計算
    double cx = rect.centerX();
    double cy = rect.centerY();
    double a = rect.semiAxisA();
    double b = rect.semiAxisB();
    
    // 座標を丸める
    cx = roundCoordinate(cx, config.d);
    cy = roundCoordinate(cy, config.d);
    
    // n個の評価点を計算
    double angleStep = 360.0 / config.n;
    
    for (int i = 0; i < config.n; ++i) {
        double angleDegrees = i * angleStep;
        double theta = toRadians(angleDegrees);
        
        // 楕円上の点（相対座標）
        double px = a * std::cos(theta);
        double py = b * std::sin(theta);
        
        // 座標を丸める
        px = roundCoordinate(px, config.d);
        py = roundCoordinate(py, config.d);
        
        // 法線方向の角度を計算
        double normalAngle = calculateNormalAngle(theta, a, b);
        
        // 重みを決定
        double weight = isHorizontalOrVertical(angleDegrees) ? config.weightHV : config.weightDiag;
        
        // カットラインIDを決定
        std::string cutlineID = determineCutlineID(angleDegrees);
        
        // 評価点を作成
        EvalPoint point;
        point.clipID = clipID;
        point.cx = cx;
        point.cy = cy;
        point.px = px;
        point.py = py;
        point.degree = normalAngle;
        point.tolerance = config.tolerance;
        point.weight = weight;
        point.cutlineID = cutlineID;
        
        points.push_back(point);
    }
    
    return points;
}

std::vector<EvalPoint> calculateAllEvalPoints(const std::vector<Rectangle>& rectangles, const EvpConfig& config) {
    std::vector<EvalPoint> allPoints;
    
    for (size_t i = 0; i < rectangles.size(); ++i) {
        auto points = calculateEvalPoints(rectangles[i], static_cast<int>(i), config);
        allPoints.insert(allPoints.end(), points.begin(), points.end());
    }
    
    return allPoints;
}

} // namespace so
