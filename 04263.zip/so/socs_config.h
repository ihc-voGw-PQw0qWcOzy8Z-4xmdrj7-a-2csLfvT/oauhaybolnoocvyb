/*!
 * @file socs_config.h
 * @brief socs_config.txt パーサー
 */

#ifndef SO_SOCS_CONFIG_H
#define SO_SOCS_CONFIG_H

#include <so/types.h>
#include <string>
#include <vector>
#include <map>
#include <utility>

namespace so {

/*!
 * @brief socs_config.txt 管理クラス
 * 
 * socs_set/socs_config.txt の読み込みを行う
 * 光学パラメータとnorm情報を保持する
 */
class SocsConfig {
private:
    OpticalParams m_opticalParams;
    std::vector<NormEntry> m_normEntries;
    
    /// (sourceID, defocus) -> norm_real のマップ
    std::map<std::pair<std::string, double>, double> m_normMap;
    
    /// defocusの丸め処理
    static double roundDefocus(double defocus);

public:
    SocsConfig();
    ~SocsConfig();

    /*!
     * @brief socs_config.txt を読み込む
     * @param filepath ファイルパス
     * @throw std::runtime_error ファイルが開けない、またはパースエラー
     */
    void load(const std::string& filepath);

    /// 光学パラメータを取得
    const OpticalParams& showOpticalParams() const;

    /// 全Norm情報を取得
    const std::vector<NormEntry>& showNormEntries() const;

    /*!
     * @brief sourceIDとdefocusからnorm実部を取得
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return norm実部
     * @throw std::runtime_error 見つからない場合
     */
    double getNorm(const std::string& sourceID, double defocus) const;

    /*!
     * @brief (sourceID, defocus)ペアが存在するか確認
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return 存在すればtrue
     */
    bool hasNorm(const std::string& sourceID, double defocus) const;

    /*!
     * @brief デフォルトのdim値を計算
     * @return dim = 4 * floor(L_max * 2 * NA / lambda) + 2
     */
    int calcDefaultDim() const;
};

/*!
 * @brief SOCSファイル操作ユーティリティ
 */
class SocsFile {
public:
    /*!
     * @brief SOCSファイルパスを生成
     * @param socsSetDir socs_setディレクトリ
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return ファイルパス (例: "socs_set/x0.500000_y0.300000_d40.socs")
     */
    static std::string makePath(const std::string& socsSetDir,
                                 const std::string& sourceID,
                                 double defocus);

    /*!
     * @brief SOCSファイルが存在するか確認
     * @param socsSetDir socs_setディレクトリ
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return 存在すればtrue
     */
    static bool exists(const std::string& socsSetDir,
                       const std::string& sourceID,
                       double defocus);

    /*!
     * @brief SOCSファイル/ディレクトリから光学パラメータを読み取る
     * @param socsPath SOCSファイルパス（M2D）またはディレクトリパス（M3D）
     * @return 光学パラメータ
     *
     * M2D（ファイル）: ヘッダ部分（DATA行まで）を解析し、lambda, NA, Lx, Ly, normを取得。
     * M3D（ディレクトリ）: 内部の最初の.socsファイルからlambda, NA, Lx, Lyを取得し、
     *                      m3dinfoから全偏光コンポーネントのnorm合計を計算。
     */
    static OpticalParams readOpticalParams(const std::string& socsPath);

private:
    /// M2D: 単一SOCSファイルからパラメータを読み取る
    static OpticalParams readOpticalParamsFromFile(const std::string& socsFilePath);

    /// M3D: SOCSディレクトリ（m3dinfo + 複数.socs）からパラメータを読み取る
    static OpticalParams readOpticalParamsFromDir(const std::string& socsDirPath);
};

} // namespace so

#endif // SO_SOCS_CONFIG_H
