/*!
 * @file constraint_handler.h
 * @brief 最適化制約の処理（射影）
 */

#ifndef SO_CONSTRAINT_HANDLER_H
#define SO_CONSTRAINT_HANDLER_H

#include <so/types.h>
#include <vector>

namespace so {

/*!
 * @brief 最適化制約の処理クラス
 *
 * Box制約（上下限）の射影を提供
 */
class ConstraintHandler {
public:
    ConstraintHandler();
    ~ConstraintHandler();

    /*!
     * @brief 制約オプションを設定
     * @param options 最適化オプション
     */
    void setOptions(const OptimizationOptions& options);

    /*!
     * @brief パラメータをBox制約内に射影
     * @param params 入力パラメータ
     * @return 制約を満たすパラメータ
     */
    std::vector<double> project(const std::vector<double>& params) const;

    /*!
     * @brief パラメータをBox制約内に射影（in-place）
     * @param params 更新するパラメータ
     */
    void projectInPlace(std::vector<double>& params) const;

    // アクセサ
    double minIntensity() const { return m_minIntensity; }
    double maxIntensity() const { return m_maxIntensity; }

private:
    double m_minIntensity = 0.0;
    double m_maxIntensity = 1.0;
};

} // namespace so

#endif // SO_CONSTRAINT_HANDLER_H
