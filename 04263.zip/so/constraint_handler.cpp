/*!
 * @file constraint_handler.cpp
 * @brief 最適化制約の処理（射影）の実装
 */

#include "constraint_handler.h"
#include <algorithm>
#include <cmath>

namespace so {

namespace {
    constexpr double BOUNDARY_EPSILON = 1e-12;
}

ConstraintHandler::ConstraintHandler() {}

ConstraintHandler::~ConstraintHandler() {}

void ConstraintHandler::setOptions(const OptimizationOptions& options) {
    m_minIntensity = options.minIntensity;
    m_maxIntensity = options.maxIntensity;
}

std::vector<double> ConstraintHandler::project(const std::vector<double>& params) const {
    std::vector<double> projected(params.size());
    for (size_t i = 0; i < params.size(); ++i) {
        projected[i] = std::clamp(params[i], m_minIntensity, m_maxIntensity);
    }
    return projected;
}

void ConstraintHandler::projectInPlace(std::vector<double>& params) const {
    for (auto& p : params) {
        p = std::clamp(p, m_minIntensity, m_maxIntensity);
    }
}

} // namespace so
