/*!
 * @file lbfgs_optimizer.h
 * @brief L-BFGS（Limited-memory BFGS）オプティマイザ
 */

#ifndef SO_LBFGS_OPTIMIZER_H
#define SO_LBFGS_OPTIMIZER_H

#include "optimizer_base.h"
#include <deque>

namespace so {

/*!
 * @brief L-BFGSオプティマイザ
 *
 * 準ニュートン法の一種で、ヘッセ行列の逆行列を
 * 過去m回の勾配・パラメータ変化から近似する。
 */
class LBFGSOptimizer : public OptimizerBase {
public:
    LBFGSOptimizer();
    ~LBFGSOptimizer() override;

    /*!
     * @brief 最適化を実行
     */
    OptimizationResult optimize(
        const std::vector<double>& x0,
        CostFunction costFunc,
        GradientFunction gradFunc,
        ProjectionFunction projFunc) override;

private:
    /*!
     * @brief Two-loop recursion でヘッセ逆近似を適用
     * @param grad 現在の勾配
     * @return 探索方向 (-H * grad)
     */
    std::vector<double> computeDirection(const std::vector<double>& grad);

    /*!
     * @brief Wolfe条件を満たすステップサイズを探索
     */
    double lineSearch(
        const std::vector<double>& x,
        const std::vector<double>& direction,
        double f0,
        const std::vector<double>& g0,
        CostFunction costFunc,
        GradientFunction gradFunc,
        ProjectionFunction projFunc);

    /*!
     * @brief 履歴を更新
     */
    void updateHistory(const std::vector<double>& s, const std::vector<double>& y);

    /*!
     * @brief メモリをリセット
     */
    void resetMemory();

    /*!
     * @brief 射影勾配を計算（Box制約対応）
     * @param x 現在のパラメータ
     * @param grad 通常の勾配
     * @return 射影勾配
     */
    std::vector<double> computeProjectedGradient(
        const std::vector<double>& x,
        const std::vector<double>& grad) const;

    /*!
     * @brief ウィンドウベースの収束判定
     * @param costHistory コスト履歴
     * @param projGradNorm 射影勾配ノルム
     * @return 収束したか
     */
    bool checkConvergence(
        const std::vector<double>& costHistory,
        double projGradNorm,
        std::string& reason) const;

    // L-BFGSの履歴
    std::deque<std::vector<double>> m_s;  ///< x_{k+1} - x_k
    std::deque<std::vector<double>> m_y;  ///< g_{k+1} - g_k
    std::deque<double> m_rho;              ///< 1 / (y^T s)

    int m_memorySize = 10;
    int m_consecutiveSmallSteps = 0;       ///< 連続小ステップカウンタ
};

} // namespace so

#endif // SO_LBFGS_OPTIMIZER_H
