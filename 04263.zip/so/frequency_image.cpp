/*!
 * @file frequency_image.cpp
 * @brief 周波数空間での光学像表現の実装
 */

#include "frequency_image.h"
#include <cmath>
#include <stdexcept>
#include <fstream>
#include <algorithm>
#include <iostream>

#ifndef USE_FFTW
    #error "USE_FFTW must be defined. FFTW3 is required."
#endif
#include <fftw3.h>

namespace so {

void FrequencyImage::initialize(int dimx, int dimy, double Lx, double Ly) {
    m_dimx = dimx;
    m_dimy = dimy;
    m_Lx = Lx;
    m_Ly = Ly;
    m_data.assign(dimx * dimy, std::complex<double>(0.0, 0.0));
}

void FrequencyImage::setData(std::vector<std::complex<double>>&& data) {
    if (static_cast<int>(data.size()) != m_dimx * m_dimy) {
        throw std::runtime_error("FrequencyImage::setData: size mismatch");
    }
    m_data = std::move(data);
}

void FrequencyImage::setData(const std::vector<std::complex<double>>& data) {
    if (static_cast<int>(data.size()) != m_dimx * m_dimy) {
        throw std::runtime_error("FrequencyImage::setData: size mismatch");
    }
    m_data = data;
}

PointValue FrequencyImage::evalAt(double x, double y) const {
    PointValue result = {0.0, 0.0, 0.0};
    
    if (m_data.empty()) {
        return result;
    }

    // 座標はそのまま使用（転置なし）

    // 周波数の基本単位
    const double dkx = 1.0 / m_Lx;
    const double dky = 1.0 / m_Ly;
    const double twoPi = 2.0 * M_PI;
    
    // 複素数の累積（精度のため）
    std::complex<double> sumI(0.0, 0.0);
    std::complex<double> sumGx(0.0, 0.0);
    std::complex<double> sumGy(0.0, 0.0);

    // m_dataはfftshift2回適用（=元に戻った状態）なので、DCは[0,0]にある
    // 周波数インデックス: 0, 1, ..., N/2-1, -N/2, -N/2+1, ..., -1
    for (int iy = 0; iy < m_dimy; ++iy) {
        // 周波数インデックス（DCは[0,0]）
        int ky = (iy < m_dimy / 2) ? iy : iy - m_dimy;
        double fy = ky * dky;
        
        for (int ix = 0; ix < m_dimx; ++ix) {
            int kx = (ix < m_dimx / 2) ? ix : ix - m_dimx;
            double fx = kx * dkx;
            
            size_t idx = ix + iy * m_dimx;
            const std::complex<double>& Fval = m_data[idx];
            
            // 位相因子 exp(2πi(fx*x + fy*y))
            double phase = twoPi * (fx * x + fy * y);
            std::complex<double> expFactor(std::cos(phase), std::sin(phase));
            
            std::complex<double> contrib = Fval * expFactor;
            
            // I(x,y) = Σ F * exp(2πi(fx*x + fy*y))
            sumI += contrib;
            
            // ∂I/∂x = Σ (2πi*fx) * F * exp(...)
            sumGx += std::complex<double>(0.0, twoPi * fx) * contrib;
            
            // ∂I/∂y = Σ (2πi*fy) * F * exp(...)
            sumGy += std::complex<double>(0.0, twoPi * fy) * contrib;
        }
    }
    
    // 正規化なし（calcImgと互換）
    result.intensity = sumI.real();
    result.gradX = sumGx.real();  // ∂I/∂x
    result.gradY = sumGy.real();  // ∂I/∂y
    
    return result;
}

void FrequencyImage::addWeighted(const FrequencyImage& other, double weight) {
    if (other.m_dimx != m_dimx || other.m_dimy != m_dimy) {
        throw std::runtime_error("FrequencyImage::addWeighted: dimension mismatch");
    }
    
    const size_t n = m_data.size();
    for (size_t i = 0; i < n; ++i) {
        m_data[i] += other.m_data[i] * weight;
    }
}

void FrequencyImage::scale(double factor) {
    for (auto& val : m_data) {
        val *= factor;
    }
}

void FrequencyImage::clear() {
    std::fill(m_data.begin(), m_data.end(), std::complex<double>(0.0, 0.0));
}

std::vector<double> FrequencyImage::toRealSpace() const {
    if (m_data.empty()) {
        return {};
    }

    const int hdimx = m_dimx / 2;
    const int hdimy = m_dimy / 2;

#ifdef USE_FFTW
    // 処理：
    // 1. IFFT実行
    // 2. 実部を取り出し（正規化なし）
    // 3. fftshift

    std::vector<std::complex<double>> fdata = m_data;

    // IFFT
    std::vector<std::complex<double>> cresult(m_dimx * m_dimy);
    fftw_plan plan = fftw_plan_dft_2d(m_dimy, m_dimx,
        reinterpret_cast<fftw_complex*>(fdata.data()),
        reinterpret_cast<fftw_complex*>(cresult.data()),
        FFTW_BACKWARD, FFTW_ESTIMATE);
    fftw_execute(plan);
    fftw_destroy_plan(plan);

    // 実部を取り出し（正規化なし）
    std::vector<double> result(m_dimx * m_dimy);
    for (size_t i = 0; i < cresult.size(); ++i) {
        result[i] = cresult[i].real();
    }

    // fftshift（実空間データ）
    std::vector<double> shifted(m_dimx * m_dimy);
    for (int iy = 0; iy < m_dimy; ++iy) {
        for (int ix = 0; ix < m_dimx; ++ix) {
            int dstX = (ix + hdimx) % m_dimx;
            int dstY = (iy + hdimy) % m_dimy;
            shifted[dstX + dstY * m_dimx] = result[ix + iy * m_dimx];
        }
    }

    return shifted;
#else
    #error "FFTW3 is required. Please install libfftw3-dev."
#endif
}

void FrequencyImage::saveAsRealImage(const std::string& filepath) const {
    std::vector<double> realData = toRealSpace();

    std::ofstream ofs(filepath, std::ios::binary);
    if (!ofs) {
        throw std::runtime_error("Cannot open file: " + filepath);
    }
    
    // データのみ（ヘッダなし）
    ofs.write(reinterpret_cast<const char*>(realData.data()), 
              realData.size() * sizeof(double));
}

FrequencyImage FrequencyImage::fromRealSpace(const std::vector<double>& realData,
                                              int dimx, int dimy, double Lx, double Ly) {
    FrequencyImage result;
    result.initialize(dimx, dimy, Lx, Ly);
    
#ifdef USE_FFTW
    // toRealSpace()の逆操作：
    // toRealSpace: IFFT（正規化なし）→ fftshift → 出力
    // fromRealSpace: 入力 → ifftshift → FFT → 1/N正規化 → 出力

    // ifftshift（実空間データ）
    const int hdimx = dimx / 2;
    const int hdimy = dimy / 2;
    std::vector<double> unshifted(dimx * dimy);
    for (int iy = 0; iy < dimy; ++iy) {
        for (int ix = 0; ix < dimx; ++ix) {
            int srcX = (ix + hdimx) % dimx;
            int srcY = (iy + hdimy) % dimy;
            unshifted[ix + iy * dimx] = realData[srcX + srcY * dimx];
        }
    }

    // 実数データを複素数に変換
    std::vector<std::complex<double>> cdata(dimx * dimy);
    for (size_t i = 0; i < unshifted.size() && i < cdata.size(); ++i) {
        cdata[i] = std::complex<double>(unshifted[i], 0.0);
    }
    
    // FFT実行
    std::vector<std::complex<double>> freqData(dimx * dimy);
    fftw_plan plan = fftw_plan_dft_2d(dimy, dimx,
        reinterpret_cast<fftw_complex*>(cdata.data()),
        reinterpret_cast<fftw_complex*>(freqData.data()),
        FFTW_FORWARD, FFTW_ESTIMATE);
    fftw_execute(plan);
    fftw_destroy_plan(plan);

    // 1/N正規化（toRealSpace()がIFFTで正規化なしなので、ここで補正）
    double norm = 1.0 / (dimx * dimy);
    for (auto& val : freqData) {
        val *= norm;
    }

    result.setData(std::move(freqData));
#else
    #error "FFTW3 is required. Please install libfftw3-dev."
#endif
    
    return result;
}

FrequencyImage FrequencyImage::loadFromRealImage(const std::string& filepath,
                                                  int dimx, int dimy, double Lx, double Ly) {
    // バイナリファイルから実空間データを読み込み
    std::ifstream ifs(filepath, std::ios::binary);
    if (!ifs) {
        throw std::runtime_error("Cannot open file: " + filepath);
    }
    
    size_t totalSize = static_cast<size_t>(dimx) * dimy;
    std::vector<double> realData(totalSize);
    
    ifs.read(reinterpret_cast<char*>(realData.data()), totalSize * sizeof(double));
    
    if (!ifs) {
        throw std::runtime_error("Failed to read image data from: " + filepath);
    }
    
    // デバッグ: 読み込んだデータの統計
    double minVal = *std::min_element(realData.begin(), realData.end());
    double maxVal = *std::max_element(realData.begin(), realData.end());
    double sumVal = 0.0;
    for (const auto& v : realData) sumVal += v;
    double avgVal = sumVal / realData.size();
    std::cerr << "[DEBUG loadFromRealImage] File: " << filepath << std::endl;
    std::cerr << "[DEBUG loadFromRealImage] Read data: min=" << minVal 
              << ", max=" << maxVal << ", avg=" << avgVal 
              << ", size=" << realData.size() 
              << ", dim=" << dimx << "x" << dimy << std::endl;
    
    // FFTして周波数空間に変換
    return fromRealSpace(realData, dimx, dimy, Lx, Ly);
}

void FrequencyImage::save(const std::string& filepath) const {
    std::ofstream ofs(filepath, std::ios::binary);
    if (!ofs) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }
    
    // ヘッダ: dimx, dimy, Lx, Ly
    ofs.write(reinterpret_cast<const char*>(&m_dimx), sizeof(m_dimx));
    ofs.write(reinterpret_cast<const char*>(&m_dimy), sizeof(m_dimy));
    ofs.write(reinterpret_cast<const char*>(&m_Lx), sizeof(m_Lx));
    ofs.write(reinterpret_cast<const char*>(&m_Ly), sizeof(m_Ly));
    
    // 周波数空間データ（複素数配列）
    ofs.write(reinterpret_cast<const char*>(m_data.data()), 
              m_data.size() * sizeof(std::complex<double>));
}

void FrequencyImage::load(const std::string& filepath) {
    std::ifstream ifs(filepath, std::ios::binary);
    if (!ifs) {
        throw std::runtime_error("Cannot open file for reading: " + filepath);
    }
    
    // ヘッダ: dimx, dimy, Lx, Ly
    ifs.read(reinterpret_cast<char*>(&m_dimx), sizeof(m_dimx));
    ifs.read(reinterpret_cast<char*>(&m_dimy), sizeof(m_dimy));
    ifs.read(reinterpret_cast<char*>(&m_Lx), sizeof(m_Lx));
    ifs.read(reinterpret_cast<char*>(&m_Ly), sizeof(m_Ly));
    
    // 周波数空間データ（複素数配列）
    size_t totalSize = static_cast<size_t>(m_dimx) * m_dimy;
    m_data.resize(totalSize);
    ifs.read(reinterpret_cast<char*>(m_data.data()), 
             totalSize * sizeof(std::complex<double>));
    
    if (!ifs) {
        throw std::runtime_error("Failed to read frequency image data from: " + filepath);
    }
    
    // デバッグ: 読み込んだデータの統計
    double maxMag = 0.0;
    std::complex<double> dc = m_data[0];
    for (const auto& v : m_data) {
        double mag = std::abs(v);
        if (mag > maxMag) maxMag = mag;
    }
    std::cerr << "[DEBUG FrequencyImage::load] DC=" << dc 
              << ", maxMag=" << maxMag 
              << ", dim=" << m_dimx << "x" << m_dimy
              << ", L=" << m_Lx << "x" << m_Ly << std::endl;
}

} // namespace so
