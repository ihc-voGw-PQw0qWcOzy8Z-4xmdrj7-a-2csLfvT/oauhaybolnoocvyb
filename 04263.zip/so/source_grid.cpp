/*!
 * @file source_grid.cpp
 * @brief 光源グリッド設定の読み込み・管理
 */

#include "source_grid.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <cmath>
#include <iomanip>
#include <algorithm>

namespace so {

SourceGrid::SourceGrid() {}

SourceGrid::~SourceGrid() {}

void SourceGrid::load(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open source_config file: " + filepath);
    }

    std::string line;
    while (std::getline(file, line)) {
        // コメントと空行をスキップ
        if (line.empty() || line[0] == '#') {
            continue;
        }

        std::istringstream iss(line);
        std::string key;
        iss >> key;

        if (key == "src_grid") {
            iss >> m_config.grid;
        } else if (key == "src_sigma_max") {
            iss >> m_config.sigma_max;
        } else if (key == "src_sigma_min") {
            iss >> m_config.sigma_min;
        } else if (key == "src_symmetry") {
            iss >> m_config.symmetry;
        }
    }
}

void SourceGrid::save(const std::string& filepath) const {
    std::ofstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }

    file << "src_grid " << m_config.grid << "\n";
    file << "src_sigma_max " << m_config.sigma_max << "\n";
    file << "src_sigma_min " << m_config.sigma_min << "\n";
    file << "src_symmetry " << m_config.symmetry << "\n";
}

const SourceGridConfig& SourceGrid::showConfig() const {
    return m_config;
}

void SourceGrid::setConfig(const SourceGridConfig& config) {
    m_config = config;
}

std::vector<std::pair<double, double>> SourceGrid::generateGridPoints() const {
    std::vector<std::pair<double, double>> points;
    
    int n = m_config.grid;
    
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            double x, y;
            
            if (n % 2 == 1) {
                // 奇数グリッド: 軸を含む
                x = -1.0 + 2.0 * i / (n - 1);
                y = -1.0 + 2.0 * j / (n - 1);
            } else {
                // 偶数グリッド: 軸を含まない
                x = -1.0 + (2.0 * i + 1.0) / n;
                y = -1.0 + (2.0 * j + 1.0) / n;
            }
            
            points.emplace_back(x, y);
        }
    }
    
    return points;
}

std::vector<std::pair<double, double>> SourceGrid::generateValidGridPoints() const {
    std::vector<std::pair<double, double>> allPoints = generateGridPoints();
    std::vector<std::pair<double, double>> validPoints;
    
    for (const auto& [x, y] : allPoints) {
        double r = std::sqrt(x * x + y * y);
        if (r >= m_config.sigma_min && r <= m_config.sigma_max) {
            validPoints.emplace_back(x, y);
        }
    }
    
    return validPoints;
}

std::string SourceGrid::makeSourceID(double x, double y) {
    std::ostringstream oss;
    oss << "x" << std::fixed << std::setprecision(6) << x
        << "_y" << std::fixed << std::setprecision(6) << y;
    return oss.str();
}

std::pair<double, double> SourceGrid::parseSourceID(const std::string& sourceID) {
    // "x0.500000_y0.300000" 形式をパース
    double x = 0.0, y = 0.0;
    
    size_t xPos = sourceID.find('x');
    size_t yPos = sourceID.find("_y");
    
    if (xPos != std::string::npos && yPos != std::string::npos) {
        x = std::stod(sourceID.substr(xPos + 1, yPos - xPos - 1));
        y = std::stod(sourceID.substr(yPos + 2));
    }
    
    return {x, y};
}

} // namespace so
