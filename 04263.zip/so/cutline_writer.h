#ifndef SO_CUTLINE_WRITER_H
#define SO_CUTLINE_WRITER_H

#include <so/types.h>
#include <string>
#include <vector>

namespace so {

/**
 * @brief 評価点リストからCutline情報を抽出する
 * @param points 評価点のリスト
 * @param numClips クリップの数
 * @param n 1クリップあたりの評価点数
 * @return Cutline情報のリスト
 */
std::vector<CutlineInfo> extractCutlineInfo(const std::vector<EvalPoint>& points, int numClips, int n);

/**
 * @brief 評価点リストから絶対座標の評価点リストを生成する
 * @param points 評価点のリスト
 * @return 絶対座標の評価点リスト
 */
std::vector<EvalPointAbs> convertToAbsoluteCoords(const std::vector<EvalPoint>& points);

/**
 * @brief Cutline情報と評価点情報をcutline.err形式でファイルに出力する
 * @param filename 出力ファイルパス
 * @param cutlines Cutline情報のリスト
 * @param evalPoints 絶対座標の評価点リスト
 * @param n 1クリップあたりの評価点数
 * @param d 座標精度
 * @throws std::runtime_error ファイルが作成できない場合
 */
void writeCutlineErr(const std::string& filename,
                     const std::vector<CutlineInfo>& cutlines,
                     const std::vector<EvalPointAbs>& evalPoints,
                     int n,
                     int d);

} // namespace so

#endif // SO_CUTLINE_WRITER_H
