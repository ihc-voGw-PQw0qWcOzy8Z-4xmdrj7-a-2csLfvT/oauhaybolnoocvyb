/*!
 * @file source_contribution_set.h
 * @brief 1条件の全光源点データの集合
 */

#ifndef SO_SOURCE_CONTRIBUTION_SET_H
#define SO_SOURCE_CONTRIBUTION_SET_H

#include "source_contribution.h"
#include "frequency_image.h"
#include <so/source_data.h>
#include <so/source_grid.h>
#include <vector>
#include <string>

namespace so {

/*!
 * @brief 1条件（clip, defocus, maskBias, deltaDose）の全光源点データ
 */
class SourceContributionSet {
public:
    SourceContributionSet() = default;
    ~SourceContributionSet() = default;
    
    // コピー・ムーブ
    SourceContributionSet(const SourceContributionSet&) = default;
    SourceContributionSet& operator=(const SourceContributionSet&) = default;
    SourceContributionSet(SourceContributionSet&&) = default;
    SourceContributionSet& operator=(SourceContributionSet&&) = default;

    /*!
     * @brief 次元を設定
     */
    void setDimensions(int dimx, int dimy, double Lx, double Ly);

    /*!
     * @brief D2対称性を設定
     * @param isD2 D2対称の場合true
     *
     * D2対称時は第1象限（gx >= 0, gy >= 0）のみを受け付け、
     * それ以外の座標は警告を出してスキップする
     */
    void setD2Symmetry(bool isD2);

    /*!
     * @brief D2対称性を取得
     */
    bool isD2Symmetry() const { return m_isD2Symmetry; }

    /*!
     * @brief 光源寄与を追加
     * @return 追加された場合true、D2対称で座標が不正な場合false
     */
    bool addContribution(SourceContribution&& contrib);
    bool addContribution(const SourceContribution& contrib);

    /*!
     * @brief 光源強度を指定して合成画像を計算（周波数空間）
     * @param sourceData 光源強度データ
     * @param gridConfig 光源グリッド設定
     * @return 合成された周波数空間画像
     * 
     * F(I) = Σ F(I_i) × (norm_i × s_i) / Σ (norm_i × s_i)
     */
    FrequencyImage combine(const SourceData& sourceData,
                           const SourceGridConfig& gridConfig) const;

    /*!
     * @brief delta_dose補正を適用した合成画像を計算
     * @param sourceData 光源強度データ
     * @param gridConfig 光源グリッド設定
     * @param deltaDose ドーズ補正値
     * @return 合成された周波数空間画像（補正済み）
     */
    FrequencyImage combineWithDoseCorrection(
        const SourceData& sourceData,
        const SourceGridConfig& gridConfig,
        double deltaDose) const;

    // アクセサ
    const std::vector<SourceContribution>& contributions() const { return m_contributions; }
    size_t numContributions() const { return m_contributions.size(); }
    bool empty() const { return m_contributions.empty(); }
    
    int dimx() const { return m_dimx; }
    int dimy() const { return m_dimy; }
    double Lx() const { return m_Lx; }
    double Ly() const { return m_Ly; }

    /*!
     * @brief ファイルに保存
     */
    void save(const std::string& filepath) const;

    /*!
     * @brief ファイルから読み込み
     */
    void load(const std::string& filepath);

    /*!
     * @brief バイト列にシリアライズ
     */
    std::vector<char> serialize() const;

    /*!
     * @brief バイト列からデシリアライズ
     */
    void deserialize(const char* data, size_t size);

private:
    std::vector<SourceContribution> m_contributions;
    int m_dimx = 0;
    int m_dimy = 0;
    double m_Lx = 0.0;
    double m_Ly = 0.0;
    bool m_isD2Symmetry = false;
};

} // namespace so

#endif // SO_SOURCE_CONTRIBUTION_SET_H
