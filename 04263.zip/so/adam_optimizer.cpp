/*!
 * @file adam_optimizer.cpp
 * @brief Adamオプティマイザの実装
 */

#include "adam_optimizer.h"
#include <cmath>
#include <iomanip>
#include <iostream>

namespace so {

AdamOptimizer::AdamOptimizer() {}

AdamOptimizer::~AdamOptimizer() {}

OptimizationResult AdamOptimizer::optimize(
    const std::vector<double>& x0,
    CostFunction costFunc,
    GradientFunction gradFunc,
    ProjectionFunction projFunc) {

    OptimizationResult result;

    const double lr = m_options.adamLearningRate;
    const double beta1 = m_options.adamBeta1;
    const double beta2 = m_options.adamBeta2;
    const double epsilon = m_options.adamEpsilon;

    const size_t n = x0.size();

    // モーメントを初期化
    m_m.assign(n, 0.0);
    m_v.assign(n, 0.0);

    std::vector<double> x = x0;
    projFunc(x);

    double f = costFunc(x);
    std::vector<double> g = gradFunc(x);
    double gNorm = gradientNorm(g);

    // 初期ログ
    OptimizationLogEntry logEntry;
    logEntry.iteration = 0;
    logEntry.cost = f;
    logEntry.gradientNorm = gNorm;
    result.log.push_back(logEntry);

    if (m_options.verbose) {
        std::cerr << "Adam Iteration 0: cost=" << std::fixed << std::setprecision(6) << f
                  << ", gradNorm=" << gNorm << std::endl;
    }

    // コスト履歴（早期終了用）
    std::vector<double> costHistory;
    costHistory.push_back(f);

    // 初期コストを記録（早期終了用）
    const double initialCost = f;

    // 収束チェック
    if (gNorm < m_options.gradientTolerance) {
        result.converged = true;
        result.iterations = 0;
        result.finalCost = f;
        result.finalGradientNorm = gNorm;
        result.terminationReason = "Gradient tolerance reached";
        result.finalVariables = x;
        return result;
    }

    double prevCost = f;
    double beta1_t = 1.0;
    double beta2_t = 1.0;

    for (int iter = 1; iter <= m_options.maxIterations; ++iter) {
        // バイアス補正係数を更新
        beta1_t *= beta1;
        beta2_t *= beta2;

        // モーメントを更新
        for (size_t i = 0; i < n; ++i) {
            m_m[i] = beta1 * m_m[i] + (1.0 - beta1) * g[i];
            m_v[i] = beta2 * m_v[i] + (1.0 - beta2) * g[i] * g[i];
        }

        // パラメータを更新
        for (size_t i = 0; i < n; ++i) {
            // バイアス補正
            double m_hat = m_m[i] / (1.0 - beta1_t);
            double v_hat = m_v[i] / (1.0 - beta2_t);

            x[i] -= lr * m_hat / (std::sqrt(v_hat) + epsilon);
        }

        // 射影
        projFunc(x);

        // コストと勾配を再計算
        f = costFunc(x);
        g = gradFunc(x);
        gNorm = gradientNorm(g);

        // ログ
        logEntry.iteration = iter;
        logEntry.cost = f;
        logEntry.gradientNorm = gNorm;
        logEntry.stepSize = lr;
        result.log.push_back(logEntry);

        if (m_options.verbose) {
            std::cerr << "Adam Iteration " << iter << ": cost=" << std::fixed << std::setprecision(6) << f
                      << ", gradNorm=" << gNorm << std::endl;
        }

        // コスト履歴更新
        costHistory.push_back(f);

        // === A. 小窓コスト改善率チェック ===
        if (m_options.earlyStopPatience > 0 &&
            static_cast<int>(costHistory.size()) > m_options.earlyStopPatience) {
            double oldCost = costHistory[costHistory.size() - 1 - m_options.earlyStopPatience];
            double relImprovement = (oldCost - f) / std::max(std::abs(oldCost), 1e-12);
            if (relImprovement < m_options.earlyStopTolerance) {
                result.converged = true;
                result.iterations = iter;
                result.finalCost = f;
                result.finalGradientNorm = gNorm;
                result.terminationReason = "Early stop: cost stagnation";
                result.finalVariables = x;
                if (m_options.verbose) {
                    std::cerr << "Adam: Early stop (stagnation) at iter " << iter
                              << ", relImprovement=" << relImprovement << std::endl;
                }
                return result;
            }
        }

        // === B. ラウンドあたり最大コスト削減率 ===
        if (m_options.maxCostReduction > 0) {
            double reduction = (initialCost - f) / std::max(std::abs(initialCost), 1e-12);
            if (reduction >= m_options.maxCostReduction) {
                result.converged = true;
                result.iterations = iter;
                result.finalCost = f;
                result.finalGradientNorm = gNorm;
                result.terminationReason = "Early stop: sufficient cost reduction";
                result.finalVariables = x;
                if (m_options.verbose) {
                    std::cerr << "Adam: Early stop (sufficient reduction) at iter " << iter
                              << ", reduction=" << reduction << std::endl;
                }
                return result;
            }
        }

        // 収束チェック
        if (gNorm < m_options.gradientTolerance) {
            result.converged = true;
            result.iterations = iter;
            result.finalCost = f;
            result.finalGradientNorm = gNorm;
            result.terminationReason = "Gradient tolerance reached";
            result.finalVariables = x;
            return result;
        }

        if (std::abs(f - prevCost) < m_options.costTolerance) {
            result.converged = true;
            result.iterations = iter;
            result.finalCost = f;
            result.finalGradientNorm = gNorm;
            result.terminationReason = "Cost tolerance reached";
            result.finalVariables = x;
            return result;
        }

        prevCost = f;
    }

    result.converged = false;
    result.iterations = m_options.maxIterations;
    result.finalCost = f;
    result.finalGradientNorm = gNorm;
    result.terminationReason = "Maximum iterations reached";
    result.finalVariables = x;
    return result;
}

} // namespace so
