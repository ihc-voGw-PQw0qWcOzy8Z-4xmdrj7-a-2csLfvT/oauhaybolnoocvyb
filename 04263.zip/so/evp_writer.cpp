#include "evp_writer.h"
#include <fstream>
#include <iomanip>
#include <stdexcept>

namespace so {

void writeCSV(const std::string& filename, const std::vector<EvalPoint>& points) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Error: Cannot create output file: " + filename);
    }
    
    // 出力精度を設定（1/8000 = 0.000125 なので小数点以下6桁あれば十分）
    file << std::fixed << std::setprecision(10);
    
    // ヘッダー行を出力
    file << "clipID,cx,cy,px,py,degree,tolerance,weight,cutlineID\n";
    
    // 各評価点を出力
    for (const auto& point : points) {
        file << point.clipID << ","
             << point.cx << ","
             << point.cy << ","
             << point.px << ","
             << point.py << ","
             << point.degree << ","
             << point.tolerance << ","
             << point.weight << ","
             << point.cutlineID << "\n";
    }
    
    file.close();
}

} // namespace so
