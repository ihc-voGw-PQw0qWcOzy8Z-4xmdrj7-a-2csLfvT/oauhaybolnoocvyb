/*!
 * @file process_config.h
 * @brief process_config.txt パーサー
 */

#ifndef SO_PROCESS_CONFIG_H
#define SO_PROCESS_CONFIG_H

#include <so/types.h>
#include <string>
#include <vector>

namespace so {

/*!
 * @brief process_config.txt 管理クラス
 * 
 * プロセス条件（PWC）の読み込み・書き出しを行う
 */
class ProcessConfig {
private:
    std::vector<PwcCondition> m_pwcConditions;

public:
    ProcessConfig();
    ~ProcessConfig();

    /*!
     * @brief process_config.txt を読み込む
     * @param filepath ファイルパス
     * @throw std::runtime_error ファイルが開けない、またはパースエラー
     */
    void load(const std::string& filepath);

    /*!
     * @brief process_config.txt を書き出す
     * @param filepath ファイルパス
     */
    void save(const std::string& filepath) const;

    /// PWC条件リストを取得
    const std::vector<PwcCondition>& showPwcConditions() const;

    /// PWC条件を追加
    void addPwcCondition(const PwcCondition& pwc);

    /// PWC条件数を取得
    size_t size() const;

    /*!
     * @brief ノミナル条件のインデックスを取得
     * @return ノミナル条件のインデックス（見つからなければ0）
     */
    int findNominalIndex() const;

    /*!
     * @brief ユニークなdefocus値リストを取得
     * @return defocus値のリスト（重複なし、ソート済み）
     */
    std::vector<double> showUniqueDefocuses() const;

    /*!
     * @brief ユニークなmask_bias値リストを取得
     * @return mask_bias値のリスト（重複なし、ソート済み）
     */
    std::vector<double> showUniqueMaskBiases() const;

    /// 全データをクリア
    void clear();
};

} // namespace so

#endif // SO_PROCESS_CONFIG_H
