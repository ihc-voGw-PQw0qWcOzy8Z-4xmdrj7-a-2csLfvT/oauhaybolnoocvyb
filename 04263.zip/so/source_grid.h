/*!
 * @file source_grid.h
 * @brief 光源グリッド設定の読み込み・管理
 */

#ifndef SO_SOURCE_GRID_H
#define SO_SOURCE_GRID_H

#include <so/types.h>
#include <string>
#include <vector>
#include <utility>

namespace so {

/*!
 * @brief 光源グリッド管理クラス
 * 
 * source_grid.txt の読み込みと、グリッド座標の生成を行う
 */
class SourceGrid {
private:
    SourceGridConfig m_config;

public:
    SourceGrid();
    ~SourceGrid();

    /*!
     * @brief source_grid.txt を読み込む
     * @param filepath ファイルパス
     * @throw std::runtime_error ファイルが開けない、またはパースエラー
     */
    void load(const std::string& filepath);

    /*!
     * @brief source_grid.txt を書き出す
     * @param filepath ファイルパス
     */
    void save(const std::string& filepath) const;

    /// 設定を取得
    const SourceGridConfig& showConfig() const;

    /// 設定を設定
    void setConfig(const SourceGridConfig& config);

    /*!
     * @brief グリッド座標を生成
     * @return 全グリッド点の(x, y)座標リスト
     * 
     * 奇数グリッド: 軸を含む (-1.0, -0.5, 0.0, 0.5, 1.0 など)
     * 偶数グリッド: 軸を含まない (-0.75, -0.25, 0.25, 0.75 など)
     */
    std::vector<std::pair<double, double>> generateGridPoints() const;

    /*!
     * @brief 有効な光源点（sigma範囲内）のグリッド座標を生成
     * @return sigma_min <= |r| <= sigma_max のグリッド点リスト
     */
    std::vector<std::pair<double, double>> generateValidGridPoints() const;

    /*!
     * @brief sourceIDを生成
     * @param x X座標
     * @param y Y座標
     * @return "x0.500000_y0.300000" 形式の文字列
     */
    static std::string makeSourceID(double x, double y);

    /*!
     * @brief sourceIDから座標を取得
     * @param sourceID "x0.500000_y0.300000" 形式の文字列
     * @return (x, y) 座標
     */
    static std::pair<double, double> parseSourceID(const std::string& sourceID);
};

} // namespace so

#endif // SO_SOURCE_GRID_H
