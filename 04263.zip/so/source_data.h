/*!
 * @file source_data.h
 * @brief 光源強度データの読み込み・管理
 */

#ifndef SO_SOURCE_DATA_H
#define SO_SOURCE_DATA_H

#include <so/types.h>
#include "source_grid.h"
#include <string>
#include <vector>
#include <map>
#include <utility>

namespace so {

/*!
 * @brief 光源強度データ管理クラス
 * 
 * source_file の読み込みと、強度値の取得・設定を行う
 */
class SourceData {
private:
    std::vector<SourcePoint> m_points;
    
    /// (x, y) -> intensity のマップ（高速検索用）
    std::map<std::pair<double, double>, double> m_intensityMap;
    
    /// マップのキー生成（浮動小数点の丸め処理込み）
    static std::pair<double, double> makeKey(double x, double y);

public:
    SourceData();
    ~SourceData();

    /*!
     * @brief 光源ファイルを読み込む
     * @param filepath ファイルパス
     * @throw std::runtime_error ファイルが開けない
     */
    void load(const std::string& filepath);

    /*!
     * @brief 光源ファイルを書き出す
     * @param filepath ファイルパス
     */
    void save(const std::string& filepath) const;

    /*!
     * @brief 光源分布をPPM画像として保存
     * @param filepath 出力ファイルパス（.ppm）
     * @param grid グリッド設定（画像サイズ決定用）
     */
    void savePpm(const std::string& filepath, const SourceGrid& grid) const;

    /// 全光源点を取得
    const std::vector<SourcePoint>& showPoints() const;

    /// 光源点数を取得
    size_t size() const;

    /*!
     * @brief 座標から強度を取得
     * @param x X座標
     * @param y Y座標
     * @return 強度値（見つからない場合は0.0）
     */
    double getIntensity(double x, double y) const;

    /*!
     * @brief D2対称時: x,y>=0 の点の強度を取得
     * @param x X座標
     * @param y Y座標
     * @return 第1象限の対応点の強度値
     */
    double getIntensityFirstQuadrant(double x, double y) const;

    /*!
     * @brief 強度を設定（最適化用）
     * @param x X座標
     * @param y Y座標
     * @param intensity 強度値
     */
    void setIntensity(double x, double y, double intensity);

    /*!
     * @brief source_fill_ratioを計算
     * @param NA 開口数
     * @return source_fill_ratio = Σs(i) / (s_max * N) * (NA/1.35)^2
     *         N = 単位円内（x² + y² ≤ 1）の点数
     */
    double calcSourceFillRatio(double NA) const;

    /// 最大強度を取得
    double showMaxIntensity() const;

    /// 強度の合計を取得
    double showTotalIntensity() const;

    /*!
     * @brief 光源点を追加
     * @param point 光源点
     */
    void addPoint(const SourcePoint& point);

    /// 全データをクリア
    void clear();

    /*!
     * @brief D2対称性を強制（第1象限の値を他の象限にコピー）
     *
     * 第1象限（x>=0, y>=0）の強度値を対称な位置にコピーする。
     * リスタート時の摂動後にD2対称性を維持するために使用。
     */
    void enforceD2Symmetry();

    /// 可変参照で光源点リストを取得（最適化用）
    std::vector<SourcePoint>& points() { return m_points; }
};

/*!
 * @brief 光源データ検証クラス
 */
class SourceValidator {
public:
    /*!
     * @brief グリッド上の全点を含むか検証
     * @param data 光源データ
     * @param grid グリッド設定
     * @return 全点を含んでいればtrue
     */
    static bool validateGridCoverage(const SourceData& data, const SourceGrid& grid);

    /*!
     * @brief 強度が非負か検証
     * @param data 光源データ
     * @return 全て非負ならtrue
     */
    static bool validateNonNegativeIntensity(const SourceData& data);

    /*!
     * @brief グリッド一致チェック
     * @param data 光源データ
     * @param grid グリッド設定
     * @return 全点がグリッド上にあればtrue
     */
    static bool validateGridAlignment(const SourceData& data, const SourceGrid& grid);

    /*!
     * @brief D2対称性チェック
     * @param data 光源データ
     * @param grid グリッド設定
     * @return D2対称であればtrue（D2設定でなければ常にtrue）
     */
    static bool validateD2Symmetry(const SourceData& data, const SourceGrid& grid);

    /*!
     * @brief σ範囲チェック
     * @param data 光源データ
     * @param grid グリッド設定
     * @return σ範囲外に非ゼロ強度がなければtrue
     */
    static bool validateSigmaRange(const SourceData& data, const SourceGrid& grid);

    /*!
     * @brief 全検証を実行
     * @param data 光源データ
     * @param grid グリッド設定
     * @return 全て合格ならtrue
     */
    static bool validateAll(const SourceData& data, const SourceGrid& grid);
};

} // namespace so

#endif // SO_SOURCE_DATA_H
