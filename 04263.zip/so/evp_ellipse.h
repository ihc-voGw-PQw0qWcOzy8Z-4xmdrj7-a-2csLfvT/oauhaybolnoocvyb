#ifndef SO_ELLIPSE_H
#define SO_ELLIPSE_H

#include <so/types.h>
#include <vector>

namespace so {

/**
 * @brief 座標を1/d単位に丸める
 * @param value 丸める前の値
 * @param d 座標精度（デフォルト: 8000）
 * @return 丸めた後の値
 */
double roundCoordinate(double value, int d = 8000);

/**
 * @brief 楕円上の点における法線方向の角度を計算する
 * @param theta 楕円の中心からの角度（ラジアン）
 * @param a X方向の半軸
 * @param b Y方向の半軸
 * @return 法線方向の角度（度）
 */
double calculateNormalAngle(double theta, double a, double b);

/**
 * @brief 矩形から楕円上の評価点を計算する
 * @param rect 矩形
 * @param clipID クリップID
 * @param config 設定パラメータ
 * @return 評価点のリスト
 */
std::vector<EvalPoint> calculateEvalPoints(const Rectangle& rect, int clipID, const EvpConfig& config);

/**
 * @brief 複数の矩形から全ての評価点を計算する
 * @param rectangles 矩形のリスト
 * @param config 設定パラメータ
 * @return 全評価点のリスト
 */
std::vector<EvalPoint> calculateAllEvalPoints(const std::vector<Rectangle>& rectangles, const EvpConfig& config);

} // namespace so

#endif // SO_ELLIPSE_H
