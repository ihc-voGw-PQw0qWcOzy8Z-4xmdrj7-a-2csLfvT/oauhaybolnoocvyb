/*!
 * @file adam_optimizer.h
 * @brief Adamオプティマイザ
 */

#ifndef SO_ADAM_OPTIMIZER_H
#define SO_ADAM_OPTIMIZER_H

#include "optimizer_base.h"

namespace so {

/*!
 * @brief Adamオプティマイザ
 *
 * 1次・2次モーメント推定による適応学習率最適化
 */
class AdamOptimizer : public OptimizerBase {
public:
    AdamOptimizer();
    ~AdamOptimizer() override;

    /*!
     * @brief 最適化を実行
     */
    OptimizationResult optimize(
        const std::vector<double>& x0,
        CostFunction costFunc,
        GradientFunction gradFunc,
        ProjectionFunction projFunc) override;

private:
    std::vector<double> m_m;  ///< 1次モーメント
    std::vector<double> m_v;  ///< 2次モーメント
};

} // namespace so

#endif // SO_ADAM_OPTIMIZER_H
