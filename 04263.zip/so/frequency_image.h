/*!
 * @file frequency_image.h
 * @brief 周波数空間での光学像表現
 */

#ifndef SO_FREQUENCY_IMAGE_H
#define SO_FREQUENCY_IMAGE_H

#include <vector>
#include <complex>
#include <string>

namespace so {

/*!
 * @brief 点での評価結果（強度と勾配）
 */
struct PointValue {
    double intensity = 0.0;  ///< I(x,y)
    double gradX = 0.0;      ///< ∂I/∂x
    double gradY = 0.0;      ///< ∂I/∂y
};

/*!
 * @brief 周波数空間での光学像
 * 
 * 周波数空間でデータを保持し、任意の点での強度と勾配を
 * Inverse DFTにより解析的に計算する。
 */
class FrequencyImage {
public:
    FrequencyImage() = default;
    ~FrequencyImage() = default;
    
    // コピー・ムーブ
    FrequencyImage(const FrequencyImage&) = default;
    FrequencyImage& operator=(const FrequencyImage&) = default;
    FrequencyImage(FrequencyImage&&) = default;
    FrequencyImage& operator=(FrequencyImage&&) = default;

    /*!
     * @brief 初期化
     * @param dimx X方向のサイズ
     * @param dimy Y方向のサイズ
     * @param Lx X方向の物理サイズ [μm]
     * @param Ly Y方向の物理サイズ [μm]
     */
    void initialize(int dimx, int dimy, double Lx, double Ly);

    /*!
     * @brief 周波数空間データを設定
     * @param data 周波数空間データ（fftshift済み、DC成分が中央）
     */
    void setData(std::vector<std::complex<double>>&& data);
    void setData(const std::vector<std::complex<double>>& data);

    // アクセサ
    int dimx() const { return m_dimx; }
    int dimy() const { return m_dimy; }
    double Lx() const { return m_Lx; }
    double Ly() const { return m_Ly; }
    size_t size() const { return m_data.size(); }
    bool empty() const { return m_data.empty(); }
    
    const std::vector<std::complex<double>>& data() const { return m_data; }
    std::vector<std::complex<double>>& data() { return m_data; }

    /*!
     * @brief 指定点での強度と勾配を計算（Inverse DFT）
     * @param x X座標 [μm]（画像中心が原点）
     * @param y Y座標 [μm]（画像中心が原点）
     * @return PointValue 強度と勾配
     */
    PointValue evalAt(double x, double y) const;

    /*!
     * @brief 重み付け加算
     * @param other 加算する画像
     * @param weight 重み
     * 
     * this += other * weight
     */
    void addWeighted(const FrequencyImage& other, double weight);

    /*!
     * @brief スカラー倍
     * @param factor スケール係数
     */
    void scale(double factor);

    /*!
     * @brief ゼロクリア
     */
    void clear();

    /*!
     * @brief 実空間画像に変換（IFFT）
     * @return 実空間データ
     */
    std::vector<double> toRealSpace() const;

    /*!
     * @brief 実空間画像としてバイナリ保存
     * @param filepath 保存先パス
     */
    void saveAsRealImage(const std::string& filepath) const;

    /*!
     * @brief 周波数空間データをバイナリ保存
     * @param filepath 保存先パス
     */
    void save(const std::string& filepath) const;

    /*!
     * @brief 周波数空間データをバイナリ読み込み
     * @param filepath ファイルパス
     */
    void load(const std::string& filepath);

    /*!
     * @brief 実空間データから周波数空間画像を生成（FFT）
     * @param realData 実空間データ
     * @param dimx X方向サイズ
     * @param dimy Y方向サイズ
     * @param Lx X方向物理サイズ [μm]
     * @param Ly Y方向物理サイズ [μm]
     * @return 周波数空間画像
     */
    static FrequencyImage fromRealSpace(const std::vector<double>& realData,
                                         int dimx, int dimy, double Lx, double Ly);

    /*!
     * @brief バイナリファイルから実空間画像を読み込みFFT
     * @param filepath ファイルパス
     * @param dimx X方向サイズ
     * @param dimy Y方向サイズ
     * @param Lx X方向物理サイズ [μm]
     * @param Ly Y方向物理サイズ [μm]
     * @return 周波数空間画像
     */
    static FrequencyImage loadFromRealImage(const std::string& filepath,
                                             int dimx, int dimy, double Lx, double Ly);

private:
    std::vector<std::complex<double>> m_data;  ///< 周波数空間データ
    int m_dimx = 0;
    int m_dimy = 0;
    double m_Lx = 0.0;  ///< X方向物理サイズ [μm]
    double m_Ly = 0.0;  ///< Y方向物理サイズ [μm]
};

} // namespace so

#endif // SO_FREQUENCY_IMAGE_H
