/*!
 * @file process_config.cpp
 * @brief process_config.txt パーサー
 */

#include "process_config.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <set>

namespace so {

ProcessConfig::ProcessConfig() {}

ProcessConfig::~ProcessConfig() {}

void ProcessConfig::load(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open process_config file: " + filepath);
    }

    clear();

    std::string line;
    bool inPwcSection = false;

    while (std::getline(file, line)) {
        // 空行をスキップ
        if (line.empty()) {
            continue;
        }

        // コメント行をスキップ
        if (line[0] == '#') {
            continue;
        }

        // セクション終了
        if (line.find("</pwc>") != std::string::npos) {
            inPwcSection = false;
            continue;
        }

        // セクション開始
        if (line.find("<pwc>") != std::string::npos) {
            inPwcSection = true;
            continue;
        }

        if (inPwcSection) {
            // PWC行をパース: "defocus mask_bias delta_dose weight"
            std::istringstream iss(line);
            PwcCondition pwc;
            
            if (iss >> pwc.defocus >> pwc.mask_bias >> pwc.delta_dose >> pwc.weight) {
                m_pwcConditions.push_back(pwc);
            }
        }
    }
}

void ProcessConfig::save(const std::string& filepath) const {
    std::ofstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }

    file << "<pwc>\n";
    file << "# defocus[nm] mask_bias[nm] delta_dose[%] weight\n";
    
    for (const auto& pwc : m_pwcConditions) {
        file << pwc.defocus << " " 
             << pwc.mask_bias << " " 
             << pwc.delta_dose << " " 
             << pwc.weight << "\n";
    }
    
    file << "</pwc>\n";
}

const std::vector<PwcCondition>& ProcessConfig::showPwcConditions() const {
    return m_pwcConditions;
}

void ProcessConfig::addPwcCondition(const PwcCondition& pwc) {
    m_pwcConditions.push_back(pwc);
}

size_t ProcessConfig::size() const {
    return m_pwcConditions.size();
}

int ProcessConfig::findNominalIndex() const {
    for (size_t i = 0; i < m_pwcConditions.size(); ++i) {
        if (m_pwcConditions[i].isNominal()) {
            return static_cast<int>(i);
        }
    }
    // 見つからなければ最初の条件を返す
    return 0;
}

std::vector<double> ProcessConfig::showUniqueDefocuses() const {
    std::set<double> unique;
    for (const auto& pwc : m_pwcConditions) {
        unique.insert(pwc.defocus);
    }
    return std::vector<double>(unique.begin(), unique.end());
}

std::vector<double> ProcessConfig::showUniqueMaskBiases() const {
    std::set<double> unique;
    for (const auto& pwc : m_pwcConditions) {
        unique.insert(pwc.mask_bias);
    }
    return std::vector<double>(unique.begin(), unique.end());
}

void ProcessConfig::clear() {
    m_pwcConditions.clear();
}

} // namespace so
