#include "cutline_writer.h"
#include <fstream>
#include <stdexcept>
#include <cmath>

namespace so {

std::vector<CutlineInfo> extractCutlineInfo(const std::vector<EvalPoint>& points, int numClips, int n) {
    std::vector<CutlineInfo> cutlines;
    
    for (int clipID = 0; clipID < numClips; ++clipID) {
        CutlineInfo info;
        info.clipID = clipID;
        
        // このclipIDに対応する評価点を探す
        int startIdx = clipID * n;
        
        double cx = 0, cy = 0;
        bool foundXL = false, foundXR = false, foundYT = false, foundYB = false;
        double xlPx = 0, xlPy = 0;
        double xrPx = 0, xrPy = 0;
        double ytPx = 0, ytPy = 0;
        double ybPx = 0, ybPy = 0;
        
        for (int i = 0; i < n && (startIdx + i) < static_cast<int>(points.size()); ++i) {
            const auto& pt = points[startIdx + i];
            cx = pt.cx;
            cy = pt.cy;
            
            if (pt.cutlineID == "cl_xl") {
                xlPx = pt.px;
                xlPy = pt.py;
                foundXL = true;
            } else if (pt.cutlineID == "cl_xr") {
                xrPx = pt.px;
                xrPy = pt.py;
                foundXR = true;
            } else if (pt.cutlineID == "cl_yt") {
                ytPx = pt.px;
                ytPy = pt.py;
                foundYT = true;
            } else if (pt.cutlineID == "cl_yb") {
                ybPx = pt.px;
                ybPy = pt.py;
                foundYB = true;
            }
        }
        
        // 水平cutline (cl_xl -> cl_xr)
        if (foundXL && foundXR) {
            info.hStartX = cx + xlPx;
            info.hStartY = cy + xlPy;
            info.hEndX = cx + xrPx;
            info.hEndY = cy + xrPy;
        }
        
        // 垂直cutline (cl_yb -> cl_yt)
        if (foundYB && foundYT) {
            info.vStartX = cx + ybPx;
            info.vStartY = cy + ybPy;
            info.vEndX = cx + ytPx;
            info.vEndY = cy + ytPy;
        }
        
        cutlines.push_back(info);
    }
    
    return cutlines;
}

std::vector<EvalPointAbs> convertToAbsoluteCoords(const std::vector<EvalPoint>& points) {
    std::vector<EvalPointAbs> absPoints;
    
    for (const auto& pt : points) {
        EvalPointAbs absPt;
        absPt.clipID = pt.clipID;
        absPt.x = pt.cx + pt.px;
        absPt.y = pt.cy + pt.py;
        absPoints.push_back(absPt);
    }
    
    return absPoints;
}

void writeCutlineErr(const std::string& filename,
                     const std::vector<CutlineInfo>& cutlines,
                     const std::vector<EvalPointAbs>& evalPoints,
                     int n,
                     int d) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Error: Cannot create output file: " + filename);
    }
    
    // ヘッダー行
    file << "TOP " << d << "\n";
    
    // 全てのCUTLINEセクションを出力
    for (const auto& cl : cutlines) {
        file << "CUTLINE_" << cl.clipID << "\n";
        file << "2 2 1 May 2 00:00:00 1978\n";
        file << "hoge\n";
        
        // 水平cutline (p 1 2)
        file << "p 1 2\n";
        file << static_cast<long long>(std::round(cl.hStartX * d)) << " "
             << static_cast<long long>(std::round(cl.hStartY * d)) << "\n";
        file << static_cast<long long>(std::round(cl.hEndX * d)) << " "
             << static_cast<long long>(std::round(cl.hEndY * d)) << "\n";
        
        // 垂直cutline (p 2 2)
        file << "p 2 2\n";
        file << static_cast<long long>(std::round(cl.vStartX * d)) << " "
             << static_cast<long long>(std::round(cl.vStartY * d)) << "\n";
        file << static_cast<long long>(std::round(cl.vEndX * d)) << " "
             << static_cast<long long>(std::round(cl.vEndY * d)) << "\n";
    }
    
    // 全てのEVPセクションを出力
    int numClips = static_cast<int>(cutlines.size());
    for (int clipID = 0; clipID < numClips; ++clipID) {
        file << "EVP_" << clipID << "\n";
        file << n << " " << n << " 1 May 2 00:00:00 1978\n";
        file << "hoge\n";
        
        // このclipIDに対応する評価点を出力
        int pointIdx = 1;
        for (const auto& pt : evalPoints) {
            if (pt.clipID == clipID) {
                file << "p " << pointIdx << " 1\n";
                file << static_cast<long long>(std::round(pt.x * d)) << " "
                     << static_cast<long long>(std::round(pt.y * d)) << "\n";
                ++pointIdx;
            }
        }
    }
    
    file.close();
}

} // namespace so
