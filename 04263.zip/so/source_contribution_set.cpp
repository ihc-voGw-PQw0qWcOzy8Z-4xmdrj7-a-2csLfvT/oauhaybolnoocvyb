/*!
 * @file source_contribution_set.cpp
 * @brief 1条件の全光源点データの集合の実装
 */

#include "source_contribution_set.h"
#include <fstream>
#include <stdexcept>
#include <cmath>
#include <cstring>
#include <iostream>

namespace so {

namespace {
    constexpr double COORD_TOLERANCE = 1e-9;
}

void SourceContributionSet::setDimensions(int dimx, int dimy, double Lx, double Ly) {
    m_dimx = dimx;
    m_dimy = dimy;
    m_Lx = Lx;
    m_Ly = Ly;
}

void SourceContributionSet::setD2Symmetry(bool isD2) {
    m_isD2Symmetry = isD2;
}

bool SourceContributionSet::addContribution(SourceContribution&& contrib) {
    // D2対称時は第1象限のみ受け付ける
    if (m_isD2Symmetry) {
        if (contrib.gx < -COORD_TOLERANCE || contrib.gy < -COORD_TOLERANCE) {
            std::cerr << "Warning: D2 symmetry is enabled but received non-first-quadrant coordinate: ("
                      << contrib.gx << ", " << contrib.gy << "). Skipping." << std::endl;
            return false;
        }
    }
    m_contributions.push_back(std::move(contrib));
    return true;
}

bool SourceContributionSet::addContribution(const SourceContribution& contrib) {
    // D2対称時は第1象限のみ受け付ける
    if (m_isD2Symmetry) {
        if (contrib.gx < -COORD_TOLERANCE || contrib.gy < -COORD_TOLERANCE) {
            std::cerr << "Warning: D2 symmetry is enabled but received non-first-quadrant coordinate: ("
                      << contrib.gx << ", " << contrib.gy << "). Skipping." << std::endl;
            return false;
        }
    }
    m_contributions.push_back(contrib);
    return true;
}

FrequencyImage SourceContributionSet::combine(
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig) const {
    
    FrequencyImage result;
    result.initialize(m_dimx, m_dimy, m_Lx, m_Ly);
    
    if (m_contributions.empty()) {
        return result;
    }

    double totalWeight = 0.0;

    for (const auto& contrib : m_contributions) {
        // 光源強度 s_i を取得
        double intensity;
        if (gridConfig.isD2Symmetry()) {
            intensity = sourceData.getIntensityFirstQuadrant(contrib.gx, contrib.gy);
        } else {
            intensity = sourceData.getIntensity(contrib.gx, contrib.gy);
        }
        
        if (intensity <= 0.0) {
            continue;
        }

        // 重み = norm_i * s_i
        double weight = contrib.norm * intensity;
        // Σ (norm_i * s_i * F_i) を計算
        result.addWeighted(contrib.freqImage, weight);
        totalWeight += weight;
    }

    // 正規化: F = Σ (norm_i * s_i * F_i) / Σ (norm_i * s_i)
    if (totalWeight > 0.0) {
        result.scale(1.0 / totalWeight);
    }

    return result;
}

FrequencyImage SourceContributionSet::combineWithDoseCorrection(
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    double deltaDose) const {
    
    FrequencyImage result = combine(sourceData, gridConfig);
    
    // delta_dose補正: I_corrected = I * (1 + deltaDose/100)
    if (std::abs(deltaDose) > 1e-9) {
        result.scale(1.0 + deltaDose / 100.0);
    }
    
    return result;
}

void SourceContributionSet::save(const std::string& filepath) const {
    std::ofstream ofs(filepath, std::ios::binary);
    if (!ofs) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }

    // ヘッダ
    ofs.write(reinterpret_cast<const char*>(&m_dimx), sizeof(m_dimx));
    ofs.write(reinterpret_cast<const char*>(&m_dimy), sizeof(m_dimy));
    ofs.write(reinterpret_cast<const char*>(&m_Lx), sizeof(m_Lx));
    ofs.write(reinterpret_cast<const char*>(&m_Ly), sizeof(m_Ly));

    // 光源点数
    size_t numContribs = m_contributions.size();
    ofs.write(reinterpret_cast<const char*>(&numContribs), sizeof(numContribs));

    // 各光源点のデータ
    for (const auto& contrib : m_contributions) {
        // sourceID
        size_t idLen = contrib.sourceID.size();
        ofs.write(reinterpret_cast<const char*>(&idLen), sizeof(idLen));
        ofs.write(contrib.sourceID.c_str(), idLen);

        // メタデータ
        ofs.write(reinterpret_cast<const char*>(&contrib.gx), sizeof(contrib.gx));
        ofs.write(reinterpret_cast<const char*>(&contrib.gy), sizeof(contrib.gy));
        ofs.write(reinterpret_cast<const char*>(&contrib.norm), sizeof(contrib.norm));

        // 周波数空間データ
        const auto& fdata = contrib.freqImage.data();
        ofs.write(reinterpret_cast<const char*>(fdata.data()), 
                  fdata.size() * sizeof(std::complex<double>));
    }
}

void SourceContributionSet::load(const std::string& filepath) {
    std::ifstream ifs(filepath, std::ios::binary);
    if (!ifs) {
        throw std::runtime_error("Cannot open file for reading: " + filepath);
    }

    // ヘッダ
    ifs.read(reinterpret_cast<char*>(&m_dimx), sizeof(m_dimx));
    ifs.read(reinterpret_cast<char*>(&m_dimy), sizeof(m_dimy));
    ifs.read(reinterpret_cast<char*>(&m_Lx), sizeof(m_Lx));
    ifs.read(reinterpret_cast<char*>(&m_Ly), sizeof(m_Ly));

    // 光源点数
    size_t numContribs;
    ifs.read(reinterpret_cast<char*>(&numContribs), sizeof(numContribs));

    m_contributions.clear();
    m_contributions.reserve(numContribs);

    // 各光源点のデータ
    for (size_t i = 0; i < numContribs; ++i) {
        SourceContribution contrib;

        // sourceID
        size_t idLen;
        ifs.read(reinterpret_cast<char*>(&idLen), sizeof(idLen));
        contrib.sourceID.resize(idLen);
        ifs.read(&contrib.sourceID[0], idLen);

        // メタデータ
        ifs.read(reinterpret_cast<char*>(&contrib.gx), sizeof(contrib.gx));
        ifs.read(reinterpret_cast<char*>(&contrib.gy), sizeof(contrib.gy));
        ifs.read(reinterpret_cast<char*>(&contrib.norm), sizeof(contrib.norm));

        // 周波数空間データ
        contrib.freqImage.initialize(m_dimx, m_dimy, m_Lx, m_Ly);
        std::vector<std::complex<double>> fdata(m_dimx * m_dimy);
        ifs.read(reinterpret_cast<char*>(fdata.data()), 
                 fdata.size() * sizeof(std::complex<double>));
        contrib.freqImage.setData(std::move(fdata));

        m_contributions.push_back(std::move(contrib));
    }
}

std::vector<char> SourceContributionSet::serialize() const {
    std::vector<char> buf;

    auto append = [&buf](const void* ptr, size_t sz) {
        const char* p = reinterpret_cast<const char*>(ptr);
        buf.insert(buf.end(), p, p + sz);
    };

    // ヘッダ
    append(&m_dimx, sizeof(m_dimx));
    append(&m_dimy, sizeof(m_dimy));
    append(&m_Lx, sizeof(m_Lx));
    append(&m_Ly, sizeof(m_Ly));

    // 光源点数
    size_t numContribs = m_contributions.size();
    append(&numContribs, sizeof(numContribs));

    // 各光源点のデータ
    for (const auto& contrib : m_contributions) {
        size_t idLen = contrib.sourceID.size();
        append(&idLen, sizeof(idLen));
        append(contrib.sourceID.c_str(), idLen);

        append(&contrib.gx, sizeof(contrib.gx));
        append(&contrib.gy, sizeof(contrib.gy));
        append(&contrib.norm, sizeof(contrib.norm));

        const auto& fdata = contrib.freqImage.data();
        append(fdata.data(), fdata.size() * sizeof(std::complex<double>));
    }

    return buf;
}

void SourceContributionSet::deserialize(const char* data, size_t size) {
    size_t offset = 0;

    auto readBuf = [&](void* dst, size_t sz) {
        std::memcpy(dst, data + offset, sz);
        offset += sz;
    };

    // ヘッダ
    readBuf(&m_dimx, sizeof(m_dimx));
    readBuf(&m_dimy, sizeof(m_dimy));
    readBuf(&m_Lx, sizeof(m_Lx));
    readBuf(&m_Ly, sizeof(m_Ly));

    // 光源点数
    size_t numContribs;
    readBuf(&numContribs, sizeof(numContribs));

    m_contributions.clear();
    m_contributions.reserve(numContribs);

    for (size_t i = 0; i < numContribs; ++i) {
        SourceContribution contrib;

        size_t idLen;
        readBuf(&idLen, sizeof(idLen));
        contrib.sourceID.resize(idLen);
        readBuf(&contrib.sourceID[0], idLen);

        readBuf(&contrib.gx, sizeof(contrib.gx));
        readBuf(&contrib.gy, sizeof(contrib.gy));
        readBuf(&contrib.norm, sizeof(contrib.norm));

        contrib.freqImage.initialize(m_dimx, m_dimy, m_Lx, m_Ly);
        std::vector<std::complex<double>> fdata(m_dimx * m_dimy);
        readBuf(fdata.data(), fdata.size() * sizeof(std::complex<double>));
        contrib.freqImage.setData(std::move(fdata));

        m_contributions.push_back(std::move(contrib));
    }
}

} // namespace so
