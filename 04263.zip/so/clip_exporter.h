/*!
 * @file clip_exporter.h
 * @brief Clip領域のOASISエクスポート機能
 */

#ifndef SO_CLIP_EXPORTER_H
#define SO_CLIP_EXPORTER_H

#include <so/evp_data.h>
#include <string>
#include <vector>
#include <utility>

namespace so {

/*!
 * @brief Clip領域をOASIS形式でエクスポートするクラス
 */
class ClipExporter {
private:
    std::string m_oasisFile;       ///< 入力OASISファイル
    std::string m_cellname;        ///< セル名
    std::vector<std::pair<int, int>> m_layers;  ///< レイヤー/データタイプ
    double m_Lx = 10.0;            ///< X方向サイズ [μm]
    double m_Ly = 10.0;            ///< Y方向サイズ [μm]
    double m_margin = 0.125;       ///< マージン [μm]
    int m_baseDatatype = 0;        ///< maskBias出力時のベースデータタイプ

public:
    ClipExporter();
    ~ClipExporter();

    /// 入力OASISファイルを設定
    void setOasisFile(const std::string& file);

    /// セル名を設定
    void setCellname(const std::string& name);

    /// レイヤーを設定
    void setLayers(const std::vector<std::pair<int, int>>& layers);

    /// 計算領域サイズを設定
    void setSize(double Lx, double Ly);

    /// マージンを設定
    void setMargin(double margin);

    /// maskBias出力時のベースデータタイプを設定
    void setBaseDatatype(int datatype);

    /*!
     * @brief 単一clipをOASIS形式でエクスポート
     * @param clip クリップ情報
     * @param outputFile 出力ファイルパス
     */
    void exportClip(const ClipInfo& clip, const std::string& outputFile) const;

    /*!
     * @brief 全clipをOASIS形式でエクスポート
     * @param evpData 評価点データ
     * @param outputDir 出力ディレクトリ
     *
     * ファイル名: clip<ID>.oas (例: clip0.oas, clip1.oas)
     */
    void exportAllClips(const EvpData& evpData, const std::string& outputDir) const;

    /*!
     * @brief maskBias付きで単一clipをOASIS形式でエクスポート
     * @param clip クリップ情報
     * @param maskBiases maskBias値リスト [nm]
     * @param outputFile 出力ファイルパス
     *
     * 各maskBias値ごとに異なるデータタイプで出力:
     * - datatype = baseDatatype + index
     */
    void exportClipWithMaskBias(const ClipInfo& clip,
                                 const std::vector<double>& maskBiases,
                                 const std::string& outputFile) const;

    /*!
     * @brief maskBias付きで全clipをOASIS形式でエクスポート
     * @param evpData 評価点データ
     * @param maskBiases maskBias値リスト [nm]
     * @param outputDir 出力ディレクトリ
     *
     * ファイル名: clip<ID>.oas
     * 各maskBias値ごとに異なるデータタイプで同一ファイルに出力
     */
    void exportAllClipsWithMaskBias(const EvpData& evpData,
                                     const std::vector<double>& maskBiases,
                                     const std::string& outputDir) const;

    /*!
     * @brief 出力ファイル名を生成
     * @param clipID クリップID
     * @return ファイル名 (例: "clip0.oas")
     */
    static std::string makeFileName(int clipID);
};

} // namespace so

#endif // SO_CLIP_EXPORTER_H
