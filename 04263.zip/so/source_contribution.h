/*!
 * @file source_contribution.h
 * @brief 光源点ごとの寄与データ
 */

#ifndef SO_SOURCE_CONTRIBUTION_H
#define SO_SOURCE_CONTRIBUTION_H

#include "frequency_image.h"
#include <string>

namespace so {

/*!
 * @brief 1光源点の寄与
 */
struct SourceContribution {
    std::string sourceID;     ///< 光源点ID (例: "gx0.5_gy0.3")
    double gx = 0.0;          ///< 光源X座標
    double gy = 0.0;          ///< 光源Y座標
    double norm = 1.0;        ///< SOCS正規化係数
    FrequencyImage freqImage; ///< 周波数空間画像
};

} // namespace so

#endif // SO_SOURCE_CONTRIBUTION_H
