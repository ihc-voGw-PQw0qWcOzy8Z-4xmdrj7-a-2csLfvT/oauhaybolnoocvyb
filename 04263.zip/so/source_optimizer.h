/*!
 * @file source_optimizer.h
 * @brief メイン最適化クラス
 */

#ifndef SO_SOURCE_OPTIMIZER_H
#define SO_SOURCE_OPTIMIZER_H

#include <so/types.h>
#include "variable_mapping.h"
#include "constraint_handler.h"
#include "gradient_calculator.h"
#include "optimizer_base.h"
#include <so/source_data.h>
#include <so/source_grid.h>
#include <so/source_contribution_set.h>
#include <so/image_calculator.h>
#include <so/evp_data.h>
#include <so/process_config.h>
#include <so/cost_calculator.h>
#include <memory>
#include <map>
#include <string>

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

namespace so {

/*!
 * @brief メイン最適化クラス
 *
 * SourceContributionSetを事前計算し、最適化ループを実行
 */
class SourceOptimizer {
public:
    SourceOptimizer();
    ~SourceOptimizer();

    /*!
     * @brief オプションを設定
     */
    void setOptions(const OptimizationOptions& options);

    /*!
     * @brief データを設定
     */
    void setSourceGrid(const SourceGrid* sourceGrid);
    void setSourceData(SourceData* sourceData);
    // IRLS / adaptive weighting で内部的に重みを書き換えるため非 const
    void setEvpData(EvpData* evpData);
    void setProcessConfig(const ProcessConfig* processConfig);

    /*!
     * @brief 事前計算済みのSourceContributionSetを設定
     */
    void setSourceContributions(
        const std::map<std::string, SourceContributionSet>* sourceContributions);

    /*!
     * @brief NAを設定
     */
    void setNA(double NA);

#ifdef HAVE_MPI_H
    /*!
     * @brief MPIコミュニケータを設定
     * @param comm 使用するMPIコミュニケータ
     */
    void setMPIComm(MPI_Comm comm) { m_mpiComm = comm; }
#endif

    /*!
     * @brief 最適化を実行（Two-Stage有効時は自動的に2段階実行）
     * @return 最適化結果
     */
    OptimizationResult optimize();

    /*!
     * @brief 勾配の数値検証を実行
     * @param epsilon 差分幅
     * @return 解析勾配と数値勾配の最大相対誤差
     */
    double verifyGradient(double epsilon = 1e-6);

    /*!
     * @brief 現在のコストを計算
     */
    double calculateCurrentCost(double* outEpeCost = nullptr,
                                double* outSourceFillCost = nullptr);

    /*!
     * @brief slice levelを取得/設定
     */
    double sliceLevel() const { return m_sliceLevel; }
    void setSliceLevel(double level) { m_sliceLevel = level; }

    /*!
     * @brief 最適なslice levelを探索
     */
    double findOptimalSliceLevel();

private:
    OptimizationOptions m_options;
    VariableMapping m_variableMapping;
    ConstraintHandler m_constraintHandler;
    GradientCalculator m_gradientCalculator;
    std::unique_ptr<OptimizerBase> m_optimizer;

    const SourceGrid* m_sourceGrid = nullptr;
    SourceData* m_sourceData = nullptr;
    EvpData* m_evpData = nullptr;
    const ProcessConfig* m_processConfig = nullptr;
    // adaptive weighting (IRLS) 用: stage 開始前に保存される元の weight
    std::vector<double> m_originalEvpWeights;
    // SA 風 sliceLevel 摂動を有効化するフラグ（Multi-Stage Stage 1 のみ true）
    bool m_saActive = false;
    const std::map<std::string, SourceContributionSet>* m_sourceContributions = nullptr;
    double m_NA = 1.35;
    double m_sliceLevel = -1.0;
#ifdef HAVE_MPI_H
    MPI_Comm m_mpiComm = MPI_COMM_WORLD;  ///< MPIコミュニケータ
#endif
    // 時間計測用
    mutable int m_gradientCallCount = 0;
    mutable double m_totalGradientTime = 0.0;
    mutable int m_costCallCount = 0;
    mutable double m_totalCostTime = 0.0;

    /*!
     * @brief コスト関数（最適化ループで使用）
     */
    double costFunction(const std::vector<double>& variables);

    /*!
     * @brief 勾配関数（最適化ループで使用）
     */
    std::vector<double> gradientFunction(const std::vector<double>& variables);

    /*!
     * @brief 射影関数（最適化ループで使用）
     */
    void projectionFunction(std::vector<double>& variables);

    /*!
     * @brief オプティマイザを作成
     */
    void createOptimizer();

    /*!
     * @brief 単一ステージの最適化を実行（ラウンドループ含む）
     * @return 最適化結果
     */
    OptimizationResult optimizeSingleStage();
};

} // namespace so

#endif // SO_SOURCE_OPTIMIZER_H
