/*!
 * @file lbfgs_optimizer.cpp
 * @brief L-BFGS オプティマイザの実装（改善版）
 *
 * 改善点:
 * - ウィンドウベースの収束判定
 * - メモリリセット機構（停滞検出、非降下方向検出）
 * - 射影勾配によるBox制約対応
 * - 最良解追跡
 */

#include "lbfgs_optimizer.h"
#include <cmath>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <limits>

namespace so {

namespace {
    constexpr double WOLFE_C1 = 1e-4;    // Armijo条件
    constexpr double MIN_STEP = 1e-20;
    constexpr double MAX_STEP = 1e10;
    constexpr int MAX_LINE_SEARCH_ITER = 30;  // 増加
    constexpr double EPSILON = 1e-15;
    constexpr double BACKTRACK_FACTOR = 0.5;  // バックトラッキング係数
}

LBFGSOptimizer::LBFGSOptimizer() {}

LBFGSOptimizer::~LBFGSOptimizer() {}

void LBFGSOptimizer::resetMemory() {
    m_s.clear();
    m_y.clear();
    m_rho.clear();
    m_consecutiveSmallSteps = 0;
}

std::vector<double> LBFGSOptimizer::computeProjectedGradient(
    const std::vector<double>& x,
    const std::vector<double>& grad) const {

    std::vector<double> projGrad = grad;
    for (size_t i = 0; i < x.size(); ++i) {
        // 下限にいて、勾配が正（さらに下げたい方向）なら0にする
        if (x[i] <= m_options.minIntensity + EPSILON && grad[i] > 0) {
            projGrad[i] = 0.0;
        }
        // 上限にいて、勾配が負（さらに上げたい方向）なら0にする
        if (x[i] >= m_options.maxIntensity - EPSILON && grad[i] < 0) {
            projGrad[i] = 0.0;
        }
    }
    return projGrad;
}

bool LBFGSOptimizer::checkConvergence(
    const std::vector<double>& costHistory,
    double projGradNorm,
    std::string& reason) const {

    // 1. 射影勾配ノルムによる判定
    if (projGradNorm < m_options.gradientTolerance) {
        reason = "Gradient tolerance reached";
        return true;
    }

    // 2. ウィンドウベースの相対改善による判定
    int windowSize = m_options.lbfgsConvergenceWindow;
    if (static_cast<int>(costHistory.size()) >= windowSize * 2) {
        // 最近のwindowSize個の最小値
        auto recentBegin = costHistory.end() - windowSize;
        auto recentEnd = costHistory.end();
        double recentBest = *std::min_element(recentBegin, recentEnd);

        // その前のwindowSize個の最小値
        auto prevBegin = costHistory.end() - windowSize * 2;
        auto prevEnd = costHistory.end() - windowSize;
        double previousBest = *std::min_element(prevBegin, prevEnd);

        double relImprovement = std::abs(recentBest - previousBest)
                               / (std::abs(previousBest) + EPSILON);

        if (relImprovement < m_options.lbfgsRelativeTolerance) {
            reason = "Relative improvement below tolerance";
            return true;
        }
    }

    return false;
}

OptimizationResult LBFGSOptimizer::optimize(
    const std::vector<double>& x0,
    CostFunction costFunc,
    GradientFunction gradFunc,
    ProjectionFunction projFunc) {

    OptimizationResult result;
    m_memorySize = m_options.lbfgsMemorySize;

    // 履歴をクリア
    resetMemory();

    std::vector<double> x = x0;
    projFunc(x);  // 初期値を射影

    double f = costFunc(x);
    std::vector<double> g = gradFunc(x);
    std::vector<double> projG = computeProjectedGradient(x, g);
    double projGNorm = gradientNorm(projG);

    // コスト履歴（ウィンドウベース収束判定用）
    std::vector<double> costHistory;
    costHistory.push_back(f);

    // 最良解追跡
    double bestCost = f;
    std::vector<double> bestX = x;

    // 初期ログ
    OptimizationLogEntry logEntry;
    logEntry.iteration = 0;
    logEntry.cost = f;
    logEntry.gradientNorm = projGNorm;
    result.log.push_back(logEntry);

    if (m_options.verbose) {
        std::cerr << "L-BFGS Iteration 0: cost=" << std::fixed << std::setprecision(6) << f
                  << ", gradNorm=" << projGNorm << std::endl;
    }

    // 初期コストを記録（早期終了用）
    const double initialCost = f;

    // 初期状態で収束チェック（最低イテレーション数が設定されていない場合のみ）
    std::string convergenceReason;
    if (m_options.lbfgsMinIterations <= 0 &&
        checkConvergence(costHistory, projGNorm, convergenceReason)) {
        result.converged = true;
        result.iterations = 0;
        result.finalCost = f;
        result.finalGradientNorm = projGNorm;
        result.terminationReason = convergenceReason;
        result.finalVariables = x;
        return result;
    }

    for (int iter = 1; iter <= m_options.maxIterations; ++iter) {
        // 探索方向を計算（通常勾配を使用）
        std::vector<double> direction = computeDirection(g);

        // 降下方向かチェック
        double dirGradDot = dot(direction, g);
        if (dirGradDot >= -1e-10) {
            // 非降下方向：メモリリセットして最急降下法に切り替え
            if (m_options.verbose) {
                std::cerr << "L-BFGS: Non-descent direction detected, resetting memory" << std::endl;
            }
            resetMemory();
            // 最急降下方向
            direction.resize(g.size());
            for (size_t i = 0; i < g.size(); ++i) {
                direction[i] = -g[i];
            }
        }

        // 線形探索
        double alpha = lineSearch(x, direction, f, g, costFunc, gradFunc, projFunc);

        // 停滞検出
        if (alpha < m_options.lbfgsSmallStepThreshold) {
            m_consecutiveSmallSteps++;
            if (m_consecutiveSmallSteps > m_options.lbfgsMaxSmallSteps) {
                if (m_options.verbose) {
                    std::cerr << "L-BFGS: Stagnation detected, resetting memory" << std::endl;
                }
                resetMemory();
            }
        } else {
            m_consecutiveSmallSteps = 0;
        }

        if (alpha < MIN_STEP && m_s.empty()) {
            // メモリリセット後も線形探索が失敗する場合は終了。
            // 射影勾配ノルムが許容値以下であれば (source, slice) 同時停留点に
            // 到達しており、数値ノイズで Armijo 条件が満たせないだけなので
            // 収束扱いにして round ループも break させる。
            result.iterations = iter;
            result.finalCost = m_options.lbfgsTrackBestSolution ? bestCost : f;
            result.finalGradientNorm = projGNorm;
            result.finalVariables = m_options.lbfgsTrackBestSolution ? bestX : x;
            if (projGNorm < m_options.gradientTolerance) {
                result.converged = true;
                result.terminationReason = "Gradient tolerance reached (line search)";
            } else {
                result.converged = false;
                result.terminationReason = "Line search failed";
            }
            return result;
        }

        if (alpha < MIN_STEP) {
            // 線形探索失敗だがメモリがある場合はリセットして続行
            resetMemory();
            continue;
        }

        // パラメータ更新
        std::vector<double> xNew = axpy(alpha, x, direction);
        projFunc(xNew);

        double fNew = costFunc(xNew);
        std::vector<double> gNew = gradFunc(xNew);

        // s = x_new - x, y = g_new - g
        std::vector<double> s(x.size());
        std::vector<double> y(x.size());
        for (size_t i = 0; i < x.size(); ++i) {
            s[i] = xNew[i] - x[i];
            y[i] = gNew[i] - g[i];
        }

        // 履歴を更新
        updateHistory(s, y);

        // 状態を更新
        x = std::move(xNew);
        f = fNew;
        g = std::move(gNew);
        projG = computeProjectedGradient(x, g);
        projGNorm = gradientNorm(projG);

        // コスト履歴更新
        costHistory.push_back(f);

        // 最良解更新
        if (m_options.lbfgsTrackBestSolution && f < bestCost) {
            bestCost = f;
            bestX = x;
        }

        // ログ
        logEntry.iteration = iter;
        logEntry.cost = f;
        logEntry.gradientNorm = projGNorm;
        logEntry.stepSize = alpha;
        result.log.push_back(logEntry);

        if (m_options.verbose) {
            std::cerr << "L-BFGS Iteration " << iter << ": cost=" << std::fixed << std::setprecision(6) << f
                      << ", gradNorm=" << projGNorm
                      << ", step=" << alpha;
            if (m_options.lbfgsTrackBestSolution && f <= bestCost) {
                std::cerr << " [BEST]";
            }
            std::cerr << std::endl;
        }

        // ============================================================
        // 終了条件の優先順位（評価順）
        // ------------------------------------------------------------
        //  A. Early stop: cost stagnation
        //       → earlyStopPatience 反復前との相対改善 < earlyStopTolerance
        //  B. Early stop: sufficient cost reduction
        //       → 初期コストからの削減率 ≥ maxCostReduction
        //  C. checkConvergence(...)
        //       C1. 射影勾配ノルム < gradientTolerance
        //       C2. ウィンドウベース相対改善 < lbfgsRelativeTolerance
        //  D. iter > maxIterations（ループ末尾）
        //
        // A,B はラウンド内打ち切り（terminationReason に "Early stop" を含む）
        // で外側 round ループは続行。C,D は round 内収束として round ループも
        // break させる（source_optimizer.cpp:453 参照）。
        // ============================================================

        // === A. 小窓コスト改善率チェック ===
        if (m_options.earlyStopPatience > 0 &&
            iter >= m_options.lbfgsMinIterations &&
            static_cast<int>(costHistory.size()) > m_options.earlyStopPatience) {
            double oldCost = costHistory[costHistory.size() - 1 - m_options.earlyStopPatience];
            double relImprovement = (oldCost - f) / std::max(std::abs(oldCost), 1e-12);
            if (relImprovement < m_options.earlyStopTolerance) {
                result.converged = true;
                result.iterations = iter;
                result.finalCost = m_options.lbfgsTrackBestSolution ? bestCost : f;
                result.finalGradientNorm = projGNorm;
                result.terminationReason = "Early stop: cost stagnation";
                result.finalVariables = m_options.lbfgsTrackBestSolution ? bestX : x;
                if (m_options.verbose) {
                    std::cerr << "L-BFGS: Early stop (stagnation) at iter " << iter
                              << ", relImprovement=" << relImprovement << std::endl;
                }
                return result;
            }
        }

        // === B. ラウンドあたり最大コスト削減率 ===
        if (m_options.maxCostReduction > 0 && iter >= m_options.lbfgsMinIterations) {
            double reduction = (initialCost - f) / std::max(std::abs(initialCost), 1e-12);
            if (reduction >= m_options.maxCostReduction) {
                result.converged = true;
                result.iterations = iter;
                result.finalCost = m_options.lbfgsTrackBestSolution ? bestCost : f;
                result.finalGradientNorm = projGNorm;
                result.terminationReason = "Early stop: sufficient cost reduction";
                result.finalVariables = m_options.lbfgsTrackBestSolution ? bestX : x;
                if (m_options.verbose) {
                    std::cerr << "L-BFGS: Early stop (sufficient reduction) at iter " << iter
                              << ", reduction=" << reduction << std::endl;
                }
                return result;
            }
        }

        // 収束チェック（最低イテレーション数に達してから）
        if (iter >= m_options.lbfgsMinIterations &&
            checkConvergence(costHistory, projGNorm, convergenceReason)) {
            result.converged = true;
            result.iterations = iter;
            if (m_options.lbfgsTrackBestSolution) {
                result.finalCost = bestCost;
            } else {
                result.finalCost = f;
            }
            result.finalGradientNorm = projGNorm;
            result.terminationReason = convergenceReason;
            result.finalVariables = m_options.lbfgsTrackBestSolution ? bestX : x;
            return result;
        }
    }

    result.converged = false;
    result.iterations = m_options.maxIterations;
    if (m_options.lbfgsTrackBestSolution) {
        result.finalCost = bestCost;
    } else {
        result.finalCost = f;
    }
    result.finalGradientNorm = projGNorm;
    result.terminationReason = "Maximum iterations reached";
    result.finalVariables = m_options.lbfgsTrackBestSolution ? bestX : x;
    return result;
}

std::vector<double> LBFGSOptimizer::computeDirection(const std::vector<double>& grad) {
    const size_t n = grad.size();
    std::vector<double> q = grad;

    // 履歴がない場合は最急降下法
    if (m_s.empty()) {
        std::vector<double> direction(n);
        for (size_t i = 0; i < n; ++i) {
            direction[i] = -grad[i];
        }
        return direction;
    }

    // Two-loop recursion
    const size_t m = m_s.size();
    std::vector<double> alpha(m);

    // 第1ループ（新しい方から古い方へ）
    for (int i = static_cast<int>(m) - 1; i >= 0; --i) {
        if (std::abs(m_rho[i]) > EPSILON) {
            alpha[i] = m_rho[i] * dot(m_s[i], q);
            for (size_t j = 0; j < n; ++j) {
                q[j] -= alpha[i] * m_y[i][j];
            }
        } else {
            alpha[i] = 0.0;
        }
    }

    // 初期ヘッセ行列近似（スケーリング）
    double ys = dot(m_y.back(), m_s.back());
    double yy = dot(m_y.back(), m_y.back());
    double gamma = ys / (yy + EPSILON);

    // γが極端な場合のみクランプ
    if (gamma < 1e-10 || gamma > 1e10) {
        gamma = 1.0;
    }

    std::vector<double> r(n);
    for (size_t i = 0; i < n; ++i) {
        r[i] = gamma * q[i];
    }

    // 第2ループ（古い方から新しい方へ）
    for (size_t i = 0; i < m; ++i) {
        if (std::abs(m_rho[i]) > EPSILON) {
            double beta = m_rho[i] * dot(m_y[i], r);
            for (size_t j = 0; j < n; ++j) {
                r[j] += (alpha[i] - beta) * m_s[i][j];
            }
        }
    }

    // 方向を反転（最小化のため）
    for (size_t i = 0; i < n; ++i) {
        r[i] = -r[i];
    }

    return r;
}

double LBFGSOptimizer::lineSearch(
    const std::vector<double>& x,
    const std::vector<double>& direction,
    double f0,
    const std::vector<double>& g0,
    CostFunction costFunc,
    GradientFunction /* gradFunc */,
    ProjectionFunction projFunc) {

    double dg0 = dot(g0, direction);

    // 降下方向でない場合
    if (dg0 >= 0) {
        return 0.0;
    }

    // Armijo条件のみのバックトラッキング線形探索
    // 制約付き最適化ではCurvature条件は問題を起こすことがある
    double alpha = 1.0;
    double bestAlpha = 0.0;
    double bestF = f0;

    for (int iter = 0; iter < MAX_LINE_SEARCH_ITER; ++iter) {
        std::vector<double> xNew = axpy(alpha, x, direction);
        projFunc(xNew);

        double fNew = costFunc(xNew);

        // コストが改善した場合は記録
        if (fNew < bestF) {
            bestF = fNew;
            bestAlpha = alpha;
        }

        // Armijo条件（十分な減少）
        if (fNew <= f0 + WOLFE_C1 * alpha * dg0) {
            // 条件を満たした
            return alpha;
        }

        // バックトラッキング
        alpha *= BACKTRACK_FACTOR;

        if (alpha < MIN_STEP) {
            break;
        }
    }

    // Armijo条件を満たさなかったが、コストが改善していれば最良のステップを返す
    // これは制約に当たっている場合に有用
    if (bestAlpha > 0.0) {
        return bestAlpha;
    }

    return 0.0;
}

void LBFGSOptimizer::updateHistory(const std::vector<double>& s, const std::vector<double>& y) {
    double ys = dot(y, s);
    double sNorm = std::sqrt(dot(s, s));
    double yNorm = std::sqrt(dot(y, y));

    // 曲率条件: ys が正でない場合、または数値的に不安定な場合はスキップ
    if (ys <= 1e-12 * sNorm * yNorm || sNorm < EPSILON || yNorm < EPSILON) {
        return;
    }

    double rho = 1.0 / ys;

    // 履歴が上限に達したら古いものを削除
    if (static_cast<int>(m_s.size()) >= m_memorySize) {
        m_s.pop_front();
        m_y.pop_front();
        m_rho.pop_front();
    }

    m_s.push_back(s);
    m_y.push_back(y);
    m_rho.push_back(rho);
}

} // namespace so
