/*!
 * @file epe_newton.h
 * @brief Newton method EPE solver (shared implementation)
 *
 * This header provides a common Newton method implementation for finding
 * contour positions (EPE calculation). Used by both cost_calculator and
 * gradient_calculator.
 */

#ifndef SO_EPE_NEWTON_H
#define SO_EPE_NEWTON_H

#include "frequency_image.h"
#include <so/types.h>
#include <cmath>
#include <algorithm>

namespace so {

/*!
 * @brief Calculate EPE using Newton's method
 *
 * Finds the contour position along the normal direction from an evaluation point.
 * Uses QEPE (1st order approximation) as the initial estimate and refines with Newton's method.
 *
 * @param freqImage  Frequency domain optical image
 * @param px         Evaluation point X coordinate [um]
 * @param py         Evaluation point Y coordinate [um]
 * @param degree     Normal direction angle [degrees]
 * @param sliceLevel Intensity threshold (contour level)
 * @param maxIter    Maximum Newton iterations (default: 20)
 * @param tolerance  Convergence tolerance (default: 1e-6)
 * @return EpeCalcResult containing EPE, QEPE, convergence status, etc.
 */
inline EpeCalcResult calcEpeNewton(
    const FrequencyImage& freqImage,
    double px, double py,
    double degree,
    double sliceLevel,
    int maxIter = 20,
    double tolerance = 1e-6) {

    constexpr double MIN_GRADIENT = 1e-12;

    EpeCalcResult result;

    if (freqImage.empty()) {
        return result;
    }

    // Evaluate at the evaluation point
    auto pv0 = freqImage.evalAt(px, py);
    result.intensity = pv0.intensity;

    // Normal direction
    double rad = degree * M_PI / 180.0;
    double nx = std::cos(rad);
    double ny = std::sin(rad);

    // Gradient in normal direction
    result.gradient = pv0.gradX * nx + pv0.gradY * ny;

    // QEPE (1st order approximation)
    if (std::abs(result.gradient) > MIN_GRADIENT) {
        result.qepe = -(result.intensity - sliceLevel) / result.gradient;
    } else {
        result.qepe = (result.intensity >= sliceLevel) ? 1e6 : -1e6;
    }

    // Search range limit (half of image size)
    double maxDist = std::max(freqImage.Lx(), freqImage.Ly()) * 0.5;

    // Initial value: QEPE with clamping
    double epe = result.qepe;
    if (std::abs(epe) > maxDist) {
        epe = (epe > 0) ? maxDist : -maxDist;
    }
    if (!std::isfinite(epe)) {
        epe = 0.0;
    }

    // Newton's method iteration
    for (int iter = 0; iter < maxIter; ++iter) {
        double cx = px + epe * nx;
        double cy = py + epe * ny;

        auto pv = freqImage.evalAt(cx, cy);
        double f = pv.intensity - sliceLevel;

        // Check convergence
        if (std::abs(f) < tolerance) {
            result.epe = epe;
            result.iterations = iter + 1;
            result.converged = true;
            return result;
        }

        // Gradient in normal direction at current position
        double G = pv.gradX * nx + pv.gradY * ny;

        if (std::abs(G) < MIN_GRADIENT) {
            break;
        }

        // Newton update
        double delta = -f / G;

        // Step size limit
        double maxStep = maxDist * 0.1;
        if (std::abs(delta) > maxStep) {
            delta = (delta > 0) ? maxStep : -maxStep;
        }

        epe += delta;

        // Range limit
        if (std::abs(epe) > maxDist) {
            epe = (epe > 0) ? maxDist : -maxDist;
            break;
        }

        result.iterations = iter + 1;
    }

    result.epe = epe;
    result.converged = false;
    return result;
}

} // namespace so

#endif // SO_EPE_NEWTON_H
