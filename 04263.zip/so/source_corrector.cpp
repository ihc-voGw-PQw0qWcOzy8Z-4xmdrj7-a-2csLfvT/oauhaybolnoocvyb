/*!
 * @file source_corrector.cpp
 * @brief 不正な光源データの自動修正
 */

#include "source_corrector.h"
#include "coord_utils.h"
#include <cmath>
#include <algorithm>
#include <limits>
#include <sstream>
#include <iostream>
#include <iomanip>

namespace so {

void SourceCorrector::setOptions(const CorrectionOptions& options) {
    m_options = options;
}

const CorrectionOptions& SourceCorrector::showOptions() const {
    return m_options;
}

int SourceCorrector::fixNegativeIntensity(SourceData& sourceData) {
    int count = 0;
    const auto& points = sourceData.showPoints();

    for (const auto& point : points) {
        if (point.intensity < 0.0) {
            sourceData.setIntensity(point.x, point.y, 0.0);
            ++count;
        }
    }

    return count;
}

double SourceCorrector::interpolateNearest(const SourceData& sourceData, double x, double y) const {
    const auto& points = sourceData.showPoints();
    if (points.empty()) {
        return 0.0;
    }

    double minDist = std::numeric_limits<double>::max();
    double nearestIntensity = 0.0;

    for (const auto& point : points) {
        double dx = point.x - x;
        double dy = point.y - y;
        double dist = dx * dx + dy * dy;

        if (dist < minDist) {
            minDist = dist;
            nearestIntensity = point.intensity;
        }
    }

    return nearestIntensity;
}

double SourceCorrector::interpolateBilinear(const SourceData& sourceData, double x, double y) const {
    const auto& points = sourceData.showPoints();
    if (points.empty()) {
        return 0.0;
    }

    // 周囲の4点を探す
    double x0 = -std::numeric_limits<double>::max();
    double x1 = std::numeric_limits<double>::max();
    double y0 = -std::numeric_limits<double>::max();
    double y1 = std::numeric_limits<double>::max();

    // x, yに最も近い格子座標を探す
    for (const auto& point : points) {
        if (point.x <= x && point.x > x0) x0 = point.x;
        if (point.x >= x && point.x < x1) x1 = point.x;
        if (point.y <= y && point.y > y0) y0 = point.y;
        if (point.y >= y && point.y < y1) y1 = point.y;
    }

    // 境界チェック
    if (x0 == -std::numeric_limits<double>::max() ||
        x1 == std::numeric_limits<double>::max() ||
        y0 == -std::numeric_limits<double>::max() ||
        y1 == std::numeric_limits<double>::max()) {
        return interpolateNearest(sourceData, x, y);
    }

    // 4隅の強度を取得
    double f00 = sourceData.getIntensity(x0, y0);
    double f10 = sourceData.getIntensity(x1, y0);
    double f01 = sourceData.getIntensity(x0, y1);
    double f11 = sourceData.getIntensity(x1, y1);

    // バイリニア補間
    double dx = (x1 != x0) ? (x - x0) / (x1 - x0) : 0.0;
    double dy = (y1 != y0) ? (y - y0) / (y1 - y0) : 0.0;

    double f0 = f00 * (1.0 - dx) + f10 * dx;
    double f1 = f01 * (1.0 - dx) + f11 * dx;

    return f0 * (1.0 - dy) + f1 * dy;
}

int SourceCorrector::interpolateToGrid(SourceData& sourceData, const SourceGrid& sourceGrid) {
    const auto& points = sourceData.showPoints();
    if (points.empty()) {
        return 0;
    }

    // 現在の点がグリッド上にあるかチェック
    auto gridPoints = sourceGrid.generateGridPoints();
    bool allOnGrid = true;

    for (const auto& point : points) {
        bool onGrid = false;
        for (const auto& [gx, gy] : gridPoints) {
            if (coordEqual(point.x, gx) && coordEqual(point.y, gy)) {
                onGrid = true;
                break;
            }
        }
        if (!onGrid) {
            allOnGrid = false;
            break;
        }
    }

    if (allOnGrid) {
        return 0;  // 補間不要
    }

    // 元のデータをコピー
    SourceData originalData = sourceData;

    // グリッド点に補間
    sourceData.clear();
    int count = 0;

    for (const auto& [gx, gy] : gridPoints) {
        double intensity;
        if (m_options.interpolation == InterpolationMethod::Bilinear) {
            intensity = interpolateBilinear(originalData, gx, gy);
        } else {
            intensity = interpolateNearest(originalData, gx, gy);
        }

        SourcePoint newPoint;
        newPoint.x = gx;
        newPoint.y = gy;
        newPoint.intensity = intensity;
        sourceData.addPoint(newPoint);
        ++count;
    }

    return count;
}

int SourceCorrector::fillMissingPoints(SourceData& sourceData, const SourceGrid& sourceGrid) {
    auto gridPoints = sourceGrid.generateGridPoints();
    int count = 0;

    for (const auto& [gx, gy] : gridPoints) {
        bool found = false;
        for (const auto& point : sourceData.showPoints()) {
            if (coordEqual(point.x, gx) && coordEqual(point.y, gy)) {
                found = true;
                break;
            }
        }

        if (!found) {
            SourcePoint newPoint;
            newPoint.x = gx;
            newPoint.y = gy;
            newPoint.intensity = 0.0;
            sourceData.addPoint(newPoint);
            ++count;
        }
    }

    return count;
}

int SourceCorrector::fixOutOfSigmaRange(SourceData& sourceData, const SourceGrid& sourceGrid) {
    const auto& config = sourceGrid.showConfig();
    int count = 0;

    for (const auto& point : sourceData.showPoints()) {
        double r = std::sqrt(point.x * point.x + point.y * point.y);

        // σ範囲外かつ強度が非ゼロ
        bool outOfRange = (r < config.sigma_min - COORD_TOLERANCE) || (r > config.sigma_max + COORD_TOLERANCE);
        if (outOfRange && point.intensity > COORD_TOLERANCE) {
            sourceData.setIntensity(point.x, point.y, 0.0);
            ++count;
        }
    }

    return count;
}

int SourceCorrector::forceD2Symmetry(SourceData& sourceData, const SourceGrid& sourceGrid) {
    const auto& config = sourceGrid.showConfig();
    if (!config.isD2Symmetry()) {
        return 0;
    }

    int count = 0;

    // 第1象限の点から他の象限を更新
    auto gridPoints = sourceGrid.generateGridPoints();

    for (const auto& [gx, gy] : gridPoints) {
        if (gx < -COORD_TOLERANCE || gy < -COORD_TOLERANCE) {
            // 第1象限以外の点
            double absX = std::abs(gx);
            double absY = std::abs(gy);

            double firstQuadrantIntensity = sourceData.getIntensity(absX, absY);
            double currentIntensity = sourceData.getIntensity(gx, gy);

            if (!coordEqual(currentIntensity, firstQuadrantIntensity)) {
                sourceData.setIntensity(gx, gy, firstQuadrantIntensity);
                ++count;
            }
        }
    }

    return count;
}

CorrectionResult SourceCorrector::correct(SourceData& sourceData, const SourceGrid& sourceGrid) {
    CorrectionResult result;

    // Step 1: 負の強度を修正
    result.numNegativePoints = fixNegativeIntensity(sourceData);
    if (result.numNegativePoints > 0) {
        result.negativeIntensityFixed = true;
        std::ostringstream oss;
        oss << "Warning: " << result.numNegativePoints << " points had negative intensity (fixed to 0)";
        result.warnings.push_back(oss.str());
        if (m_options.verbose) {
            std::cerr << result.warnings.back() << std::endl;
        }
    }

    // Step 2: グリッド不一致を補間
    result.numGridMismatches = interpolateToGrid(sourceData, sourceGrid);
    if (result.numGridMismatches > 0) {
        result.gridCorrected = true;
        std::ostringstream oss;
        oss << "Warning: Source data interpolated to " << result.numGridMismatches << " grid points";
        if (m_options.interpolation == InterpolationMethod::Bilinear) {
            oss << " (bilinear)";
        } else {
            oss << " (nearest)";
        }
        result.warnings.push_back(oss.str());
        if (m_options.verbose) {
            std::cerr << result.warnings.back() << std::endl;
        }
    }

    // Step 3: 欠落点を追加
    result.numMissingPoints = fillMissingPoints(sourceData, sourceGrid);
    if (result.numMissingPoints > 0) {
        result.missingPointsAdded = true;
        std::ostringstream oss;
        oss << "Warning: " << result.numMissingPoints << " missing grid points added with intensity 0";
        result.warnings.push_back(oss.str());
        if (m_options.verbose) {
            std::cerr << result.warnings.back() << std::endl;
        }
    }

    // Step 4: σ範囲外を修正
    result.numOutOfRangePoints = fixOutOfSigmaRange(sourceData, sourceGrid);
    if (result.numOutOfRangePoints > 0) {
        result.outOfRangeWarning = true;
        std::ostringstream oss;
        oss << "Warning: " << result.numOutOfRangePoints << " points outside sigma range had non-zero intensity (fixed to 0)";
        result.warnings.push_back(oss.str());
        if (m_options.verbose) {
            std::cerr << result.warnings.back() << std::endl;
        }
    }

    // Step 5: D2対称性を強制
    result.numAsymmetricPoints = forceD2Symmetry(sourceData, sourceGrid);
    if (result.numAsymmetricPoints > 0) {
        result.symmetryCorrected = true;
        std::ostringstream oss;
        oss << "Warning: " << result.numAsymmetricPoints << " points corrected for D2 symmetry (using first quadrant values)";
        result.warnings.push_back(oss.str());
        if (m_options.verbose) {
            std::cerr << result.warnings.back() << std::endl;
        }
    }

    // Step 6: デバッグ出力
    if (!m_options.debugOutputPath.empty()) {
        sourceData.save(m_options.debugOutputPath);
        if (m_options.verbose) {
            std::cerr << "Debug: Corrected source saved to " << m_options.debugOutputPath << std::endl;
        }
    }

    return result;
}

CorrectionResult validateAndCorrect(SourceData& sourceData,
                                     const SourceGrid& sourceGrid,
                                     const CorrectionOptions& options) {
    SourceCorrector corrector;
    corrector.setOptions(options);
    return corrector.correct(sourceData, sourceGrid);
}

} // namespace so
