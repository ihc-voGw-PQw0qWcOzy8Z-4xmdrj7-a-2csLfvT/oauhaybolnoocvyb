/*!
 * @file cost_calculator.h
 * @brief コスト計算クラス
 */

#ifndef SO_COST_CALCULATOR_H
#define SO_COST_CALCULATOR_H

#include <so/types.h>
#include <so/frequency_image.h>
#include <so/source_contribution_set.h>
#include <so/evp_data.h>
#include <so/process_config.h>
#include <so/source_data.h>
#include <so/source_grid.h>
#include <map>
#include <string>
#include <functional>

namespace so {

/*!
 * @brief コスト計算クラス（周波数空間ベース）
 */
class CostCalculator {
private:
    CostOptions m_options;

public:
    CostCalculator();
    ~CostCalculator();

    /// オプションを設定
    void setOptions(const CostOptions& options);
    
    /// オプションを取得
    const CostOptions& showOptions() const;

    /*!
     * @brief 単一評価点のEPEを計算（周波数空間、ニュートン法）
     * @param freqImage 周波数空間画像
     * @param px 評価点X座標
     * @param py 評価点Y座標
     * @param degree 法線方向角度
     * @param sliceLevel 閾値
     * @param maxIter ニュートン法の最大反復回数
     * @param tolerance 収束判定の許容誤差
     * @return EPE計算結果（詳細情報付き）
     */
    EpeCalcResult calcEPE(const FrequencyImage& freqImage,
                                   double px, double py,
                                   double degree,
                                   double sliceLevel,
                                   int maxIter = 20,
                                   double tolerance = 1e-6) const;

    /*!
     * @brief 最適閾値を探索（SourceContributionSet版）
     */
    double findOptimalSliceLevel(
        const std::map<std::string, SourceContributionSet>& sourceContributions,
        const SourceData& sourceData,
        const SourceGridConfig& gridConfig,
        const EvpData& evpData,
        const ProcessConfig& processConfig) const;

    /*!
     * @brief 最適閾値を探索（FrequencyImage版）
     */
    double findOptimalSliceLevel(
        const std::map<std::string, FrequencyImage>& freqImages,
        const EvpData& evpData,
        const ProcessConfig& processConfig) const;

    /*!
     * @brief 「指定 cutline ペアの delta_CD = 0」になる sliceLevel を二分探索
     *
     * 指定 (clipID, direction="X" or "Y") の cutline ペアで EPE1+EPE2 = 0
     * になる sliceLevel を返す。物理的には「その cutline の CD が公称値と
     * 一致する露光閾値」に相当する。1 次元 monotone なので二分探索で安価。
     *
     * @param anchorClipID 対象 clip。-1 のときは最初の利用可能 clip
     * @param direction "X" または "Y"
     * @return 求まった sliceLevel
     */
    double findSliceLevelByEpeZero(
        const std::map<std::string, SourceContributionSet>& sourceContributions,
        const SourceData& sourceData,
        const SourceGridConfig& gridConfig,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        int anchorClipID,
        const std::string& direction) const;

    /*!
     * @brief 目標delta_CDを達成する閾値を探索（SourceContributionSet版）
     */
    double findSliceLevelForTargetDeltaCD(
        const std::map<std::string, SourceContributionSet>& sourceContributions,
        const SourceData& sourceData,
        const SourceGridConfig& gridConfig,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double targetDeltaCD) const;

    /*!
     * @brief 目標delta_CDを達成する閾値を探索（FrequencyImage版）
     */
    double findSliceLevelForTargetDeltaCD(
        const std::map<std::string, FrequencyImage>& freqImages,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double targetDeltaCD) const;

    /*!
     * @brief source_fill_costを計算
     * @param sourceFillRatio source_fill_ratio
     * @return source_fill_cost
     */
    double calcSourceFillCost(double sourceFillRatio) const;

    /*!
     * @brief EPE_costを計算
     * @param epeResults EPE計算結果リスト
     * @return EPE_cost
     */
    double calcEPECost(const std::vector<EpeResult>& epeResults) const;

    /*!
     * @brief QEPE_costを計算
     * @param epeResults EPE計算結果リスト
     * @return QEPE_cost
     */
    double calcQEPECost(const std::vector<EpeResult>& epeResults) const;

    /*!
     * @brief NILS_costを計算（weightNils 乗算済み）
     * @param epeResults EPE計算結果リスト（各点の gradient を利用）
     * @return NILS_cost = weightNils × Σ(max(0, nilsMin - NILS)² × w) / Σw
     *
     * NILS = nilsCdReference × |G| / sliceLevel
     */
    double calcNilsCost(const std::vector<EpeResult>& epeResults, double sliceLevel) const;

    /*!
     * @brief 全コスト計算を実行（SourceContributionSet版）
     * @param sourceContributions 光源寄与マップ（周波数空間、光源分離）
     * @param sourceData 光源強度データ
     * @param gridConfig 光源グリッド設定
     * @param evpData 評価点データ
     * @param processConfig プロセス設定
     * @param sourceFillRatio source_fill_ratio
     * @return コスト計算結果
     * 
     * --freqモード用: 各光源点の寄与を保持し、sourceDataで重み付け合成
     */
    CostResult calculate(
        const std::map<std::string, SourceContributionSet>& sourceContributions,
        const SourceData& sourceData,
        const SourceGridConfig& gridConfig,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sourceFillRatio) const;

    /*!
     * @brief 全コスト計算を実行（FrequencyImage版）
     * @param freqImages 周波数空間画像マップ（光源積分済み）
     * @param evpData 評価点データ
     * @param processConfig プロセス設定
     * @param sourceFillRatio source_fill_ratio
     * @return コスト計算結果
     * 
     * 実空間ファイルをFFTした場合用: 既に光源積分済み
     */
    CostResult calculate(
        const std::map<std::string, FrequencyImage>& freqImages,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sourceFillRatio) const;

private:
    /*!
     * @brief アンカーclipのdelta_CD合計を計算
     */
    double calcAnchorDeltaCDSum(
        const std::map<std::string, SourceContributionSet>& sourceContributions,
        const SourceData& sourceData,
        const SourceGridConfig& gridConfig,
        const EvpData& evpData,
        const ProcessConfig& processConfig,
        double sliceLevel) const;
};

/*!
 * @brief cost.csv 書き出しクラス
 */
class CostWriter {
public:
    static void write(const std::string& filepath, const CostResult& result);
};

} // namespace so

#endif // SO_COST_CALCULATOR_H
