/*!
 * @file variable_mapping.cpp
 * @brief D2対称性を考慮した最適化変数マッピングの実装
 */

#include "variable_mapping.h"
#include "coord_utils.h"
#include <cmath>
#include <algorithm>

namespace so {

VariableMapping::VariableMapping() {}

VariableMapping::~VariableMapping() {}

std::pair<double, double> VariableMapping::makeKey(double x, double y) {
    return makeCoordKey(x, y);
}

void VariableMapping::initialize(const SourceGrid& sourceGrid,
                                  const SourceData& sourceData) {
    m_gridConfig = sourceGrid.showConfig();
    m_variableInfos.clear();
    m_coordToVarIndex.clear();

    auto validPoints = sourceGrid.generateValidGridPoints();

    int varIdx = 0;
    for (const auto& [gx, gy] : validPoints) {
        // D2対称の場合は第1象限のみ
        if (m_gridConfig.isD2Symmetry()) {
            if (gx < -COORD_TOLERANCE || gy < -COORD_TOLERANCE) {
                continue;
            }
        }

        // 有効な光源点として登録
        VariableInfo info;
        info.varIndex = varIdx;
        info.gx = gx;
        info.gy = gy;
        info.multiplier = calcMultiplier(gx, gy);

        m_variableInfos.push_back(info);
        m_coordToVarIndex[makeKey(gx, gy)] = varIdx;
        ++varIdx;
    }
}

int VariableMapping::calcMultiplier(double gx, double gy) const {
    if (!m_gridConfig.isD2Symmetry()) {
        return 1;
    }

    bool xOnAxis = isNearZero(gx);
    bool yOnAxis = isNearZero(gy);

    if (xOnAxis && yOnAxis) {
        // 原点：multiplier = 1
        return 1;
    } else if (xOnAxis || yOnAxis) {
        // X軸上またはY軸上（原点除く）：multiplier = 2
        return 2;
    } else {
        // 一般点：multiplier = 4
        return 4;
    }
}

void VariableMapping::variablesToSource(const std::vector<double>& variables,
                                         SourceData& sourceData) const {
    for (const auto& info : m_variableInfos) {
        double intensity = variables[info.varIndex];

        if (m_gridConfig.isD2Symmetry()) {
            // 第1象限の値を対称点にもコピー
            sourceData.setIntensity(info.gx, info.gy, intensity);
            if (!isNearZero(info.gx)) {
                sourceData.setIntensity(-info.gx, info.gy, intensity);
            }
            if (!isNearZero(info.gy)) {
                sourceData.setIntensity(info.gx, -info.gy, intensity);
            }
            if (!isNearZero(info.gx) && !isNearZero(info.gy)) {
                sourceData.setIntensity(-info.gx, -info.gy, intensity);
            }
        } else {
            sourceData.setIntensity(info.gx, info.gy, intensity);
        }
    }
}

std::vector<double> VariableMapping::sourceToVariables(
    const SourceData& sourceData) const {
    std::vector<double> variables(m_variableInfos.size());

    for (const auto& info : m_variableInfos) {
        double intensity;
        if (m_gridConfig.isD2Symmetry()) {
            intensity = sourceData.getIntensityFirstQuadrant(info.gx, info.gy);
        } else {
            intensity = sourceData.getIntensity(info.gx, info.gy);
        }
        variables[info.varIndex] = intensity;
    }

    return variables;
}

std::vector<double> VariableMapping::gradientMapToVector(
    const std::map<std::pair<double, double>, double>& gradientMap) const {

    std::vector<double> gradientVec(m_variableInfos.size(), 0.0);

    for (const auto& info : m_variableInfos) {
        auto it = gradientMap.find(makeKey(info.gx, info.gy));
        if (it != gradientMap.end()) {
            gradientVec[info.varIndex] = it->second;
        }
    }

    return gradientVec;
}

} // namespace so
