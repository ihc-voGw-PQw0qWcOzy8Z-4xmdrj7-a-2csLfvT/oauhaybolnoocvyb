#include "evp_parser.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <limits>
#include <algorithm>
#include <regex>

namespace so {

namespace {

/**
 * @brief 文字列の前後の空白を削除する
 * @param str 対象文字列
 * @return 空白を削除した文字列
 */
std::string trim(const std::string& str) {
    size_t first = str.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return "";
    size_t last = str.find_last_not_of(" \t\r\n");
    return str.substr(first, last - first + 1);
}

/**
 * @brief 行がセパレータ（---で始まる）かどうかを判定
 * @param line 対象行
 * @return セパレータならtrue
 */
bool isSeparator(const std::string& line) {
    std::string trimmed = trim(line);
    return trimmed.size() >= 3 && trimmed.substr(0, 3) == "---";
}

/**
 * @brief COORD行から<current>列の座標を抽出する
 * @param line 対象行
 * @param x 出力: X座標
 * @param y 出力: Y座標
 * @return 座標が取得できたらtrue
 */
bool parseCoordLine(const std::string& line, double& x, double& y) {
    // 行の形式: "        1 :        10.1200000000        21.2712500000,        10.1200000000        21.2712500000"
    // <current>列は最初の2つの数値
    
    // コロンの位置を探す
    size_t colonPos = line.find(':');
    if (colonPos == std::string::npos) {
        return false;
    }
    
    // コロンより後の部分を取得
    std::string afterColon = line.substr(colonPos + 1);
    
    // 数値を抽出
    std::istringstream iss(afterColon);
    std::string token;
    std::vector<double> values;
    
    while (iss >> token) {
        // カンマを除去
        token.erase(std::remove(token.begin(), token.end(), ','), token.end());
        
        try {
            double val = std::stod(token);
            values.push_back(val);
        } catch (...) {
            // 数値でない場合はスキップ
            continue;
        }
    }
    
    // 最初の2つの数値が<current>列の座標
    if (values.size() >= 2) {
        x = values[0];
        y = values[1];
        return true;
    }
    
    return false;
}

} // anonymous namespace

std::vector<Rectangle> parseInputFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Error: Cannot open input file: " + filename);
    }
    
    std::vector<Rectangle> rectangles;
    std::string line;
    bool inCoordSection = false;
    std::vector<std::pair<double, double>> currentCoords;
    
    while (std::getline(file, line)) {
        std::string trimmedLine = trim(line);
        
        // セパレータの場合、現在の座標リストから矩形を作成
        if (isSeparator(line)) {
            if (currentCoords.size() >= 4) {
                // 座標から矩形の範囲を計算
                double x_min = std::numeric_limits<double>::max();
                double x_max = std::numeric_limits<double>::lowest();
                double y_min = std::numeric_limits<double>::max();
                double y_max = std::numeric_limits<double>::lowest();
                
                for (const auto& coord : currentCoords) {
                    x_min = std::min(x_min, coord.first);
                    x_max = std::max(x_max, coord.first);
                    y_min = std::min(y_min, coord.second);
                    y_max = std::max(y_max, coord.second);
                }
                
                rectangles.push_back({x_min, x_max, y_min, y_max});
            }
            currentCoords.clear();
            inCoordSection = false;
            continue;
        }
        
        // COORDセクションの開始を検出
        if (trimmedLine == "COORD") {
            inCoordSection = true;
            continue;
        }
        
        // <current>と<original>のヘッダー行をスキップ
        if (trimmedLine.find("<current>") != std::string::npos) {
            continue;
        }
        
        // COORDセクション内の座標行を解析
        if (inCoordSection) {
            double x, y;
            if (parseCoordLine(line, x, y)) {
                currentCoords.emplace_back(x, y);
            }
        }
    }
    
    // ファイル末尾でセパレータがない場合の処理
    if (currentCoords.size() >= 4) {
        double x_min = std::numeric_limits<double>::max();
        double x_max = std::numeric_limits<double>::lowest();
        double y_min = std::numeric_limits<double>::max();
        double y_max = std::numeric_limits<double>::lowest();
        
        for (const auto& coord : currentCoords) {
            x_min = std::min(x_min, coord.first);
            x_max = std::max(x_max, coord.first);
            y_min = std::min(y_min, coord.second);
            y_max = std::max(y_max, coord.second);
        }
        
        rectangles.push_back({x_min, x_max, y_min, y_max});
    }
    
    if (rectangles.empty()) {
        throw std::runtime_error("Error: No rectangle data found in input file.");
    }
    
    return rectangles;
}

} // namespace so
