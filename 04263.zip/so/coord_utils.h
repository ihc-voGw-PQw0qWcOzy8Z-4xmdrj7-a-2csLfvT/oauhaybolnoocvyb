/*!
 * @file coord_utils.h
 * @brief 座標ユーティリティ関数
 *
 * 座標の丸め、キー生成、ゼロ判定などの共通処理を提供。
 * 複数ファイルで重複していた実装を統合。
 */

#ifndef SO_COORD_UTILS_H
#define SO_COORD_UTILS_H

#include <cmath>
#include <utility>

namespace so {

/// 座標丸めの精度（小数点以下6桁）
constexpr double COORD_PRECISION = 1e6;

/// 座標比較の許容誤差
constexpr double COORD_TOLERANCE = 1e-6;

/*!
 * @brief 座標値を丸める
 * @param v 座標値
 * @return 丸められた座標値（小数点以下6桁）
 */
inline double roundCoord(double v) {
    return std::round(v * COORD_PRECISION) / COORD_PRECISION;
}

/*!
 * @brief 座標ペアをマップのキーとして使用するための変換
 * @param x X座標
 * @param y Y座標
 * @return 丸められた座標のペア
 */
inline std::pair<double, double> makeCoordKey(double x, double y) {
    return {roundCoord(x), roundCoord(y)};
}

/*!
 * @brief 座標値がゼロに近いかどうかを判定
 * @param v 座標値
 * @return COORD_TOLERANCE以下ならtrue
 */
inline bool isNearZero(double v) {
    return std::abs(v) < COORD_TOLERANCE;
}

/*!
 * @brief 2つの座標値が等しいかどうかを判定
 * @param a 座標値1
 * @param b 座標値2
 * @param tol 許容誤差（デフォルト: COORD_TOLERANCE）
 * @return 差がtol以下ならtrue
 */
inline bool coordEqual(double a, double b, double tol = COORD_TOLERANCE) {
    return std::abs(a - b) < tol;
}

} // namespace so

#endif // SO_COORD_UTILS_H
