/*!
 * @file source_corrector.h
 * @brief 不正な光源データの自動修正
 */

#ifndef SO_SOURCE_CORRECTOR_H
#define SO_SOURCE_CORRECTOR_H

#include <so/types.h>
#include "source_data.h"
#include "source_grid.h"
#include <string>
#include <vector>

namespace so {

/*!
 * @brief 光源データ修正クラス
 *
 * 不正な光源データを自動修正し、警告を出力する
 */
class SourceCorrector {
private:
    CorrectionOptions m_options;

    /*!
     * @brief 負の強度を0に修正
     * @param sourceData 修正対象データ
     * @return 修正した点数
     */
    int fixNegativeIntensity(SourceData& sourceData);

    /*!
     * @brief グリッドに合わせて補間
     * @param sourceData 修正対象データ
     * @param sourceGrid グリッド設定
     * @return 補間した点数
     */
    int interpolateToGrid(SourceData& sourceData, const SourceGrid& sourceGrid);

    /*!
     * @brief 欠落点を強度0で追加
     * @param sourceData 修正対象データ
     * @param sourceGrid グリッド設定
     * @return 追加した点数
     */
    int fillMissingPoints(SourceData& sourceData, const SourceGrid& sourceGrid);

    /*!
     * @brief σ範囲外の非ゼロ強度をチェックし0に修正
     * @param sourceData 修正対象データ
     * @param sourceGrid グリッド設定
     * @return 範囲外の点数
     */
    int fixOutOfSigmaRange(SourceData& sourceData, const SourceGrid& sourceGrid);

    /*!
     * @brief D2対称性を強制（第1象限から他の象限を生成）
     * @param sourceData 修正対象データ
     * @param sourceGrid グリッド設定
     * @return 修正した点数
     */
    int forceD2Symmetry(SourceData& sourceData, const SourceGrid& sourceGrid);

    /*!
     * @brief 最近傍補間
     * @param sourceData ソースデータ
     * @param x X座標
     * @param y Y座標
     * @return 補間された強度
     */
    double interpolateNearest(const SourceData& sourceData, double x, double y) const;

    /*!
     * @brief バイリニア補間
     * @param sourceData ソースデータ
     * @param x X座標
     * @param y Y座標
     * @return 補間された強度
     */
    double interpolateBilinear(const SourceData& sourceData, double x, double y) const;

public:
    SourceCorrector() = default;
    ~SourceCorrector() = default;

    /*!
     * @brief オプションを設定
     * @param options 修正オプション
     */
    void setOptions(const CorrectionOptions& options);

    /*!
     * @brief オプションを取得
     * @return 修正オプション
     */
    const CorrectionOptions& showOptions() const;

    /*!
     * @brief 光源データを修正
     * @param sourceData 修正対象データ
     * @param sourceGrid グリッド設定
     * @return 修正結果
     *
     * 処理順序:
     * 1. 負の強度 → 0に修正
     * 2. グリッド不一致 → 補間で変換
     * 3. 欠落点 → 強度0で追加
     * 4. σ範囲外の非ゼロ → 0に修正
     * 5. D2非対称（D2設定時） → 第1象限から対称化
     * 6. debugOutputPath指定時 → 修正後ソース保存
     */
    CorrectionResult correct(SourceData& sourceData, const SourceGrid& sourceGrid);
};

/*!
 * @brief 光源データの検証と修正を一括実行
 * @param sourceData 修正対象データ
 * @param sourceGrid グリッド設定
 * @param options 修正オプション
 * @return 修正結果
 */
CorrectionResult validateAndCorrect(SourceData& sourceData,
                                     const SourceGrid& sourceGrid,
                                     const CorrectionOptions& options = {});

} // namespace so

#endif // SO_SOURCE_CORRECTOR_H
