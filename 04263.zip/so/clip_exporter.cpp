/*!
 * @file clip_exporter.cpp
 * @brief Clip領域のOASISエクスポート機能
 */

#include "clip_exporter.h"
#include <tkk/lithoKernel/cgtl.h>
#include <OASISWriter.h>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <cmath>

namespace so {

ClipExporter::ClipExporter() {}

ClipExporter::~ClipExporter() {}

void ClipExporter::setOasisFile(const std::string& file) {
    m_oasisFile = file;
}

void ClipExporter::setCellname(const std::string& name) {
    m_cellname = name;
}

void ClipExporter::setLayers(const std::vector<std::pair<int, int>>& layers) {
    m_layers = layers;
}

void ClipExporter::setSize(double Lx, double Ly) {
    m_Lx = Lx;
    m_Ly = Ly;
}

void ClipExporter::setMargin(double margin) {
    m_margin = margin;
}

void ClipExporter::setBaseDatatype(int datatype) {
    m_baseDatatype = datatype;
}

void ClipExporter::exportClip(const ClipInfo& clip, const std::string& outputFile) const {
    if (m_oasisFile.empty()) {
        throw std::runtime_error("OASIS file not set");
    }
    if (m_layers.empty()) {
        throw std::runtime_error("Layers not set");
    }

    double cx = clip.cx;
    double cy = clip.cy;

    // 全レイヤーのポリゴンを読み込んで結合
    lithoGtl::Polygons allPolygons;
    bool first = true;

    for (const auto& [layer, datatype] : m_layers) {
        lithoGtl::Polygons layerPolygons;
        layerPolygons.read_oasis(m_oasisFile, m_cellname,
                                  layer, datatype,
                                  cx - m_Lx/2. - m_margin, cy - m_Ly/2. - m_margin,
                                  cx + m_Lx/2. + m_margin, cy + m_Ly/2. + m_margin);

        if (first) {
            allPolygons = layerPolygons;
            first = false;
        } else {
            // 追加のレイヤーは別ファイルに出力するか、同じファイルにマージ
            // ここでは最初のレイヤーのみを出力
        }
    }

    // clip中心を原点に移動
    allPolygons.shift_double(-cx, -cy);
    
    // 計算領域でクリップ
    allPolygons.window_double(-m_Lx/2., -m_Ly/2., m_Lx/2., m_Ly/2.);

    // OASISファイルとして出力
    std::string topcellname = "clip" + std::to_string(clip.clipID);
    auto [layer, datatype] = m_layers[0];
    allPolygons.write_oasis(outputFile, topcellname, layer, datatype);
}

void ClipExporter::exportAllClips(const EvpData& evpData, const std::string& outputDir) const {
    // 出力ディレクトリを作成
    std::filesystem::create_directories(outputDir);

    const auto& clips = evpData.showClips();
    
    std::cerr << "Exporting " << clips.size() << " clips to OASIS..." << std::endl;

    for (const auto& clip : clips) {
        std::string outputFile = outputDir + "/" + makeFileName(clip.clipID);
        
        try {
            exportClip(clip, outputFile);
            std::cerr << "  Exported: " << outputFile << std::endl;
        } catch (const std::exception& e) {
            std::cerr << "  Warning: Failed to export clip " << clip.clipID 
                      << ": " << e.what() << std::endl;
        }
    }

    std::cerr << "Clip export completed." << std::endl;
}

std::string ClipExporter::makeFileName(int clipID) {
    return "clip" + std::to_string(clipID) + ".oas";
}

void ClipExporter::exportClipWithMaskBias(const ClipInfo& clip,
                                           const std::vector<double>& maskBiases,
                                           const std::string& outputFile) const {
    if (m_oasisFile.empty()) {
        throw std::runtime_error("OASIS file not set");
    }
    if (m_layers.empty()) {
        throw std::runtime_error("Layers not set");
    }
    if (maskBiases.empty()) {
        throw std::runtime_error("maskBiases is empty");
    }

    double cx = clip.cx;
    double cy = clip.cy;

    // 元のポリゴンを読み込み
    lithoGtl::Polygons basePolygons;
    auto [layer, datatype] = m_layers[0];

    basePolygons.read_oasis(m_oasisFile, m_cellname,
                             layer, datatype,
                             cx - m_Lx/2. - m_margin, cy - m_Ly/2. - m_margin,
                             cx + m_Lx/2. + m_margin, cy + m_Ly/2. + m_margin);

    // clip中心を原点に移動
    basePolygons.shift_double(-cx, -cy);

    // 計算領域でクリップ
    basePolygons.window_double(-m_Lx/2., -m_Ly/2., m_Lx/2., m_Ly/2.);

    // OASISWriterで複数レイヤーを同一ファイルに出力
    OASISWriter writer;
    int DBU = basePolygons.show_DBU();
    writer.create(outputFile.c_str(), DBU);

    std::string topcellname = "clip" + std::to_string(clip.clipID);
    OASISWriterCell* top = writer.createCell(topcellname.c_str());

    // 各maskBias値に対してポリゴンを出力
    for (size_t i = 0; i < maskBiases.size(); ++i) {
        double maskBiasNm = maskBiases[i];
        double maskBiasUm = maskBiasNm / 1000.0;  // nm → μm

        // ポリゴンをコピーしてsizing
        lithoGtl::Polygons polygons = basePolygons;

        if (std::abs(maskBiasUm) > 1e-9) {
            if (maskBiasUm > 0) {
                polygons.dilate(maskBiasUm);
            } else {
                polygons.erode(-maskBiasUm);
            }
            // sizing後に再度クリップ
            polygons.window_double(-m_Lx/2., -m_Ly/2., m_Lx/2., m_Ly/2.);
        }

        // データタイプをインデックスで分ける
        int outputDatatype = m_baseDatatype + static_cast<int>(i);
        polygons.write_oasis(top, layer, outputDatatype);
    }

    writer.closeCell(top);
    writer.close();
}

void ClipExporter::exportAllClipsWithMaskBias(const EvpData& evpData,
                                               const std::vector<double>& maskBiases,
                                               const std::string& outputDir) const {
    // 出力ディレクトリを作成
    std::filesystem::create_directories(outputDir);

    const auto& clips = evpData.showClips();

    std::cerr << "Exporting " << clips.size() << " clips with "
              << maskBiases.size() << " maskBias conditions to OASIS..." << std::endl;

    // maskBias値を表示
    std::cerr << "  maskBias values [nm]:";
    for (size_t i = 0; i < maskBiases.size(); ++i) {
        std::cerr << " " << maskBiases[i] << "(datatype=" << (m_baseDatatype + i) << ")";
    }
    std::cerr << std::endl;

    for (const auto& clip : clips) {
        std::string outputFile = outputDir + "/" + makeFileName(clip.clipID);

        try {
            exportClipWithMaskBias(clip, maskBiases, outputFile);
            std::cerr << "  Exported: " << outputFile << std::endl;
        } catch (const std::exception& e) {
            std::cerr << "  Warning: Failed to export clip " << clip.clipID
                      << ": " << e.what() << std::endl;
        }
    }

    std::cerr << "Clip export with maskBias completed." << std::endl;
}

} // namespace so
