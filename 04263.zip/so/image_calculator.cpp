/*!
 * @file image_calculator.cpp
 * @brief 光学像計算・積分
 * 
 * Note: 実行前に ulimit -n 65536 を実行してファイルディスクリプタ上限を増やすこと
 */

#include "image_calculator.h"
#include "frequency_image.h"
#include "source_contribution.h"
#include "source_contribution_set.h"
#include <tkk/lithoKernel/ccalcs_m3d.h>
#include <tkk/lithoKernel/cresistImage.h>
#include <tkk/lithoKernel/util.h>
#include <tkk/resistModel6/cResistModel.h>
#include <fftw3.h>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <filesystem>
#include <iostream>
#include <cmath>
#include <regex>
#include <set>

#ifdef _OPENMP
#include <omp.h>
#endif

namespace so {

ImageCalculator::ImageCalculator() {}

ImageCalculator::~ImageCalculator() {}

void ImageCalculator::setSourceGrid(const SourceGrid* grid) {
    m_sourceGrid = grid;
}

void ImageCalculator::setSourceData(const SourceData* data) {
    m_sourceData = data;
}

void ImageCalculator::setProcessConfig(const ProcessConfig* config) {
    m_processConfig = config;
}

void ImageCalculator::setSocsSetDir(const std::string& dir) {
    m_socsSetDir = dir;
}

void ImageCalculator::setOasisFile(const std::string& file) {
    m_oasisFile = file;
}

void ImageCalculator::setResistModelFile(const std::string& file) {
    m_resistModelFile = file;
}

void ImageCalculator::setOptions(const CalcOptions& options) {
    m_options = options;
}

CalcResult ImageCalculator::calcImagesInternal(
    const EvpData& evpData,
    const std::string& resistModelDir) const {
    
    if (!m_processConfig || !m_sourceGrid || !m_sourceData) {
        throw std::runtime_error("Required data not set");
    }

#ifdef _OPENMP
    // lithoKernel内部のOpenMP並列化も含めてスレッド数を制限する
    int prevMaxThreads = omp_get_max_threads();
    if (m_options.numThreads > 0) {
        omp_set_num_threads(m_options.numThreads);
    }
#endif

    CalcResult calcResult;

    // 外部ライブラリ(lithoKernel, resistModel6)のデバッグ出力を関数全体で抑制
    std::streambuf* origCoutBuf = std::cout.rdbuf();
    std::streambuf* origCerrBuf = std::cerr.rdbuf();
    std::ofstream nullStream("/dev/null");
    std::cout.rdbuf(nullStream.rdbuf());
    std::cerr.rdbuf(nullStream.rdbuf());
    // 自前のログ出力用（元のcerrバッファに直接書く）
    std::ostream log(origCerrBuf);

    // resistModelファイルを生成（rank 0のみ。MPI時の競合状態を防止）
    // 呼び出し元でsetMPIRank()を設定し、MPI_Barrierを呼ぶこと
    auto uniqueMaskBiases = m_processConfig->showUniqueMaskBiases();
    if (m_mpiRank == 0) {
        ResistModelGenerator::generateAll(m_resistModelFile, resistModelDir, uniqueMaskBiases);
    }

    const auto& clips = evpData.showClips();
    const auto& pwcs = m_processConfig->showPwcConditions();
    const auto& gridConfig = m_sourceGrid->showConfig();

    std::vector<std::pair<int, int>> layers = m_options.layers;
    if (layers.empty()) {
        layers.emplace_back(0, 0);
    }

    // 有効な光源点を取得
    auto validPoints = m_sourceGrid->generateValidGridPoints();
    
    // D2対称の場合は第1象限のみ
    std::vector<std::pair<double, double>> sourcePoints;
    for (const auto& [gx, gy] : validPoints) {
        if (gridConfig.isD2Symmetry()) {
            if (gx >= 0 && gy >= 0) {
                sourcePoints.emplace_back(gx, gy);
            }
        } else {
            sourcePoints.emplace_back(gx, gy);
        }
    }

    // 最初の有効な光源点のSOCSファイルからlambda, NA, Lx, Lyを取得
    double lambda = 0.0, NA = 0.0, Lx = 0.0, Ly = 0.0;
    {
        double firstDefocus = pwcs[0].defocus;
        
        for (const auto& [gx, gy] : sourcePoints) {
            std::string sourceID = SourceGrid::makeSourceID(gx, gy);
            std::string socsPath = SocsFile::makePath(m_socsSetDir, sourceID, firstDefocus);
            
            if (std::filesystem::exists(socsPath)) {
                OpticalParams socsParams = SocsFile::readOpticalParams(socsPath);
                lambda = socsParams.lambda;
                NA = socsParams.NA;
                Lx = socsParams.Lx;
                Ly = socsParams.Ly;
                
                log << "Optical params from SOCS: lambda=" << lambda
                    << ", NA=" << NA << ", Lx=" << Lx << ", Ly=" << Ly << std::endl;
                break;
            }
        }
    }
    
    if (Lx <= 0.0 || Ly <= 0.0) {
        throw std::runtime_error("Failed to get Lx, Ly from SOCS files");
    }

    // 光学パラメータを設定
    calcResult.opticalParams.lambda = lambda;
    calcResult.opticalParams.NA = NA;
    calcResult.opticalParams.Lx = Lx;
    calcResult.opticalParams.Ly = Ly;

    // dim計算（オプションで指定がなければSOCSパラメータから計算）
    int dimx = m_options.dimx;
    int dimy = m_options.dimy;
    if (dimx == 0 || dimy == 0) {
        double L_max = std::max(Lx, Ly);
        int defaultDim = 4 * static_cast<int>(std::floor(L_max * 2.0 * NA / lambda)) + 2;
        if (dimx == 0) dimx = defaultDim;
        if (dimy == 0) dimy = defaultDim;
    }
    int dimx0 = (m_options.dimx0 > 0) ? m_options.dimx0 : dimx;
    int dimy0 = (m_options.dimy0 > 0) ? m_options.dimy0 : dimy;

    log << "Note: If you encounter file descriptor errors, run: ulimit -n 65536" << std::endl;

    // --- ユニークな(defocus, mask_bias)の組み合わせを収集 ---
    // delta_doseは光学像計算に影響しないため、(defocus, mask_bias)が同じなら1回だけ計算
    std::set<std::pair<double, double>> uniqueDefocusMaskBias;
    std::set<double> uniqueDefocus;
    for (const auto& pwc : pwcs) {
        uniqueDefocusMaskBias.insert({pwc.defocus, pwc.mask_bias});
        uniqueDefocus.insert(pwc.defocus);
    }

    size_t totalTasks = clips.size() * uniqueDefocusMaskBias.size();
    size_t completedTasks = 0;

    log << "Unique (defocus, mask_bias) combinations: " << uniqueDefocusMaskBias.size()
        << " (from " << pwcs.size() << " PWC conditions)" << std::endl;

    // --- 自ランクが担当するclipインデックスを収集（MPIクリップ分散） ---
    // SOCSキャッシュ構築前に判定し、担当クリップがないランクはスキップ
    std::vector<size_t> myClipIndices;
    for (size_t ci = 0; ci < clips.size(); ++ci) {
        if (m_mpiSize > 1 && ci % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;
        myClipIndices.push_back(ci);
    }

    if (m_mpiSize > 1) {
        log << "[Rank " << m_mpiRank << "] Assigned " << myClipIndices.size()
            << "/" << clips.size() << " clips" << std::endl;
    }

    // --- SOCSキャッシュの構築 ---
    // defocus × 光源点 の組み合わせでccalcs_m3dオブジェクトをキャッシュ
    // これにより、clip × PWCループでの重複読み込みを回避
    struct SocsCache {
        lithoKernel::ccalcs_m3d* mcalcs;
        double norm;
    };
    std::map<std::pair<std::string, double>, SocsCache> socsCache;

    log << "Building SOCS cache for " << uniqueDefocus.size()
        << " defocus × " << sourcePoints.size() << " source points..." << std::endl;

    for (double defocus : uniqueDefocus) {
        for (const auto& [gx, gy] : sourcePoints) {
            std::string sourceID = SourceGrid::makeSourceID(gx, gy);
            std::string socsPath = SocsFile::makePath(m_socsSetDir, sourceID, defocus);

            if (!std::filesystem::exists(socsPath)) continue;

            OpticalParams socsParams = SocsFile::readOpticalParams(socsPath);
            double norm = socsParams.norm_real;

            auto* MCALCS = new lithoKernel::ccalcs_m3d;
            MCALCS->set_dimx0(dimx0);
            MCALCS->set_dimy0(dimy0);
            MCALCS->set_dimx1(dimx);
            MCALCS->set_dimy1(dimy);
            MCALCS->set_kernel_num(m_options.kernelNum);
            MCALCS->set_flag_binary(m_options.binary ? 1 : 0);
            MCALCS->set_flag_brightfield(m_options.brightfield ? 1 : 0);

            MCALCS->set_socs(socsPath, false, 0);

            socsCache[{sourceID, defocus}] = {MCALCS, norm};
        }
    }

    log << "SOCS cache built: " << socsCache.size() << " entries" << std::endl;

    // --- 担当clipのポリゴンを事前読み込み（read_oasisのスレッドセーフ性を仮定しない） ---
    struct ClipPolygons {
        lithoGtl::Polygons PMain;
        lithoGtl::Polygons PSraf;
    };
    std::map<size_t, ClipPolygons> clipPolygons;

    // ポリゴン読み込み中はstderr/stdoutを復元（lithoKernelがexit()する場合にエラーメッセージを表示するため）
    std::cerr.rdbuf(origCerrBuf);
    std::cout.rdbuf(origCoutBuf);

    for (size_t ci : myClipIndices) {
        const auto& clip = clips[ci];
        double cx = clip.cx;
        double cy = clip.cy;

        double margin = 0.125;
        lithoGtl::Polygons PMain, PSraf;

        auto [layer_main, datatype_main] = layers[0];
        PMain.read_oasis(m_oasisFile.c_str(), m_options.cellname,
                         layer_main, datatype_main,
                         cx - Lx/2. - margin, cy - Ly/2. - margin,
                         cx + Lx/2. + margin, cy + Ly/2. + margin);

        for (size_t li = 1; li < layers.size(); ++li) {
            auto [layer_sraf, datatype_sraf] = layers[li];
            PSraf.read_oasis(m_oasisFile.c_str(), m_options.cellname,
                            layer_sraf, datatype_sraf,
                            cx - Lx/2. - margin, cy - Ly/2. - margin,
                            cx + Lx/2. + margin, cy + Ly/2. + margin);
        }

        // 座標変換（クリップ中心を原点に）
        PMain.shift_double(-cx, -cy);
        PMain.window_double(-Lx/2., -Ly/2., Lx/2., Ly/2.);
        PSraf.shift_double(-cx, -cy);
        PSraf.window_double(-Lx/2., -Ly/2., Lx/2., Ly/2.);

        clipPolygons[ci] = {std::move(PMain), std::move(PSraf)};
    }

    // 外部ライブラリの出力抑制を再適用
    std::cout.rdbuf(nullStream.rdbuf());
    std::cerr.rdbuf(nullStream.rdbuf());

    // --- タスクリスト構築: 担当clip × unique(defocus, mask_bias) ---
    struct ImgTask {
        size_t clipIdx;
        double defocus;
        double mask_bias;
    };
    std::vector<ImgTask> tasks;
    std::vector<std::pair<double, double>> dmVec(uniqueDefocusMaskBias.begin(),
                                                  uniqueDefocusMaskBias.end());
    for (size_t ci : myClipIndices) {
        for (size_t di = 0; di < dmVec.size(); ++di) {
            tasks.push_back({ci, dmVec[di].first, dmVec[di].second});
        }
    }

    size_t myTotalTasks = tasks.size();

    // 像計算ループ中はstderr/stdoutを復元（lithoKernelがexit()する場合にエラーメッセージを表示するため）
    std::cerr.rdbuf(origCerrBuf);
    std::cout.rdbuf(origCoutBuf);

#ifdef _OPENMP
    // --- OpenMP並列化 ---
    std::vector<std::pair<std::string, SourceContributionSet>> taskResults(tasks.size());
    std::vector<bool> taskSuccess(tasks.size(), false);

    #pragma omp parallel for schedule(dynamic)
    for (size_t t = 0; t < tasks.size(); ++t) {
        const auto& task = tasks[t];
        const auto& clip = clips[task.clipIdx];
        const auto& polyData = clipPolygons.at(task.clipIdx);

        try {
            // resistModelパスを決定
            std::string resistModelPath = m_resistModelFile;
            if (std::abs(task.mask_bias) > 1e-9) {
                resistModelPath = resistModelDir + "/" +
                                 ResistModelGenerator::makeFileName(task.mask_bias);
            }
            if (resistModelPath.empty() || !std::filesystem::exists(resistModelPath)) {
                resistModelPath = resistModelDir + "/resistModel_default.info";
                // Note: デフォルトファイル作成はスレッドセーフでないため、
                // 事前にrank 0で作成済みと仮定
            }

            // 周波数空間で計算
            SourceContributionSet contribSet;
            contribSet.setDimensions(dimx, dimy, Lx, Ly);
            contribSet.setD2Symmetry(gridConfig.isD2Symmetry());

            auto* resist = new resistModel6::cResistModelList(resistModelPath);

            for (const auto& [gx, gy] : sourcePoints) {
                std::string sourceID = SourceGrid::makeSourceID(gx, gy);

                auto cacheIt = socsCache.find({sourceID, task.defocus});
                if (cacheIt == socsCache.end()) continue;

                auto* MCALCS = cacheIt->second.mcalcs;
                double norm = cacheIt->second.norm;

                auto* m_pattern = new lithoKernel::cResistImage(MCALCS, resist);

                lithoGtl::Polygons PMainCopy = polyData.PMain;
                lithoGtl::Polygons PSrafCopy = polyData.PSraf;
                std::vector<std::complex<double>> fResistImage = m_pattern->calc_image(PMainCopy, PSrafCopy);
                lithoKernel::fftshift2d(fResistImage);

                SourceContribution contrib;
                contrib.sourceID = sourceID;
                contrib.gx = gx;
                contrib.gy = gy;
                contrib.norm = norm;
                contrib.freqImage.initialize(dimx, dimy, Lx, Ly);
                contrib.freqImage.setData(std::move(fResistImage));

                contribSet.addContribution(std::move(contrib));

                delete m_pattern;
            }

            delete resist;

            std::string filename = makeImageFileName(clip.clipID, task.defocus,
                                                      task.mask_bias, 0.0);
            taskResults[t] = {std::move(filename), std::move(contribSet)};
            taskSuccess[t] = true;

        } catch (const std::exception& e) {
            #pragma omp critical
            {
                log << "Error processing clip " << clip.clipID
                    << " with defocus=" << task.defocus << ", mask_bias=" << task.mask_bias
                    << ": " << e.what() << std::endl;
            }
        }
    }

    // 結果をcalcResultに集約
    for (size_t t = 0; t < tasks.size(); ++t) {
        if (taskSuccess[t]) {
            calcResult.sourceContributions[taskResults[t].first] = std::move(taskResults[t].second);
            ++completedTasks;
        }
    }

    if (m_mpiSize > 1) {
        log << "[Rank " << m_mpiRank << "] Completed " << completedTasks
            << "/" << myTotalTasks << " tasks" << std::endl;
    } else {
        log << "  Completed: " << completedTasks << "/" << myTotalTasks << std::endl;
    }

#else
    // --- シングルスレッド版 ---
    for (size_t t = 0; t < tasks.size(); ++t) {
        const auto& task = tasks[t];
        const auto& clip = clips[task.clipIdx];
        const auto& polyData = clipPolygons.at(task.clipIdx);

        try {
            std::string resistModelPath = m_resistModelFile;
            if (std::abs(task.mask_bias) > 1e-9) {
                resistModelPath = resistModelDir + "/" +
                                 ResistModelGenerator::makeFileName(task.mask_bias);
            }
            if (resistModelPath.empty() || !std::filesystem::exists(resistModelPath)) {
                resistModelPath = resistModelDir + "/resistModel_default.info";
                if (!std::filesystem::exists(resistModelPath)) {
                    std::ofstream tmp(resistModelPath);
                    tmp << "IntensityWeight 1" << std::endl;
                    tmp.close();
                }
            }

            SourceContributionSet contribSet;
            contribSet.setDimensions(dimx, dimy, Lx, Ly);
            contribSet.setD2Symmetry(gridConfig.isD2Symmetry());

            auto* resist = new resistModel6::cResistModelList(resistModelPath);

            for (const auto& [gx, gy] : sourcePoints) {
                std::string sourceID = SourceGrid::makeSourceID(gx, gy);

                auto cacheIt = socsCache.find({sourceID, task.defocus});
                if (cacheIt == socsCache.end()) continue;

                auto* MCALCS = cacheIt->second.mcalcs;
                double norm = cacheIt->second.norm;

                auto* m_pattern = new lithoKernel::cResistImage(MCALCS, resist);

                lithoGtl::Polygons PMainCopy = polyData.PMain;
                lithoGtl::Polygons PSrafCopy = polyData.PSraf;
                std::vector<std::complex<double>> fResistImage = m_pattern->calc_image(PMainCopy, PSrafCopy);
                lithoKernel::fftshift2d(fResistImage);

                SourceContribution contrib;
                contrib.sourceID = sourceID;
                contrib.gx = gx;
                contrib.gy = gy;
                contrib.norm = norm;
                contrib.freqImage.initialize(dimx, dimy, Lx, Ly);
                contrib.freqImage.setData(std::move(fResistImage));

                contribSet.addContribution(std::move(contrib));

                delete m_pattern;
            }

            delete resist;

            std::string filename = makeImageFileName(clip.clipID, task.defocus,
                                                      task.mask_bias, 0.0);
            calcResult.sourceContributions[filename] = std::move(contribSet);

            ++completedTasks;
            if (m_mpiSize > 1) {
                log << "  [Rank " << m_mpiRank << "] Progress: " << completedTasks
                    << "/" << myTotalTasks << " (total: " << totalTasks << " tasks)" << std::endl;
            } else {
                log << "  Progress: " << completedTasks << "/" << totalTasks << std::endl;
            }

        } catch (const std::exception& e) {
            log << "Error processing clip " << clip.clipID
                << " with defocus=" << task.defocus << ", mask_bias=" << task.mask_bias
                << ": " << e.what() << std::endl;
        }
    }
#endif

    // SOCSキャッシュをクリーンアップ
    for (auto& [key, cache] : socsCache) {
        delete cache.mcalcs;
    }

#ifdef _OPENMP
    // スレッド数を元に戻す
    omp_set_num_threads(prevMaxThreads);
#endif

    // stdout/stderr を復元
    std::cerr.rdbuf(origCerrBuf);
    std::cout.rdbuf(origCoutBuf);

    return calcResult;
}

CalcResult ImageCalculator::calcImages(const EvpData& evpData,
                                         const std::string& resistModelOutputDir) const {
    bool useTempDir = resistModelOutputDir.empty();
    std::string resistDir;

    if (useTempDir) {
        // 一時ディレクトリを作成
        resistDir = ".tmp_resistModel_" + std::to_string(getpid());
    } else {
        // 指定されたディレクトリを使用
        resistDir = resistModelOutputDir;
    }
    std::filesystem::create_directories(resistDir);

    try {
        CalcResult result = calcImagesInternal(evpData, resistDir);

        // 一時ディレクトリの場合のみ削除
        if (useTempDir) {
            std::filesystem::remove_all(resistDir);
        }

        return result;
    } catch (...) {
        // エラー時は一時ディレクトリのみ削除
        if (useTempDir) {
            std::filesystem::remove_all(resistDir);
        }
        throw;
    }
}

void ImageCalculator::calcAndSaveImages(const EvpData& evpData,
                                         const std::string& outputDir,
                                         bool saveAsFrequency) const {
    // 出力ディレクトリを作成
    if (std::filesystem::exists(outputDir)) {
        throw std::runtime_error("Output directory already exists: " + outputDir);
    }
    std::filesystem::create_directories(outputDir);

    // 光学像を計算（resistModelはoutputDirに生成）
    CalcResult result = calcImagesInternal(evpData, outputDir);

    const auto& gridConfig = m_sourceGrid->showConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = m_processConfig->showPwcConditions();

    if (saveAsFrequency) {
        // 周波数空間モード: combine()後のFrequencyImageをファイルに保存
        for (const auto& clip : clips) {
            for (const auto& pwc : pwcs) {
                // sourceContributionsのキー（delta_dose=0で保存されている）
                std::string baseKey = makeImageFileName(clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
                
                auto it = result.sourceContributions.find(baseKey);
                if (it == result.sourceContributions.end()) {
                    std::cerr << "Warning: No contribution set for " << baseKey << std::endl;
                    continue;
                }
                
                // 光源強度で重み付け合成（実空間モードと同じ）
                FrequencyImage freqImg = it->second.combine(*m_sourceData, gridConfig);
                
                // デバッグ: combine後の統計
                {
                    double maxMag = 0.0;
                    std::complex<double> dc = freqImg.data()[0];
                    for (const auto& v : freqImg.data()) {
                        double mag = std::abs(v);
                        if (mag > maxMag) maxMag = mag;
                    }
                    std::cerr << "[DEBUG calcImgSet freq] After combine: DC=" << dc 
                              << ", maxMag=" << maxMag << std::endl;
                }
                
                // delta_doseを適用
                if (std::abs(pwc.delta_dose) > 1e-9) {
                    freqImg.scale(1.0 + pwc.delta_dose / 100.0);
                }

                // 周波数空間のまま保存
                std::string outputFilename = makeImageFileName(clip.clipID, pwc.defocus, 
                                                                pwc.mask_bias, pwc.delta_dose);
                std::string filepath = outputDir + "/" + outputFilename + ".freq";
                freqImg.save(filepath);
            }
        }
    } else {
        // 実空間モード: 光源強度で合成→IFFT→保存
        for (const auto& clip : clips) {
            for (const auto& pwc : pwcs) {
                // sourceContributionsのキー（delta_dose=0で保存されている）
                std::string baseKey = makeImageFileName(clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
                
                auto it = result.sourceContributions.find(baseKey);
                if (it == result.sourceContributions.end()) {
                    std::cerr << "Warning: No contribution set for " << baseKey << std::endl;
                    continue;
                }
                
                // 光源強度で重み付け合成
                FrequencyImage freqImg = it->second.combine(*m_sourceData, gridConfig);
                
                // デバッグ: combine後の統計
                {
                    double maxMag = 0.0;
                    std::complex<double> dc = freqImg.data()[0];
                    for (const auto& v : freqImg.data()) {
                        double mag = std::abs(v);
                        if (mag > maxMag) maxMag = mag;
                    }
                    std::cerr << "[DEBUG calcImgSet real] After combine: DC=" << dc 
                              << ", maxMag=" << maxMag << std::endl;
                }
                
                // delta_doseを適用
                if (std::abs(pwc.delta_dose) > 1e-9) {
                    freqImg.scale(1.0 + pwc.delta_dose / 100.0);
                }

                // 実空間に変換して保存
                std::string outputFilename = makeImageFileName(clip.clipID, pwc.defocus, 
                                                                pwc.mask_bias, pwc.delta_dose);
                std::string filepath = outputDir + "/" + outputFilename;
                freqImg.saveAsRealImage(filepath);
            }
        }
    }
}

// ResistModelGenerator

void ResistModelGenerator::generate(const std::string& baseFile,
                                     const std::string& outputFile,
                                     double maskBiasNm) {
    std::vector<std::string> lines;
    double existingBiasMain = 0.0;
    double existingBiasSraf = 0.0;

    if (!baseFile.empty() && std::filesystem::exists(baseFile)) {
        std::ifstream inFile(baseFile);
        std::string line;
        
        while (std::getline(inFile, line)) {
            if (line.find("MaskBias") == 0) {
                std::istringstream iss(line);
                std::string keyword;
                iss >> keyword >> existingBiasMain >> existingBiasSraf;
            } else {
                lines.push_back(line);
            }
        }
    } else {
        lines.push_back("IntensityWeight 1");
    }

    double newBiasMain = existingBiasMain + maskBiasNm / 1000.0;
    double newBiasSraf = existingBiasSraf + maskBiasNm / 1000.0;

    std::ofstream outFile(outputFile);
    if (!outFile.is_open()) {
        throw std::runtime_error("Cannot open file for writing: " + outputFile);
    }

    for (const auto& line : lines) {
        outFile << line << "\n";
    }
    outFile << "MaskBias " << newBiasMain << " " << newBiasSraf << "\n";
}

void ResistModelGenerator::generateAll(const std::string& baseFile,
                                         const std::string& outputDir,
                                         const std::vector<double>& maskBiases) {
    // mask_bias=0のフォールバック用デフォルトファイルを生成
    generate(baseFile, outputDir + "/resistModel_default.info", 0.0);

    for (double mb : maskBiases) {
        std::string filename = makeFileName(mb);
        std::string filepath = outputDir + "/" + filename;
        generate(baseFile, filepath, mb);
    }
}

std::string ResistModelGenerator::makeFileName(double maskBiasNm) {
    std::ostringstream oss;
    oss << "resistModel_mb" << maskBiasNm << ".info";
    return oss.str();
}

} // namespace so
