/*!
 * @file optimizer_base.h
 * @brief オプティマイザ基底クラス
 */

#ifndef SO_OPTIMIZER_BASE_H
#define SO_OPTIMIZER_BASE_H

#include <so/types.h>
#include <vector>
#include <functional>
#include <cmath>

namespace so {

/*!
 * @brief コスト関数と勾配関数の型定義
 */
using CostFunction = std::function<double(const std::vector<double>&)>;
using GradientFunction = std::function<std::vector<double>(const std::vector<double>&)>;
using ProjectionFunction = std::function<void(std::vector<double>&)>;

/*!
 * @brief オプティマイザ基底クラス
 */
class OptimizerBase {
public:
    virtual ~OptimizerBase() = default;

    /*!
     * @brief オプションを設定
     */
    virtual void setOptions(const OptimizationOptions& options) {
        m_options = options;
    }

    /*!
     * @brief 最適化を実行
     * @param x0 初期値
     * @param costFunc コスト関数
     * @param gradFunc 勾配関数
     * @param projFunc 射影関数（制約処理）
     * @return 最適化結果
     */
    virtual OptimizationResult optimize(
        const std::vector<double>& x0,
        CostFunction costFunc,
        GradientFunction gradFunc,
        ProjectionFunction projFunc) = 0;

protected:
    OptimizationOptions m_options;

    /*!
     * @brief 勾配のL2ノルムを計算
     */
    double gradientNorm(const std::vector<double>& grad) const {
        double norm = 0.0;
        for (double g : grad) {
            norm += g * g;
        }
        return std::sqrt(norm);
    }

    /*!
     * @brief ベクトルの内積
     */
    double dot(const std::vector<double>& a, const std::vector<double>& b) const {
        double sum = 0.0;
        for (size_t i = 0; i < a.size(); ++i) {
            sum += a[i] * b[i];
        }
        return sum;
    }

    /*!
     * @brief a + alpha * b
     */
    std::vector<double> axpy(double alpha, const std::vector<double>& x,
                             const std::vector<double>& y) const {
        std::vector<double> result(x.size());
        for (size_t i = 0; i < x.size(); ++i) {
            result[i] = x[i] + alpha * y[i];
        }
        return result;
    }
};

} // namespace so

#endif // SO_OPTIMIZER_BASE_H
