/*!
 * @file evp_data.cpp
 * @brief evp.csv 読み込み・管理
 */

#include "evp_data.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <set>
#include <cmath>

namespace so {

EvpData::EvpData() {}

EvpData::~EvpData() {}

void EvpData::load(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open evp file: " + filepath);
    }

    m_evalPoints.clear();
    m_clips.clear();
    m_cutlinePairs.clear();

    std::string line;
    bool headerSkipped = false;

    while (std::getline(file, line)) {
        // 空行をスキップ
        if (line.empty()) {
            continue;
        }

        // ヘッダ行をスキップ（最初の非空行）
        if (!headerSkipped) {
            // ヘッダかどうか確認（clipIDで始まるか数字で始まるか）
            if (line.find("clipID") != std::string::npos) {
                headerSkipped = true;
                continue;
            }
            headerSkipped = true;
        }

        // CSV行をパース
        std::istringstream iss(line);
        std::string token;
        std::vector<std::string> tokens;
        
        while (std::getline(iss, token, ',')) {
            tokens.push_back(token);
        }

        if (tokens.size() >= 9) {
            EvalPoint ep;
            try {
                ep.clipID = std::stoi(tokens[0]);
                ep.cx = std::stod(tokens[1]);
                ep.cy = std::stod(tokens[2]);
                ep.px = std::stod(tokens[3]);
                ep.py = std::stod(tokens[4]);
                ep.degree = std::stod(tokens[5]);
                ep.tolerance = std::stod(tokens[6]);
                ep.weight = std::stod(tokens[7]);
                ep.cutlineID = tokens[8];
                
                // 末尾の改行・空白を除去
                while (!ep.cutlineID.empty() && 
                       (ep.cutlineID.back() == '\r' || 
                        ep.cutlineID.back() == '\n' ||
                        ep.cutlineID.back() == ' ')) {
                    ep.cutlineID.pop_back();
                }
                
                m_evalPoints.push_back(ep);
            } catch (const std::exception& e) {
                // パースエラーは無視して続行
                continue;
            }
        }
    }

    // クリップ情報とCutlineペアを構築
    buildClipInfo();
    buildCutlinePairs();
}

void EvpData::buildClipInfo() {
    m_clips.clear();
    
    std::map<int, ClipInfo> clipMap;
    
    for (const auto& ep : m_evalPoints) {
        if (clipMap.find(ep.clipID) == clipMap.end()) {
            ClipInfo info;
            info.clipID = ep.clipID;
            info.cx = ep.cx;
            info.cy = ep.cy;
            clipMap[ep.clipID] = info;
        }
        clipMap[ep.clipID].evalPoints.push_back(&ep);
    }
    
    for (auto& [id, info] : clipMap) {
        m_clips.push_back(std::move(info));
    }
    
    // clipIDでソート
    std::sort(m_clips.begin(), m_clips.end(), 
              [](const ClipInfo& a, const ClipInfo& b) {
                  return a.clipID < b.clipID;
              });
}

void EvpData::buildCutlinePairs() {
    m_cutlinePairs.clear();
    
    for (const auto& clip : m_clips) {
        // X方向cutline (cl_xl と cl_xr)
        const EvalPoint* cl_xl = nullptr;
        const EvalPoint* cl_xr = nullptr;
        
        // Y方向cutline (cl_yb と cl_yt)
        const EvalPoint* cl_yb = nullptr;
        const EvalPoint* cl_yt = nullptr;
        
        for (const auto* ep : clip.evalPoints) {
            if (ep->cutlineID == "cl_xl") cl_xl = ep;
            else if (ep->cutlineID == "cl_xr") cl_xr = ep;
            else if (ep->cutlineID == "cl_yb") cl_yb = ep;
            else if (ep->cutlineID == "cl_yt") cl_yt = ep;
        }
        
        // X方向cutline
        if (cl_xl && cl_xr) {
            CutlinePair pair;
            pair.clipID = clip.clipID;
            pair.direction = "X";
            pair.point1 = cl_xl;
            pair.point2 = cl_xr;
            // CD = cl_xr.x - cl_xl.x (相対座標の差)
            pair.CD = cl_xr->px - cl_xl->px;
            m_cutlinePairs.push_back(pair);
        }
        
        // Y方向cutline
        if (cl_yb && cl_yt) {
            CutlinePair pair;
            pair.clipID = clip.clipID;
            pair.direction = "Y";
            pair.point1 = cl_yb;
            pair.point2 = cl_yt;
            // CD = cl_yt.y - cl_yb.y (相対座標の差)
            pair.CD = cl_yt->py - cl_yb->py;
            m_cutlinePairs.push_back(pair);
        }
    }
}

const std::vector<ClipInfo>& EvpData::showClips() const {
    return m_clips;
}

const std::vector<CutlinePair>& EvpData::showCutlinePairs() const {
    return m_cutlinePairs;
}

const ClipInfo* EvpData::getClip(int clipID) const {
    for (const auto& clip : m_clips) {
        if (clip.clipID == clipID) {
            return &clip;
        }
    }
    return nullptr;
}

size_t EvpData::showClipCount() const {
    return m_clips.size();
}

std::vector<int> EvpData::showClipIDs() const {
    std::vector<int> ids;
    for (const auto& clip : m_clips) {
        ids.push_back(clip.clipID);
    }
    return ids;
}

size_t EvpData::showEvalPointCount() const {
    return m_evalPoints.size();
}

void EvpData::setEvalPointWeights(const std::vector<double>& newWeights) {
    if (newWeights.size() != m_evalPoints.size()) {
        return;  // サイズ不一致は無視（呼び出し側で保証）
    }
    for (size_t i = 0; i < m_evalPoints.size(); ++i) {
        m_evalPoints[i].weight = newWeights[i];
    }
    // ClipInfo::evalPoints は m_evalPoints へのポインタなので追加処理は不要
}

} // namespace so
