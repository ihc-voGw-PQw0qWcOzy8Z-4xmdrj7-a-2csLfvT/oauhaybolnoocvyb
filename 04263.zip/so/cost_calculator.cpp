/*!
 * @file cost_calculator.cpp
 * @brief コスト計算クラスの実装（周波数空間ベース）
 */

#include "cost_calculator.h"
#include "epe_newton.h"
#include <so/types.h>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <stdexcept>

namespace so {

CostCalculator::CostCalculator() {
    m_options.anchorClips.push_back(0);
}

CostCalculator::~CostCalculator() = default;

void CostCalculator::setOptions(const CostOptions& options) {
    m_options = options;
}

const CostOptions& CostCalculator::showOptions() const {
    return m_options;
}

EpeCalcResult CostCalculator::calcEPE(
    const FrequencyImage& freqImage,
    double px, double py,
    double degree,
    double sliceLevel,
    int maxIter,
    double tolerance) const {

    return calcEpeNewton(freqImage, px, py, degree, sliceLevel, maxIter, tolerance);
}

double CostCalculator::findOptimalSliceLevel(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.5;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    // ============================================================
    // Phase B: anchor 画像を「全 anchor clip × (nominal もしくは 全 PWC)」分構築
    // ============================================================
    // pwcMode が AllPwc なら全 PWC、NominalOnly なら nominal のみ。
    std::vector<int> effectiveAnchorClips = m_options.anchorClips;
    if (effectiveAnchorClips.empty()) {
        for (const auto& clip : evpData.showClips()) {
            effectiveAnchorClips.push_back(clip.clipID);
        }
    }

    // PWC リストを決定
    std::vector<size_t> usedPwcIndices;
    if (m_options.slicePwcMode == SlicePwcMode::AllPwc) {
        for (size_t i = 0; i < pwcs.size(); ++i) usedPwcIndices.push_back(i);
    } else {
        usedPwcIndices.push_back(static_cast<size_t>(nominalIndex));
    }

    // (clipInfo, pwc, freqImage) のセットを保持
    struct AnchorEntry {
        const ClipInfo* clipInfo;
        const PwcCondition* pwc;
        FrequencyImage freqImg;
    };
    std::vector<AnchorEntry> anchorEntries;

    for (int clipID : effectiveAnchorClips) {
        const ClipInfo* clipInfo = evpData.getClip(clipID);
        if (!clipInfo) continue;
        for (size_t pi : usedPwcIndices) {
            const auto& pwc = pwcs[pi];
            std::string filename = makeImageFileName(clipID, pwc.defocus,
                                                              pwc.mask_bias, 0.0);
            auto it = sourceContributions.find(filename);
            if (it == sourceContributions.end()) continue;

            FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
            if (std::abs(pwc.delta_dose) > 1e-9) {
                freqImg.scale(1.0 + pwc.delta_dose / 100.0);
            }
            anchorEntries.push_back({clipInfo, &pwc, std::move(freqImg)});
        }
    }

    // フォールバック: anchor が一つも見つからなかった場合は nominal の任意 clip を使う
    if (anchorEntries.empty()) {
        std::cerr << "Warning: Specified anchor clips not found, searching for available clips..." << std::endl;
        const auto& clips = evpData.showClips();
        for (const auto& clip : clips) {
            std::string filename = makeImageFileName(clip.clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, 0.0);
            auto it = sourceContributions.find(filename);
            if (it != sourceContributions.end()) {
                FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
                if (std::abs(nominalPwc.delta_dose) > 1e-9) {
                    freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
                }
                anchorEntries.push_back({&clip, &nominalPwc, std::move(freqImg)});
                std::cerr << "  Using clipID=" << clip.clipID << " as anchor" << std::endl;
                break;
            }
        }
    }

    if (anchorEntries.empty()) {
        return 0.5;
    }

    // 評価点強度の平均から探索範囲を決める（nominal 相当のエントリ）
    double sumIntensity = 0.0;
    int countPoints = 0;
    for (const auto& ae : anchorEntries) {
        // nominal 相当のエントリのみ平均に使う（off-nominal だと dose 補正で偏るため）
        if (std::abs(ae.pwc->delta_dose) > 1e-9) continue;
        for (const auto* ep : ae.clipInfo->evalPoints) {
            auto pv = ae.freqImg.evalAt(ep->px, ep->py);
            sumIntensity += pv.intensity;
            countPoints++;
        }
    }
    if (countPoints == 0) {
        // 全部 off-nominal だった場合は仕方なく全部使う
        for (const auto& ae : anchorEntries) {
            for (const auto* ep : ae.clipInfo->evalPoints) {
                auto pv = ae.freqImg.evalAt(ep->px, ep->py);
                sumIntensity += pv.intensity;
                countPoints++;
            }
        }
    }
    double avgEdgeIntensity = (countPoints > 0) ? sumIntensity / countPoints : 0.5;

    std::cerr << "Average intensity at evaluation points: " << avgEdgeIntensity
              << " (anchorEntries=" << anchorEntries.size()
              << ", objective=" << (m_options.sliceObjective == SliceObjective::MaxAbsEPE ? "MaxAbsEPE" : "DeltaCD2")
              << ", pwcMode=" << (m_options.slicePwcMode == SlicePwcMode::AllPwc ? "AllPwc" : "NominalOnly")
              << ")" << std::endl;

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);

    if (b - a < avgEdgeIntensity * 0.2) {
        a = avgEdgeIntensity * 0.5;
        b = avgEdgeIntensity * 1.5;
    }

    std::cerr << "Slice level search: range=[" << a << ", " << b << "]" << std::endl;

    const double goldenRatio = (std::sqrt(5.0) - 1.0) / 2.0;
    double c = b - goldenRatio * (b - a);
    double d = a + goldenRatio * (b - a);

    // ============================================================
    // 目的関数: SliceObjective に応じて
    //   DeltaCD2:   Σ_pwc Σ_pair w_pwc × (EPE1+EPE2)²
    //   MaxAbsEPE:  max_{pwc, evp} max(0, |EPE_i|-tol_i)  （重みは
    //               smooth-max 化のため使わない）
    // ============================================================
    auto evalFunc = [&](double sliceLevel) -> double {
        if (m_options.sliceObjective == SliceObjective::MaxAbsEPE) {
            double maxAbs = 0.0;
            for (const auto& ae : anchorEntries) {
                for (const auto* ep : ae.clipInfo->evalPoints) {
                    auto er = calcEPE(ae.freqImg, ep->px, ep->py,
                                      ep->degree, sliceLevel);
                    double absEpe = std::abs(er.epe);
                    double eff = std::max(0.0, absEpe - ep->tolerance);
                    if (eff > maxAbs) maxAbs = eff;
                }
            }
            return maxAbs;
        } else {
            double totalDeltaCDSq = 0.0;
            for (const auto& ae : anchorEntries) {
                double w = ae.pwc->weight;
                for (const auto& pair : evpData.showCutlinePairs()) {
                    if (pair.clipID != ae.clipInfo->clipID) continue;
                    auto epe1 = calcEPE(ae.freqImg, pair.point1->px, pair.point1->py,
                                        pair.point1->degree, sliceLevel);
                    auto epe2 = calcEPE(ae.freqImg, pair.point2->px, pair.point2->py,
                                        pair.point2->degree, sliceLevel);
                    double delta_CD = epe1.epe + epe2.epe;
                    totalDeltaCDSq += w * delta_CD * delta_CD;
                }
            }
            return totalDeltaCDSq;
        }
    };

    double fc = evalFunc(c);
    double fd = evalFunc(d);

    for (int iter = 0; iter < 50; ++iter) {
        if (fc < fd) {
            b = d;
            d = c;
            fd = fc;
            c = b - goldenRatio * (b - a);
            fc = evalFunc(c);
        } else {
            a = c;
            c = d;
            fc = fd;
            d = a + goldenRatio * (b - a);
            fd = evalFunc(d);
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

// ----------------------------------------------------------------------------
// 「指定 cutline ペアの delta_CD = 0」二分探索
// ----------------------------------------------------------------------------
double CostCalculator::findSliceLevelByEpeZero(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    int anchorClipID,
    const std::string& direction) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    if (pwcs.empty()) return 0.5;
    const auto& nominalPwc = pwcs[nominalIndex];

    // anchor clip の決定
    int useClipID = anchorClipID;
    if (useClipID < 0) {
        // anchor_clips オプションの先頭 → なければ最初の利用可能 clip
        if (!m_options.anchorClips.empty()) {
            useClipID = m_options.anchorClips.front();
        } else if (!evpData.showClips().empty()) {
            useClipID = evpData.showClips().front().clipID;
        } else {
            return 0.5;
        }
    }

    // anchor cutline ペアを探す
    const CutlinePair* targetPair = nullptr;
    for (const auto& pair : evpData.showCutlinePairs()) {
        if (pair.clipID == useClipID && pair.direction == direction) {
            targetPair = &pair;
            break;
        }
    }
    if (!targetPair) {
        std::cerr << "Warning: cutline pair (clipID=" << useClipID
                  << ", direction=" << direction << ") not found, "
                  << "falling back to first available pair" << std::endl;
        if (!evpData.showCutlinePairs().empty()) {
            targetPair = &evpData.showCutlinePairs().front();
        } else {
            return 0.5;
        }
    }

    // anchor 画像（nominal PWC）
    std::string filename = makeImageFileName(useClipID, nominalPwc.defocus,
                                                       nominalPwc.mask_bias, 0.0);
    auto it = sourceContributions.find(filename);
    if (it == sourceContributions.end()) {
        std::cerr << "Warning: anchor image not found for clipID="
                  << useClipID << std::endl;
        return 0.5;
    }
    FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
    if (std::abs(nominalPwc.delta_dose) > 1e-9) {
        freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
    }

    // 評価点平均強度から探索範囲を決める（nominal PWC ベース）
    double sumIntensity = 0.0;
    int countPoints = 0;
    auto clipInfo = evpData.getClip(useClipID);
    if (clipInfo) {
        for (const auto* ep : clipInfo->evalPoints) {
            auto pv = freqImg.evalAt(ep->px, ep->py);
            sumIntensity += pv.intensity;
            countPoints++;
        }
    }
    double avgEdgeIntensity = (countPoints > 0) ? sumIntensity / countPoints : 0.5;
    double a = avgEdgeIntensity * 0.1;
    double b = avgEdgeIntensity * 2.0;
    if (m_options.sliceLevelHint > 0) {
        // hint があればその近傍に絞る
        double range = std::max(0.05, avgEdgeIntensity * 0.5);
        a = std::max(0.0, m_options.sliceLevelHint - range);
        b = m_options.sliceLevelHint + range;
    }

    // delta_CD(t) = EPE1(t) + EPE2(t) は t の増加に対して概ね単調
    // （sliceLevel が上がると intensity > sliceLevel 領域が縮み EPE が変化）
    // 二分探索で零点を探す
    auto delta = [&](double t) {
        auto e1 = calcEPE(freqImg, targetPair->point1->px, targetPair->point1->py,
                          targetPair->point1->degree, t);
        auto e2 = calcEPE(freqImg, targetPair->point2->px, targetPair->point2->py,
                          targetPair->point2->degree, t);
        return e1.epe + e2.epe;
    };

    double fa = delta(a);
    double fb = delta(b);
    if (fa * fb > 0) {
        // 零点が範囲内にない: 範囲を拡張して再試行
        double extA = std::max(1e-6, avgEdgeIntensity * 0.05);
        double extB = avgEdgeIntensity * 4.0;
        a = extA; b = extB;
        fa = delta(a); fb = delta(b);
        if (fa * fb > 0) {
            // それでも見つからない: 絶対値最小の端点を返す
            std::cerr << "Warning: epe-zero bisection failed, returning best end-point" << std::endl;
            return (std::abs(fa) < std::abs(fb)) ? a : b;
        }
    }

    // bisection 50 iter（精度 1e-8 程度）
    for (int iter = 0; iter < 60; ++iter) {
        double m = 0.5 * (a + b);
        double fm = delta(m);
        if (std::abs(fm) < 1e-12 || (b - a) < 1e-9) {
            return m;
        }
        if (fa * fm < 0) {
            b = m; fb = fm;
        } else {
            a = m; fa = fm;
        }
    }
    return 0.5 * (a + b);
}

double CostCalculator::calcAnchorDeltaCDSum(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.0;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    double totalDeltaCD = 0.0;
    bool foundAnyClip = false;

    for (int clipID : m_options.anchorClips) {
        std::string filename = makeImageFileName(clipID, nominalPwc.defocus,
                                                          nominalPwc.mask_bias, 0.0);
        auto it = sourceContributions.find(filename);
        if (it == sourceContributions.end()) continue;
        
        foundAnyClip = true;
        FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
        if (std::abs(nominalPwc.delta_dose) > 1e-9) {
            freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
        }

        for (const auto& pair : evpData.showCutlinePairs()) {
            if (pair.clipID != clipID) continue;
            
            auto epe1 = calcEPE(freqImg, pair.point1->px, pair.point1->py,
                                pair.point1->degree, sliceLevel);
            auto epe2 = calcEPE(freqImg, pair.point2->px, pair.point2->py,
                                pair.point2->degree, sliceLevel);
            totalDeltaCD += epe1.epe + epe2.epe;
        }
    }

    if (!foundAnyClip) {
        const auto& clips = evpData.showClips();
        for (const auto& clip : clips) {
            std::string filename = makeImageFileName(clip.clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, 0.0);
            auto it = sourceContributions.find(filename);
            if (it == sourceContributions.end()) continue;
            
            FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
            if (std::abs(nominalPwc.delta_dose) > 1e-9) {
                freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
            }

            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clip.clipID) continue;
                
                auto epe1 = calcEPE(freqImg, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(freqImg, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                totalDeltaCD += epe1.epe + epe2.epe;
            }
            break;
        }
    }

    return totalDeltaCD;
}

double CostCalculator::findSliceLevelForTargetDeltaCD(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double targetDeltaCD) const {

    double avgEdgeIntensity = 0.5;
    
    for (const auto& [filename, contribSet] : sourceContributions) {
        if (contribSet.empty()) continue;
        
        FrequencyImage freqImg = contribSet.combine(sourceData, gridConfig);
        const auto& clips = evpData.showClips();
        
        if (!clips.empty() && !clips[0].evalPoints.empty()) {
            auto pv = freqImg.evalAt(clips[0].evalPoints[0]->px, clips[0].evalPoints[0]->py);
            avgEdgeIntensity = pv.intensity;
            break;
        }
    }

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);

    std::cerr << "Target delta_CD search: range=[" << a << ", " << b << "]"
              << ", target=" << targetDeltaCD << std::endl;

    auto evalFunc = [&](double sliceLevel) {
        double deltaCDSum = calcAnchorDeltaCDSum(sourceContributions, sourceData, gridConfig,
                                                 evpData, processConfig, sliceLevel);
        return std::abs(targetDeltaCD - deltaCDSum);
    };

    for (int iter = 0; iter < 50; ++iter) {
        double m1 = a + (b - a) / 3.0;
        double m2 = b - (b - a) / 3.0;
        
        if (evalFunc(m1) < evalFunc(m2)) {
            b = m2;
        } else {
            a = m1;
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

CostResult CostCalculator::calculate(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sourceFillRatio) const {

    CostResult result;

    double sliceLevel = m_options.sliceLevel;
    if (sliceLevel < 0) {
        if (m_options.useTargetDeltaCD) {
            sliceLevel = findSliceLevelForTargetDeltaCD(
                sourceContributions, sourceData, gridConfig,
                evpData, processConfig, m_options.targetDeltaCD);
        } else {
            sliceLevel = findOptimalSliceLevel(
                sourceContributions, sourceData, gridConfig,
                evpData, processConfig);
        }
    }
    result.sliceLevel = sliceLevel;

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            
            std::string filename = makeImageFileName(clip.clipID, pwc.defocus,
                                                              pwc.mask_bias, 0.0);
            auto it = sourceContributions.find(filename);
            if (it == sourceContributions.end()) {
                std::cerr << "Warning: Image not found for " << filename << std::endl;
                continue;
            }
            
            FrequencyImage freqImage = it->second.combine(sourceData, gridConfig);

            if (std::abs(pwc.delta_dose) > 1e-9) {
                freqImage.scale(1.0 + pwc.delta_dose / 100.0);
            }

            for (size_t evpIdx = 0; evpIdx < clip.evalPoints.size(); ++evpIdx) {
                const auto* ep = clip.evalPoints[evpIdx];
                
                auto epeCalc = calcEPE(freqImage, ep->px, ep->py, ep->degree, sliceLevel);
                
                EpeResult epeResult;
                epeResult.clipID = clip.clipID;
                epeResult.pwcIndex = static_cast<int>(pwcIdx);
                epeResult.evpIndex = static_cast<int>(evpIdx);
                epeResult.defocus = pwc.defocus;
                epeResult.maskBias = pwc.mask_bias;
                epeResult.deltaDose = pwc.delta_dose;
                epeResult.px = ep->px;
                epeResult.py = ep->py;
                epeResult.degree = ep->degree;
                epeResult.EPE = epeCalc.epe;
                epeResult.QEPE = epeCalc.qepe;
                epeResult.intensity = epeCalc.intensity;
                epeResult.gradient = epeCalc.gradient;
                epeResult.weight_p = ep->weight;
                epeResult.weight_pwc = pwc.weight;
                epeResult.converged = epeCalc.converged;
                epeResult.iterations = epeCalc.iterations;
                
                result.epeResults.push_back(epeResult);
            }
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clip.clipID) continue;
                
                auto epe1 = calcEPE(freqImage, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(freqImage, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                
                CutlineResult cutlineResult;
                cutlineResult.clipID = clip.clipID;
                cutlineResult.pwcIndex = static_cast<int>(pwcIdx);
                cutlineResult.defocus = pwc.defocus;
                cutlineResult.maskBias = pwc.mask_bias;
                cutlineResult.deltaDose = pwc.delta_dose;
                cutlineResult.direction = pair.direction;
                cutlineResult.CD = pair.CD;
                cutlineResult.delta_CD = epe1.epe + epe2.epe;
                cutlineResult.delta_CD_QEPE = epe1.qepe + epe2.qepe;
                cutlineResult.EPE1 = epe1.epe;
                cutlineResult.EPE2 = epe2.epe;
                cutlineResult.QEPE1 = epe1.qepe;
                cutlineResult.QEPE2 = epe2.qepe;
                
                result.cutlineResults.push_back(cutlineResult);
            }
        }
    }

    result.EPE_cost = calcEPECost(result.epeResults);
    result.QEPE_cost = calcQEPECost(result.epeResults);
    result.source_fill_cost = calcSourceFillCost(sourceFillRatio);
    result.NILS_cost = calcNilsCost(result.epeResults, result.sliceLevel);
    result.total_cost = result.EPE_cost + m_options.weightFill * result.source_fill_cost
                      + m_options.weightNils * result.NILS_cost;
    result.total_cost_QEPE = result.QEPE_cost + m_options.weightFill * result.source_fill_cost
                           + m_options.weightNils * result.NILS_cost;

    // |EPE|, |QEPE| の最大値とそのインデックスを走査
    for (size_t i = 0; i < result.epeResults.size(); ++i) {
        const auto& er = result.epeResults[i];
        double aE = std::abs(er.EPE);
        double aQ = std::abs(er.QEPE);
        if (aE > result.maxAbsEPE) {
            result.maxAbsEPE = aE;
            result.maxAbsEPE_index = static_cast<int>(i);
        }
        if (aQ > result.maxAbsQEPE) {
            result.maxAbsQEPE = aQ;
            result.maxAbsQEPE_index = static_cast<int>(i);
        }
    }

    return result;
}

double CostCalculator::calcSourceFillCost(double sourceFillRatio) const {
    if (sourceFillRatio >= m_options.minSourceFillRatio) {
        return 0.0;
    }

    double diff = m_options.minSourceFillRatio - sourceFillRatio;

    if (m_options.useExponentialFillPenalty) {
        // 指数ペナルティ: exp(k * diff) - 1
        double k = m_options.fillPenaltyExponent;
        return std::exp(k * diff) - 1.0;
    } else {
        // 従来の二乗ペナルティ
        return diff * diff;
    }
}

double CostCalculator::calcEPECost(const std::vector<EpeResult>& epeResults) const {
    double totalCost = 0.0;
    double totalWeight = 0.0;

    for (const auto& result : epeResults) {
        totalCost += result.EPE * result.EPE * result.weight_p * result.weight_pwc;
        totalWeight += result.weight_p * result.weight_pwc;
    }

    if (totalWeight > 0) {
        return totalCost * EPE_SCALE / totalWeight;
    }
    return 0.0;
}

double CostCalculator::calcQEPECost(const std::vector<EpeResult>& epeResults) const {
    double totalCost = 0.0;
    double totalWeight = 0.0;

    for (const auto& result : epeResults) {
        totalCost += result.QEPE * result.QEPE * result.weight_p * result.weight_pwc;
        totalWeight += result.weight_p * result.weight_pwc;
    }

    if (totalWeight > 0) {
        return totalCost * EPE_SCALE / totalWeight;
    }
    return 0.0;
}

double CostCalculator::calcNilsCost(const std::vector<EpeResult>& epeResults, double sliceLevel) const {
    if (sliceLevel <= 0.0) return 0.0;

    double totalPenalty = 0.0;
    double totalWeight = 0.0;
    for (const auto& r : epeResults) {
        double nils = m_options.nilsCdReference * std::abs(r.gradient) / sliceLevel;
        double deficit = std::max(0.0, m_options.nilsMin - nils);
        double w = r.weight_p * r.weight_pwc;
        totalPenalty += deficit * deficit * w;
        totalWeight += w;
    }
    if (totalWeight <= 0.0) return 0.0;
    return totalPenalty / totalWeight;
}

// =============================================================================
// FrequencyImage版（実空間ファイル読み込み用）
// =============================================================================

double CostCalculator::findOptimalSliceLevel(
    const std::map<std::string, FrequencyImage>& freqImages,
    const EvpData& evpData,
    const ProcessConfig& processConfig) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.5;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    std::vector<const FrequencyImage*> anchorFreqImages;
    std::vector<const ClipInfo*> anchorClipInfos;
    
    for (int clipID : m_options.anchorClips) {
        std::string filename = makeImageFileName(clipID, nominalPwc.defocus,
                                                          nominalPwc.mask_bias, nominalPwc.delta_dose);
        auto it = freqImages.find(filename);
        if (it != freqImages.end()) {
            anchorFreqImages.push_back(&it->second);
            auto clipInfo = evpData.getClip(clipID);
            if (clipInfo) {
                anchorClipInfos.push_back(clipInfo);
            }
        }
    }

    if (anchorFreqImages.empty()) {
        const auto& clips = evpData.showClips();
        for (const auto& clip : clips) {
            std::string filename = makeImageFileName(clip.clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, nominalPwc.delta_dose);
            auto it = freqImages.find(filename);
            if (it != freqImages.end()) {
                anchorFreqImages.push_back(&it->second);
                anchorClipInfos.push_back(&clip);
                break;
            }
        }
    }

    if (anchorFreqImages.empty()) {
        return 0.5;
    }

    double sumIntensity = 0.0;
    int countPoints = 0;
    for (size_t i = 0; i < anchorFreqImages.size() && i < anchorClipInfos.size(); ++i) {
        const auto* freqImg = anchorFreqImages[i];
        const auto* clipInfo = anchorClipInfos[i];
        
        for (const auto* ep : clipInfo->evalPoints) {
            auto pv = freqImg->evalAt(ep->px, ep->py);
            sumIntensity += pv.intensity;
            countPoints++;
        }
    }
    
    double avgEdgeIntensity = (countPoints > 0) ? sumIntensity / countPoints : 0.5;

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);
    
    if (b - a < avgEdgeIntensity * 0.2) {
        a = avgEdgeIntensity * 0.5;
        b = avgEdgeIntensity * 1.5;
    }

    const double goldenRatio = (std::sqrt(5.0) - 1.0) / 2.0;
    double c = b - goldenRatio * (b - a);
    double d = a + goldenRatio * (b - a);

    auto evalFunc = [&](double sliceLevel) {
        double totalDeltaCDSq = 0.0;
        
        for (size_t i = 0; i < anchorFreqImages.size() && i < anchorClipInfos.size(); ++i) {
            const auto* freqImg = anchorFreqImages[i];
            const auto* clipInfo = anchorClipInfos[i];
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clipInfo->clipID) continue;
                
                auto epe1 = calcEPE(*freqImg, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(*freqImg, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                double delta_CD = epe1.epe + epe2.epe;
                totalDeltaCDSq += delta_CD * delta_CD;
            }
        }
        
        return totalDeltaCDSq;
    };

    double fc = evalFunc(c);
    double fd = evalFunc(d);

    for (int iter = 0; iter < 50; ++iter) {
        if (fc < fd) {
            b = d;
            d = c;
            fd = fc;
            c = b - goldenRatio * (b - a);
            fc = evalFunc(c);
        } else {
            a = c;
            c = d;
            fc = fd;
            d = a + goldenRatio * (b - a);
            fd = evalFunc(d);
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

double CostCalculator::findSliceLevelForTargetDeltaCD(
    const std::map<std::string, FrequencyImage>& freqImages,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double targetDeltaCD) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.5;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    double avgEdgeIntensity = 0.5;
    for (const auto& [filename, freqImg] : freqImages) {
        const auto& clips = evpData.showClips();
        if (!clips.empty() && !clips[0].evalPoints.empty()) {
            auto pv = freqImg.evalAt(clips[0].evalPoints[0]->px, clips[0].evalPoints[0]->py);
            avgEdgeIntensity = pv.intensity;
            break;
        }
    }

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);

    auto calcDeltaCDSum = [&](double sliceLevel) {
        double totalDeltaCD = 0.0;
        
        for (int clipID : m_options.anchorClips) {
            std::string filename = makeImageFileName(clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, nominalPwc.delta_dose);
            auto it = freqImages.find(filename);
            if (it == freqImages.end()) continue;
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clipID) continue;
                
                auto epe1 = calcEPE(it->second, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(it->second, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                totalDeltaCD += epe1.epe + epe2.epe;
            }
        }
        
        return totalDeltaCD;
    };

    auto evalFunc = [&](double sliceLevel) {
        return std::abs(targetDeltaCD - calcDeltaCDSum(sliceLevel));
    };

    for (int iter = 0; iter < 50; ++iter) {
        double m1 = a + (b - a) / 3.0;
        double m2 = b - (b - a) / 3.0;
        
        if (evalFunc(m1) < evalFunc(m2)) {
            b = m2;
        } else {
            a = m1;
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

CostResult CostCalculator::calculate(
    const std::map<std::string, FrequencyImage>& freqImages,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sourceFillRatio) const {

    CostResult result;

    // デバッグ: 入力されたFrequencyImageの統計を出力
    std::cerr << "[DEBUG calculate] Number of freqImages: " << freqImages.size() << std::endl;
    int debugCount = 0;
    for (const auto& [filename, freqImg] : freqImages) {
        if (debugCount++ >= 2) break;  // 最初の2つだけ出力
        double maxMag = 0.0;
        std::complex<double> dc = freqImg.data()[0];
        for (const auto& v : freqImg.data()) {
            double mag = std::abs(v);
            if (mag > maxMag) maxMag = mag;
        }
        std::cerr << "[DEBUG calculate] " << filename 
                  << ": DC=" << dc << ", maxMag=" << maxMag 
                  << ", dim=" << freqImg.dimx() << "x" << freqImg.dimy() << std::endl;
    }

    double sliceLevel = m_options.sliceLevel;
    if (sliceLevel < 0) {
        if (m_options.useTargetDeltaCD) {
            sliceLevel = findSliceLevelForTargetDeltaCD(
                freqImages, evpData, processConfig, m_options.targetDeltaCD);
        } else {
            sliceLevel = findOptimalSliceLevel(freqImages, evpData, processConfig);
        }
    }
    result.sliceLevel = sliceLevel;

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // デバッグ: 最初のevalAt結果を出力
    bool firstEval = true;

    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            
            // 実空間ファイルはdelta_dose込みのファイル名
            std::string filename = makeImageFileName(clip.clipID, pwc.defocus,
                                                              pwc.mask_bias, pwc.delta_dose);
            auto it = freqImages.find(filename);
            if (it == freqImages.end()) {
                std::cerr << "Warning: Image not found for " << filename << std::endl;
                continue;
            }
            
            const auto& freqImage = it->second;
            
            for (size_t evpIdx = 0; evpIdx < clip.evalPoints.size(); ++evpIdx) {
                const auto* ep = clip.evalPoints[evpIdx];
                
                auto epeCalc = calcEPE(freqImage, ep->px, ep->py, ep->degree, sliceLevel);
                
                // デバッグ: 最初のevalAt結果
                if (firstEval) {
                    std::cerr << "[DEBUG calculate] First evalAt at (" << ep->px << ", " << ep->py << "): "
                              << "intensity=" << epeCalc.intensity 
                              << ", gradient=" << epeCalc.gradient 
                              << ", sliceLevel=" << sliceLevel << std::endl;
                    firstEval = false;
                }
                
                EpeResult epeResult;
                epeResult.clipID = clip.clipID;
                epeResult.pwcIndex = static_cast<int>(pwcIdx);
                epeResult.evpIndex = static_cast<int>(evpIdx);
                epeResult.defocus = pwc.defocus;
                epeResult.maskBias = pwc.mask_bias;
                epeResult.deltaDose = pwc.delta_dose;
                epeResult.px = ep->px;
                epeResult.py = ep->py;
                epeResult.degree = ep->degree;
                epeResult.EPE = epeCalc.epe;
                epeResult.QEPE = epeCalc.qepe;
                epeResult.intensity = epeCalc.intensity;
                epeResult.gradient = epeCalc.gradient;
                epeResult.weight_p = ep->weight;
                epeResult.weight_pwc = pwc.weight;
                epeResult.converged = epeCalc.converged;
                epeResult.iterations = epeCalc.iterations;
                
                result.epeResults.push_back(epeResult);
            }
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clip.clipID) continue;
                
                auto epe1 = calcEPE(freqImage, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(freqImage, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                
                CutlineResult cutlineResult;
                cutlineResult.clipID = clip.clipID;
                cutlineResult.pwcIndex = static_cast<int>(pwcIdx);
                cutlineResult.defocus = pwc.defocus;
                cutlineResult.maskBias = pwc.mask_bias;
                cutlineResult.deltaDose = pwc.delta_dose;
                cutlineResult.direction = pair.direction;
                cutlineResult.CD = pair.CD;
                cutlineResult.delta_CD = epe1.epe + epe2.epe;
                cutlineResult.delta_CD_QEPE = epe1.qepe + epe2.qepe;
                cutlineResult.EPE1 = epe1.epe;
                cutlineResult.EPE2 = epe2.epe;
                cutlineResult.QEPE1 = epe1.qepe;
                cutlineResult.QEPE2 = epe2.qepe;
                
                result.cutlineResults.push_back(cutlineResult);
            }
        }
    }

    result.EPE_cost = calcEPECost(result.epeResults);
    result.QEPE_cost = calcQEPECost(result.epeResults);
    result.source_fill_cost = calcSourceFillCost(sourceFillRatio);
    result.NILS_cost = calcNilsCost(result.epeResults, result.sliceLevel);
    result.total_cost = result.EPE_cost + m_options.weightFill * result.source_fill_cost
                      + m_options.weightNils * result.NILS_cost;
    result.total_cost_QEPE = result.QEPE_cost + m_options.weightFill * result.source_fill_cost
                           + m_options.weightNils * result.NILS_cost;

    // |EPE|, |QEPE| の最大値とそのインデックスを走査
    for (size_t i = 0; i < result.epeResults.size(); ++i) {
        const auto& er = result.epeResults[i];
        double aE = std::abs(er.EPE);
        double aQ = std::abs(er.QEPE);
        if (aE > result.maxAbsEPE) {
            result.maxAbsEPE = aE;
            result.maxAbsEPE_index = static_cast<int>(i);
        }
        if (aQ > result.maxAbsQEPE) {
            result.maxAbsQEPE = aQ;
            result.maxAbsQEPE_index = static_cast<int>(i);
        }
    }

    return result;
}

void CostWriter::write(const std::string& filepath, const CostResult& result) {
    std::ofstream ofs(filepath);
    if (!ofs.is_open()) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }

    ofs << "# Summary\n";
    ofs << "sliceLevel," << result.sliceLevel << "\n";
    ofs << "EPE_cost," << result.EPE_cost << "\n";
    ofs << "QEPE_cost," << result.QEPE_cost << "\n";
    ofs << "source_fill_cost," << result.source_fill_cost << "\n";
    ofs << "NILS_cost," << result.NILS_cost << "\n";
    ofs << "total_cost," << result.total_cost << "\n";
    ofs << "total_cost_QEPE," << result.total_cost_QEPE << "\n";
    ofs << "maxAbsEPE," << result.maxAbsEPE << "\n";
    ofs << "maxAbsQEPE," << result.maxAbsQEPE << "\n";
    // ピーク点の評価点識別子（epeResults を参照するための ID 列）
    if (result.maxAbsEPE_index >= 0 &&
        result.maxAbsEPE_index < static_cast<int>(result.epeResults.size())) {
        const auto& er = result.epeResults[result.maxAbsEPE_index];
        ofs << "maxAbsEPE_location,clipID=" << er.clipID
            << ";pwcIndex=" << er.pwcIndex
            << ";evpIndex=" << er.evpIndex
            << ";px=" << er.px << ";py=" << er.py << ";degree=" << er.degree << "\n";
    } else {
        ofs << "maxAbsEPE_location,\n";
    }
    if (result.maxAbsQEPE_index >= 0 &&
        result.maxAbsQEPE_index < static_cast<int>(result.epeResults.size())) {
        const auto& er = result.epeResults[result.maxAbsQEPE_index];
        ofs << "maxAbsQEPE_location,clipID=" << er.clipID
            << ";pwcIndex=" << er.pwcIndex
            << ";evpIndex=" << er.evpIndex
            << ";px=" << er.px << ";py=" << er.py << ";degree=" << er.degree << "\n";
    } else {
        ofs << "maxAbsQEPE_location,\n";
    }

    ofs << "# Cutline Results\n";
    ofs << "clipID,pwcIndex,defocus,maskBias,deltaDose,direction,CD,delta_CD,delta_CD_QEPE,EPE1,EPE2,QEPE1,QEPE2\n";
    for (const auto& cr : result.cutlineResults) {
        ofs << cr.clipID << ","
            << cr.pwcIndex << ","
            << cr.defocus << ","
            << cr.maskBias << ","
            << cr.deltaDose << ","
            << cr.direction << ","
            << cr.CD << ","
            << cr.delta_CD << ","
            << cr.delta_CD_QEPE << ","
            << cr.EPE1 << ","
            << cr.EPE2 << ","
            << cr.QEPE1 << ","
            << cr.QEPE2 << "\n";
    }

    ofs << "# EPE Results\n";
    ofs << "clipID,pwcIndex,defocus,maskBias,deltaDose,evpIndex,px,py,degree,EPE,QEPE,intensity,gradient,weight_p,weight_pwc,converged,iterations\n";
    for (const auto& er : result.epeResults) {
        ofs << er.clipID << ","
            << er.pwcIndex << ","
            << er.defocus << ","
            << er.maskBias << ","
            << er.deltaDose << ","
            << er.evpIndex << ","
            << er.px << ","
            << er.py << ","
            << er.degree << ","
            << er.EPE << ","
            << er.QEPE << ","
            << er.intensity << ","
            << er.gradient << ","
            << er.weight_p << ","
            << er.weight_pwc << ","
            << (er.converged ? "true" : "false") << ","
            << er.iterations << "\n";
    }
}

} // namespace so
