#ifndef SO_PARSER_H
#define SO_PARSER_H

#include <so/types.h>
#include <string>
#include <vector>

namespace so {

/**
 * @brief 入力ファイルを解析し、矩形のリストを取得する
 * @param filename 入力ファイルパス
 * @return 矩形のリスト
 * @throws std::runtime_error ファイルが開けない場合やデータが見つからない場合
 */
std::vector<Rectangle> parseInputFile(const std::string& filename);

} // namespace so

#endif // SO_PARSER_H
