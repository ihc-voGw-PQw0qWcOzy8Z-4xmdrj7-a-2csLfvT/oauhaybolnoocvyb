#!/usr/bin/env python3
"""make_socs_for_margin.py

calcMargin 用に「最適化済み光源 (.illum) + defocus 毎」の SOCS を一括生成する。
点光源毎の SOCS を作る make_socs_set_v2.py とは別物で、ここでは
maketcc3 を `-pnt_source=<illum>` で呼び出して光源全体を SOCS に焼き込む。

ファイル命名: <output_dir>/socs_d{int_nm}.socs   (例: socs_d-100.socs, socs_d0.socs)

Usage:
    make_socs_for_margin.py \
        --source optimized_source.illum \
        --ini base_ini.txt \
        --output socs_dir/ \
        --defocus_min -100 --defocus_max 100 --defocus_step 10 \
        --kernel_num 30

環境変数 MTCCPATH に maketcc3 の格納ディレクトリを設定しておくこと
(make_socs_set_v2.py と同じ仕様)。
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def get_mtcc_path() -> str:
    path = os.environ.get("MTCCPATH", "")
    return path + "/" if path else ""


def make_defocus_ini(base_ini: Path, defocus_nm: float, out_ini: Path) -> None:
    """ini ファイルの yok_defocus を書き換える。

    make_socs_set_v2.create_defocus_ini と同じ規約:
      yok_defocus = defocus_nm / 1000.0  (μm 単位)
    既存の `yok_defocus ...` 行を置換する。無い場合はファイル末尾に追加する。
    """
    delta_um = defocus_nm / 1000.0
    replaced = False
    with open(base_ini, "r") as fin, open(out_ini, "w") as fout:
        for line in fin:
            if re.match(r"^\s*yok_defocus\b", line):
                fout.write(f"yok_defocus {delta_um:g}\n")
                replaced = True
            else:
                fout.write(line)
        if not replaced:
            fout.write(f"yok_defocus {delta_um:g}\n")


def parse_defocus_list(args: argparse.Namespace) -> list[float]:
    if args.defocus_list:
        items = [s.strip() for s in args.defocus_list.split(",") if s.strip()]
        return [float(s) for s in items]
    if args.defocus_step <= 0:
        raise ValueError("--defocus_step must be > 0")
    out = []
    v = args.defocus_min
    eps = args.defocus_step * 1e-6
    while v <= args.defocus_max + eps:
        out.append(round(v, 6))
        v += args.defocus_step
    return out


def run_one_m2d(maketcc: str, ini: Path, socs_out: Path, source_illum: Path,
                kernel_num: int, openmp_num: int, log_path: Path) -> bool:
    """M2D: maketcc3 -pnt_source=<illum> ini tcc -soc=socs を実行。"""
    tcc_tmp = socs_out.with_suffix(".tcc")
    cmd = [
        f"{maketcc}maketcc3",
        f"-pnt_source={source_illum}",
        str(ini),
        str(tcc_tmp),
        f"-kernel={kernel_num}",
        f"-soc={socs_out}",
    ]
    env = os.environ.copy()
    env["OMP_NUM_THREADS"] = str(openmp_num)

    with open(log_path, "w") as logf:
        logf.write(f"# command: {' '.join(cmd)}\n")
        logf.flush()
        result = subprocess.run(cmd, env=env, stdout=logf, stderr=subprocess.STDOUT)

    # tcc 中間ファイルは不要
    if tcc_tmp.exists():
        try:
            tcc_tmp.unlink()
        except OSError:
            pass

    if result.returncode != 0:
        return False
    return socs_out.exists()


def _env_with_mtcc_in_path() -> dict:
    """maketcc_* は内部で m3d_cgr など同ディレクトリのバイナリを PATH 経由で
    呼ぶので、MTCCPATH を PATH の先頭に追加した env を返す。"""
    env = os.environ.copy()
    mtcc_dir = env.get("MTCCPATH", "")
    if mtcc_dir:
        env["PATH"] = f"{mtcc_dir}:{env.get('PATH', '')}"
    return env


def make_cgrp(maketcc: str, source_illum: Path, cgrp_out: Path,
              cgrp_x: str, cgrp_y: str, cgrp_xy: str, log_path: Path) -> bool:
    """maketcc_cgrp で coherence group ファイルを生成 (illum 全体から、defocus に依存しない)。

    maketcc_cgrp は内部で m3d_cgr を PATH 経由で呼び出すので、env["PATH"] に
    MTCCPATH を含めておく必要がある。
    パス長対策で cgrp_out の親を cwd にし、cgrp は相対パスで渡す。
    """
    cgrp_rel = cgrp_out.name
    cwd = cgrp_out.parent
    cwd.mkdir(parents=True, exist_ok=True)

    cmd = [
        f"{maketcc}maketcc_cgrp",
        str(source_illum),
        cgrp_rel,
        "--x", cgrp_x,
        "--y", cgrp_y,
        "--xy", cgrp_xy,
    ]
    env = _env_with_mtcc_in_path()
    with open(log_path, "w") as logf:
        logf.write(f"# cgrp command: {' '.join(cmd)}\n")
        logf.write(f"# cwd: {cwd}\n")
        logf.flush()
        result = subprocess.run(cmd, env=env, cwd=str(cwd),
                                stdout=logf, stderr=subprocess.STDOUT)
    if result.returncode != 0:
        return False
    return cgrp_out.exists()


def run_one_m3d(maketcc: str, ini: Path, socs_out: Path, source_illum: Path,
                cgrp_file: Path, kernel_num: int, openmp_num: int,
                log_path: Path) -> bool:
    """M3D: maketcc_m3d --cgrp <cgrp> -n 1 -o N -s --kernel_num K <illum> <ini> <socs> を実行。

    -s フラグを付けないと中間 tcc までしか作られず socs が生成されない。

    パス長対策: maketcc_m3d は SOCS の絶対パスが 64 文字を超えるとエラーに
    なることが報告されているので、socs_out の親を cwd にして socs を相対パス
    (socs ファイル名のみ) で渡す。illum / ini / cgrp は絶対パスで渡しても OK。
    """
    socs_rel = socs_out.name
    cwd = socs_out.parent
    cwd.mkdir(parents=True, exist_ok=True)

    cmd = [
        f"{maketcc}maketcc_m3d",
        "--cgrp", str(cgrp_file),
        "-n", "1",
        "-o", str(openmp_num),
        "-s",
        "--kernel_num", str(kernel_num),
        str(source_illum),
        str(ini),
        socs_rel,  # 相対パスで短く保つ
    ]
    env = _env_with_mtcc_in_path()
    env["OMP_NUM_THREADS"] = str(openmp_num)

    # 警告: SOCS 絶対パスが長い場合は気をつける
    if len(str(socs_out)) > 64:
        # cwd 切替で相対化しているので大丈夫だが、log には残す
        pass

    with open(log_path, "w") as logf:
        logf.write(f"# command: {' '.join(cmd)}\n")
        logf.write(f"# cwd: {cwd}\n")
        logf.write(f"# socs_abs_path_len: {len(str(socs_out))} chars\n")
        logf.flush()
        result = subprocess.run(cmd, env=env, cwd=str(cwd),
                                stdout=logf, stderr=subprocess.STDOUT)

    if result.returncode != 0:
        return False
    # M3D 出力はディレクトリの場合もある。ファイル or ディレクトリ存在のどちらかで成功とみなす。
    return socs_out.exists()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Generate per-defocus whole-source SOCS files for calcMargin."
    )
    parser.add_argument("--source", required=True, help="optimized source .illum file")
    parser.add_argument("--ini", required=True, help="base ini.txt (defocus will be overridden)")
    parser.add_argument("--output", required=True, help="output SOCS directory")
    parser.add_argument("--defocus_min", type=float, default=-100.0, help="[nm]")
    parser.add_argument("--defocus_max", type=float, default=100.0, help="[nm]")
    parser.add_argument("--defocus_step", type=float, default=10.0, help="[nm]")
    parser.add_argument("--defocus_list", default="",
                        help="comma-separated defocus list (overrides min/max/step)")
    parser.add_argument("--kernel_num", type=int, default=100)
    parser.add_argument("--openmp_num", type=int, default=8)
    parser.add_argument("--force", action="store_true",
                        help="re-generate SOCS even if existing file is found")
    # M3D 設定
    parser.add_argument("--m3d", action="store_true",
                        help="M3D 用 SOCS を生成 (maketcc_m3d + maketcc_cgrp を使用)")
    parser.add_argument("--cgrp_x", default="0.5",
                        help="maketcc_cgrp --x value (default: 0.5)")
    parser.add_argument("--cgrp_y", default="0.5",
                        help="maketcc_cgrp --y value (default: 0.5)")
    parser.add_argument("--cgrp_xy", default="0.5:0.5",
                        help="maketcc_cgrp --xy value (default: 0.5:0.5)")
    parser.add_argument("--cgrp_file", default="",
                        help="既存の CGRP ファイルパス (M3D 時のみ。空=自動生成)")
    args = parser.parse_args()

    source_illum = Path(args.source).resolve()
    base_ini = Path(args.ini).resolve()
    out_dir = Path(args.output).resolve()

    for p, label in [(source_illum, "--source"), (base_ini, "--ini")]:
        if not p.exists():
            print(f"ERROR: {label} not found: {p}", file=sys.stderr)
            return 1

    maketcc = get_mtcc_path()
    if maketcc == "":
        which_bin = "maketcc_m3d" if args.m3d else "maketcc3"
        print(f"WARNING: MTCCPATH not set; using {which_bin} from PATH.", file=sys.stderr)

    out_dir.mkdir(parents=True, exist_ok=True)
    work_dir = out_dir / ".work"
    work_dir.mkdir(parents=True, exist_ok=True)

    # M3D: CGRP ファイルを 1 回だけ生成 (illum 全体に依存、defocus 非依存)
    cgrp_file = None
    if args.m3d:
        if args.cgrp_file:
            cgrp_file = Path(args.cgrp_file).resolve()
            if not cgrp_file.exists():
                print(f"ERROR: specified --cgrp_file not found: {cgrp_file}",
                      file=sys.stderr)
                return 1
            print(f"[m3d ] reusing existing CGRP: {cgrp_file}")
        else:
            cgrp_file = out_dir / "src.cgrp"
            if cgrp_file.exists() and not args.force:
                print(f"[m3d ] reusing existing CGRP: {cgrp_file.name}")
            else:
                log_cgrp = work_dir / "cgrp.log"
                print(f"[m3d ] generating CGRP via maketcc_cgrp "
                      f"(x={args.cgrp_x}, y={args.cgrp_y}, xy={args.cgrp_xy})")
                ok = make_cgrp(maketcc, source_illum, cgrp_file,
                               args.cgrp_x, args.cgrp_y, args.cgrp_xy, log_cgrp)
                if not ok:
                    print(f"ERROR: CGRP generation failed. log: {log_cgrp}",
                          file=sys.stderr)
                    return 1
                print(f"[m3d ] CGRP generated: {cgrp_file.name}")

    defocus_list = parse_defocus_list(args)
    print(f"defocus list ({len(defocus_list)} points): {defocus_list}")
    print(f"mode: {'M3D (maketcc_m3d)' if args.m3d else 'M2D (maketcc3)'}")

    fail_count = 0
    for d in defocus_list:
        d_int = int(round(d))
        socs_out = out_dir / f"socs_d{d_int}.socs"
        if socs_out.exists() and not args.force:
            print(f"[skip ] socs_d{d_int}.socs (already exists)")
            continue

        ini_out = work_dir / f"ini_d{d_int}.txt"
        log_out = work_dir / f"log_d{d_int}.txt"
        make_defocus_ini(base_ini, d, ini_out)

        print(f"[build] defocus={d} nm  →  {socs_out.name}")
        if args.m3d:
            ok = run_one_m3d(maketcc, ini_out, socs_out, source_illum,
                             cgrp_file, args.kernel_num, args.openmp_num, log_out)
        else:
            ok = run_one_m2d(maketcc, ini_out, socs_out, source_illum,
                             args.kernel_num, args.openmp_num, log_out)
        if not ok:
            print(f"  FAILED. see log: {log_out}", file=sys.stderr)
            fail_count += 1

    # .work ディレクトリは ini / log を残しておく（デバッグ用）

    if fail_count > 0:
        print(f"\n{fail_count} of {len(defocus_list)} defocus values failed.", file=sys.stderr)
        return 1

    # .ready マーカ
    (out_dir / ".ready").write_text("")
    print(f"\nAll SOCS files generated in: {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
