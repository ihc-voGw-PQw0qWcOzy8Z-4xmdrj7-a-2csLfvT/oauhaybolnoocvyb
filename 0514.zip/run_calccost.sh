#!/bin/bash
#
# run_calccost.sh
#
# .illum ファイル 1 つを calcCostDirect で評価し cost.csv を出力するラッパー。
# 商用 SMO と自作 srcOptim の解を **同一条件のコスト関数** で比較するときに使う。
#
# 使い方:
#   # ローカル実行
#   ./run_calccost.sh -s <socs_dir> -l <layout> -f <source.illum> -o <cost.csv> -e <evp.csv>
#
#   # 同 PWC / 同 evp / 同 layout で 2 つ評価し直接比較
#   ./run_calccost.sh -s socs_set/ -l layout.oas -f commercial.illum -o cost_commercial.csv -e evp.csv
#   ./run_calccost.sh -s socs_set/ -l layout.oas -f mine.illum       -o cost_mine.csv       -e evp.csv
#   diff <(head -10 cost_commercial.csv) <(head -10 cost_mine.csv)
#
#   # LSF (bsub) 経由で実行
#   ./run_calccost.sh --bsub -n 1 -q OPCALL \
#       -s ./socs_set -l layout.oas -f source.illum -o cost.csv -e evp.csv
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ===== Defaults =====
CALCCOST="$PROJECT_ROOT/build/src/bin/calcCostDirect/calcCostDirect"
SOURCE_CONFIG="$SCRIPT_DIR/../tmp0507/in/source_config.txt"
PROCESS_CONFIG="$SCRIPT_DIR/../tmp0507/in/pwc_config.txt"
EVP=""
LAYER="0/0"
CELLNAME=""
RESIST_MODEL=""

# LSF
USE_BSUB=0
MPI_NP=1
QUEUE="OPCALL"
JOB_NAME=""

# 画像計算
BRIGHTFIELD=1     # 1=bright, 0=dark
BINARY=0          # 0=halftone, 1=binary
DIM0=""
DIM=""
DIMX0=""; DIMY0=""
DIMX=""; DIMY=""
KERNEL_NUM=""
OPENMP_NUM=16

# コスト計算
SLICE_LEVEL=""        # 空 = auto
SLICE_LEVEL_HINT=""
ANCHOR_CLIPS=""       # 空 = default (0)
WEIGHT_FILL=""        # 空 = default (1.0)
MIN_FILL_RATIO=""     # 空 = default (0.07)
EPE_METHOD="newton"   # newton | qepe
TARGET_DELTA_CD=""

# Source 補正
INTERPOLATION="nearest"   # nearest | bilinear
DEBUG_SOURCE=""

# Export
EXPORT_CLIPS=""

# 必須引数
SOCS_DIR=""
LAYOUT=""
SOURCE_FILE=""
OUTPUT_FILE=""

usage() {
    cat << EOF
Usage: $0 -s <socs_dir> -l <layout> -f <source.illum> -o <cost.csv> -e <evp.csv> [options]

Required:
  -s, --socs DIR              SOCS set directory
  -l, --layout FILE           layout (.oas / .gds)
  -f, --source FILE           source intensity file (.illum)
  -o, --output FILE           output cost.csv
  -e, --evp FILE              evaluation points csv

LSF (bsub) options:
      --bsub                  submit to LSF instead of running locally
  -n, --np N                  MPI ranks (= bsub -n) (default: $MPI_NP)
  -q, --queue NAME            LSF queue (default: $QUEUE)
      --job-name NAME         bsub -J name (default: calccost_<basename>)

Common options:
  -p, --process FILE          process_config (default: $PROCESS_CONFIG)
  -g, --source-config FILE    source_config (default: $SOURCE_CONFIG)
      --layer SPEC            layer/datatype (default: $LAYER)
      --cellname NAME         OASIS cell name
      --brightfield           (default)
      --darkfield
      --binary                binary mask
      --halftone              halftone mask (default)
      --resistModel FILE      base resistModel file
      --calccost PATH         override calcCostDirect binary path

Image calc options:
      --dim N                 dimension (large)
      --dim0 N                dimension (small)
      --dimx N / --dimy N
      --dimx0 N / --dimy0 N
      --kernel N              SOCS kernel count
  -j, --openmp N              OpenMP threads (default: $OPENMP_NUM)

Cost options:
      --sliceLevel VAL        固定 sliceLevel (空 = auto search)
      --sliceLevelHint VAL    sliceLevel 探索の初期値
      --anchor-clips CSV      anchor clip ID 列 (例: "0,2")
      --weight-fill VAL       source_fill_cost の重み
      --min-fill-ratio VAL    source fill ratio 下限
      --epe-method NAME       newton | qepe (default: $EPE_METHOD)
      --target-delta-cd VAL   sliceLevel 探索の delta_CD ターゲット

Source correction:
      --interpolation NAME    nearest | bilinear (default: $INTERPOLATION)
      --debug-source PATH     補正後 source を保存

Export:
      --export-clips DIR      clip 領域を OASIS で出力

  -h, --help                  show this help

比較ワークフロー例:
  # 商用 illum を評価
  $0 -s socs_set/ -l layout.oas -e evp.csv \\
     -f commercial.illum -o cost_commercial.csv

  # 自作 illum を評価 (同条件)
  $0 -s socs_set/ -l layout.oas -e evp.csv \\
     -f mine.illum -o cost_mine.csv

  # total_cost を直接比較
  for f in cost_commercial.csv cost_mine.csv; do
      echo -n "\$f: "; grep "^total_cost," "\$f" | cut -d',' -f2
  done
EOF
}

# ===== Parse args =====
while [ $# -gt 0 ]; do
    case "$1" in
        -s|--socs)                  SOCS_DIR="$2"; shift 2;;
        -l|--layout)                LAYOUT="$2"; shift 2;;
        -f|--source)                SOURCE_FILE="$2"; shift 2;;
        -o|--output)                OUTPUT_FILE="$2"; shift 2;;
        -e|--evp)                   EVP="$2"; shift 2;;
        -p|--process)               PROCESS_CONFIG="$2"; shift 2;;
        -g|--source-config)         SOURCE_CONFIG="$2"; shift 2;;
        --bsub)                     USE_BSUB=1; shift;;
        -n|--np)                    MPI_NP="$2"; shift 2;;
        -q|--queue)                 QUEUE="$2"; shift 2;;
        --job-name)                 JOB_NAME="$2"; shift 2;;
        --layer)                    LAYER="$2"; shift 2;;
        --cellname)                 CELLNAME="$2"; shift 2;;
        --brightfield)              BRIGHTFIELD=1; shift;;
        --darkfield)                BRIGHTFIELD=0; shift;;
        --binary)                   BINARY=1; shift;;
        --halftone)                 BINARY=0; shift;;
        --resistModel)              RESIST_MODEL="$2"; shift 2;;
        --calccost)                 CALCCOST="$2"; shift 2;;
        --dim)                      DIM="$2"; shift 2;;
        --dim0)                     DIM0="$2"; shift 2;;
        --dimx)                     DIMX="$2"; shift 2;;
        --dimy)                     DIMY="$2"; shift 2;;
        --dimx0)                    DIMX0="$2"; shift 2;;
        --dimy0)                    DIMY0="$2"; shift 2;;
        --kernel)                   KERNEL_NUM="$2"; shift 2;;
        -j|--openmp)                OPENMP_NUM="$2"; shift 2;;
        --sliceLevel)               SLICE_LEVEL="$2"; shift 2;;
        --sliceLevelHint)           SLICE_LEVEL_HINT="$2"; shift 2;;
        --anchor-clips)             ANCHOR_CLIPS="$2"; shift 2;;
        --weight-fill)              WEIGHT_FILL="$2"; shift 2;;
        --min-fill-ratio)           MIN_FILL_RATIO="$2"; shift 2;;
        --epe-method)               EPE_METHOD="$2"; shift 2;;
        --target-delta-cd)          TARGET_DELTA_CD="$2"; shift 2;;
        --interpolation)            INTERPOLATION="$2"; shift 2;;
        --debug-source)             DEBUG_SOURCE="$2"; shift 2;;
        --export-clips)             EXPORT_CLIPS="$2"; shift 2;;
        -h|--help)                  usage; exit 0;;
        *) echo "ERROR: unknown option: $1" >&2; usage; exit 1;;
    esac
done

# ===== Validate =====
if [ -z "$SOCS_DIR" ] || [ -z "$LAYOUT" ] || [ -z "$SOURCE_FILE" ] || [ -z "$OUTPUT_FILE" ] || [ -z "$EVP" ]; then
    echo "ERROR: -s, -l, -f, -o, -e are all required" >&2
    usage; exit 1
fi

for f in "$LAYOUT" "$SOURCE_FILE" "$EVP" "$SOURCE_CONFIG" "$PROCESS_CONFIG"; do
    [ -f "$f" ] || { echo "ERROR: file not found: $f" >&2; exit 1; }
done

[ -d "$SOCS_DIR" ] || { echo "ERROR: SOCS dir not found: $SOCS_DIR" >&2; exit 1; }
[ -x "$CALCCOST" ] || { echo "ERROR: calcCostDirect not executable: $CALCCOST" >&2; exit 1; }

# ===== Resolve output =====
OUT_DIR=$(dirname "$OUTPUT_FILE")
mkdir -p "$OUT_DIR"
[ -z "$JOB_NAME" ] && JOB_NAME="calccost_$(basename "$OUTPUT_FILE" .csv)"

# ===== Build EXTRA_OPTS =====
# 空文字なら CLI に渡さない (calcCostDirect 側のデフォルト値を使う)
EXTRA_OPTS=""
add_extra() {
    EXTRA_OPTS+="    $* \\
"
}

[ -n "$RESIST_MODEL" ]      && add_extra "--resistModel \"$RESIST_MODEL\""
[ -n "$DIM0" ]              && add_extra "--dim0 \"$DIM0\""
[ -n "$DIM" ]               && add_extra "--dim \"$DIM\""
[ -n "$DIMX0" ]             && add_extra "--dimx0 \"$DIMX0\""
[ -n "$DIMY0" ]             && add_extra "--dimy0 \"$DIMY0\""
[ -n "$DIMX" ]              && add_extra "--dimx \"$DIMX\""
[ -n "$DIMY" ]              && add_extra "--dimy \"$DIMY\""
[ -n "$KERNEL_NUM" ]        && add_extra "--kernel \"$KERNEL_NUM\""
[ -n "$CELLNAME" ]          && add_extra "--cellname \"$CELLNAME\""

[ -n "$SLICE_LEVEL" ]       && add_extra "--sliceLevel \"$SLICE_LEVEL\""
[ -n "$SLICE_LEVEL_HINT" ]  && add_extra "--sliceLevelHint \"$SLICE_LEVEL_HINT\""
[ -n "$ANCHOR_CLIPS" ]      && add_extra "--anchor_clips \"$ANCHOR_CLIPS\""
[ -n "$WEIGHT_FILL" ]       && add_extra "--weight_fill \"$WEIGHT_FILL\""
[ -n "$MIN_FILL_RATIO" ]    && add_extra "--min_fill_ratio \"$MIN_FILL_RATIO\""
[ -n "$EPE_METHOD" ]        && add_extra "--epe_method \"$EPE_METHOD\""
[ -n "$TARGET_DELTA_CD" ]   && add_extra "--target_delta_cd \"$TARGET_DELTA_CD\""

[ -n "$INTERPOLATION" ]     && add_extra "--interpolation \"$INTERPOLATION\""
[ -n "$DEBUG_SOURCE" ]      && add_extra "--debug_source \"$DEBUG_SOURCE\""
[ -n "$EXPORT_CLIPS" ]      && add_extra "--export_clips \"$EXPORT_CLIPS\""

# brightfield/darkfield
BF_LINE='--darkfield'
[ "$BRIGHTFIELD" = "1" ] && BF_LINE='--brightfield'

# binary/halftone
BIN_LINE='--halftone'
[ "$BINARY" = "1" ] && BIN_LINE='--binary'

# ===== Generate wrapper =====
WRAPPER="$OUT_DIR/run_calccost_wrapper.sh"
BSUB_LOG="$OUT_DIR/calccost_bsub.log"

cat > "$WRAPPER" << SCRIPT_EOF
#!/bin/bash
set -e

if [ -n "\$LSB_DJOB_HOSTFILE" ]; then
    NP=\$(wc -l < "\$LSB_DJOB_HOSTFILE")
    RUNCMD="mpirun -bootstrap lsf -np \$NP $CALCCOST"
elif [ "$MPI_NP" -gt 1 ]; then
    RUNCMD="mpirun -np $MPI_NP $CALCCOST"
else
    RUNCMD="$CALCCOST"
fi

\$RUNCMD \\
    -s "$SOCS_DIR" \\
    -g "$SOURCE_CONFIG" \\
    -p "$PROCESS_CONFIG" \\
    -f "$SOURCE_FILE" \\
    -e "$EVP" \\
    -l "$LAYOUT" \\
    -o "$OUTPUT_FILE" \\
    --layer "$LAYER" \\
    $BF_LINE \\
    $BIN_LINE \\
${EXTRA_OPTS}    -j "$OPENMP_NUM"
SCRIPT_EOF
chmod +x "$WRAPPER"

# ===== Log header =====
echo "[run_calccost] socs    = $SOCS_DIR"
echo "[run_calccost] layout  = $LAYOUT"
echo "[run_calccost] source  = $SOURCE_FILE"
echo "[run_calccost] evp     = $EVP"
echo "[run_calccost] output  = $OUTPUT_FILE"
echo "[run_calccost] wrapper = $WRAPPER"
[ -n "$SLICE_LEVEL" ]      && echo "[run_calccost] sliceLevel    = $SLICE_LEVEL"
[ -n "$SLICE_LEVEL_HINT" ] && echo "[run_calccost] sliceLevelHint= $SLICE_LEVEL_HINT"
[ -n "$ANCHOR_CLIPS" ]     && echo "[run_calccost] anchor_clips  = $ANCHOR_CLIPS"
echo "[run_calccost] epe_method = $EPE_METHOD"

T0=$(date +%s)

if [ "$USE_BSUB" = "1" ]; then
    # ===== LSF (bsub) =====
    echo "[run_calccost] submitting to LSF: queue=$QUEUE, -n $MPI_NP, job=$JOB_NAME"
    OUT_MSG=$(bsub \
        -n "$MPI_NP" \
        -R "span[ptile=1]" \
        -q "$QUEUE" \
        -J "$JOB_NAME" \
        -o "$BSUB_LOG" \
        "$WRAPPER" 2>&1)
    JOBID=$(echo "$OUT_MSG" | sed -n 's/.*Job <\([0-9]*\)>.*/\1/p')
    if [ -z "$JOBID" ]; then
        echo "ERROR: bsub failed: $OUT_MSG" >&2
        exit 1
    fi
    echo "[run_calccost] submitted: JobID=$JOBID, log=$BSUB_LOG"

    JOB_SEEN=false
    UNKNOWN_SINCE=0
    UNKNOWN_GRACE=60
    LAST_REPORT=0
    REPORT_INTERVAL=30
    while true; do
        STATUS=$(bjobs -noheader -o "stat" "$JOBID" 2>/dev/null || echo "UNKNOWN")
        case "$STATUS" in
            DONE)
                E=$(( $(date +%s) - T0 ))
                echo "[run_calccost] job DONE (elapsed $((E/60))m $((E%60))s)"
                break
                ;;
            EXIT)
                echo "ERROR: job EXIT (failed). JobID=$JOBID, log=$BSUB_LOG" >&2
                exit 1
                ;;
            UNKNOWN|"")
                if [ "$JOB_SEEN" = true ]; then
                    echo "[run_calccost] job status UNKNOWN after seen: assuming done"
                    break
                fi
                [ "$UNKNOWN_SINCE" -eq 0 ] && UNKNOWN_SINCE=$(date +%s)
                if [ $(( $(date +%s) - UNKNOWN_SINCE )) -ge "$UNKNOWN_GRACE" ]; then
                    echo "[run_calccost] job never seen by bjobs (assuming flushed-done)"
                    break
                fi
                ;;
            *)
                JOB_SEEN=true
                UNKNOWN_SINCE=0
                ;;
        esac

        E=$(( $(date +%s) - T0 ))
        if [ $((E - LAST_REPORT)) -ge "$REPORT_INTERVAL" ]; then
            echo "[run_calccost] ... $STATUS  (elapsed $((E/60))m $((E%60))s)"
            LAST_REPORT=$E
        fi
        sleep 10
    done

    # NFS sync: output ファイル出現を待つ
    for i in $(seq 1 30); do
        [ -f "$OUTPUT_FILE" ] && break
        ls -la "$OUT_DIR" >/dev/null 2>&1 || true
        sleep 2
    done
else
    # ===== ローカル実行 =====
    echo "[run_calccost] running locally (use --bsub to submit to LSF)..."
    "$WRAPPER"
fi

ELAPSED=$(( $(date +%s) - T0 ))

if [ ! -f "$OUTPUT_FILE" ]; then
    echo "ERROR: cost.csv not produced: $OUTPUT_FILE" >&2
    [ "$USE_BSUB" = "1" ] && echo "       check bsub log: $BSUB_LOG" >&2
    exit 1
fi

# ===== サマリ =====
TOTAL=$(grep "^total_cost,"       "$OUTPUT_FILE" | head -1 | cut -d',' -f2)
EPE=$(grep "^EPE_cost,"           "$OUTPUT_FILE" | head -1 | cut -d',' -f2)
QEPE=$(grep "^QEPE_cost,"         "$OUTPUT_FILE" | head -1 | cut -d',' -f2)
FILL=$(grep "^source_fill_cost,"  "$OUTPUT_FILE" | head -1 | cut -d',' -f2)
SL=$(grep   "^sliceLevel,"        "$OUTPUT_FILE" | head -1 | cut -d',' -f2)

echo "[run_calccost] DONE in ${ELAPSED}s"
echo "[run_calccost] -----------------------------------------------"
[ -n "$SL" ]    && echo "[run_calccost] sliceLevel       = $SL"
[ -n "$EPE" ]   && echo "[run_calccost] EPE_cost         = $EPE"
[ -n "$QEPE" ]  && echo "[run_calccost] QEPE_cost        = $QEPE"
[ -n "$FILL" ]  && echo "[run_calccost] source_fill_cost = $FILL"
[ -n "$TOTAL" ] && echo "[run_calccost] total_cost       = $TOTAL"
echo "[run_calccost] output           = $OUTPUT_FILE"
