/*!
 * @file source_optimizer.cpp
 * @brief メイン最適化クラスの実装
 */

#include "source_optimizer.h"
#include "lbfgs_optimizer.h"
#include "adam_optimizer.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

namespace so {

SourceOptimizer::SourceOptimizer() {}

SourceOptimizer::~SourceOptimizer() {}

void SourceOptimizer::setOptions(const OptimizationOptions& options) {
    m_options = options;
    m_constraintHandler.setOptions(options);
    m_gradientCalculator.setOptions(options);
}

void SourceOptimizer::setSourceGrid(const SourceGrid* sourceGrid) {
    m_sourceGrid = sourceGrid;
}

void SourceOptimizer::setSourceData(SourceData* sourceData) {
    m_sourceData = sourceData;
}

void SourceOptimizer::setEvpData(const EvpData* evpData) {
    m_evpData = evpData;
}

void SourceOptimizer::setProcessConfig(const ProcessConfig* processConfig) {
    m_processConfig = processConfig;
}

void SourceOptimizer::setSourceContributions(
    const std::map<std::string, SourceContributionSet>* sourceContributions) {
    m_sourceContributions = sourceContributions;
    m_gradientCalculator.setSourceContributions(sourceContributions);
}

void SourceOptimizer::setNA(double NA) {
    m_NA = NA;
    m_gradientCalculator.setNA(NA);
}

void SourceOptimizer::createOptimizer() {
    if (m_options.optimizer == OptimizerType::LBFGS) {
        m_optimizer = std::make_unique<LBFGSOptimizer>();
    } else {
        m_optimizer = std::make_unique<AdamOptimizer>();
    }
    m_optimizer->setOptions(m_options);
}

// ============================================================================
// 公開API: Two-Stage対応の最適化エントリポイント
// ============================================================================

OptimizationResult SourceOptimizer::optimize() {
    int mpiRank = 0;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
#endif

    if (!m_options.enableTwoStage) {
        return optimizeSingleStage();
    }

    // Two-Stage optimization
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\n###############################################" << std::endl;
        std::cerr << "# Two-Stage Optimization Enabled              #" << std::endl;
        std::cerr << "###############################################" << std::endl;
    }

    auto savedOptions = m_options;

    // Stage 1: epePower (デフォルト: EPE²)
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\n=== Stage 1: EPE^" << m_options.epePower << " optimization ===" << std::endl;
    }
    m_options.enableTwoStage = false;  // 再帰防止
    if (!m_options.roundOutputPrefix.empty()) {
        m_options.roundOutputPrefix = savedOptions.roundOutputPrefix + "_stage1";
    }
    auto stage1Result = optimizeSingleStage();
    // stage1のログエントリにstage=1を付与
    for (auto& entry : stage1Result.log) {
        entry.stage = 1;
    }
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\nStage 1 completed:" << std::endl;
        std::cerr << "  Cost: " << stage1Result.finalCost << std::endl;
        std::cerr << "  Iterations: " << stage1Result.iterations << std::endl;
    }

    // Stage 2: epePowerStage2 (デフォルト: EPE⁴)
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\n=== Stage 2: EPE^" << savedOptions.epePowerStage2 << " optimization ===" << std::endl;
    }
    m_options.epePower = savedOptions.epePowerStage2;
    if (!savedOptions.roundOutputPrefix.empty()) {
        m_options.roundOutputPrefix = savedOptions.roundOutputPrefix + "_stage2";
    }
    auto stage2Result = optimizeSingleStage();
    // stage2のログエントリにstage=2を付与
    for (auto& entry : stage2Result.log) {
        entry.stage = 2;
    }
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\nStage 2 completed:" << std::endl;
        std::cerr << "  Cost: " << stage2Result.finalCost << std::endl;
        std::cerr << "  Iterations: " << stage2Result.iterations << std::endl;
    }

    // オプションを復元（ただしepePowerはstage2の値のままにして、
    // 後段のcalculateCurrentCost(=cost.csv)が最終stageのコスト関数を使うようにする）
    int finalEpePower = m_options.epePower;
    m_options = savedOptions;
    m_options.epePower = finalEpePower;

    // 結果をマージ（Stage 1のログをStage 2の前に挿入）
    OptimizationResult result = stage2Result;
    result.log.insert(result.log.begin(), stage1Result.log.begin(), stage1Result.log.end());
    result.iterations = stage1Result.iterations + stage2Result.iterations;
    result.terminationReason = "Two-stage: " + stage2Result.terminationReason;

    return result;
}

// ============================================================================
// 単一ステージの最適化（ラウンドループ含む）
// ============================================================================

OptimizationResult SourceOptimizer::optimizeSingleStage() {
    OptimizationResult result;

    // MPIランク情報を取得
    int mpiRank = 0, mpiSize = 1;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
    MPI_Comm_size(m_mpiComm, &mpiSize);
#endif
    m_gradientCalculator.setMPI(mpiRank, mpiSize);
#ifdef HAVE_MPI_H
    m_gradientCalculator.setMPIComm(m_mpiComm);
#endif

    // rank 0以外はverboseを無効化（ログ重複を防止）
    bool savedVerbose = m_options.verbose;
    if (mpiRank != 0) {
        m_options.verbose = false;
    }

    // OpenMPスレッド数を設定
#ifdef _OPENMP
    if (m_options.numThreads > 0) {
        omp_set_num_threads(m_options.numThreads);
    }
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "OpenMP threads: " << omp_get_max_threads() << std::endl;
    }
#endif

    // 時間計測用カウンターをリセット
    m_gradientCallCount = 0;
    m_totalGradientTime = 0.0;
    m_costCallCount = 0;
    m_totalCostTime = 0.0;

    // 前提条件チェック
    if (!m_sourceGrid || !m_sourceData || !m_evpData || !m_processConfig || !m_sourceContributions) {
        result.converged = false;
        result.terminationReason = "Missing required data";
        return result;
    }

    // 変数マッピングを初期化
    m_variableMapping.initialize(*m_sourceGrid, *m_sourceData);
    m_gradientCalculator.setVariableMapping(&m_variableMapping);

    if (m_variableMapping.numVariables() == 0) {
        result.converged = false;
        result.terminationReason = "No variables to optimize";
        return result;
    }

    if (m_options.verbose) {
        std::cerr << "Optimization variables: " << m_variableMapping.numVariables() << std::endl;
        if (mpiSize > 1) {
            size_t numClips = m_evpData->showClips().size();
            std::cerr << "MPI ranks: " << mpiSize << std::endl;
            std::cerr << "  Total clips: " << numClips << std::endl;
            for (int r = 0; r < mpiSize; ++r) {
                size_t count = 0;
                for (size_t c = 0; c < numClips; ++c) {
                    if (c % static_cast<size_t>(mpiSize) == static_cast<size_t>(r)) ++count;
                }
                std::cerr << "  Rank " << r << ": " << count << " clips" << std::endl;
            }
        }
    }

    // 外部ループ回数
    int numRounds = std::max(1, m_options.sliceLevelOptimizationRounds);
    std::vector<double> roundCostHistory;

    // Stage内（round跨ぎ）のbest追跡
    // 最良cost時点のvariables/sliceLevelを保持し、stage終了時に復元する。
    // そのstage内で観測された最良costの累積（running min）もログに記録。
    double stageBestCost = std::numeric_limits<double>::infinity();
    std::vector<double> stageBestVariables;
    double stageBestSliceLevel = m_sliceLevel;

    // feasibility 優先の最終選択用トラッカー
    // - 未feasibleだけのときは pickedCost（総コスト）で比較
    // - 初回 feasible は無条件で採用
    // - feasible 同士は pickedEpeCost（重みの影響を受けない）で比較
    // - feasible を infeasible で上書きしない
    double pickedCost = std::numeric_limits<double>::infinity();
    double pickedEpeCost = std::numeric_limits<double>::infinity();
    std::vector<double> pickedVariables;
    double pickedSliceLevel = m_sliceLevel;
    bool pickedFeasible = false;

    // fill weight 連続化
    double baseFillWeight = m_options.weightFillPenalty;
    double currentFillWeight = baseFillWeight;

    for (int round = 0; round < numRounds; ++round) {
        if (numRounds > 1 && mpiRank == 0) {
            std::cerr << "\n=== Optimization Round " << (round + 1) << "/" << numRounds
                      << " ===" << std::endl;
        }

        // この round に適用する fill weight を反映し、
        // gradient calculator（および既存 optimizer）へ伝搬する
        m_options.weightFillPenalty = currentFillWeight;
        m_gradientCalculator.setOptions(m_options);

        // slice levelの決定
        if (round == 0 && m_options.sliceLevel >= 0) {
            m_sliceLevel = m_options.sliceLevel;
        } else {
            m_sliceLevel = findOptimalSliceLevel();
        }

        if (m_options.verbose && mpiRank == 0) {
            std::cerr << "Slice level: " << m_sliceLevel << std::endl;
            if (std::abs(currentFillWeight - baseFillWeight) > 0.0) {
                std::cerr << "weightFillPenalty: " << currentFillWeight
                          << " (base=" << baseFillWeight << ")" << std::endl;
            }
        }

        // オプティマイザを作成（各ラウンドで新しいオプティマイザ）
        createOptimizer();

        // ラウンド2以降は最低1回はイテレーションを実行
        // ユーザ指定の lbfgsMinIterations が 1 以上ならその値を尊重する
        if (round > 0) {
            OptimizationOptions roundOptions = m_options;
            roundOptions.lbfgsMinIterations = std::max(1, m_options.lbfgsMinIterations);
            m_optimizer->setOptions(roundOptions);
        }

        // 現在の変数を取得
        std::vector<double> x0 = m_variableMapping.sourceToVariables(*m_sourceData);

        // 最適化を実行
        OptimizationResult roundResult = m_optimizer->optimize(
            x0,
            [this](const std::vector<double>& vars) { return costFunction(vars); },
            [this](const std::vector<double>& vars) { return gradientFunction(vars); },
            [this](std::vector<double>& vars) { projectionFunction(vars); }
        );

        // 最良解をsourceDataに復元
        if (!roundResult.finalVariables.empty()) {
            m_variableMapping.variablesToSource(roundResult.finalVariables, *m_sourceData);
        }

        // ラウンド情報とsliceLevelをログに記録
        // iteration は optimizer 側で既にround-local値（0..N）なので、そのまま使用
        // stageBestCost はstage内running min（このroundの各entry.costを順次取り込む）
        double roundFillRatio = m_sourceData->calcSourceFillRatio(m_NA);

        // Round終了時のbreakdown（EPE/Fill/NILS）を最後の entry に記録するために先に計算
        bool roundFeasible = (roundFillRatio >= m_options.minSourceFillRatio);
        double roundEpeCost = 0.0;
        double roundFillCostOnly = 0.0;
        double roundNilsCost = 0.0;
        m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig,
            m_sliceLevel, m_options.epePower, &roundEpeCost, &roundFillCostOnly, &roundNilsCost);

        const size_t lastEntryIdx = roundResult.log.empty() ? 0 : roundResult.log.size() - 1;
        for (size_t ei = 0; ei < roundResult.log.size(); ++ei) {
            auto& entry = roundResult.log[ei];
            entry.round = round;
            entry.sliceLevel = m_sliceLevel;
            entry.sourceFillRatio = roundFillRatio;
            if (entry.cost < stageBestCost) {
                stageBestCost = entry.cost;
                stageBestSliceLevel = m_sliceLevel;
            }
            entry.stageBestCost = stageBestCost;
            entry.stageBestSliceLevel = stageBestSliceLevel;
            // breakdown は round 終端状態のものを最後の entry に記録
            if (ei == lastEntryIdx) {
                entry.epeCost = roundEpeCost;
                entry.sourceFillCost = roundFillCostOnly;
                entry.nilsCost = roundNilsCost;
            }
            result.log.push_back(entry);
        }

        // Round終了時のbest（=roundResult.finalCost）を用いてstage-best候補を更新
        if (!roundResult.finalVariables.empty() && roundResult.finalCost <= stageBestCost) {
            stageBestCost = roundResult.finalCost;
            stageBestVariables = roundResult.finalVariables;
            stageBestSliceLevel = m_sliceLevel;
        }

        // feasibility 優先の最終選択トラッカーを更新
        // （重みが round で変動しても比較可能なように EPE コストも取得）

        bool shouldUpdatePicked = false;
        if (!roundResult.finalVariables.empty()) {
            if (roundFeasible && !pickedFeasible) {
                shouldUpdatePicked = true;  // 初回 feasible は無条件採用
            } else if (roundFeasible && pickedFeasible) {
                // feasible 同士: EPE コストのみで比較（重み変動の影響を排除）
                shouldUpdatePicked = (roundEpeCost <= pickedEpeCost);
            } else if (!roundFeasible && !pickedFeasible) {
                // 両方 infeasible: 現在の重みでの総コストで比較
                shouldUpdatePicked = (roundResult.finalCost <= pickedCost);
            }
            // feasible を infeasible で上書きはしない
        }
        if (shouldUpdatePicked) {
            pickedCost = roundResult.finalCost;
            pickedEpeCost = roundEpeCost;
            pickedVariables = roundResult.finalVariables;
            pickedSliceLevel = m_sliceLevel;
            pickedFeasible = roundFeasible;
        }

        // fill weight 連続化: infeasible なら次 round で重みを増倍
        if (!roundFeasible
            && m_options.fillWeightMultiplier > 1.0
            && currentFillWeight < m_options.fillWeightMax) {
            double newWeight = std::min(
                currentFillWeight * m_options.fillWeightMultiplier,
                m_options.fillWeightMax);
            if (mpiRank == 0) {
                std::cerr << "  Fill ratio " << roundFillRatio
                          << " < min " << m_options.minSourceFillRatio
                          << ", escalating weightFillPenalty: "
                          << currentFillWeight << " -> " << newWeight << std::endl;
            }
            currentFillWeight = newWeight;
        }

        // 結果を統合
        result.iterations += roundResult.iterations;
        result.converged = roundResult.converged;
        result.terminationReason = roundResult.terminationReason;
        result.finalCost = roundResult.finalCost;
        result.finalGradientNorm = roundResult.finalGradientNorm;

        if (numRounds > 1 && mpiRank == 0) {
            std::cerr << "Round " << (round + 1) << " completed: cost=" << std::fixed << std::setprecision(6)
                      << roundResult.finalCost
                      << ", iterations=" << roundResult.iterations
                      << ", reason=" << roundResult.terminationReason << std::endl;
        }

        // ラウンドごとのPPM出力（rank 0のみ）
        if (!m_options.roundOutputPrefix.empty() && m_sourceGrid && mpiRank == 0) {
            std::string ppmFilename = m_options.roundOutputPrefix
                + "_round" + std::to_string(round + 1) + ".ppm";
            try {
                m_sourceData->savePpm(ppmFilename, *m_sourceGrid);
                std::cerr << "  Saved round " << (round + 1) << " source to: " << ppmFilename << std::endl;
            } catch (const std::exception& e) {
                std::cerr << "  Warning: Failed to save PPM: " << e.what() << std::endl;
            }
        }

        // ラウンド間収束判定
        double currentCost = roundResult.finalCost;
        roundCostHistory.push_back(currentCost);
        int w = m_options.roundConvergenceWindow;
        if (w <= 1) {
            // 従来の2点比較
            if (round > 0 && m_options.roundConvergenceTolerance > 0) {
                double prev = roundCostHistory[roundCostHistory.size() - 2];
                double relImprovement = (prev - currentCost)
                                        / std::max(std::abs(prev), 1e-12);
                if (relImprovement < m_options.roundConvergenceTolerance) {
                    result.converged = true;
                    result.terminationReason = "Round convergence";
                    if (mpiRank == 0) {
                        std::cerr << "Round convergence at round " << (round + 1)
                                  << ", relImprovement=" << relImprovement << std::endl;
                    }
                    break;
                }
            }
        } else {
            // ウィンドウベース判定
            if (static_cast<int>(roundCostHistory.size()) >= w * 2) {
                auto recentBest = *std::min_element(
                    roundCostHistory.end() - w, roundCostHistory.end());
                auto previousBest = *std::min_element(
                    roundCostHistory.end() - w * 2, roundCostHistory.end() - w);
                double relImprovement = std::abs(recentBest - previousBest)
                                        / (std::abs(previousBest) + 1e-12);
                if (relImprovement < m_options.roundConvergenceTolerance) {
                    result.converged = true;
                    result.terminationReason = "Round convergence (window)";
                    if (mpiRank == 0) {
                        std::cerr << "Round convergence (window=" << w
                                  << ") at round " << (round + 1)
                                  << ", relImprovement=" << relImprovement << std::endl;
                    }
                    break;
                }
            }
        }

        // 内側ループの収束判定（従来の動作）
        // 早期終了（A: cost stagnation, B: sufficient cost reduction）は
        // ラウンド内の打ち切りなので外側ループは続行する
        if (roundResult.converged &&
            roundResult.terminationReason.find("Early stop") == std::string::npos) {
            if (m_options.verbose && mpiRank == 0) {
                std::cerr << "Converged in round " << (round + 1) << ", stopping." << std::endl;
            }
            break;
        }
    }

    // Stage内best追跡の復元
    // feasibility 優先: pickedVariables（feasible優先・同クラスではEPEで選定）を
    // 優先し、pickedが空なら stageBestVariables（総コスト最小）にフォールバック。
    // Stage2への入力（two-stage時）やcost.csv出力はこの状態を使う。
    if (!pickedVariables.empty()) {
        m_variableMapping.variablesToSource(pickedVariables, *m_sourceData);
        m_sliceLevel = pickedSliceLevel;
        result.finalCost = pickedCost;
        result.finalVariables = pickedVariables;
        if (mpiRank == 0) {
            std::cerr << "Stage final selection: "
                      << (pickedFeasible ? "feasible" : "infeasible (best effort)")
                      << ", epeCost=" << pickedEpeCost
                      << ", totalCost=" << pickedCost << std::endl;
        }
    } else if (!stageBestVariables.empty()) {
        m_variableMapping.variablesToSource(stageBestVariables, *m_sourceData);
        m_sliceLevel = stageBestSliceLevel;
        result.finalCost = stageBestCost;
        result.finalVariables = stageBestVariables;
    }

    // fill weight を stage 開始時の baseline に戻す（cost.csv の再現性のため）
    m_options.weightFillPenalty = baseFillWeight;
    m_gradientCalculator.setOptions(m_options);

    // 追加の結果情報を設定
    result.finalSliceLevel = m_sliceLevel;
    result.finalSourceFillRatio = m_sourceData->calcSourceFillRatio(m_NA);

    // EPEコストとSourceFillCostとNILSコストを分けて計算（最適化と同じ方法で、
    // 復元されたstage-best状態に対して）
    double epeCost, fillCost, nilsCost;
    m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, m_options.epePower,
        &epeCost, &fillCost, &nilsCost);
    result.finalEpeCost = epeCost;
    result.finalSourceFillCost = fillCost;
    result.finalNilsCost = nilsCost;

    // 時間計測の統計を出力
    if (m_options.verbose && m_gradientCallCount > 0) {
        double avgGradTime = m_totalGradientTime / m_gradientCallCount;
        std::cerr << "-----------------------------------------------" << std::endl;
        std::cerr << "Timing Statistics:" << std::endl;
        std::cerr << "  Gradient calculations: " << m_gradientCallCount << " calls" << std::endl;
        std::cerr << "  Total gradient time:   " << std::fixed << std::setprecision(2)
                  << m_totalGradientTime << " sec" << std::endl;
        std::cerr << "  Avg gradient time:     " << std::fixed << std::setprecision(3)
                  << avgGradTime << " sec/call" << std::endl;
    }

    // verboseを復元
    m_options.verbose = savedVerbose;

    return result;
}

double SourceOptimizer::costFunction(const std::vector<double>& variables) {
    // 変数を光源データに変換
    m_variableMapping.variablesToSource(variables, *m_sourceData);

    // コストを計算（GradientMethodに基づいて計算方法を選択）
    return m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, m_options.epePower);
}

std::vector<double> SourceOptimizer::gradientFunction(const std::vector<double>& variables) {
    auto startTime = std::chrono::high_resolution_clock::now();

    // 変数を光源データに変換
    m_variableMapping.variablesToSource(variables, *m_sourceData);

    // 勾配を計算（GradientMethodに基づいて計算方法を選択）
    std::vector<double> gradient = m_gradientCalculator.calculateGradient(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, m_options.epePower);

    auto endTime = std::chrono::high_resolution_clock::now();
    double duration = std::chrono::duration<double>(endTime - startTime).count();
    m_totalGradientTime += duration;
    ++m_gradientCallCount;

    // 最初の3回は時間を出力（rank 0のみ）
    int mpiRank = 0;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
#endif
    if (m_options.verbose && m_gradientCallCount <= 3 && mpiRank == 0) {
        std::cerr << "  [Timing] Gradient calculation #" << m_gradientCallCount
                  << ": " << std::fixed << std::setprecision(3) << duration << " sec" << std::endl;
    }

    return gradient;
}

void SourceOptimizer::projectionFunction(std::vector<double>& variables) {
    m_constraintHandler.projectInPlace(variables);
}

double SourceOptimizer::verifyGradient(double epsilon) {
    if (!m_sourceGrid || !m_sourceData || !m_evpData || !m_processConfig || !m_sourceContributions) {
        return -1.0;
    }

    // MPIランク情報を設定（optimize()前に呼ばれても正しく動作するように）
    int mpiRank = 0, mpiSize = 1;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
    MPI_Comm_size(m_mpiComm, &mpiSize);
#endif
    m_gradientCalculator.setMPI(mpiRank, mpiSize);

    // 変数マッピングを初期化（まだの場合）
    if (m_variableMapping.numVariables() == 0) {
        m_variableMapping.initialize(*m_sourceGrid, *m_sourceData);
        m_gradientCalculator.setVariableMapping(&m_variableMapping);
    }

    // slice levelの自動決定（まだの場合）
    if (m_sliceLevel < 0) {
        m_sliceLevel = findOptimalSliceLevel();
    }

    std::cerr << "-----------------------------------------------" << std::endl;
    std::cerr << "Gradient Verification (epsilon=" << epsilon << ")" << std::endl;
    std::cerr << "  Variables: " << m_variableMapping.numVariables() << std::endl;
    std::cerr << "  Slice level: " << m_sliceLevel << std::endl;
    std::cerr << "  D2 symmetry: " << (m_variableMapping.isD2Symmetry() ? "yes" : "no") << std::endl;

    // 変数情報（最初の3つ）を表示
    const auto& varInfos = m_variableMapping.variableInfos();
    std::cerr << "  First 3 variables:" << std::endl;
    for (size_t i = 0; i < std::min<size_t>(3, varInfos.size()); ++i) {
        const auto& info = varInfos[i];
        double intensity = m_sourceData->getIntensityFirstQuadrant(info.gx, info.gy);
        std::cerr << "    [" << i << "] gx=" << info.gx << ", gy=" << info.gy
                  << ", mult=" << info.multiplier << ", intensity=" << intensity << std::endl;
    }

    // 勾配計算方法を表示
    std::cerr << "  Gradient method: " << gradientMethodToString(m_options.gradientMethod) << std::endl;

    int epePower = m_options.epePower;

    // 現在のコストを表示（選択された方法に基づく）
    double currentCost = m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);
    std::cerr << "  Current cost: " << currentCost << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    // 単一変数の詳細検証（最初の変数）
    if (!varInfos.empty()) {
        std::cerr << "Detailed check for variable 0:" << std::endl;
        std::vector<double> vars = m_variableMapping.sourceToVariables(*m_sourceData);
        double origVal = vars[0];

        // +epsilon
        vars[0] = origVal + epsilon;
        m_variableMapping.variablesToSource(vars, *m_sourceData);
        double costPlus = m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);

        // -epsilon
        vars[0] = origVal - epsilon;
        m_variableMapping.variablesToSource(vars, *m_sourceData);
        double costMinus = m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);

        // restore
        vars[0] = origVal;
        m_variableMapping.variablesToSource(vars, *m_sourceData);

        double numGrad0 = (costPlus - costMinus) / (2.0 * epsilon);
        std::cerr << "  cost(+eps)=" << std::scientific << std::setprecision(10) << costPlus << std::endl;
        std::cerr << "  cost(-eps)=" << costMinus << std::endl;
        std::cerr << "  cost_diff=" << (costPlus - costMinus) << std::endl;
        std::cerr << "  numerical_grad=" << numGrad0 << std::endl;
        std::cerr << "-----------------------------------------------" << std::endl;
    }

    // 解析勾配と数値勾配の対応を決定
    // gradientMethod が解析的 → そのまま解析勾配、対応する数値勾配と比較
    // gradientMethod が数値的 → 対応する解析勾配と比較
    GradientMethod analyticMethod, numericalMethod;
    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
        case GradientMethod::QEPE_Numerical:
            analyticMethod = GradientMethod::QEPE_Analytical;
            numericalMethod = GradientMethod::QEPE_Numerical;
            break;
        case GradientMethod::EPE_Analytical:
        case GradientMethod::EPE_Numerical:
        default:
            analyticMethod = GradientMethod::EPE_Analytical;
            numericalMethod = GradientMethod::EPE_Numerical;
            break;
    }

    std::cerr << "  Analytic method:  " << gradientMethodToString(analyticMethod) << std::endl;
    std::cerr << "  Numerical method: " << gradientMethodToString(numericalMethod) << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    // 解析勾配（時間計測）
    auto savedMethod = m_options.gradientMethod;

    m_gradientCalculator.setGradientMethod(analyticMethod);
    auto analyticStart = std::chrono::high_resolution_clock::now();
    std::vector<double> analyticGrad = m_gradientCalculator.calculateGradient(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);
    auto analyticEnd = std::chrono::high_resolution_clock::now();
    double analyticTime = std::chrono::duration<double>(analyticEnd - analyticStart).count();

    std::cerr << "Analytic gradient:  " << std::fixed << std::setprecision(3)
              << analyticTime << " sec" << std::endl;

    // 数値勾配（時間計測）- GradientCalculator の数値勾配メソッドを使用
    m_gradientCalculator.setGradientMethod(numericalMethod);
    auto numericalStart = std::chrono::high_resolution_clock::now();
    std::vector<double> numericalGrad = m_gradientCalculator.calculateGradient(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);
    auto numericalEnd = std::chrono::high_resolution_clock::now();
    double numericalTime = std::chrono::duration<double>(numericalEnd - numericalStart).count();

    // gradientMethod を復元
    m_gradientCalculator.setGradientMethod(savedMethod);

    std::cerr << "Numerical gradient: " << std::fixed << std::setprecision(3)
              << numericalTime << " sec" << std::endl;

    // 速度比
    double actualRatio = (analyticTime > 0) ? (numericalTime / analyticTime) : 0;
    std::cerr << "Speed ratio:        " << std::fixed << std::setprecision(1)
              << actualRatio << "x slower (numerical)" << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    // 最大相対誤差を計算
    double maxRelError = 0.0;
    size_t maxErrorIdx = 0;
    double sumRatio = 0.0;
    int ratioCount = 0;

    for (size_t i = 0; i < analyticGrad.size(); ++i) {
        double a = analyticGrad[i];
        double n = numericalGrad[i];
        double absError = std::abs(a - n);
        double denom = std::max(std::abs(a) + std::abs(n), 1e-12);
        double relError = absError / denom;

        if (relError > maxRelError) {
            maxRelError = relError;
            maxErrorIdx = i;
        }

        // 比率の統計（両方が有意な値の場合のみ）
        if (std::abs(a) > 1e-12 && std::abs(n) > 1e-12) {
            sumRatio += n / a;
            ++ratioCount;
        }

        if (m_options.verbose) {
            double ratio = (std::abs(a) > 1e-12) ? n / a : 0.0;
            std::cerr << "Gradient[" << i << "]: analytic=" << std::scientific << std::setprecision(4) << a
                      << ", numerical=" << n
                      << ", ratio=" << std::fixed << std::setprecision(2) << ratio
                      << ", relError=" << std::scientific << std::setprecision(2) << relError << std::endl;
        }
    }

    // 統計情報
    std::cerr << "Max relative error: " << std::scientific << std::setprecision(3)
              << maxRelError << " (at index " << maxErrorIdx << ")" << std::endl;
    if (ratioCount > 0) {
        double avgRatio = sumRatio / ratioCount;
        std::cerr << "Avg ratio (num/ana): " << std::fixed << std::setprecision(2)
                  << avgRatio << " (should be ~1.0)" << std::endl;
    }
    std::cerr << "Verification:       " << (maxRelError < 1e-3 ? "PASSED" : "FAILED") << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    return maxRelError;
}

double SourceOptimizer::calculateCurrentCost(double* outEpeCost, double* outSourceFillCost) {
    if (!m_sourceData || !m_evpData || !m_processConfig) {
        return 0.0;
    }

    // 変数マッピングを初期化（まだの場合）
    if (m_variableMapping.numVariables() == 0 && m_sourceGrid) {
        m_variableMapping.initialize(*m_sourceGrid, *m_sourceData);
        m_gradientCalculator.setVariableMapping(&m_variableMapping);
    }

    // slice levelの自動決定（まだの場合）
    if (m_sliceLevel < 0) {
        m_sliceLevel = findOptimalSliceLevel();
    }

    return m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel,
        m_options.epePower, outEpeCost, outSourceFillCost);
}

double SourceOptimizer::findOptimalSliceLevel() {
    if (!m_sourceData || !m_evpData || !m_processConfig || !m_sourceContributions) {
        return 0.5;
    }

    int mpiRank = 0, mpiSize = 1;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
    MPI_Comm_size(m_mpiComm, &mpiSize);
#endif

    double sliceLevel = 0.5;

    // rank 0がanchor clipのデータを持っているので、rank 0で計算してBroadcast
    if (mpiRank == 0) {
        const auto& gridConfig = m_sourceGrid->showConfig();

        CostCalculator costCalc;
        CostOptions costOptions;
        costOptions.sliceLevelHint = m_options.sliceLevelHint;
        costOptions.anchorClips = m_options.anchorClips;
        if (costOptions.anchorClips.empty()) {
            costOptions.anchorClips.push_back(0);
        }
        costCalc.setOptions(costOptions);

        sliceLevel = costCalc.findOptimalSliceLevel(
            *m_sourceContributions, *m_sourceData, gridConfig, *m_evpData, *m_processConfig);
    }

#ifdef HAVE_MPI_H
    if (mpiSize > 1) {
        MPI_Bcast(&sliceLevel, 1, MPI_DOUBLE, 0, m_mpiComm);
    }
#endif

    return sliceLevel;
}


} // namespace so
