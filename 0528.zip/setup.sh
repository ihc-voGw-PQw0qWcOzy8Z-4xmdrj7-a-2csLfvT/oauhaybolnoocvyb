#!/bin/bash
#
# smo_lib/setup.sh - SMO の既定値・入力ファイル・ツールパス
#
# 変数の優先順位:
#   1) 本ファイル (setup.sh) の既定値
#   2) --config <file> で source する追加ファイル (任意)
#   3) CLI オプション (--num_cycles, --layout_org_name など)
#   4) [末尾] 派生変数を再計算 (run_smo.sh が CLI 反映後に再実行)
#

# ============================================================
# 1. SMO ループ全体
# ============================================================
NUM_CYCLES=2                        # SO + OPC の反復回数

# NA 探索 (cycle ごとに [NA_MIN, NA_MAX] 内で最良 NA を探す)
NA_SEARCH_MODE="ternary"            # ternary | parallel
                                    # ternary : 三分探索 (適応的・シーケンシャル, NA_TOL で収束)
                                    # parallel: 全 NA 候補を NA_PRECISION 刻みで列挙し、
                                    #           各 NA の SOCS生成+srcOptim を同時並列実行
                                    #           → wall time 短縮。NA_TOL は未使用。
NA_MIN=1.2                          # 探索下限
NA_MAX=1.3                          # 探索上限
NA_TOL=0.05                         # range <= NA_TOL で打ち切り (ternary のみ)
NA_PRECISION=0.05                   # NA グリッド幅 (ternary: m1/m2 丸め, parallel: 候補刻み)

# ============================================================
# 2. レイアウト・入力ファイル
# ============================================================

# 入力レイアウト (srcOptim 用 .gds、no-vis OPC 用 .oas をペアで用意)
LAYOUT_ORG_DIR="$SCRIPT_DIR/Layout"
LAYOUT_ORG_NAME="arrayPitch/ah_ax5000_ay5000_mx64_my64_rx64_ry64_cx150_crx75_cry150.gds"
# cycle 1 の OPC (flow01) 入力 OAS。空なら LAYOUT_ORIGINAL の .gds → .oas で自動導出
LAYOUT_OAS=""

# srcOptim --layer に渡すレイヤ指定
LAYOUT_LAYER_INI="2/1,60/0"         # cycle 1 (litho target レイヤ)
LAYOUT_LAYER="1/1,60/0"             # cycle 2+ (post-OPC mask レイヤ)

# 評価点・srcOptim 入力
EVP="$SCRIPT_DIR/Layout/arrayPitch/ah_ax5000_ay5000_mx64_my64_rx64_ry64_cx150_crx75_cry150_ep.csv"
INI_TEMPLATE="$SCRIPT_DIR/in/ini.txt"
SOURCE_CONFIG="$SCRIPT_DIR/in/source_config.txt"
PWC_CONFIG="$SCRIPT_DIR/in/pwc_config.txt"
INITIAL_SOURCE="$SCRIPT_DIR/in/initial_source.illum"

# ============================================================
# 3. ソース最適化 (srcOptim) — 共通設定
# ============================================================
OPTIMIZER="lbfgs"                   # lbfgs | adam
GRADIENT_METHOD=2                   # 解析勾配 ID
MAX_ITER=200                        # L-BFGS / Adam の最大反復
KERNEL_NUM=30                       # SOCS カーネル数
OPENMP_NUM=16                       # OpenMP スレッド数
MPI_NP=1                            # MPI ランク数

# srcOptim cost 関数のステージスケジュール (CSV)
SO_EPE_POWER_SCHEDULE="2,4,6,8"
SO_ADAPTIVE_WEIGHT_P_SCHEDULE="1.0,3.0,5.0,7.0"
SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE="0.5,0.1,0.01,0.001"

# Basin Hopping (停滞検知トリガー + source 摂動 + Greedy accept/reject)
SO_BH_AMPLITUDE_INIT=0              # 0=無効。摂動振幅 (source 強度の単位)
SO_BH_COOLING=0.85                  # 摂動ごとの amplitude 減衰率
SO_BH_STALL_ROUNDS=2               # 何 round 連続で cost 停滞したら摂動するか
SO_BH_STALL_TOL=1e-4              # 停滞とみなす cost 相対改善率
SO_BH_MAX_PERTURBATIONS=10         # 最大摂動回数
SO_BH_ALL_STAGES=0                  # 全ステージで BH を回すか (0/1)

# Warmup (各 stage 序盤の round は L-BFGS iteration 数を絞って粗く回す)
SO_WARMUP_ROUNDS=0                  # 0=無効。各 stage の最初の N round を warmup 扱い
SO_WARMUP_MAX_ITER=4               # warmup round 内の L-BFGS 最大反復

# Slice level スイープ
SO_SLICE_METHOD="minmax"
SO_SLICE_OBJECTIVE="max_abs_epe"
SO_SLICE_PWC_MODE="all"
SO_SLICELEVEL_ROUNDS=30
SO_SLICE_MIN=0.05                   # sliceLevel 下限 (全 objective モードで clamp)
SO_SLICE_MAX=0.50                   # sliceLevel 上限

# 収束判定
SO_ROUND_CONV_WINDOW=3              # ラウンド単位の収束ウィンドウ
SO_ROUND_CONV_TOL=1e-6
SO_LBFGS_MEMORY=20
SO_LBFGS_WINDOW=15
SO_LBFGS_REL_TOL=1e-6
SO_LBFGS_MIN_ITER=20                # L-BFGS 最小反復回数
SO_EARLY_STOP_PATIENCE=20
SO_EARLY_STOP_TOL=1e-6
SO_GRAD_TOL=1e-4

# 光源強度の境界・制約
SO_MIN_INTENSITY=0.0
SO_MAX_INTENSITY=2.0
SO_MIN_FILL_RATIO=0.07              # source_fill_ratio 下限
SO_WEIGHT_FILL=10                   # source_fill_cost の重み
SO_FILL_PENALTY_K=10                # exp ペナルティの k

# ---- tmp0512 追加: tolerance 整合 + 追加ペナルティ (default は全て無効) ----
# 空文字 or 0 のときは wrapper 内のコマンドラインに追加されない (従来挙動)。
# 有効化すると tmp0512/run_srcoptim.sh と同じく srcOptim の対応オプションに伝搬する。
SO_TOLERANCE=""                     # 空 = evp.csv の tolerance 列を使う
                                    # 例: 0.0035 (μm = 3.5 nm) で calcMargin の --tolerance と整合
SO_WEIGHT_NILS=0                    # NILS ペナルティの重み (0 = 無効)
SO_NILS_MIN=2.0                     # NILS 下限
SO_NILS_CD_REF=0.022                # NILS 正規化用 CD 参照 [um]
SO_WEIGHT_BT=0                      # Bossung Tilt ペナルティ重み (0 = 無効)
SO_WEIGHT_BFS=0                     # Best Focus Shift ペナルティ重み (0 = 無効)
SO_BT_POWER=2
SO_BFS_POWER=2
SO_PAIR_CLIPS=""
SO_BT_PAIRS=""                      # 複数 BT ペア "Fp,Fn;Fp,Fn;..." 空なら defocus 極値ペア自動検出
SO_BFS_PAIRS=""                     # 複数 BFS ペア "Fp,Fn[,Nom];..." 3つ組指定可。
                                    # Nom 省略時は SO_BFS_PWC_NOM (or auto) を使用。
                                    # 空なら BT_PAIRS 流用 (or 自動検出)
SO_BFS_PWC_NOM=""                   # BFS の共通 Nom PWC index (空=自動: defocus=0,bias=0,dose=0)                    # BT/BFS 適用 clip ID (空 = 全 clip)
SO_REGULARIZATION="none"            # none|laplacian|l2|tv|isolated
SO_REGULARIZATION_WEIGHT=0          # 0 = 無効
SO_RESIST_MODEL=""                  # resistModel.info ファイルパス。空なら srcOptim 側で
                                    # resistModel_default.info を自動生成 (フォールバック)

# Multi-Start (異なる seed の SA を並列実行 → 最良解採用)
# - 1 で従来動作 (single-start)
# - 2 以上で seed ごとに独立 bsub
SO_NUM_STARTS=4
SO_START_SEEDS="11,22,33,44"        # 空なら 1,2,...,SO_NUM_STARTS で自動生成
                                    # 設定された場合 SO_NUM_STARTS を超える分は truncate

# ============================================================
# 4. ソース最適化 — cycle 別パラメータ (CSV; 空なら §3 単発値を全 cycle で使用)
# ============================================================
# - リスト長 < NUM_CYCLES なら最後の値を残り cycle で繰り返す
# - 例 (5 cycle, 序盤を粗く・終盤を深く):
#     MAX_ITER_PER_CYCLE="30,50,100,200,200"
#     SO_NUM_STARTS_PER_CYCLE="4,2,1,1,1"

# スカラ (区切り ',')
MAX_ITER_PER_CYCLE=""
SO_NUM_STARTS_PER_CYCLE=""
SO_BH_STALL_ROUNDS_PER_CYCLE=""
SO_SLICELEVEL_ROUNDS_PER_CYCLE=""
SO_LBFGS_MIN_ITER_PER_CYCLE=""
SO_BH_AMPLITUDE_INIT_PER_CYCLE=""
SO_BH_COOLING_PER_CYCLE=""
SO_WARMUP_ROUNDS_PER_CYCLE=""
SO_WARMUP_MAX_ITER_PER_CYCLE=""

# CSV-of-CSV (cycle 区切り ';', 値区切り ',')
# 例: SO_EPE_POWER_SCHEDULE_PER_CYCLE="2;2,4;2,4,6;2,4,6,8"
#     cycle1="2"  cycle2="2,4"  cycle3="2,4,6"  cycle4+="2,4,6,8"
SO_EPE_POWER_SCHEDULE_PER_CYCLE=""
SO_ADAPTIVE_WEIGHT_P_SCHEDULE_PER_CYCLE=""
SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE_PER_CYCLE=""

# ============================================================
# 5. OPC (TKO) — 共通設定
# ============================================================

# M3D オプション
M3D_SO=0                            # SO 側 M3D (SOCS 生成に --m3d を渡す)
M3D_OPC=0                           # OPC 側 M3D (MSOCS 生成に maketcc_m3dmtcc3)
MASK_KIKAKU="4kikaku"               # M3D_SO=1 / M3D_OPC=1 のとき使用
CGRP=""                             # M3D_OPC=1 時の coherent-group ファイル
                                    # 空なら illum から auto-generate

# OPC テンプレート (run.csh + tko_sub_dir1/ のフラット構成)
# run_smo.sh が cycle ごとに smo_work/<L>/cycle<N>/opc/ にコピー
OPC_TEMPLATE_DIR="$SCRIPT_DIR/tko_template"

# OPC 実行モード (./run.csh の扱い)
#   wait   = 終了まで待つ (デフォルト)
#   kill   = 出力ファイル出現で kill して次へ
#   detach = 出力ファイル出現で disown して放置・次へ進む
OPC_MODE="wait"
OPC_POLL_INTERVAL=5                 # kill/detach: 出力監視間隔 (秒)
OPC_POLL_TIMEOUT=7200               # kill/detach: 諦める時間 (秒)

# ツール別並列度 (LSF ホスト数 × OpenMP スレッド数)
# - tko (重い):    flow03 (tko_pre), flow10 (tko)
# - light (軽い):  tkl/tkqilt/tkv (flow01,02,04,05,09,11,12)
# 各ツール起動行の直前に setenv を inject するため、ドリフトしない。
TK_OMP_NUM_HOSTS_TKO=2
TK_OMP_NUM_THREADS_TKO=32
TK_OMP_NUM_HOSTS_LIGHT=1
TK_OMP_NUM_THREADS_LIGHT=16

# tkqilt + tko_pre 自動リトライ
# flow02 (tkqilt) の sliceLevel が高すぎて flow03 (tko_pre) が
# "failed to get exactly core polygon" で落ちることへの対処。
# 失敗時は sliceLevel を STEP ずつ下げて MAX_RETRY 回まで再試行。
# 既定: 0.98 → 0.95 → 0.92 (max 3 回)
TKQILT_SLICE_INIT=0.98
TKQILT_SLICE_STEP=0.03
TKQILT_MAX_RETRY=3                  # 1 ならリトライ無効 (テンプレ既定で 1 回だけ)

# blur 強制無効化
# source_config に src_blur が書かれていても MSOCS 生成前の blur を skip する。
# 0 (default) = src_blur 設定があれば blur 実行 / 1 = 常に skip
DISABLE_BLUR=0

# OPC の sliceLevel ソース (flow03_in.param.tko_pre / flow10_in.param.tko に設定する値)
# so    : ソース最適化の cost.csv の sliceLevel を使う (default)
# fixed : OPC_SLICE_FIXED の固定値を使う
OPC_SLICE_MODE="so"
OPC_SLICE_FIXED="0.30"              # OPC_SLICE_MODE=fixed のとき使う固定 sliceLevel

# ============================================================
# 6. OPC (TKO) — cycle 別パラメータ (CSV; 空なら tko_template 既定値を維持)
# ============================================================
# 既定値 (tko_template 内):
#   Optimizer.info: MaxEpoch=500
#   flow03_in.param.tko_pre / flow10_in.param.tko: ConvergenceCriterion=0.0002
# 注意: flow11/12 の tkv 系 ConvergenceCriterion は対象外 (変更しない)。
#
# 例 (5 cycle, 序盤の OPC を浅く):
#   TKO_MAX_EPOCH_PER_CYCLE="30,30,100,300,500"
#   TKO_CONV_PER_CYCLE="0.01,0.01,0.001,0.0005,0.0002"
TKO_MAX_EPOCH_PER_CYCLE=""
TKO_CONV_PER_CYCLE=""

# ============================================================
# 7. ツールパス
# ============================================================
SRCOPTIM="$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim"
MAKE_SOCS="$PROJECT_ROOT/mkSocsSet/make_socs_set_v2.py"
BLUR_ILLUM="$PROJECT_ROOT/mkSocsSet/blur_illum.py"
MAKETCC_MTCC3="maketcc_mtcc3"        # M2D MSOCS (PATH 経由)
MAKETCC_M3DMTCC3="maketcc_m3dmtcc3"  # M3D MSOCS (PATH 経由)
MAKETCC_CGRP="maketcc_cgrp"          # CGRP 自動生成 (PATH 経由)

# ============================================================
# 8. 作業ディレクトリ
# ============================================================
WORK_DIR="$SCRIPT_DIR/smo_work"          # SMO 全体の作業ルート
SOCS_CACHE_DIR="$WORK_DIR/socs_cache"    # SOCS キャッシュ (NA キー、レイアウト/cycle 横断)

# ============================================================
# 9. SOCS 半数間引き / tar.xz 圧縮 (tmp0428 統合)
# ============================================================
# 0/1 のトグルで SOCS の生成・保管・展開挙動を切り替える。
#
# - USE_SOCS_HALF=1  : make_socs_set_v2.py に --socs_skip_y_gt_x を渡して
#                      x>=y のみ生成。後段で transpose_socs_file/transpose_msocs_dir
#                      が x<y を転置復元する。
# - USE_SOCS_TARXZ=1 : 生成完了後 socs_archive.sh pack で socs_set/ を
#                      socs_set.tar.xz に圧縮 (元ディレクトリ削除)。
#
# どちらかが 1 のとき、submit ホスト側 (run_srcoptim 関数) が NA ごとに 1 回だけ
# socs_archive.sh prepare を呼び、$SOCS_CACHE_DIR/na_${na}/extracted/socs_set/ に
# 展開する。展開済み cache は SMO 全期間 (cycle 横断・seed 横断) で共有再利用。
# lock + .ready マーカーで並行 SMO に対して安全。
# 0/0 なら従来通り srcOptim を直接呼ぶ (展開作業も発生しない)。
#
# 展開済み cache は自動削除されない (永続 cache と同方針)。不要時は
#   rm -rf $SOCS_CACHE_DIR/*/extracted
# で手動削除する。
USE_SOCS_HALF=0
USE_SOCS_TARXZ=0

# tmp0428 由来の SOCS アーカイブツール (本ディレクトリにコピー済み)
SOCS_ARCHIVE_TOOL="$SCRIPT_DIR/socs_archive.sh"

# ============================================================
# 10. 派生変数 (run_smo.sh が CLI 反映後に再計算する)
# ============================================================
LAYOUT_ORIGINAL="$LAYOUT_ORG_DIR/$LAYOUT_ORG_NAME"
# LAYOUT_ORG_NAME のファイル名から拡張子を除いたもの (AAA/BBB.gds → BBB)
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME##*/}"
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME_DASH%.*}"
# レイアウト別の作業ディレクトリ
LAYOUT_WORK_DIR="$WORK_DIR/$LAYOUT_ORG_NAME_DASH"
