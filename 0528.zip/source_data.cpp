/*!
 * @file source_data.cpp
 * @brief 光源強度データの読み込み・管理
 */

#include "source_data.h"
#include "coord_utils.h"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <cmath>
#include <algorithm>
#include <iomanip>

namespace so {

std::pair<double, double> SourceData::makeKey(double x, double y) {
    return makeCoordKey(x, y);
}

SourceData::SourceData() {}

SourceData::~SourceData() {}

void SourceData::load(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open source file: " + filepath);
    }

    clear();

    std::string line;
    while (std::getline(file, line)) {
        // コメントと空行をスキップ
        if (line.empty() || line[0] == '#') {
            continue;
        }

        std::istringstream iss(line);
        SourcePoint point;
        if (iss >> point.x >> point.y >> point.intensity) {
            addPoint(point);
        }
    }
}

void SourceData::save(const std::string& filepath) const {
    std::ofstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }

    file << "# x y intensity\n";
    file << std::fixed << std::setprecision(12);

    for (const auto& point : m_points) {
        file << point.x << " " << point.y << " " << point.intensity << "\n";
    }
}

void SourceData::savePpm(const std::string& filepath, const SourceGrid& grid) const {
    const auto& config = grid.showConfig();

    // グリッドサイズ（正方形）- config.gridは全グリッド点数（例: 33点）
    int imgSize = config.grid;

    // 最大強度を取得（正規化用）
    double maxIntensity = showMaxIntensity();
    if (maxIntensity <= 0.0) {
        maxIntensity = 1.0;
    }

    // PPMファイルを開く
    std::ofstream file(filepath);
    if (!file.is_open()) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }

    // PPMヘッダ（P3 = ASCII RGB）
    file << "P3\n";
    file << imgSize << " " << imgSize << "\n";
    file << "255\n";

    // 画像データを出力（上から下へ、Y座標は反転）
    for (int iy = imgSize - 1; iy >= 0; --iy) {
        for (int ix = 0; ix < imgSize; ++ix) {
            // SourceGrid::generateGridPoints() と同じ座標生成ロジック
            double gx, gy;
            if (imgSize % 2 == 1) {
                // 奇数グリッド: 軸を含む（例: 33点 → -1.0 ... 0 ... 1.0）
                gx = -1.0 + 2.0 * ix / (imgSize - 1);
                gy = -1.0 + 2.0 * iy / (imgSize - 1);
            } else {
                // 偶数グリッド: 軸を含まない（例: 32点 → -0.96875 ... 0.96875）
                gx = -1.0 + (2.0 * ix + 1.0) / imgSize;
                gy = -1.0 + (2.0 * iy + 1.0) / imgSize;
            }

            // 強度を取得（D2対称を考慮）
            double intensity = getIntensityFirstQuadrant(gx, gy);

            // 正規化（0.0〜1.0）
            double t = std::max(0.0, std::min(1.0, intensity / maxIntensity));

            // Jetカラーマップ: 青(低) → シアン → 緑 → 黄 → 赤(高)
            int r, g, b;
            if (t < 0.25) {
                r = 0;
                g = static_cast<int>(255.0 * (t / 0.25));
                b = 255;
            } else if (t < 0.5) {
                r = 0;
                g = 255;
                b = static_cast<int>(255.0 * (1.0 - (t - 0.25) / 0.25));
            } else if (t < 0.75) {
                r = static_cast<int>(255.0 * ((t - 0.5) / 0.25));
                g = 255;
                b = 0;
            } else {
                r = 255;
                g = static_cast<int>(255.0 * (1.0 - (t - 0.75) / 0.25));
                b = 0;
            }

            file << r << " " << g << " " << b;

            if (ix < imgSize - 1) {
                file << " ";
            }
        }
        file << "\n";
    }
}

const std::vector<SourcePoint>& SourceData::showPoints() const {
    return m_points;
}

size_t SourceData::size() const {
    return m_points.size();
}

double SourceData::getIntensity(double x, double y) const {
    auto key = makeKey(x, y);
    auto it = m_intensityMap.find(key);
    if (it != m_intensityMap.end()) {
        return it->second;
    }
    return 0.0;
}

double SourceData::getIntensityFirstQuadrant(double x, double y) const {
    return getIntensity(std::abs(x), std::abs(y));
}

void SourceData::setIntensity(double x, double y, double intensity) {
    auto key = makeKey(x, y);
    
    // マップを更新
    m_intensityMap[key] = intensity;
    
    // ベクタも更新
    for (auto& point : m_points) {
        if (makeKey(point.x, point.y) == key) {
            point.intensity = intensity;
            return;
        }
    }
    
    // 見つからなければ新規追加
    SourcePoint newPoint;
    newPoint.x = x;
    newPoint.y = y;
    newPoint.intensity = intensity;
    m_points.push_back(newPoint);
}

double SourceData::calcSourceFillRatio(double NA) const {
    if (m_points.empty()) {
        return 0.0;
    }

    double totalIntensity = showTotalIntensity();
    double maxIntensity = showMaxIntensity();
    
    // 単位円内（x² + y² ≤ 1）の点数をカウント
    size_t n = 0;
    for (const auto& point : m_points) {
        if (point.x * point.x + point.y * point.y <= 1.0) {
            ++n;
        }
    }

    if (maxIntensity <= 0.0 || n == 0) {
        return 0.0;
    }

    double ratio = totalIntensity / (maxIntensity * static_cast<double>(n));
    ratio *= (NA / 1.35) * (NA / 1.35);

    return ratio;
}

double SourceData::showMaxIntensity() const {
    if (m_points.empty()) {
        return 0.0;
    }

    double maxVal = m_points[0].intensity;
    for (const auto& point : m_points) {
        if (point.intensity > maxVal) {
            maxVal = point.intensity;
        }
    }
    return maxVal;
}

double SourceData::normalizeMaxToOne() {
    if (m_points.empty()) return 0.0;
    double maxVal = m_points[0].intensity;
    for (const auto& point : m_points) {
        if (point.intensity > maxVal) maxVal = point.intensity;
    }
    if (maxVal <= 0.0) return 0.0;
    for (auto& point : m_points) {
        point.intensity /= maxVal;
    }
    return maxVal;
}

double SourceData::showTotalIntensity() const {
    double total = 0.0;
    for (const auto& point : m_points) {
        total += point.intensity;
    }
    return total;
}

void SourceData::addPoint(const SourcePoint& point) {
    m_points.push_back(point);
    auto key = makeKey(point.x, point.y);
    m_intensityMap[key] = point.intensity;
}

void SourceData::clear() {
    m_points.clear();
    m_intensityMap.clear();
}

void SourceData::enforceD2Symmetry() {
    constexpr double COORD_TOL = 1e-6;

    // 第1象限（x>=0, y>=0）の強度値を収集
    std::map<std::pair<double, double>, double> firstQuadrantValues;
    for (const auto& point : m_points) {
        if (point.x >= -COORD_TOL && point.y >= -COORD_TOL) {
            double absX = std::abs(point.x);
            double absY = std::abs(point.y);
            auto key = makeKey(absX, absY);
            firstQuadrantValues[key] = point.intensity;
        }
    }

    // 全点に第1象限の値をコピー
    for (auto& point : m_points) {
        double absX = std::abs(point.x);
        double absY = std::abs(point.y);
        auto key = makeKey(absX, absY);

        auto it = firstQuadrantValues.find(key);
        if (it != firstQuadrantValues.end()) {
            point.intensity = it->second;
        }
    }

    // intensityMapも更新
    m_intensityMap.clear();
    for (const auto& point : m_points) {
        auto key = makeKey(point.x, point.y);
        m_intensityMap[key] = point.intensity;
    }
}

// SourceValidator

bool SourceValidator::validateGridCoverage(const SourceData& data, const SourceGrid& grid) {
    auto gridPoints = grid.generateGridPoints();
    
    for (const auto& [gx, gy] : gridPoints) {
        bool found = false;
        for (const auto& point : data.showPoints()) {
            if (std::abs(point.x - gx) < 1e-6 && std::abs(point.y - gy) < 1e-6) {
                found = true;
                break;
            }
        }
        if (!found) {
            return false;
        }
    }
    
    return true;
}

bool SourceValidator::validateNonNegativeIntensity(const SourceData& data) {
    for (const auto& point : data.showPoints()) {
        if (point.intensity < 0.0) {
            return false;
        }
    }
    return true;
}

bool SourceValidator::validateGridAlignment(const SourceData& data, const SourceGrid& grid) {
    auto gridPoints = grid.generateGridPoints();

    for (const auto& point : data.showPoints()) {
        bool onGrid = false;
        for (const auto& [gx, gy] : gridPoints) {
            if (std::abs(point.x - gx) < 1e-6 && std::abs(point.y - gy) < 1e-6) {
                onGrid = true;
                break;
            }
        }
        if (!onGrid) {
            return false;
        }
    }

    return true;
}

bool SourceValidator::validateD2Symmetry(const SourceData& data, const SourceGrid& grid) {
    const auto& config = grid.showConfig();
    if (!config.isD2Symmetry()) {
        return true;  // D2設定でなければ常にtrue
    }

    auto gridPoints = grid.generateGridPoints();

    for (const auto& [gx, gy] : gridPoints) {
        double absX = std::abs(gx);
        double absY = std::abs(gy);

        double firstQuadrantIntensity = data.getIntensity(absX, absY);
        double currentIntensity = data.getIntensity(gx, gy);

        if (std::abs(currentIntensity - firstQuadrantIntensity) > 1e-6) {
            return false;
        }
    }

    return true;
}

bool SourceValidator::validateSigmaRange(const SourceData& data, const SourceGrid& grid) {
    const auto& config = grid.showConfig();

    for (const auto& point : data.showPoints()) {
        double r = std::sqrt(point.x * point.x + point.y * point.y);
        bool outOfRange = (r < config.sigma_min - 1e-6) || (r > config.sigma_max + 1e-6);

        if (outOfRange && point.intensity > 1e-6) {
            return false;
        }
    }

    return true;
}

bool SourceValidator::validateAll(const SourceData& data, const SourceGrid& grid) {
    return validateGridCoverage(data, grid) &&
           validateNonNegativeIntensity(data) &&
           validateGridAlignment(data, grid) &&
           validateD2Symmetry(data, grid) &&
           validateSigmaRange(data, grid);
}

} // namespace so
