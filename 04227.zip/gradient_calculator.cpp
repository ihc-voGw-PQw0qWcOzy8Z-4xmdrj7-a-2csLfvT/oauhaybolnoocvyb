/*!
 * @file gradient_calculator.cpp
 * @brief コスト勾配計算の実装
 */

#include "gradient_calculator.h"
#include "coord_utils.h"
#include "epe_newton.h"
#include <so/types.h>
#include <cmath>
#include <iostream>
#include <chrono>

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

namespace so {

namespace {
    constexpr double MIN_GRADIENT = 1e-12;
}

GradientCalculator::GradientCalculator() {}

GradientCalculator::~GradientCalculator() {}

void GradientCalculator::setVariableMapping(const VariableMapping* mapping) {
    m_mapping = mapping;
}

void GradientCalculator::setOptions(const OptimizationOptions& options) {
    m_options = options;
}

void GradientCalculator::setNA(double NA) {
    m_NA = NA;
}

void GradientCalculator::setSourceContributions(
    const std::map<std::string, SourceContributionSet>* sourceContributions) {
    m_sourceContributions = sourceContributions;
}

GradientIntermediates GradientCalculator::calcIntermediates(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData) const {

    GradientIntermediates inter;
    const auto& gridConfig = m_mapping->gridConfig();

    for (const auto& contrib : contribSet.contributions()) {
        double intensity;
        if (gridConfig.isD2Symmetry()) {
            intensity = sourceData.getIntensityFirstQuadrant(contrib.gx, contrib.gy);
        } else {
            intensity = sourceData.getIntensity(contrib.gx, contrib.gy);
        }

        double weight = contrib.norm * intensity;
        inter.totalWeight += weight;
        inter.weightPerSource[makeCoordKey(contrib.gx, contrib.gy)] = weight;
    }

    return inter;
}

std::map<std::pair<double, double>, double> GradientCalculator::calcQepeGradientAtPoint(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    const GradientIntermediates& inter,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose) const {

    std::map<std::pair<double, double>, double> gradients;
    const auto& gridConfig = m_mapping->gridConfig();

    if (inter.totalWeight < MIN_GRADIENT) {
        return gradients;
    }

    // 合成画像を計算（delta_dose適用）
    FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
    if (std::abs(delta_dose) > 1e-9) {
        combinedImg.scale(1.0 + delta_dose / 100.0);
    }
    auto pv = combinedImg.evalAt(px, py);

    // 法線方向を計算
    double rad = degree * M_PI / 180.0;
    double nx = std::cos(rad);
    double ny = std::sin(rad);

    // 法線方向の勾配 G = ∂I/∂n
    double G = pv.gradX * nx + pv.gradY * ny;

    // G が非常に小さい場合は勾配を計算しない
    if (std::abs(G) < MIN_GRADIENT) {
        return gradients;
    }

    // QEPE = -(I - sliceLevel) / G
    // ∂QEPE/∂s_j = -1/G × ∂I/∂s_j
    //
    // ∂I/∂s_j = norm_j × (I_j - I) / W
    //   where I = 合成画像の強度、I_j = 光源点jの寄与画像の強度
    //   W = Σ(norm_i × s_i)

    double W = inter.totalWeight;
    double I_combined = pv.intensity;

    for (const auto& contrib : contribSet.contributions()) {
        // 光源点jの寄与画像での強度
        auto pv_j = contrib.freqImage.evalAt(px, py);
        double I_j = pv_j.intensity;

        // delta_dose補正を適用（I_combinedと同じスケールにする）
        if (std::abs(delta_dose) > 1e-9) {
            I_j *= (1.0 + delta_dose / 100.0);
        }

        // ∂I/∂s_j = norm_j × (I_j - I) / W
        double dI_dsj = contrib.norm * (I_j - I_combined) / W;

        // 法線方向の勾配変化も考慮（2次効果は無視）
        // ∂G/∂s_j の影響は小さいので無視

        // ∂QEPE/∂s_j = -1/G × ∂I/∂s_j
        double dQEPE_dsj = -dI_dsj / G;

        auto key = makeCoordKey(contrib.gx, contrib.gy);
        gradients[key] = dQEPE_dsj;
    }

    return gradients;
}

std::vector<double> GradientCalculator::calculate(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    // クリップ毎の勾配と重みを保持（MPI決定的集約用）
    size_t numClips = clips.size();
    size_t numVars = m_mapping->numVariables();
    std::vector<std::map<std::pair<double, double>, double>> clipGradientMaps(numClips);
    std::vector<double> clipWeights(numClips, 0.0);

#ifdef _OPENMP
    // タスク毎の結果を格納（OpenMP決定的な加算順序を保証）
    std::vector<std::map<std::pair<double, double>, double>> taskGradients(tasks.size());
    std::vector<double> taskWeights(tasks.size(), 0.0);

    #pragma omp parallel for schedule(dynamic)
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ: このランクが担当しないクリップはスキップ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        // 合成画像を計算（delta_dose適用）
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        // 各評価点について勾配を計算
        for (const auto* ep : clip.evalPoints) {
            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double I = pv.intensity;

            // delta_dose補正後の強度でQEPEを計算
            double QEPE = 0.0;
            if (std::abs(G) > MIN_GRADIENT) {
                QEPE = -(I - sliceLevel) / G;
            }

            double w_total = ep->weight * pwc.weight;
            taskWeights[taskIdx] += w_total;

            // 勾配を計算（delta_dose適用）
            auto pointGrad = calcQepeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose);

            // tolerance デッドバンド:
            //   cost_i = (max(0,|QEPE|-tol))^2
            //   d cost_i / ds_j = 2 * QEPE_eff * sign(QEPE) * dQEPE/ds_j   (|QEPE|>tol時)
            //                   = 0                                        (|QEPE|<=tol時)
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - ep->tolerance);
            double QEPE_sign = (QEPE >= 0.0) ? 1.0 : -1.0;
            double factor = 2.0 * QEPE_eff * QEPE_sign;  // デッドバンド内なら0

            // ∂cost/∂s_j = factor × w × ∂QEPE/∂s_j
            for (const auto& [key, dQEPE] : pointGrad) {
                double contribution = factor * w_total * dQEPE;
                taskGradients[taskIdx][key] += contribution;
            }
        }
    }

    // タスクインデックス順にクリップ毎に集約
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        size_t c = tasks[taskIdx].clipIdx;
        for (const auto& [key, val] : taskGradients[taskIdx]) {
            clipGradientMaps[c][key] += val;
        }
        clipWeights[c] += taskWeights[taskIdx];
    }
#else
    // シングルスレッド版
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ: このランクが担当しないクリップはスキップ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        // 合成画像を計算（delta_dose適用）
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        // 各評価点について勾配を計算
        for (const auto* ep : clip.evalPoints) {
            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double I = pv.intensity;

            // delta_dose補正後の強度でQEPEを計算
            double QEPE = 0.0;
            if (std::abs(G) > MIN_GRADIENT) {
                QEPE = -(I - sliceLevel) / G;
            }

            double w_total = ep->weight * pwc.weight;
            clipWeights[task.clipIdx] += w_total;

            // 勾配を計算（delta_dose適用）
            auto pointGrad = calcQepeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose);

            // tolerance デッドバンド:
            //   cost_i = (max(0,|QEPE|-tol))^2
            //   d cost_i / ds_j = 2 * QEPE_eff * sign(QEPE) * dQEPE/ds_j   (|QEPE|>tol時)
            //                   = 0                                        (|QEPE|<=tol時)
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - ep->tolerance);
            double QEPE_sign = (QEPE >= 0.0) ? 1.0 : -1.0;
            double factor = 2.0 * QEPE_eff * QEPE_sign;  // デッドバンド内なら0

            // ∂cost/∂s_j = factor × w × ∂QEPE/∂s_j
            for (const auto& [key, dQEPE] : pointGrad) {
                double contribution = factor * w_total * dQEPE;
                clipGradientMaps[task.clipIdx][key] += contribution;
            }
        }
    }
#endif

    // デバッグ出力（verbose時、MPI交換前のローカル勾配を表示）
    if (m_options.verbose) {
        // ローカルのfullGradientを構築（デバッグ用）
        std::map<std::pair<double, double>, double> fullGradient;
        for (size_t c = 0; c < numClips; ++c) {
            for (const auto& [key, val] : clipGradientMaps[c]) {
                fullGradient[key] += val;
            }
        }
        if (!fullGradient.empty()) {
            const auto& varInfos = m_mapping->variableInfos();
            if (!varInfos.empty()) {
                const auto& info = varInfos[0];
                std::cerr << "  [GradCalc Debug] Variable 0: gx=" << info.gx << ", gy=" << info.gy << std::endl;
                std::cerr << "    fullGradient entries for symmetric points:" << std::endl;

                auto key1 = std::make_pair(roundCoord(info.gx), roundCoord(info.gy));
                auto it1 = fullGradient.find(key1);
                std::cerr << "      (" << info.gx << "," << info.gy << "): "
                          << (it1 != fullGradient.end() ? std::to_string(it1->second) : "NOT FOUND") << std::endl;

                if (gridConfig.isD2Symmetry()) {
                    if (std::abs(info.gx) > 1e-6) {
                        auto key2 = std::make_pair(roundCoord(-info.gx), roundCoord(info.gy));
                        auto it2 = fullGradient.find(key2);
                        std::cerr << "      (" << -info.gx << "," << info.gy << "): "
                                  << (it2 != fullGradient.end() ? std::to_string(it2->second) : "NOT FOUND") << std::endl;
                    }
                    if (std::abs(info.gy) > 1e-6) {
                        auto key3 = std::make_pair(roundCoord(info.gx), roundCoord(-info.gy));
                        auto it3 = fullGradient.find(key3);
                        std::cerr << "      (" << info.gx << "," << -info.gy << "): "
                                  << (it3 != fullGradient.end() ? std::to_string(it3->second) : "NOT FOUND") << std::endl;
                    }
                    if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) {
                        auto key4 = std::make_pair(roundCoord(-info.gx), roundCoord(-info.gy));
                        auto it4 = fullGradient.find(key4);
                        std::cerr << "      (" << -info.gx << "," << -info.gy << "): "
                                  << (it4 != fullGradient.end() ? std::to_string(it4->second) : "NOT FOUND") << std::endl;
                    }
                }
            }
        }
    }

    // クリップ毎の勾配マップをベクトルに変換し、フラット配列に格納
    std::vector<double> flatGradients(numClips * numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        if (clipGradientMaps[c].empty()) continue;
        std::vector<double> clipVec = m_mapping->gradientMapToVector(clipGradientMaps[c]);
        std::copy(clipVec.begin(), clipVec.end(), flatGradients.begin() + c * numVars);
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalFlat(numClips * numVars, 0.0);
        MPI_Allreduce(flatGradients.data(), globalFlat.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        flatGradients = std::move(globalFlat);

        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    std::vector<double> gradient(numVars, 0.0);
    double totalWeight = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        for (size_t j = 0; j < numVars; ++j) {
            gradient[j] += flatGradients[c * numVars + j];
        }
        totalWeight += clipWeights[c];
    }

    // 重みで正規化 + EPEスケーリング
    if (totalWeight > 0.0) {
        for (size_t i = 0; i < gradient.size(); ++i) {
            gradient[i] *= EPE_SCALE / totalWeight;
        }
    }

    if (m_options.verbose) {
        std::cerr << "    totalWeight (for normalization): " << totalWeight << std::endl;
    }

    // source_fill_cost の勾配を追加（全ランクで同一計算）
    std::vector<double> fillGrad = calcSourceFillGradient(sourceData);
    for (size_t i = 0; i < gradient.size(); ++i) {
        gradient[i] += m_options.weightFillPenalty * fillGrad[i];
    }

    // 正則化の勾配を追加（全ランクで同一計算）
    if (m_options.regularizationWeight > 0.0) {
        std::vector<double> regGrad;
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regGrad = calcLaplacianGradient(sourceData);
                break;
            case RegularizationType::L2:
                regGrad = calcL2Gradient(sourceData);
                break;
            case RegularizationType::TV:
                regGrad = calcTVGradient(sourceData);
                break;
            case RegularizationType::Isolated:
                regGrad = calcIsolatedGradient(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
        for (size_t i = 0; i < gradient.size() && i < regGrad.size(); ++i) {
            gradient[i] += regGrad[i];
        }
    }

    // NILS ペナルティの勾配を追加
    if (m_options.weightNilsPenalty > 0.0) {
        auto nilsGrad = calcNilsGradientTotal(sourceData, evpData, processConfig, sliceLevel);
        for (size_t i = 0; i < gradient.size() && i < nilsGrad.size(); ++i) {
            gradient[i] += m_options.weightNilsPenalty * nilsGrad[i];
        }
    }

    // デバッグ出力（最初の変数の勾配）
    if (m_options.verbose && !gradient.empty()) {
        std::cerr << "    Folded gradient[0]: " << gradient[0] << std::endl;
        std::cerr << "    source_fill gradient[0]: " << (fillGrad.empty() ? 0.0 : fillGrad[0]) << std::endl;
    }

    return gradient;
}

std::vector<double> GradientCalculator::calcSourceFillGradient(
    const SourceData& sourceData) const {

    double sourceFillRatio = calcSourceFillRatio(sourceData);

    std::vector<double> grad(m_mapping->numVariables(), 0.0);

    if (sourceFillRatio >= m_options.minSourceFillRatio) {
        return grad;  // 制約を満たしている場合は勾配ゼロ
    }

    double diff = m_options.minSourceFillRatio - sourceFillRatio;
    double dCost_dRatio;
    if (m_options.useExponentialFillPenalty) {
        // 指数ペナルティ: cost = exp(k * diff) - 1
        double k = m_options.fillPenaltyExponent;
        dCost_dRatio = -k * std::exp(k * diff);
    } else {
        // 二乗ペナルティ: cost = diff^2
        dCost_dRatio = -2.0 * diff;
    }

    // 単位円内の物理点数 n
    const auto& points = sourceData.showPoints();
    size_t n = 0;
    for (const auto& point : points) {
        if (point.x * point.x + point.y * point.y <= 1.0) {
            ++n;
        }
    }
    if (n == 0) {
        return grad;
    }

    double maxIntensity = sourceData.showMaxIntensity();
    double totalIntensity = sourceData.showTotalIntensity();
    if (maxIntensity <= 0.0) {
        return grad;
    }

    // ratio = c·total/(max·n), c = (NA/1.35)^2
    //
    // スケール不変性 (ratio(α·s) = ratio(s)) から ∂ratio/∂s_j は max の依存を
    // 含めて計算しなければならない。一意ピーク点 j* では
    //   ∂ratio/∂s_j    =  c/(max·n)                         (j ≠ j*)
    //   ∂ratio/∂s_{j*} =  c/(max·n) - c·total/(max²·n)
    // タイブレーク(m個同点)時はピーク集合へ均等分配:
    //   ピーク点 k     :  c/(max·n) - (1/m)·c·total/(max²·n)
    //
    // D2 対称では 1 変数 i の multiplier_i 個の物理コピーは常に同値なので、
    // 変数 i がピークなら全コピーがピーク集合に属する。
    double naFactor = (m_NA / 1.35) * (m_NA / 1.35);
    double common = naFactor / (maxIntensity * static_cast<double>(n));
    double peakCorr = -naFactor * totalIntensity
                      / (maxIntensity * maxIntensity * static_cast<double>(n));

    // ピーク変数の同定
    std::vector<double> varValues = m_mapping->sourceToVariables(sourceData);
    const double peakRelTol = 1e-9;
    double peakThreshold = maxIntensity * (1.0 - peakRelTol);

    const auto& infos = m_mapping->variableInfos();
    std::vector<bool> isPeakVar(infos.size(), false);
    int peakCount = 0;  // ピーク物理点の総数 (= m)
    for (size_t i = 0; i < infos.size(); ++i) {
        if (varValues[i] >= peakThreshold) {
            isPeakVar[i] = true;
            peakCount += infos[i].multiplier;
        }
    }
    if (peakCount == 0) {
        // 念のためのガード（到達しないはず）
        peakCount = 1;
    }

    for (size_t i = 0; i < infos.size(); ++i) {
        double mult = static_cast<double>(infos[i].multiplier);
        double dRatio_dxi = mult * common;
        if (isPeakVar[i]) {
            dRatio_dxi += (mult / static_cast<double>(peakCount)) * peakCorr;
        }
        grad[i] = dCost_dRatio * dRatio_dxi;
    }

    return grad;
}

double GradientCalculator::calcSourceFillRatio(
    const SourceData& sourceData) const {
    return sourceData.calcSourceFillRatio(m_NA);
}

double GradientCalculator::calcSourceFillCost(double sourceFillRatio) const {
    if (sourceFillRatio >= m_options.minSourceFillRatio) {
        return 0.0;
    }

    double diff = m_options.minSourceFillRatio - sourceFillRatio;

    if (m_options.useExponentialFillPenalty) {
        // 指数ペナルティ: exp(k * diff) - 1
        // diff → 0 で cost → 0、diff が大きいと急激に増加
        double k = m_options.fillPenaltyExponent;
        return std::exp(k * diff) - 1.0;
    } else {
        // 従来の二乗ペナルティ
        return diff * diff;
    }
}

// ============================================================================
// NILS ペナルティ
// ============================================================================

double GradientCalculator::calcNilsAtPoint(
    const FrequencyImage& combinedImg,
    double px, double py, double degree,
    double sliceLevel,
    double* outG) const {

    double rad = degree * M_PI / 180.0;
    double nx = std::cos(rad);
    double ny = std::sin(rad);

    auto pv = combinedImg.evalAt(px, py);
    double G = pv.gradX * nx + pv.gradY * ny;
    if (outG) *outG = G;

    if (sliceLevel < MIN_GRADIENT) {
        return 0.0;
    }
    return m_options.nilsCdReference * std::abs(G) / sliceLevel;
}

double GradientCalculator::calcNilsCostTotal(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    // weightNilsPenalty == 0 でもログ/cost.csv 出力のため値を計算する。
    // （最適化ループ側は outNilsCost=nullptr のときだけ本関数の呼び出しを
    //   スキップしているので、毎 iteration の FFT 合成コストは増えない。）
    if (!m_mapping || !m_sourceContributions) return 0.0;

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    struct Task { size_t clipIdx; size_t pwcIdx; };
    std::vector<Task> tasks;
    for (size_t c = 0; c < clips.size(); ++c)
        for (size_t p = 0; p < pwcs.size(); ++p)
            tasks.push_back({c, p});

    std::vector<double> taskPenalty(tasks.size(), 0.0);
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) continue;

        FrequencyImage combinedImg = it->second.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            double nils = calcNilsAtPoint(combinedImg, ep->px, ep->py, ep->degree, sliceLevel, nullptr);
            double deficit = std::max(0.0, m_options.nilsMin - nils);
            double w = ep->weight * pwc.weight;
            taskPenalty[taskIdx] += deficit * deficit * w;
            taskWeights[taskIdx] += w;
        }
    }

    size_t numClips = clips.size();
    std::vector<double> clipPenalty(numClips, 0.0);
    std::vector<double> clipWeights(numClips, 0.0);
    for (size_t t = 0; t < tasks.size(); ++t) {
        clipPenalty[tasks[t].clipIdx] += taskPenalty[t];
        clipWeights[tasks[t].clipIdx] += taskWeights[t];
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> gP(numClips, 0.0), gW(numClips, 0.0);
        MPI_Allreduce(clipPenalty.data(), gP.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeights.data(), gW.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipPenalty = std::move(gP);
        clipWeights = std::move(gW);
    }
#endif

    double totalP = 0.0, totalW = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        totalP += clipPenalty[c];
        totalW += clipWeights[c];
    }
    return (totalW > 0.0) ? (totalP / totalW) : 0.0;
}

std::vector<double> GradientCalculator::calcNilsGradientTotal(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    size_t numVars = m_mapping ? m_mapping->numVariables() : 0;
    std::vector<double> zero(numVars, 0.0);
    if (m_options.weightNilsPenalty <= 0.0) return zero;
    if (!m_mapping || !m_sourceContributions) return zero;

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    struct Task { size_t clipIdx; size_t pwcIdx; };
    std::vector<Task> tasks;
    for (size_t c = 0; c < clips.size(); ++c)
        for (size_t p = 0; p < pwcs.size(); ++p)
            tasks.push_back({c, p});

    size_t numClips = clips.size();
    std::vector<std::map<std::pair<double, double>, double>> clipGradMaps(numClips);
    std::vector<double> clipWeights(numClips, 0.0);

    std::vector<std::map<std::pair<double, double>, double>> taskGrads(tasks.size());
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) continue;

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);
        if (inter.totalWeight < MIN_GRADIENT) continue;

        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }
        double W = inter.totalWeight;

        for (const auto* ep : clip.evalPoints) {
            double w_total = ep->weight * pwc.weight;
            taskWeights[taskIdx] += w_total;

            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double absG = std::abs(G);
            double nils = m_options.nilsCdReference * absG / sliceLevel;

            double deficit = m_options.nilsMin - nils;
            if (deficit <= 0.0) continue;  // ペナルティ領域外

            // penalty_i = deficit^2, ∂deficit/∂s = -∂NILS/∂s
            // NILS = cdRef/slice × |G|, ∂|G|/∂s = sign(G) × ∂G/∂s
            // ∂G/∂s_j = norm_j × (G_j - G_combined) / W
            double sG = (G >= 0.0) ? 1.0 : -1.0;
            double coef = -2.0 * deficit * m_options.nilsCdReference / sliceLevel * sG;
            double factor = coef * w_total;

            for (const auto& contrib : contribSet.contributions()) {
                auto pv_j = contrib.freqImage.evalAt(ep->px, ep->py);
                double Gj = pv_j.gradX * nx + pv_j.gradY * ny;
                if (std::abs(pwc.delta_dose) > 1e-9) {
                    Gj *= (1.0 + pwc.delta_dose / 100.0);
                }
                double dG_dsj = contrib.norm * (Gj - G) / W;
                double dPen_dsj = factor * dG_dsj;

                auto key = makeCoordKey(contrib.gx, contrib.gy);
                taskGrads[taskIdx][key] += dPen_dsj;
            }
        }
    }

    for (size_t t = 0; t < tasks.size(); ++t) {
        size_t c = tasks[t].clipIdx;
        for (const auto& [k, v] : taskGrads[t]) clipGradMaps[c][k] += v;
        clipWeights[c] += taskWeights[t];
    }

    std::vector<double> flat(numClips * numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        if (clipGradMaps[c].empty()) continue;
        auto v = m_mapping->gradientMapToVector(clipGradMaps[c]);
        std::copy(v.begin(), v.end(), flat.begin() + c * numVars);
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> gFlat(numClips * numVars, 0.0);
        MPI_Allreduce(flat.data(), gFlat.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        flat = std::move(gFlat);
        std::vector<double> gW(numClips, 0.0);
        MPI_Allreduce(clipWeights.data(), gW.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipWeights = std::move(gW);
    }
#endif

    std::vector<double> gradient(numVars, 0.0);
    double totalW = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        for (size_t j = 0; j < numVars; ++j) gradient[j] += flat[c * numVars + j];
        totalW += clipWeights[c];
    }
    if (totalW > 0.0) {
        for (auto& v : gradient) v /= totalW;
    }
    return gradient;
}

double GradientCalculator::calculateCost(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    double* outEpeCost,
    double* outSourceFillCost,
    double* outNilsCost) const {

    if (!m_mapping || !m_sourceContributions) {
        if (outEpeCost) *outEpeCost = 0.0;
        if (outSourceFillCost) *outSourceFillCost = 0.0;
        if (outNilsCost) *outNilsCost = 0.0;
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    double totalWeightedQEPESq = 0.0;
    double totalWeight = 0.0;

    // タスク毎の結果を格納（決定的な加算順序を保証）
    std::vector<double> taskQEPESq(tasks.size(), 0.0);
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        FrequencyImage combinedImg = it->second.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double I = pv.intensity;

            double QEPE = 0.0;
            if (std::abs(G) > MIN_GRADIENT) {
                QEPE = -(I - sliceLevel) / G;
            }

            double w = ep->weight * pwc.weight;
            // tolerance デッドバンド: |QEPE|<=tolerance は無罰
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - ep->tolerance);
            taskQEPESq[taskIdx] += QEPE_eff * QEPE_eff * w;
            taskWeights[taskIdx] += w;
        }
    }

    // タスク結果をクリップ単位に集約（MPI決定的集約用）
    size_t numClips = clips.size();
    std::vector<double> clipCosts(numClips, 0.0);
    std::vector<double> clipWeights(numClips, 0.0);
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        clipCosts[tasks[taskIdx].clipIdx] += taskQEPESq[taskIdx];
        clipWeights[tasks[taskIdx].clipIdx] += taskWeights[taskIdx];
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalClipCosts(numClips, 0.0);
        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipCosts.data(), globalClipCosts.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipCosts = std::move(globalClipCosts);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    for (size_t c = 0; c < numClips; ++c) {
        totalWeightedQEPESq += clipCosts[c];
        totalWeight += clipWeights[c];
    }

    double epeCost = (totalWeight > 0.0) ? totalWeightedQEPESq * EPE_SCALE / totalWeight : 0.0;
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double sourceFillCost = calcSourceFillCost(sourceFillRatio);

    // 正則化コストを追加
    double regularizationCost = 0.0;
    if (m_options.regularizationWeight > 0.0) {
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regularizationCost = calcLaplacianCost(sourceData);
                break;
            case RegularizationType::L2:
                regularizationCost = calcL2Cost(sourceData);
                break;
            case RegularizationType::TV:
                regularizationCost = calcTVCost(sourceData);
                break;
            case RegularizationType::Isolated:
                regularizationCost = calcIsolatedCost(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
    }

    // NILS ペナルティ
    // 最適化ループでは outNilsCost=nullptr かつ weight=0 の場合はスキップしてFFT合成コストを節約。
    // ログ/cost.csv 出力で outNilsCost が要求された場合は weight=0 でも値を返す。
    bool needNils = (outNilsCost != nullptr) || (m_options.weightNilsPenalty > 0.0);
    double nilsCost = needNils
        ? calcNilsCostTotal(sourceData, evpData, processConfig, sliceLevel)
        : 0.0;

    if (outEpeCost) *outEpeCost = epeCost;
    if (outSourceFillCost) *outSourceFillCost = sourceFillCost;
    if (outNilsCost) *outNilsCost = nilsCost;

    return epeCost + m_options.weightFillPenalty * sourceFillCost + regularizationCost
         + m_options.weightNilsPenalty * nilsCost;
}

std::vector<double> GradientCalculator::calculateNumerical(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    double epsilon) const {

    if (!m_mapping) {
        return {};
    }

    std::vector<double> gradient(m_mapping->numVariables());
    std::vector<double> variables = m_mapping->sourceToVariables(sourceData);

    for (size_t i = 0; i < variables.size(); ++i) {
        // 中心差分
        double originalValue = variables[i];

        // +epsilon
        variables[i] = originalValue + epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costPlus = calculateCost(sourceData, evpData, processConfig, sliceLevel);

        // -epsilon
        variables[i] = originalValue - epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costMinus = calculateCost(sourceData, evpData, processConfig, sliceLevel);

        gradient[i] = (costPlus - costMinus) / (2.0 * epsilon);

        // 元に戻す
        variables[i] = originalValue;
    }

    // 光源データを元に戻す
    m_mapping->variablesToSource(variables, sourceData);

    return gradient;
}

std::vector<double> GradientCalculator::calculateNumericalEfficient(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    // GradientMethodに基づいて効率版を選択
    // QEPE系(1,3) → QEPE効率版、EPE系(2,4) → EPE効率版
    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
        case GradientMethod::QEPE_Numerical:
            return calculateQepeNumericalEfficient(sourceData, evpData, processConfig, sliceLevel);

        case GradientMethod::EPE_Analytical:
        case GradientMethod::EPE_Numerical:
        default:
            return calculateEpeNumericalEfficient(sourceData, evpData, processConfig, sliceLevel, epePower);
    }
}

// ============================================================================
// 厳密EPE、EPE^n コスト/勾配計算
// ============================================================================

double GradientCalculator::findContourPosition(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose,
    bool* outConverged,
    int /* debugClipID */,
    int /* debugPwcIdx */,
    double /* debugMaskBias */) const {

    EpeCalcResult result = findContourPositionFull(
        contribSet, sourceData, px, py, degree, sliceLevel, delta_dose);

    if (outConverged) {
        *outConverged = result.converged;
    }
    return result.epe;
}

EpeCalcResult GradientCalculator::findContourPositionFull(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose) const {

    const auto& gridConfig = m_mapping->gridConfig();

    FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
    if (std::abs(delta_dose) > 1e-9) {
        combinedImg.scale(1.0 + delta_dose / 100.0);
    }

    return calcEpeNewton(combinedImg, px, py, degree, sliceLevel);
}

std::map<std::pair<double, double>, double> GradientCalculator::calcStrictEpeGradientAtPoint(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    const GradientIntermediates& inter,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose,
    double* outEpe,
    bool* outConverged,
    int /* debugClipID */,
    int /* debugPwcIdx */,
    double /* debugMaskBias */) const {

    std::map<std::pair<double, double>, double> gradients;
    const auto& gridConfig = m_mapping->gridConfig();

    if (inter.totalWeight < MIN_GRADIENT) {
        if (outEpe) *outEpe = 0.0;
        if (outConverged) *outConverged = false;
        return gradients;
    }

    // Newton法でコントア位置を取得。収束の可否に関わらず result.epe を採用する
    //（＝「たまたま tolerance に入らなかっただけ」扱い）。
    EpeCalcResult result = findContourPositionFull(
        contribSet, sourceData, px, py, degree, sliceLevel, delta_dose);

    if (outConverged) *outConverged = result.converged;

    double epe = result.epe;
    if (outEpe) *outEpe = epe;

    double rad = degree * M_PI / 180.0;
    double nx = std::cos(rad);
    double ny = std::sin(rad);

    // コントア位置
    double cx = px + epe * nx;
    double cy = py + epe * ny;

    // コントア位置での合成画像と勾配（delta_dose適用）
    FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
    if (std::abs(delta_dose) > 1e-9) {
        combinedImg.scale(1.0 + delta_dose / 100.0);
    }
    auto pv_c = combinedImg.evalAt(cx, cy);
    double I_c = pv_c.intensity;

    // コントア位置での法線勾配 G_c
    double G_c = pv_c.gradX * nx + pv_c.gradY * ny;

    if (std::abs(G_c) < MIN_GRADIENT) {
        // G_c ≈ 0 では ∂EPE/∂s_j = -∂I/∂s_j / G_c が発散するため
        // この点の勾配寄与のみ空マップでスキップ（重みは呼び出し側で加算される）。
        return gradients;
    }

    double W = inter.totalWeight;

    // 各光源点について、コントア位置での勾配を計算
    // ∂EPE/∂s_j = -∂I(C)/∂s_j / G_c
    // ∂I(C)/∂s_j = norm_j × (I_j(C) - I(C)) / W
    for (const auto& contrib : contribSet.contributions()) {
        auto pv_j = contrib.freqImage.evalAt(cx, cy);
        double I_j_c = pv_j.intensity;
        if (std::abs(delta_dose) > 1e-9) {
            I_j_c *= (1.0 + delta_dose / 100.0);
        }

        double dI_dsj = contrib.norm * (I_j_c - I_c) / W;
        double dEPE_dsj = -dI_dsj / G_c;

        auto key = makeCoordKey(contrib.gx, contrib.gy);
        gradients[key] = dEPE_dsj;
    }

    return gradients;
}

std::vector<double> GradientCalculator::calculateEpeAnalytical(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    // クリップ毎の勾配と重みを保持（MPI決定的集約用）
    size_t numClips = clips.size();
    size_t numVars = m_mapping->numVariables();
    std::vector<std::map<std::pair<double, double>, double>> clipGradientMaps(numClips);
    std::vector<double> clipWeights(numClips, 0.0);

#ifdef _OPENMP
    // タスク毎の結果を格納（OpenMP決定的な加算順序を保証）
    std::vector<std::map<std::pair<double, double>, double>> taskGradients(tasks.size());
    std::vector<double> taskWeights(tasks.size(), 0.0);

    #pragma omp parallel for schedule(dynamic)
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        for (const auto* ep : clip.evalPoints) {
            double w_total = ep->weight * pwc.weight;

            // 厳密EPEと勾配を計算（Newton 非収束でも result.epe を採用）
            double epe = 0.0;
            bool converged = false;
            auto pointGrad = calcStrictEpeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose, &epe, &converged);

            // 収束/非収束に関わらず重みを加算（cost 側と totalWeight を一致させる）。
            taskWeights[taskIdx] += w_total;

            if (pointGrad.empty()) {
                // G_c≈0 等で勾配が計算不能な点は勾配寄与 0 として扱う（weight は加算済み）
                continue;
            }

            // tolerance デッドバンド:
            //   cost_i = (max(0,|EPE|-tol))^n
            //   |EPE|>tol: d cost_i / ds_j = n * (|EPE|-tol)^(n-1) * sign(EPE) * dEPE/ds_j
            //   |EPE|<=tol: 0
            double epeAbs = std::abs(epe);
            double epe_eff = std::max(0.0, epeAbs - ep->tolerance);
            double epePowM1 = (epe_eff > 0.0) ? std::pow(epe_eff, epePower - 1) : 0.0;
            double sign = (epe >= 0) ? 1.0 : -1.0;

            for (auto& [key, dEPE] : pointGrad) {
                double contribution = static_cast<double>(epePower) * epePowM1 * sign * w_total * dEPE;
                taskGradients[taskIdx][key] += contribution;
            }
        }
    }

    // タスクインデックス順にクリップ毎に集約
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        size_t c = tasks[taskIdx].clipIdx;
        for (const auto& [key, val] : taskGradients[taskIdx]) {
            clipGradientMaps[c][key] += val;
        }
        clipWeights[c] += taskWeights[taskIdx];
    }
#else
    // シングルスレッド版
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        for (const auto* ep : clip.evalPoints) {
            double w_total = ep->weight * pwc.weight;

            double epe = 0.0;
            bool converged = false;
            auto pointGrad = calcStrictEpeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose, &epe, &converged);

            clipWeights[task.clipIdx] += w_total;

            if (pointGrad.empty()) {
                continue;
            }

            double epeAbs = std::abs(epe);
            double epe_eff = std::max(0.0, epeAbs - ep->tolerance);
            double epePowM1 = (epe_eff > 0.0) ? std::pow(epe_eff, epePower - 1) : 0.0;
            double sign = (epe >= 0) ? 1.0 : -1.0;

            for (auto& [key, dEPE] : pointGrad) {
                double contribution = static_cast<double>(epePower) * epePowM1 * sign * w_total * dEPE;
                clipGradientMaps[task.clipIdx][key] += contribution;
            }
        }
    }
#endif

    // クリップ毎の勾配マップをベクトルに変換し、フラット配列に格納
    std::vector<double> flatGradients(numClips * numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        if (clipGradientMaps[c].empty()) continue;
        std::vector<double> clipVec = m_mapping->gradientMapToVector(clipGradientMaps[c]);
        std::copy(clipVec.begin(), clipVec.end(), flatGradients.begin() + c * numVars);
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalFlat(numClips * numVars, 0.0);
        MPI_Allreduce(flatGradients.data(), globalFlat.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        flatGradients = std::move(globalFlat);

        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    std::vector<double> gradient(numVars, 0.0);
    double totalWeight = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        for (size_t j = 0; j < numVars; ++j) {
            gradient[j] += flatGradients[c * numVars + j];
        }
        totalWeight += clipWeights[c];
    }

    // 重みで正規化 + べき乗に応じたEPEスケーリング
    double epeScaleForPower = 1.0 / std::pow(EPE_REF, epePower);
    if (totalWeight > 0.0) {
        for (size_t i = 0; i < gradient.size(); ++i) {
            gradient[i] *= epeScaleForPower / totalWeight;
        }
    }

    // source_fill_cost の勾配を追加
    std::vector<double> fillGrad = calcSourceFillGradient(sourceData);
    for (size_t i = 0; i < gradient.size(); ++i) {
        gradient[i] += m_options.weightFillPenalty * fillGrad[i];
    }

    // 正則化の勾配を追加
    if (m_options.regularizationWeight > 0.0) {
        std::vector<double> regGrad;
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regGrad = calcLaplacianGradient(sourceData);
                break;
            case RegularizationType::L2:
                regGrad = calcL2Gradient(sourceData);
                break;
            case RegularizationType::TV:
                regGrad = calcTVGradient(sourceData);
                break;
            case RegularizationType::Isolated:
                regGrad = calcIsolatedGradient(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
        for (size_t i = 0; i < gradient.size() && i < regGrad.size(); ++i) {
            gradient[i] += regGrad[i];
        }
    }

    // NILS ペナルティの勾配を追加
    if (m_options.weightNilsPenalty > 0.0) {
        auto nilsGrad = calcNilsGradientTotal(sourceData, evpData, processConfig, sliceLevel);
        for (size_t i = 0; i < gradient.size() && i < nilsGrad.size(); ++i) {
            gradient[i] += m_options.weightNilsPenalty * nilsGrad[i];
        }
    }

    return gradient;
}

double GradientCalculator::calculateCostEpe(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower,
    double* outEpeCost,
    double* outSourceFillCost,
    double* outNilsCost) const {

    if (!m_mapping || !m_sourceContributions) {
        if (outEpeCost) *outEpeCost = 0.0;
        if (outSourceFillCost) *outSourceFillCost = 0.0;
        if (outNilsCost) *outNilsCost = 0.0;
        return 0.0;
    }

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    double totalWeightedEpePow = 0.0;
    double totalWeight = 0.0;

    // タスク毎の結果を格納（決定的な加算順序を保証）
    std::vector<double> taskEpePow(tasks.size(), 0.0);
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;

        for (const auto* ep : clip.evalPoints) {
            // Newton で EPE を取得。収束の可否に関わらず result.epe を採用する
            //（QEPE へのフォールバックは行わない）。
            EpeCalcResult r = findContourPositionFull(
                contribSet, sourceData,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose);
            double epe = r.epe;

            double w = ep->weight * pwc.weight;
            // tolerance デッドバンド: |EPE|<=tolerance は無罰
            double epe_eff = std::max(0.0, std::abs(epe) - ep->tolerance);
            taskEpePow[taskIdx] += std::pow(epe_eff, epePower) * w;
            taskWeights[taskIdx] += w;
        }
    }

    // タスク結果をクリップ単位に集約（MPI決定的集約用）
    size_t numClips = clips.size();
    std::vector<double> clipCosts(numClips, 0.0);
    std::vector<double> clipWeights(numClips, 0.0);
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        clipCosts[tasks[taskIdx].clipIdx] += taskEpePow[taskIdx];
        clipWeights[tasks[taskIdx].clipIdx] += taskWeights[taskIdx];
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalClipCosts(numClips, 0.0);
        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipCosts.data(), globalClipCosts.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipCosts = std::move(globalClipCosts);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    for (size_t c = 0; c < numClips; ++c) {
        totalWeightedEpePow += clipCosts[c];
        totalWeight += clipWeights[c];
    }

    // べき乗に応じた正規化: 1 / EPE_REF^n
    // EPE_REF = 0.001μm (1nm) を基準に、EPE=1nmでcost≈1となるようにスケーリング
    double epeScaleForPower = 1.0 / std::pow(EPE_REF, epePower);
    double epeCost = (totalWeight > 0.0) ? totalWeightedEpePow * epeScaleForPower / totalWeight : 0.0;
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double sourceFillCost = calcSourceFillCost(sourceFillRatio);

    // 正則化コストを追加
    double regularizationCost = 0.0;
    if (m_options.regularizationWeight > 0.0) {
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regularizationCost = calcLaplacianCost(sourceData);
                break;
            case RegularizationType::L2:
                regularizationCost = calcL2Cost(sourceData);
                break;
            case RegularizationType::TV:
                regularizationCost = calcTVCost(sourceData);
                break;
            case RegularizationType::Isolated:
                regularizationCost = calcIsolatedCost(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
    }

    // NILS ペナルティ
    // 最適化ループでは outNilsCost=nullptr かつ weight=0 の場合はスキップしてFFT合成コストを節約。
    // ログ/cost.csv 出力で outNilsCost が要求された場合は weight=0 でも値を返す。
    bool needNils = (outNilsCost != nullptr) || (m_options.weightNilsPenalty > 0.0);
    double nilsCost = needNils
        ? calcNilsCostTotal(sourceData, evpData, processConfig, sliceLevel)
        : 0.0;

    if (outEpeCost) *outEpeCost = epeCost;
    if (outSourceFillCost) *outSourceFillCost = sourceFillCost;
    if (outNilsCost) *outNilsCost = nilsCost;

    return epeCost + m_options.weightFillPenalty * sourceFillCost + regularizationCost
         + m_options.weightNilsPenalty * nilsCost;
}

// ============================================================================
// 統一勾配計算インターフェース
// ============================================================================

std::vector<double> GradientCalculator::calculateGradient(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    if (m_options.verbose) {
        std::cerr << "  [calculateGradient] Dispatching to method: "
                  << static_cast<int>(m_options.gradientMethod) << std::endl;
    }

    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
            // 選択肢1: QEPE + 解析勾配
            return calculate(sourceData, evpData, processConfig, sliceLevel);

        case GradientMethod::EPE_Analytical:
            // 選択肢2: EPE + 解析勾配
            return calculateEpeAnalytical(sourceData, evpData, processConfig, sliceLevel, epePower);

        case GradientMethod::QEPE_Numerical:
            // 選択肢3: QEPE + 数値差分
            return calculateQepeNumerical(sourceData, evpData, processConfig, sliceLevel);

        case GradientMethod::EPE_Numerical:
            // 選択肢4: EPE + 数値差分
            return calculateEpeNumerical(sourceData, evpData, processConfig, sliceLevel, epePower);

        default:
            // デフォルトは選択肢2
            return calculateEpeAnalytical(sourceData, evpData, processConfig, sliceLevel, epePower);
    }
}

double GradientCalculator::calculateCostByMethod(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower,
    double* outEpeCost,
    double* outSourceFillCost,
    double* outNilsCost) const {

    // QEPE系（選択肢1,3）はQEPEコスト、EPE系（選択肢2,4）はEPEコストを使用
    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
        case GradientMethod::QEPE_Numerical:
            return calculateCost(sourceData, evpData, processConfig, sliceLevel,
                               outEpeCost, outSourceFillCost, outNilsCost);

        case GradientMethod::EPE_Analytical:
        case GradientMethod::EPE_Numerical:
            return calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower,
                                      outEpeCost, outSourceFillCost, outNilsCost);

        default:
            return calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower,
                                      outEpeCost, outSourceFillCost, outNilsCost);
    }
}

std::vector<double> GradientCalculator::calculateQepeNumerical(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    // 選択肢3: QEPE + 数値差分（効率版を使用）
    return calculateQepeNumericalEfficient(sourceData, evpData, processConfig, sliceLevel);
}

std::vector<double> GradientCalculator::calculateEpeNumerical(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    // 選択肢4: EPE + 数値差分
    if (!m_mapping) {
        return {};
    }

    std::vector<double> gradient(m_mapping->numVariables());
    std::vector<double> variables = m_mapping->sourceToVariables(sourceData);
    double epsilon = m_options.numericalEpsilon;

    for (size_t i = 0; i < variables.size(); ++i) {
        double originalValue = variables[i];

        // +epsilon
        variables[i] = originalValue + epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costPlus = calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower);

        // -epsilon
        variables[i] = originalValue - epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costMinus = calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower);

        gradient[i] = (costPlus - costMinus) / (2.0 * epsilon);

        // 元に戻す
        variables[i] = originalValue;
    }

    // 光源データを元に戻す
    m_mapping->variablesToSource(variables, sourceData);

    return gradient;
}

// ============================================================================
// 効率的な数値差分（評価点×光源点キャッシュ + 並列化）
// ============================================================================

std::vector<double> GradientCalculator::calculateQepeNumericalEfficient(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();
    double epsilon = m_options.numericalEpsilon;

    std::vector<double> gradient(numVars, 0.0);

    // 評価点情報を収集
    struct EvalPointInfo {
        const EvalPoint* ep;
        double pwcWeight;
        double deltaDose;
        std::string filename;
        double nx, ny;  // 法線方向（事前計算）
    };
    std::vector<EvalPointInfo> evalPoints;

    // 注: 数値勾配では全クリップのコストの比率 A/B を計算するため、
    // クリップ分散は不適切（Σ d(A_i/B_i)/dx ≠ d(A_total/B_total)/dx）。
    // 各ランクが全クリップを処理し、独立に正確な勾配を計算する。
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        const auto& clip = clips[clipIdx];
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            for (const auto* ep : clip.evalPoints) {
                EvalPointInfo info;
                info.ep = ep;
                info.pwcWeight = pwc.weight;
                info.deltaDose = pwc.delta_dose;
                info.filename = filename;
                double rad = ep->degree * M_PI / 180.0;
                info.nx = std::cos(rad);
                info.ny = std::sin(rad);
                evalPoints.push_back(info);
            }
        }
    }

    const size_t numEvalPoints = evalPoints.size();

    // 光源点座標からインデックスへのマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        coordToVarIdx[makeCoordKey(varInfos[i].gx, varInfos[i].gy)] = i;
    }

    // 条件ごとのキャッシュ構造
    struct ConditionCache {
        double totalWeight = 0.0;
        std::vector<size_t> contribVarIndices;  // 各寄与の変数インデックス（-1なら非最適化変数）
        std::vector<double> contribNorms;       // 各寄与のnorm
        std::vector<size_t> evalPointIndices;   // この条件の評価点インデックス
    };
    std::map<std::string, ConditionCache> conditionCacheMap;

    // 条件キャッシュを構築
    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            if (conditionCacheMap.find(filename) != conditionCacheMap.end()) continue;

            auto it = m_sourceContributions->find(filename);
            if (it == m_sourceContributions->end()) continue;

            const auto& contribSet = it->second;
            ConditionCache cache;

            for (const auto& contrib : contribSet.contributions()) {
                double intensity;
                if (gridConfig.isD2Symmetry()) {
                    intensity = sourceData.getIntensityFirstQuadrant(contrib.gx, contrib.gy);
                } else {
                    intensity = sourceData.getIntensity(contrib.gx, contrib.gy);
                }
                cache.totalWeight += contrib.norm * intensity;

                auto coordKey = makeCoordKey(contrib.gx, contrib.gy);
                auto varIt = coordToVarIdx.find(coordKey);
                if (varIt != coordToVarIdx.end()) {
                    cache.contribVarIndices.push_back(varIt->second);
                } else {
                    cache.contribVarIndices.push_back(SIZE_MAX);  // 非最適化変数
                }
                cache.contribNorms.push_back(contrib.norm);
            }

            conditionCacheMap[filename] = std::move(cache);
        }
    }

    // 各評価点の条件キャッシュインデックスを設定
    for (size_t epIdx = 0; epIdx < numEvalPoints; ++epIdx) {
        auto& condCache = conditionCacheMap[evalPoints[epIdx].filename];
        condCache.evalPointIndices.push_back(epIdx);
    }

    // ========== 評価点×光源点のキャッシュを事前計算 ==========
    // evalPointCache[epIdx] = {combinedPV, contribPVs[]}
    struct EvalPointCache {
        PointValue combinedPV;                      // 合成画像の強度・勾配
        std::vector<PointValue> contribPVs;         // 各光源点寄与の強度・勾配
        double W;                                   // 重み合計
        const ConditionCache* condCache;            // 条件キャッシュへのポインタ
    };
    std::vector<EvalPointCache> evalPointCache(numEvalPoints);

    // 各条件について評価点キャッシュを計算
    for (auto& [filename, condCache] : conditionCacheMap) {
        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) continue;

        const auto& contribSet = it->second;
        const auto& contribs = contribSet.contributions();

        // 合成画像を計算
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);

        // この条件の評価点について
        for (size_t epIdx : condCache.evalPointIndices) {
            const auto& epInfo = evalPoints[epIdx];
            auto& epCache = evalPointCache[epIdx];

            epCache.condCache = &condCache;
            epCache.W = condCache.totalWeight;

            // 合成画像のevalAt
            epCache.combinedPV = combinedImg.evalAt(epInfo.ep->px, epInfo.ep->py);

            // delta_dose補正
            if (std::abs(epInfo.deltaDose) > 1e-9) {
                double scale = 1.0 + epInfo.deltaDose / 100.0;
                epCache.combinedPV.intensity *= scale;
                epCache.combinedPV.gradX *= scale;
                epCache.combinedPV.gradY *= scale;
            }

            // 各光源点の寄与のevalAt
            epCache.contribPVs.resize(contribs.size());
            for (size_t cIdx = 0; cIdx < contribs.size(); ++cIdx) {
                epCache.contribPVs[cIdx] = contribs[cIdx].freqImage.evalAt(epInfo.ep->px, epInfo.ep->py);

                // delta_dose補正
                if (std::abs(epInfo.deltaDose) > 1e-9) {
                    double scale = 1.0 + epInfo.deltaDose / 100.0;
                    epCache.contribPVs[cIdx].intensity *= scale;
                    epCache.contribPVs[cIdx].gradX *= scale;
                    epCache.contribPVs[cIdx].gradY *= scale;
                }
            }
        }
    }

    // source_fill関連の事前計算
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double naFactor = (m_NA / 1.35) * (m_NA / 1.35);
    double maxIntensity = sourceData.showMaxIntensity();
    if (maxIntensity <= 0.0) maxIntensity = 1.0;
    size_t numPoints = sourceData.showPoints().size();

    // コスト計算関数（キャッシュを使用、変数インデックスと差分値を受け取る）
    auto calcCostWithDelta = [&](size_t varIdx, double delta) -> double {
        double totalWeightedQEPESq = 0.0;
        double totalWeight = 0.0;

        for (size_t epIdx = 0; epIdx < numEvalPoints; ++epIdx) {
            const auto& epCache = evalPointCache[epIdx];
            const auto& epInfo = evalPoints[epIdx];
            const auto* condCache = epCache.condCache;

            if (!condCache || epCache.W < MIN_GRADIENT) continue;

            double W = epCache.W;
            double deltaW = 0.0;
            double deltaI = 0.0;
            double deltaGx = 0.0;
            double deltaGy = 0.0;

            // この変数がこの条件に含まれているか確認し、差分を計算
            for (size_t cIdx = 0; cIdx < condCache->contribVarIndices.size(); ++cIdx) {
                if (condCache->contribVarIndices[cIdx] == varIdx) {
                    double norm = condCache->contribNorms[cIdx];
                    const auto& pv_j = epCache.contribPVs[cIdx];

                    deltaW += norm * delta;
                    deltaI += norm * delta * pv_j.intensity;
                    deltaGx += norm * delta * pv_j.gradX;
                    deltaGy += norm * delta * pv_j.gradY;
                    break;
                }
            }

            double W_new = W + deltaW;
            if (W_new < MIN_GRADIENT) continue;

            // 新しい強度と勾配
            double I_new = (W * epCache.combinedPV.intensity + deltaI) / W_new;
            double Gx_new = (W * epCache.combinedPV.gradX + deltaGx) / W_new;
            double Gy_new = (W * epCache.combinedPV.gradY + deltaGy) / W_new;
            double G_new = Gx_new * epInfo.nx + Gy_new * epInfo.ny;

            // QEPE計算
            double QEPE = 0.0;
            if (std::abs(G_new) > MIN_GRADIENT) {
                QEPE = -(I_new - sliceLevel) / G_new;
            }

            double w = epInfo.ep->weight * epInfo.pwcWeight;
            // tolerance デッドバンド
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - epInfo.ep->tolerance);
            totalWeightedQEPESq += QEPE_eff * QEPE_eff * w;
            totalWeight += w;
        }

        double epeCost = (totalWeight > 0.0) ? totalWeightedQEPESq * EPE_SCALE / totalWeight : 0.0;

        // source_fill_cost（差分補正）
        const auto& info = varInfos[varIdx];
        int multiplier = 1;
        if (gridConfig.isD2Symmetry()) {
            if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) multiplier = 4;
            else if (std::abs(info.gx) > 1e-6 || std::abs(info.gy) > 1e-6) multiplier = 2;
        }
        double deltaRatio = delta * multiplier * naFactor / (maxIntensity * numPoints);
        double newRatio = sourceFillRatio + deltaRatio;
        double sourceFillCost = calcSourceFillCost(newRatio);
        return epeCost + m_options.weightFillPenalty * sourceFillCost;
    };

    // ========== 並列化: 各変数について勾配を計算 ==========
#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t varIdx = 0; varIdx < numVars; ++varIdx) {
        double costPlus = calcCostWithDelta(varIdx, epsilon);
        double costMinus = calcCostWithDelta(varIdx, -epsilon);
        gradient[varIdx] = (costPlus - costMinus) / (2.0 * epsilon);
    }

    return gradient;
}

std::vector<double> GradientCalculator::calculateEpeNumericalEfficient(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();
    double epsilon = m_options.numericalEpsilon;

    std::vector<double> gradient(numVars, 0.0);

    // 評価点情報を収集
    struct EvalPointInfo {
        const EvalPoint* ep;
        double pwcWeight;
        double deltaDose;
        std::string filename;
        int clipID;
        int pwcIdx;
        double maskBias;
    };
    std::vector<EvalPointInfo> evalPoints;

    // 注: 数値勾配では全クリップのコストの比率 A/B を計算するため、
    // クリップ分散は不適切（Σ d(A_i/B_i)/dx ≠ d(A_total/B_total)/dx）。
    // 各ランクが全クリップを処理し、独立に正確な勾配を計算する。
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        const auto& clip = clips[clipIdx];
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            for (const auto* ep : clip.evalPoints) {
                EvalPointInfo info;
                info.ep = ep;
                info.pwcWeight = pwc.weight;
                info.deltaDose = pwc.delta_dose;
                info.filename = filename;
                info.clipID = clip.clipID;
                info.pwcIdx = static_cast<int>(pwcIdx);
                info.maskBias = pwc.mask_bias;
                evalPoints.push_back(info);
            }
        }
    }

    const size_t numEvalPoints = evalPoints.size();

    // 各条件のキャッシュ
    struct ConditionCache {
        const SourceContributionSet* contribSet = nullptr;
    };
    std::map<std::string, ConditionCache> conditionCache;

    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            if (conditionCache.find(filename) != conditionCache.end()) continue;

            auto it = m_sourceContributions->find(filename);
            if (it == m_sourceContributions->end()) continue;

            ConditionCache cache;
            cache.contribSet = &(it->second);
            conditionCache[filename] = cache;
        }
    }

    // source_fill関連の事前計算
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double naFactor = (m_NA / 1.35) * (m_NA / 1.35);
    double maxIntensity = sourceData.showMaxIntensity();
    if (maxIntensity <= 0.0) maxIntensity = 1.0;
    size_t numPoints = sourceData.showPoints().size();
    double epeScaleForPower = 1.0 / std::pow(EPE_REF, epePower);

    // EPEコスト計算関数（変数インデックスと差分値を受け取る）
    // スレッドセーフ: sourceData をコピーして使用
    auto calcEpeCostWithDelta = [&](size_t varIdx, double delta) -> double {
        const auto& info = varInfos[varIdx];

        // 一時的なSourceDataを作成（差分を適用）
        SourceData tempSourceData = sourceData;
        double currentIntensity;
        if (gridConfig.isD2Symmetry()) {
            currentIntensity = tempSourceData.getIntensityFirstQuadrant(info.gx, info.gy);
        } else {
            currentIntensity = tempSourceData.getIntensity(info.gx, info.gy);
        }
        double newIntensity = std::max(0.0, currentIntensity + delta);

        if (gridConfig.isD2Symmetry()) {
            tempSourceData.setIntensity(info.gx, info.gy, newIntensity);
            if (std::abs(info.gx) > 1e-6) {
                tempSourceData.setIntensity(-info.gx, info.gy, newIntensity);
            }
            if (std::abs(info.gy) > 1e-6) {
                tempSourceData.setIntensity(info.gx, -info.gy, newIntensity);
            }
            if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) {
                tempSourceData.setIntensity(-info.gx, -info.gy, newIntensity);
            }
        } else {
            tempSourceData.setIntensity(info.gx, info.gy, newIntensity);
        }

        double totalWeightedEpePow = 0.0;
        double totalWeight = 0.0;

        for (size_t epIdx = 0; epIdx < numEvalPoints; ++epIdx) {
            const auto& epInfo = evalPoints[epIdx];

            auto cacheIt = conditionCache.find(epInfo.filename);
            if (cacheIt == conditionCache.end()) continue;
            const auto* contribSet = cacheIt->second.contribSet;
            if (!contribSet) continue;

            // EPEを計算（delta_dose適用）
            bool converged = false;
            double epe = findContourPosition(
                *contribSet, tempSourceData,
                epInfo.ep->px, epInfo.ep->py, epInfo.ep->degree, sliceLevel, epInfo.deltaDose, &converged,
                epInfo.clipID, epInfo.pwcIdx, epInfo.maskBias);

            double w = epInfo.ep->weight * epInfo.pwcWeight;
            // tolerance デッドバンド
            double epe_eff = std::max(0.0, std::abs(epe) - epInfo.ep->tolerance);
            totalWeightedEpePow += std::pow(epe_eff, epePower) * w;
            totalWeight += w;
        }

        double epeCost = (totalWeight > 0.0) ? totalWeightedEpePow * epeScaleForPower / totalWeight : 0.0;

        // source_fill_cost（差分補正）
        int multiplier = 1;
        if (gridConfig.isD2Symmetry()) {
            if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) multiplier = 4;
            else if (std::abs(info.gx) > 1e-6 || std::abs(info.gy) > 1e-6) multiplier = 2;
        }
        double deltaRatio = delta * multiplier * naFactor / (maxIntensity * numPoints);
        double newRatio = sourceFillRatio + deltaRatio;
        double sourceFillCost = calcSourceFillCost(newRatio);
        return epeCost + m_options.weightFillPenalty * sourceFillCost;
    };

    // ========== 並列化: 各変数について勾配を計算 ==========
#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t varIdx = 0; varIdx < numVars; ++varIdx) {
        double costPlus = calcEpeCostWithDelta(varIdx, epsilon);
        double costMinus = calcEpeCostWithDelta(varIdx, -epsilon);
        gradient[varIdx] = (costPlus - costMinus) / (2.0 * epsilon);
    }

    return gradient;
}

// ============================================================================
// ラプラシアン正則化
// ============================================================================

std::vector<std::pair<double, double>> GradientCalculator::getNeighbors(
    double gx, double gy) const {

    std::vector<std::pair<double, double>> neighbors;
    const auto& gridConfig = m_mapping->gridConfig();

    // グリッド間隔を計算
    // 座標範囲は -1.0 から 1.0、グリッド数は grid
    double delta = 2.0 / (gridConfig.grid > 1 ? (gridConfig.grid - 1) : 1);

    // 4近傍（上下左右）
    const double offsets[4][2] = {
        {delta, 0.0},   // 右
        {-delta, 0.0},  // 左
        {0.0, delta},   // 上
        {0.0, -delta}   // 下
    };

    for (const auto& offset : offsets) {
        double nx = gx + offset[0];
        double ny = gy + offset[1];

        // グリッド範囲内かチェック（-1.0 ~ 1.0）
        if (nx < -1.0 - 1e-6 || nx > 1.0 + 1e-6 ||
            ny < -1.0 - 1e-6 || ny > 1.0 + 1e-6) {
            continue;
        }

        // sigma範囲内かチェック
        double r = std::sqrt(nx * nx + ny * ny);
        if (r < gridConfig.sigma_min - 1e-6 || r > gridConfig.sigma_max + 1e-6) {
            continue;
        }

        neighbors.push_back({nx, ny});
    }

    return neighbors;
}

double GradientCalculator::calcLaplacianCost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization == RegularizationType::None) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    double totalCost = 0.0;

    // 各最適化変数（第1象限の点）についてラプラシアンコストを計算
    for (const auto& info : varInfos) {
        double gx = info.gx;
        double gy = info.gy;

        // この点の強度
        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(gx, gy);
        } else {
            s_i = sourceData.getIntensity(gx, gy);
        }

        // 隣接点を取得
        auto neighbors = getNeighbors(gx, gy);
        if (neighbors.empty()) {
            continue;
        }

        // 隣接点の強度の平均を計算
        double sumNeighborIntensity = 0.0;
        for (const auto& [nx, ny] : neighbors) {
            if (gridConfig.isD2Symmetry()) {
                sumNeighborIntensity += sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                sumNeighborIntensity += sourceData.getIntensity(nx, ny);
            }
        }
        double avgNeighborIntensity = sumNeighborIntensity / neighbors.size();

        // (s_i - avg(N_i))²
        double diff = s_i - avgNeighborIntensity;
        totalCost += diff * diff * info.multiplier;  // D2対称のmultiplierを考慮
    }

    return lambda * totalCost;
}

std::vector<double> GradientCalculator::calcLaplacianGradient(
    const SourceData& sourceData) const {

    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization == RegularizationType::None) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    std::vector<double> gradient(numVars, 0.0);

    // 変数のインデックスを座標から引けるようにマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        auto key = makeCoordKey(varInfos[i].gx, varInfos[i].gy);
        coordToVarIdx[key] = i;
    }

    // 各変数についてラプラシアン勾配を計算
    // ∂R_Lap/∂s_k = 2λ × [(s_k - avg(N_k)) - Σ_{i: k∈N_i} (s_i - avg(N_i)) / |N_i|]
    for (size_t k = 0; k < numVars; ++k) {
        const auto& infoK = varInfos[k];
        double gx_k = infoK.gx;
        double gy_k = infoK.gy;

        // s_kの強度
        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(gx_k, gy_k);
        } else {
            s_k = sourceData.getIntensity(gx_k, gy_k);
        }

        // 第1項: s_k - avg(N_k)
        auto neighbors_k = getNeighbors(gx_k, gy_k);
        double term1 = 0.0;
        if (!neighbors_k.empty()) {
            double sumNeighborK = 0.0;
            for (const auto& [nx, ny] : neighbors_k) {
                if (gridConfig.isD2Symmetry()) {
                    sumNeighborK += sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    sumNeighborK += sourceData.getIntensity(nx, ny);
                }
            }
            double avgNeighborK = sumNeighborK / neighbors_k.size();
            term1 = s_k - avgNeighborK;
        }

        // 第2項: Σ_{i: k∈N_i} (s_i - avg(N_i)) / |N_i|
        // kがiの隣接点である場合の寄与を集める
        double term2 = 0.0;

        for (size_t i = 0; i < numVars; ++i) {
            const auto& infoI = varInfos[i];
            double gx_i = infoI.gx;
            double gy_i = infoI.gy;

            // iの隣接点を取得
            auto neighbors_i = getNeighbors(gx_i, gy_i);
            if (neighbors_i.empty()) {
                continue;
            }

            // kがiの隣接点かチェック
            bool k_is_neighbor_of_i = false;
            for (const auto& [nx, ny] : neighbors_i) {
                // D2対称の場合、第1象限に折りたたんで比較
                double check_x = nx;
                double check_y = ny;
                if (gridConfig.isD2Symmetry()) {
                    check_x = std::abs(nx);
                    check_y = std::abs(ny);
                }
                if (std::abs(check_x - gx_k) < 1e-6 && std::abs(check_y - gy_k) < 1e-6) {
                    k_is_neighbor_of_i = true;
                    break;
                }
            }

            if (!k_is_neighbor_of_i) {
                continue;
            }

            // s_iの強度
            double s_i;
            if (gridConfig.isD2Symmetry()) {
                s_i = sourceData.getIntensityFirstQuadrant(gx_i, gy_i);
            } else {
                s_i = sourceData.getIntensity(gx_i, gy_i);
            }

            // avg(N_i)を計算
            double sumNeighborI = 0.0;
            for (const auto& [nx, ny] : neighbors_i) {
                if (gridConfig.isD2Symmetry()) {
                    sumNeighborI += sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    sumNeighborI += sourceData.getIntensity(nx, ny);
                }
            }
            double avgNeighborI = sumNeighborI / neighbors_i.size();

            // (s_i - avg(N_i)) / |N_i| の寄与
            // kがN_iに含まれる回数をカウント（D2対称の場合、対称点も考慮）
            int countK = 0;
            for (const auto& [nx, ny] : neighbors_i) {
                double check_x = nx;
                double check_y = ny;
                if (gridConfig.isD2Symmetry()) {
                    check_x = std::abs(nx);
                    check_y = std::abs(ny);
                }
                if (std::abs(check_x - gx_k) < 1e-6 && std::abs(check_y - gy_k) < 1e-6) {
                    ++countK;
                }
            }

            // ∂avg(N_i)/∂s_k = countK / |N_i|
            // ∂(s_i - avg(N_i))²/∂s_k = 2(s_i - avg(N_i)) × (-countK / |N_i|)
            term2 += (s_i - avgNeighborI) * countK / neighbors_i.size() * infoI.multiplier;
        }

        // 勾配 = 2λ × (term1 × multiplier - term2)
        gradient[k] = 2.0 * lambda * (term1 * infoK.multiplier - term2);
    }

    return gradient;
}

// ============================================================================
// L2正則化
// ============================================================================

double GradientCalculator::calcL2Cost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::L2) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    double totalCost = 0.0;

    // L2正則化: 各最適化変数を均等に正則化
    // D2対称性のmultiplierは使用しない（軸上と軸外を同等に扱う）
    for (const auto& info : varInfos) {
        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(info.gx, info.gy);
        } else {
            s_i = sourceData.getIntensity(info.gx, info.gy);
        }

        // s_i²（multiplierなし：各変数を均等に正則化）
        totalCost += s_i * s_i;
    }

    return lambda * totalCost;
}

std::vector<double> GradientCalculator::calcL2Gradient(const SourceData& sourceData) const {
    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::L2) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    std::vector<double> gradient(numVars, 0.0);

    // L2正則化の勾配: 各最適化変数を均等に正則化
    // D2対称性のmultiplierは使用しない
    for (size_t k = 0; k < numVars; ++k) {
        const auto& info = varInfos[k];

        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(info.gx, info.gy);
        } else {
            s_k = sourceData.getIntensity(info.gx, info.gy);
        }

        // ∂(λ × s_k²)/∂s_k = 2λ × s_k（multiplierなし）
        gradient[k] = 2.0 * lambda * s_k;
    }

    return gradient;
}

// ============================================================================
// TV正則化（Total Variation）
// ============================================================================

double GradientCalculator::calcTVCost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::TV) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    // 微分可能な近似のためのε
    constexpr double TV_EPSILON = 1e-8;

    double totalCost = 0.0;

    for (const auto& info : varInfos) {
        double gx = info.gx;
        double gy = info.gy;

        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(gx, gy);
        } else {
            s_i = sourceData.getIntensity(gx, gy);
        }

        auto neighbors = getNeighbors(gx, gy);

        for (const auto& [nx, ny] : neighbors) {
            double s_j;
            if (gridConfig.isD2Symmetry()) {
                s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                s_j = sourceData.getIntensity(nx, ny);
            }

            // smooth approximation: sqrt((s_i - s_j)² + ε)
            double diff = s_i - s_j;
            totalCost += std::sqrt(diff * diff + TV_EPSILON) * info.multiplier;
        }
    }

    // 各エッジを2回カウントしているので2で割る
    return lambda * totalCost / 2.0;
}

std::vector<double> GradientCalculator::calcTVGradient(const SourceData& sourceData) const {
    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::TV) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    // 微分可能な近似のためのε
    constexpr double TV_EPSILON = 1e-8;

    std::vector<double> gradient(numVars, 0.0);

    // 変数のインデックスマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        auto key = makeCoordKey(varInfos[i].gx, varInfos[i].gy);
        coordToVarIdx[key] = i;
    }

    for (size_t k = 0; k < numVars; ++k) {
        const auto& infoK = varInfos[k];
        double gx_k = infoK.gx;
        double gy_k = infoK.gy;

        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(gx_k, gy_k);
        } else {
            s_k = sourceData.getIntensity(gx_k, gy_k);
        }

        auto neighbors_k = getNeighbors(gx_k, gy_k);

        // kの隣接点からの勾配寄与
        // ∂/∂s_k [ sqrt((s_k - s_j)² + ε) ] = (s_k - s_j) / sqrt((s_k - s_j)² + ε)
        for (const auto& [nx, ny] : neighbors_k) {
            double s_j;
            if (gridConfig.isD2Symmetry()) {
                s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                s_j = sourceData.getIntensity(nx, ny);
            }

            double diff = s_k - s_j;
            double denom = std::sqrt(diff * diff + TV_EPSILON);

            // 勾配に加算（各エッジを2回カウントするため/2は後で）
            gradient[k] += lambda * diff / denom * infoK.multiplier;
        }
    }

    return gradient;
}

// ============================================================================
// 孤立点ペナルティ正則化
// ============================================================================

double GradientCalculator::calcIsolatedCost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::Isolated) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    double totalCost = 0.0;

    // 孤立点ペナルティ: R_isolated = λ × Σ_i max(0, s_i - max(s_neighbors))²
    // ある点の強度がすべての隣接点より高い場合にペナルティを与える
    for (const auto& info : varInfos) {
        double gx = info.gx;
        double gy = info.gy;

        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(gx, gy);
        } else {
            s_i = sourceData.getIntensity(gx, gy);
        }

        // 隣接点を取得
        auto neighbors = getNeighbors(gx, gy);
        if (neighbors.empty()) {
            continue;
        }

        // 隣接点の最大強度を計算
        double maxNeighborIntensity = 0.0;
        for (const auto& [nx, ny] : neighbors) {
            double s_j;
            if (gridConfig.isD2Symmetry()) {
                s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                s_j = sourceData.getIntensity(nx, ny);
            }
            maxNeighborIntensity = std::max(maxNeighborIntensity, s_j);
        }

        // max(0, s_i - max(s_neighbors))²
        double excess = s_i - maxNeighborIntensity;
        if (excess > 0.0) {
            totalCost += excess * excess * info.multiplier;
        }
    }

    return lambda * totalCost;
}

std::vector<double> GradientCalculator::calcIsolatedGradient(
    const SourceData& sourceData) const {

    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::Isolated) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    std::vector<double> gradient(numVars, 0.0);

    // 変数のインデックスマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        auto key = makeCoordKey(varInfos[i].gx, varInfos[i].gy);
        coordToVarIdx[key] = i;
    }

    // 孤立点ペナルティの勾配
    // R_isolated = λ × Σ_i max(0, s_i - max(s_neighbors))²
    //
    // ∂R_isolated/∂s_k:
    // - もしkがある点iの場合: excess > 0 なら 2λ × excess
    // - もしkがある点iの最大隣接点の場合: excess > 0 なら -2λ × excess
    //
    // ただし、max(s_neighbors)に対する微分はsubgradientとして扱う
    // （最大値を取る隣接点のみに勾配が伝播）

    for (size_t k = 0; k < numVars; ++k) {
        const auto& infoK = varInfos[k];
        double gx_k = infoK.gx;
        double gy_k = infoK.gy;

        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(gx_k, gy_k);
        } else {
            s_k = sourceData.getIntensity(gx_k, gy_k);
        }

        // 第1項: k自身が孤立点である場合
        auto neighbors_k = getNeighbors(gx_k, gy_k);
        if (!neighbors_k.empty()) {
            // 隣接点の最大強度を計算
            double maxNeighborIntensity = 0.0;
            for (const auto& [nx, ny] : neighbors_k) {
                double s_j;
                if (gridConfig.isD2Symmetry()) {
                    s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    s_j = sourceData.getIntensity(nx, ny);
                }
                maxNeighborIntensity = std::max(maxNeighborIntensity, s_j);
            }

            double excess = s_k - maxNeighborIntensity;
            if (excess > 0.0) {
                // ∂(excess²)/∂s_k = 2 × excess
                gradient[k] += 2.0 * lambda * excess * infoK.multiplier;
            }
        }

        // 第2項: kが他の点iの最大隣接点である場合
        // iの各隣接点をチェックし、kが最大の隣接点ならiからの勾配寄与を受ける
        for (size_t i = 0; i < numVars; ++i) {
            if (i == k) continue;

            const auto& infoI = varInfos[i];
            double gx_i = infoI.gx;
            double gy_i = infoI.gy;

            double s_i;
            if (gridConfig.isD2Symmetry()) {
                s_i = sourceData.getIntensityFirstQuadrant(gx_i, gy_i);
            } else {
                s_i = sourceData.getIntensity(gx_i, gy_i);
            }

            auto neighbors_i = getNeighbors(gx_i, gy_i);
            if (neighbors_i.empty()) continue;

            // kがiの隣接点かチェックし、最大かどうかも確認
            bool k_is_neighbor = false;
            bool k_is_max_neighbor = false;
            double maxNeighborI = 0.0;

            for (const auto& [nx, ny] : neighbors_i) {
                double s_j;
                if (gridConfig.isD2Symmetry()) {
                    s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    s_j = sourceData.getIntensity(nx, ny);
                }
                maxNeighborI = std::max(maxNeighborI, s_j);

                // kがこの隣接点かチェック
                double check_x = nx;
                double check_y = ny;
                if (gridConfig.isD2Symmetry()) {
                    check_x = std::abs(nx);
                    check_y = std::abs(ny);
                }
                if (std::abs(check_x - gx_k) < 1e-6 && std::abs(check_y - gy_k) < 1e-6) {
                    k_is_neighbor = true;
                }
            }

            if (!k_is_neighbor) continue;

            // kがiの隣接点の中で最大かチェック
            if (std::abs(s_k - maxNeighborI) < 1e-9) {
                k_is_max_neighbor = true;
            }

            if (!k_is_max_neighbor) continue;

            // iが孤立点（excess > 0）の場合のみ勾配に寄与
            double excess_i = s_i - maxNeighborI;
            if (excess_i > 0.0) {
                // ∂(excess_i²)/∂s_k = 2 × excess_i × ∂excess_i/∂s_k
                //                   = 2 × excess_i × (-1)  (kが最大隣接点の場合)
                // ただし、同値の隣接点が複数ある場合は分割する必要がある
                // 簡易的に、最大値を取る隣接点にのみ勾配を伝播
                int numMaxNeighbors = 0;
                for (const auto& [nx, ny] : neighbors_i) {
                    double s_j;
                    if (gridConfig.isD2Symmetry()) {
                        s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
                    } else {
                        s_j = sourceData.getIntensity(nx, ny);
                    }
                    if (std::abs(s_j - maxNeighborI) < 1e-9) {
                        ++numMaxNeighbors;
                    }
                }

                // 勾配を最大隣接点の数で分割
                gradient[k] -= 2.0 * lambda * excess_i * infoI.multiplier / numMaxNeighbors;
            }
        }
    }

    return gradient;
}

} // namespace so
