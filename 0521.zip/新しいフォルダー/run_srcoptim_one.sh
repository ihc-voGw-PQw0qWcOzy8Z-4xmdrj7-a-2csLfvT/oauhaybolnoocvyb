#!/bin/bash
#
# run_srcoptim_one.sh - 単一 SOCS cache + 単一 layout に対して srcOptim を 1 回実行
#
# 使い方:
#   # ローカル実行 (テスト用)
#   ./run_srcoptim_one.sh -s <socs_dir> -l <layout> -f <input_source> -o <output_source>
#
#   # LSF (bsub) 経由で本番投入
#   ./run_srcoptim_one.sh --bsub -n 4 -q OPCALL \
#       -s ./socs_set -l Layout/foo.oas \
#       -f in/initial_source.illum -o ./optimized_source.illum
#
# 動作:
#   1. socs_dir/.ready の存在を確認 (無ければエラー)
#   2. srcOptim 起動用の wrapper script を生成
#      - LSF 内では LSB_DJOB_HOSTFILE から MPI np を自動算出
#      - LSF 外ではローカル実行 (MPI_NP=1 ならそのまま、>1 なら mpirun)
#   3. --bsub なら bsub 投入 → bjobs で完了待ち
#      そうでなければそのまま wrapper を起動
#   4. optimized_source.illum / cost.csv / log.csv を出力
#
# 注意:
#   - SMO ループ / NA 探索 / multi-start は含みません (単発実行)
#   - tar.xz や half 形式の SOCS を使う場合は事前に展開してください
#     (./socs_archive.sh prepare <archive_or_dir> <dest>)
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ===== Defaults =====
SRCOPTIM="$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim"
SOURCE_CONFIG="$SCRIPT_DIR/in/source_config.txt"
PWC_CONFIG="$SCRIPT_DIR/in/pwc_config.txt"
EVP="$SCRIPT_DIR/Layout/arrayPitch/ah_ax5000_ay5000_mx64_my64_rx64_ry64_cx150_crx75_cry150_ep.csv"
LAYER="1/1,60/0"

# LSF / MPI
USE_BSUB=0
MPI_NP=1
QUEUE="OPCALL"
JOB_NAME=""

# srcOptim 主要パラメータ (setup.sh §3 の既定値と一致)
OPTIMIZER="lbfgs"
GRADIENT_METHOD=2
MAX_ITER=200
OPENMP_NUM=16

EPE_POWER_SCHEDULE="2,4,6,8"
ADAPT_P_SCHEDULE="1.0,3.0,5.0,7.0"
ADAPT_FLOOR_SCHEDULE="0.5,0.1,0.01,0.001"

BH_AMPLITUDE_INIT=0.03
BH_COOLING=0.85
BH_MAX_ROUNDS=20
BH_ALL_STAGES=1
BH_SEED=1

SLICE_METHOD="minmax"
SLICE_OBJECTIVE="max_abs_epe"
SLICE_PWC_MODE="all"
SLICELEVEL_ROUNDS=30

ROUND_CONV_WINDOW=3
ROUND_CONV_TOL=1e-6
LBFGS_MEMORY=20
LBFGS_WINDOW=15
LBFGS_REL_TOL=1e-6
LBFGS_MIN_ITER=20
EARLY_STOP_PATIENCE=20
EARLY_STOP_TOL=1e-6
GRAD_TOL=1e-4

MIN_INTENSITY=0.0
MAX_INTENSITY=2.0
MIN_FILL_RATIO=0.07
WEIGHT_FILL=10
FILL_PENALTY_K=10

# 必須引数
SOCS_DIR=""
LAYOUT=""
INPUT_SOURCE=""
OUTPUT_SOURCE=""
COST_CSV=""
LOG_CSV=""

usage() {
    cat << EOF
Usage: $0 -s <socs_dir> -l <layout> -f <input_source> -o <output_source> [options]

Required:
  -s, --socs DIR              SOCS cache directory (must contain .ready)
  -l, --layout FILE           layout (.gds / .oas)
  -f, --input-source FILE     initial source .illum
  -o, --output-source FILE    output optimized source .illum

LSF (bsub) options:
      --bsub                  submit to LSF instead of running locally
  -n, --np N                  MPI ranks (= bsub -n) (default: $MPI_NP)
  -q, --queue NAME            LSF queue (default: $QUEUE)
      --job-name NAME         bsub -J name (default: srcoptim_one_<basename>)

Common options:
  -e, --evp FILE              evaluation points CSV
  -p, --pwc FILE              pwc config (default: in/pwc_config.txt)
  -g, --source-config FILE    source config (default: in/source_config.txt)
      --layer SPEC            srcOptim --layer (default: $LAYER)
      --cost-output FILE      cost.csv path (default: alongside output)
      --log-output FILE       log.csv path  (default: alongside output)

srcOptim tuning:
      --optimizer NAME        lbfgs | adam (default: $OPTIMIZER)
      --max-iter N            (default: $MAX_ITER)
  -j, --openmp N              OpenMP threads (default: $OPENMP_NUM)
      --epe-power-schedule CSV       (default: $EPE_POWER_SCHEDULE)
      --adapt-p-schedule CSV         (default: $ADAPT_P_SCHEDULE)
      --adapt-floor-schedule CSV     (default: $ADAPT_FLOOR_SCHEDULE)
      --bh-seed N             (default: $BH_SEED)
      --bh-max-rounds N       (default: $BH_MAX_ROUNDS)
      --slicelevel-rounds N   (default: $SLICELEVEL_ROUNDS)
      --srcoptim PATH         override srcOptim binary path
  -h, --help                  show this help
EOF
}

# ===== Parse args =====
while [ $# -gt 0 ]; do
    case "$1" in
        -s|--socs)            SOCS_DIR="$2"; shift 2;;
        -l|--layout)          LAYOUT="$2"; shift 2;;
        -f|--input-source)    INPUT_SOURCE="$2"; shift 2;;
        -o|--output-source)   OUTPUT_SOURCE="$2"; shift 2;;
        --bsub)               USE_BSUB=1; shift;;
        -n|--np)              MPI_NP="$2"; shift 2;;
        -q|--queue)           QUEUE="$2"; shift 2;;
        --job-name)           JOB_NAME="$2"; shift 2;;
        -e|--evp)             EVP="$2"; shift 2;;
        -p|--pwc)             PWC_CONFIG="$2"; shift 2;;
        -g|--source-config)   SOURCE_CONFIG="$2"; shift 2;;
        --layer)              LAYER="$2"; shift 2;;
        --cost-output)        COST_CSV="$2"; shift 2;;
        --log-output)         LOG_CSV="$2"; shift 2;;
        --optimizer)          OPTIMIZER="$2"; shift 2;;
        --max-iter)           MAX_ITER="$2"; shift 2;;
        -j|--openmp)          OPENMP_NUM="$2"; shift 2;;
        --epe-power-schedule)   EPE_POWER_SCHEDULE="$2"; shift 2;;
        --adapt-p-schedule)     ADAPT_P_SCHEDULE="$2"; shift 2;;
        --adapt-floor-schedule) ADAPT_FLOOR_SCHEDULE="$2"; shift 2;;
        --bh-seed)            BH_SEED="$2"; shift 2;;
        --bh-max-rounds)      BH_MAX_ROUNDS="$2"; shift 2;;
        --slicelevel-rounds)  SLICELEVEL_ROUNDS="$2"; shift 2;;
        --srcoptim)           SRCOPTIM="$2"; shift 2;;
        -h|--help)            usage; exit 0;;
        *) echo "ERROR: unknown option: $1" >&2; usage; exit 1;;
    esac
done

# ===== Validate =====
if [ -z "$SOCS_DIR" ] || [ -z "$LAYOUT" ] || [ -z "$INPUT_SOURCE" ] || [ -z "$OUTPUT_SOURCE" ]; then
    echo "ERROR: -s, -l, -f, -o are all required" >&2
    usage; exit 1
fi

if [ ! -f "$SOCS_DIR/.ready" ]; then
    echo "ERROR: SOCS not ready (missing $SOCS_DIR/.ready)" >&2
    echo "HINT : run ./make_socs_one.sh first, or check tar.xz extraction" >&2
    exit 1
fi

for f in "$LAYOUT" "$INPUT_SOURCE" "$SOURCE_CONFIG" "$PWC_CONFIG" "$EVP"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: required file not found: $f" >&2
        exit 1
    fi
done

if [ ! -x "$SRCOPTIM" ]; then
    echo "ERROR: srcOptim binary not found / not executable: $SRCOPTIM" >&2
    exit 1
fi

# ===== Resolve output paths =====
OUT_DIR=$(dirname "$OUTPUT_SOURCE")
mkdir -p "$OUT_DIR"
[ -z "$COST_CSV" ] && COST_CSV="$OUT_DIR/cost.csv"
[ -z "$LOG_CSV" ]  && LOG_CSV="$OUT_DIR/log.csv"
[ -z "$JOB_NAME" ] && JOB_NAME="srcoptim_one_$(basename "$OUTPUT_SOURCE" .illum)"

# ===== Generate wrapper script =====
# LSF 内なら LSB_DJOB_HOSTFILE から np を自動算出。ローカル実行時は MPI_NP に従う。
WRAPPER="$OUT_DIR/run_srcoptim_wrapper.sh"
BSUB_LOG="$OUT_DIR/srcoptim_bsub.log"

cat > "$WRAPPER" << SCRIPT_EOF
#!/bin/bash
set -e

if [ -n "\$LSB_DJOB_HOSTFILE" ]; then
    NP=\$(wc -l < "\$LSB_DJOB_HOSTFILE")
    RUNCMD="mpirun -bootstrap lsf -np \$NP $SRCOPTIM"
elif [ "$MPI_NP" -gt 1 ]; then
    RUNCMD="mpirun -np $MPI_NP $SRCOPTIM"
else
    RUNCMD="$SRCOPTIM"
fi

\$RUNCMD \\
    -l "$LAYOUT" \\
    -s "$SOCS_DIR" \\
    -g "$SOURCE_CONFIG" \\
    -f "$INPUT_SOURCE" \\
    -p "$PWC_CONFIG" \\
    -e "$EVP" \\
    -o "$OUTPUT_SOURCE" \\
    --brightfield \\
    --cost_output "$COST_CSV" \\
    --log_output "$LOG_CSV" \\
    --optimizer "$OPTIMIZER" \\
    --max_iter "$MAX_ITER" \\
    --gradient_method "$GRADIENT_METHOD" \\
    --layer "$LAYER" \\
    --epe_power_schedule "$EPE_POWER_SCHEDULE" \\
    --adaptive_weight_p_schedule "$ADAPT_P_SCHEDULE" \\
    --adaptive_weight_floor_schedule "$ADAPT_FLOOR_SCHEDULE" \\
    --bh_amplitude_init "$BH_AMPLITUDE_INIT" \\
    --bh_cooling "$BH_COOLING" \\
    --bh_max_rounds "$BH_MAX_ROUNDS" \\
    --bh_all_stages "$BH_ALL_STAGES" \\
    --bh_seed "$BH_SEED" \\
    --slice_method "$SLICE_METHOD" \\
    --slice_objective "$SLICE_OBJECTIVE" \\
    --slice_pwc_mode "$SLICE_PWC_MODE" \\
    --sliceLevelRounds "$SLICELEVEL_ROUNDS" \\
    --round_conv_window "$ROUND_CONV_WINDOW" \\
    --round_conv_tol "$ROUND_CONV_TOL" \\
    --lbfgs_memory "$LBFGS_MEMORY" \\
    --lbfgs_window "$LBFGS_WINDOW" \\
    --lbfgs_rel_tol "$LBFGS_REL_TOL" \\
    --lbfgs_min_iter "$LBFGS_MIN_ITER" \\
    --early_stop_patience "$EARLY_STOP_PATIENCE" \\
    --early_stop_tol "$EARLY_STOP_TOL" \\
    --grad_tol "$GRAD_TOL" \\
    --min_intensity "$MIN_INTENSITY" \\
    --max_intensity "$MAX_INTENSITY" \\
    --min_fill_ratio "$MIN_FILL_RATIO" \\
    --weight_fill "$WEIGHT_FILL" \\
    --exp_fill_penalty \\
    --fill_penalty_k "$FILL_PENALTY_K" \\
    -j "$OPENMP_NUM" \\
    --verbose
SCRIPT_EOF
chmod +x "$WRAPPER"

# ===== Log header =====
echo "[run_srcoptim_one] socs    = $SOCS_DIR"
echo "[run_srcoptim_one] layout  = $LAYOUT"
echo "[run_srcoptim_one] input   = $INPUT_SOURCE"
echo "[run_srcoptim_one] output  = $OUTPUT_SOURCE"
echo "[run_srcoptim_one] cost    = $COST_CSV"
echo "[run_srcoptim_one] log     = $LOG_CSV"
echo "[run_srcoptim_one] wrapper = $WRAPPER"

T0=$(date +%s)

if [ "$USE_BSUB" = "1" ]; then
    # ===== LSF (bsub) =====
    echo "[run_srcoptim_one] submitting to LSF: queue=$QUEUE, -n $MPI_NP, job=$JOB_NAME"
    OUT_MSG=$(bsub \
        -n "$MPI_NP" \
        -R "span[ptile=1]" \
        -q "$QUEUE" \
        -J "$JOB_NAME" \
        -o "$BSUB_LOG" \
        "$WRAPPER" 2>&1)
    JOBID=$(echo "$OUT_MSG" | sed -n 's/.*Job <\([0-9]*\)>.*/\1/p')
    if [ -z "$JOBID" ]; then
        echo "ERROR: bsub failed: $OUT_MSG" >&2
        exit 1
    fi
    echo "[run_srcoptim_one] submitted: JobID=$JOBID, log=$BSUB_LOG"

    # bjobs で完了待ち (smo_lib/srcoptim.sh と同じパターン: 投入直後の UNKNOWN は猶予)
    JOB_SEEN=false
    UNKNOWN_SINCE=0
    UNKNOWN_GRACE=60
    LAST_REPORT=0
    REPORT_INTERVAL=30
    while true; do
        STATUS=$(bjobs -noheader -o "stat" "$JOBID" 2>/dev/null || echo "UNKNOWN")
        case "$STATUS" in
            DONE)
                E=$(( $(date +%s) - T0 ))
                echo "[run_srcoptim_one] job DONE (elapsed $((E/60))m $((E%60))s)"
                break
                ;;
            EXIT)
                echo "ERROR: job EXIT (failed). JobID=$JOBID, log=$BSUB_LOG" >&2
                exit 1
                ;;
            UNKNOWN|"")
                if [ "$JOB_SEEN" = true ]; then
                    echo "[run_srcoptim_one] job status UNKNOWN after seen: assuming done"
                    break
                fi
                [ "$UNKNOWN_SINCE" -eq 0 ] && UNKNOWN_SINCE=$(date +%s)
                if [ $(( $(date +%s) - UNKNOWN_SINCE )) -ge "$UNKNOWN_GRACE" ]; then
                    echo "[run_srcoptim_one] job never seen by bjobs (assuming flushed-done)"
                    break
                fi
                ;;
            *)
                JOB_SEEN=true
                UNKNOWN_SINCE=0
                ;;
        esac

        E=$(( $(date +%s) - T0 ))
        if [ $((E - LAST_REPORT)) -ge "$REPORT_INTERVAL" ]; then
            echo "[run_srcoptim_one] ... $STATUS  (elapsed $((E/60))m $((E%60))s)"
            LAST_REPORT=$E
        fi
        sleep 10
    done

    # NFS sync: output ファイル出現を待つ
    for i in $(seq 1 30); do
        [ -f "$OUTPUT_SOURCE" ] && break
        ls -la "$OUT_DIR" >/dev/null 2>&1 || true
        sleep 2
    done
else
    # ===== ローカル実行 =====
    echo "[run_srcoptim_one] running locally (use --bsub to submit to LSF)..."
    "$WRAPPER"
fi

ELAPSED=$(( $(date +%s) - T0 ))

# ===== Final cost (best effort) =====
if [ ! -f "$OUTPUT_SOURCE" ]; then
    echo "ERROR: optimized source not produced: $OUTPUT_SOURCE" >&2
    [ "$USE_BSUB" = "1" ] && echo "       check bsub log: $BSUB_LOG" >&2
    exit 1
fi

FINAL=""
if [ -f "$COST_CSV" ]; then
    FINAL=$(grep "^total_cost," "$COST_CSV" | head -1 | cut -d',' -f2)
fi
echo "[run_srcoptim_one] DONE in ${ELAPSED}s"
[ -n "$FINAL" ] && echo "[run_srcoptim_one] total_cost = $FINAL"
echo "[run_srcoptim_one] output     = $OUTPUT_SOURCE"
