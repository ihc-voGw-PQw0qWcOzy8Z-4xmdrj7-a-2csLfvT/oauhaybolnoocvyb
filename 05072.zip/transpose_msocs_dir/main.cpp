// transpose_msocs_dir: y=x mirror an M3D SOCS directory
//
// An M3D SOCS is a directory containing:
//   - m3dinfo                   ← per-cgrp/polarization SOCS index
//   - cgrp                      ← cgrp coordinates (cx cy per line)
//   - illum                     ← original point source illumination
//   - ini                       (optional, copied as-is)
//   - mask_kikaku               (optional, copied as-is)
//   - tcc{idx}_{cx}_{cy}_{TETE|TMTM}.socs    (per-cgrp, per-polarization SOCS)
//
// y=x mirror transforms (sx,sy)+(cx,cy)+TMTM into (sy,sx)+(cy,cx)+TETE
// (and vice versa: TMTM<->TETE), preserving optical equivalence under
// y=x symmetric optics.
//
// This tool:
//   1. Reads m3dinfo and inverts each row (TMTM<->TETE, cgrp coords swap)
//   2. Writes a new m3dinfo with swapped entries
//   3. For each SOCS file, applies index1<->index2 swap and writes with the
//      new filename
//   4. Swaps coordinates in cgrp and illum files
//   5. Copies ini, mask_kikaku as-is
//
// Usage:
//   transpose_msocs_dir <input_dir> <output_dir>

#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "so/simple_socs_reader.h"
#include "so/simple_socs_writer.h"
#include "so/socs_transpose.h"

namespace fs = std::filesystem;

namespace {

struct M3DEntry {
    std::string m3doption;
    int cgrp_index;
    double sx;
    double sy;
    std::string socsfilename;
    std::string norm;  // 文字列として保持（精度欠落を避ける）
};

std::string formatCoord(double v) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6) << v;
    return oss.str();
}

std::string swapPolOption(const std::string& opt) {
    if (opt == "TMTM") return "TETE";
    if (opt == "TETE") return "TMTM";
    if (opt == "TMTE") return "TETM";
    if (opt == "TETM") return "TMTE";
    return opt;  // "2d" など
}

// "tcc{idx}_{cx}_{cy}_{POL}.socs" 形式のファイル名を生成
std::string makeSocsFilename(int idx, double cx, double cy, const std::string& pol) {
    std::ostringstream oss;
    oss << "tcc" << idx << "_" << formatCoord(cx) << "_" << formatCoord(cy)
        << "_" << pol << ".socs";
    return oss.str();
}

std::vector<M3DEntry> readM3DInfo(const fs::path& path) {
    std::vector<M3DEntry> entries;
    std::ifstream ifs(path);
    if (!ifs.is_open()) {
        throw std::runtime_error("cannot open m3dinfo: " + path.string());
    }
    std::string line;
    while (std::getline(ifs, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream iss(line);
        M3DEntry e;
        if (iss >> e.m3doption >> e.cgrp_index >> e.sx >> e.sy
                >> e.socsfilename >> e.norm) {
            entries.push_back(e);
        }
    }
    return entries;
}

void writeM3DInfo(const fs::path& path, const std::vector<M3DEntry>& entries,
                  bool socs_mode) {
    std::ofstream ofs(path);
    if (!ofs.is_open()) {
        throw std::runtime_error("cannot write m3dinfo: " + path.string());
    }
    if (socs_mode) {
        ofs << "#M3Doption\tcgrp_index\tsx\tsy\tsocsfilename\tnorm\n";
    } else {
        ofs << "#M3Doption\tcgrp_index\tsx\tsy\ttccfilename\tnorm\n";
    }
    for (const auto& e : entries) {
        ofs << e.m3doption << "\t" << e.cgrp_index << "\t"
            << formatCoord(e.sx) << "\t" << formatCoord(e.sy) << "\t"
            << e.socsfilename << "\t" << e.norm << "\n";
    }
}

// "0.1 0.05" 形式の各行について x と y を swap
void swapXYTextFile(const fs::path& src, const fs::path& dst) {
    std::ifstream ifs(src);
    if (!ifs.is_open()) {
        throw std::runtime_error("cannot open: " + src.string());
    }
    std::ofstream ofs(dst);
    if (!ofs.is_open()) {
        throw std::runtime_error("cannot write: " + dst.string());
    }
    std::string line;
    while (std::getline(ifs, line)) {
        std::istringstream iss(line);
        double x, y;
        std::string rest_str;
        if (!(iss >> x >> y)) {
            // 数値2つ取れない行はそのままコピー
            ofs << line << "\n";
            continue;
        }
        std::getline(iss, rest_str);  // 残りの部分（intensity 等）
        ofs << formatCoord(y) << " " << formatCoord(x) << rest_str << "\n";
    }
}

void copyFileIfExists(const fs::path& src, const fs::path& dst) {
    if (fs::exists(src)) {
        fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
    }
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 3) {
        std::fprintf(stderr,
                     "Usage: %s <input_dir> <output_dir>\n"
                     "  Apply y=x mirror to an M3D SOCS directory.\n",
                     argv[0]);
        return 2;
    }

    fs::path input_dir = argv[1];
    fs::path output_dir = argv[2];

    try {
        if (!fs::is_directory(input_dir)) {
            throw std::runtime_error("input is not a directory: " + input_dir.string());
        }
        fs::create_directories(output_dir);

        // 1. m3dinfo を読み込んで swap 規則で書き直し
        fs::path m3dinfo_path = input_dir / "m3dinfo";
        auto entries_in = readM3DInfo(m3dinfo_path);

        // socs_mode かどうかをファイル名拡張子で判定 (ヘッダ行に基づく)
        bool socs_mode = true;
        {
            std::ifstream ifs(m3dinfo_path);
            std::string first_line;
            std::getline(ifs, first_line);
            socs_mode = (first_line.find("socsfilename") != std::string::npos);
        }

        std::vector<M3DEntry> entries_out;
        for (const auto& e : entries_in) {
            M3DEntry o = e;
            o.m3doption = swapPolOption(e.m3doption);
            o.sx = e.sy;
            o.sy = e.sx;
            o.socsfilename = makeSocsFilename(o.cgrp_index, o.sx, o.sy, o.m3doption);
            // norm はそのまま
            entries_out.push_back(o);
        }
        writeM3DInfo(output_dir / "m3dinfo", entries_out, socs_mode);

        // 2. 各 SOCS ファイルを transpose して新ファイル名で書き出し
        for (size_t i = 0; i < entries_in.size(); ++i) {
            const auto& src_e = entries_in[i];
            const auto& dst_e = entries_out[i];
            fs::path src_socs = input_dir / src_e.socsfilename;
            fs::path dst_socs = output_dir / dst_e.socsfilename;

            solib::SocsFileHeader hdr;
            SocsStruct s = solib::readDecompositionSocs(src_socs.string(), &hdr);
            SocsStruct st = solib::transposeXY(s);
            solib::writeDecompositionSocs(dst_socs.string(), st,
                                          hdr.norm_re, hdr.norm_im, hdr.info);
        }

        // 3. cgrp ファイル: 各行 (cx, cy) を swap
        if (fs::exists(input_dir / "cgrp")) {
            swapXYTextFile(input_dir / "cgrp", output_dir / "cgrp");
        }

        // 4. illum: 各行 (sx, sy, intensity) の sx と sy を swap
        if (fs::exists(input_dir / "illum")) {
            swapXYTextFile(input_dir / "illum", output_dir / "illum");
        }

        // 5. ini, mask_kikaku, cgrp.suggested: そのままコピー
        copyFileIfExists(input_dir / "ini", output_dir / "ini");
        copyFileIfExists(input_dir / "mask_kikaku", output_dir / "mask_kikaku");
        copyFileIfExists(input_dir / "cgrp.suggested", output_dir / "cgrp.suggested");

        // illum0_* など (m3d_cgr が生成する追加 illum ファイル) は
        // 内部状態でしか参照されないので不要だが、念のためコピー
        for (const auto& entry : fs::directory_iterator(input_dir)) {
            std::string name = entry.path().filename().string();
            if (name.rfind("illum0_", 0) == 0) {
                fs::copy_file(entry.path(), output_dir / name,
                              fs::copy_options::overwrite_existing);
            }
        }

    } catch (const std::exception& e) {
        std::fprintf(stderr, "Error: %s\n", e.what());
        return 1;
    }

    return 0;
}
