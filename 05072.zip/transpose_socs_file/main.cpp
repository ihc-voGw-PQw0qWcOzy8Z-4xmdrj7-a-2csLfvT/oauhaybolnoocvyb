// transpose_socs_file: read a Decomposition SOCS file, swap (x,y) indices
// (y=x mirror), and write it back as a new SOCS file.
//
// Used by run_srcoptim.sh to reconstruct missing x<y SOCS files from their
// (y, x) counterparts in y=x symmetric optical systems.
//
// Usage:
//   transpose_socs_file <input.socs> <output.socs> [--norm <real>] [--norm_imag <imag>]
//
//   --norm <real>       Override norm value in the output header (default: copy from input)
//   --norm_imag <imag>  Override imaginary part of norm (default: copy from input)
//
// Without --norm, the input's norm is preserved as-is. This is correct under
// y=x optical symmetry (norm is invariant under x<->y swap).

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <string>

#include "so/simple_socs_reader.h"
#include "so/simple_socs_writer.h"
#include "so/socs_transpose.h"

int main(int argc, char** argv) {
    if (argc < 3) {
        std::fprintf(stderr,
                     "Usage: %s <input.socs> <output.socs> "
                     "[--norm <real>] [--norm_imag <imag>]\n"
                     "  Reads input, applies y=x mirror (transposeXY), writes output.\n",
                     argv[0]);
        return 2;
    }

    std::string inpath = argv[1];
    std::string outpath = argv[2];

    bool norm_re_overridden = false;
    bool norm_im_overridden = false;
    double norm_re_override = 0.0;
    double norm_im_override = 0.0;

    for (int i = 3; i < argc; ++i) {
        if (std::strcmp(argv[i], "--norm") == 0 && i + 1 < argc) {
            norm_re_override = std::atof(argv[++i]);
            norm_re_overridden = true;
        } else if (std::strcmp(argv[i], "--norm_imag") == 0 && i + 1 < argc) {
            norm_im_override = std::atof(argv[++i]);
            norm_im_overridden = true;
        } else {
            std::fprintf(stderr, "Unknown arg: %s\n", argv[i]);
            return 2;
        }
    }

    try {
        solib::SocsFileHeader hdr;
        SocsStruct s = solib::readDecompositionSocs(inpath, &hdr);
        SocsStruct st = solib::transposeXY(s);
        double nre = norm_re_overridden ? norm_re_override : hdr.norm_re;
        double nim = norm_im_overridden ? norm_im_override : hdr.norm_im;
        solib::writeDecompositionSocs(outpath, st, nre, nim, hdr.info);
    } catch (const std::exception& e) {
        std::fprintf(stderr, "Error: %s\n", e.what());
        return 1;
    }

    return 0;
}
