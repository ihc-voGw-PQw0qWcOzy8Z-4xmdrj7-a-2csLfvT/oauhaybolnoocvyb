#ifndef SO_SOCS_TRANSPOSE_H
#define SO_SOCS_TRANSPOSE_H

#include <tk/mtcc/mtcc_api.h>

namespace solib {

SocsStruct transposeXY(const SocsStruct& s);

}

#endif
