#include "simple_socs_reader.h"

#include <cstdio>
#include <cstring>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace solib {

SocsStruct readDecompositionSocs(const std::string& path, SocsFileHeader* hdr_out) {
    FILE* fp = std::fopen(path.c_str(), "rb");
    if (!fp) {
        throw std::runtime_error("cannot open SOCS file: " + path);
    }

    SocsFileHeader hdr;
    char line[1024];

    // Header section: read line by line until "DATA"
    while (std::fgets(line, sizeof(line), fp) != nullptr) {
        if (std::strcmp(line, "DATA\n") == 0) break;

        std::stringstream ss(line);
        std::string type;
        ss >> type;
        if (ss.fail()) continue;

        if (type == "index") {
            ss >> hdr.dim;
        } else if (type == "kernel") {
            ss >> hdr.kernel;
        } else if (type == "norm") {
            // norm (Re,Im)  -- format: "norm (1.234, 0.000)"
            std::string rest;
            std::getline(ss, rest);
            // strip parens and comma
            for (auto& c : rest) {
                if (c == '(' || c == ')' || c == ',') c = ' ';
            }
            std::stringstream ss2(rest);
            ss2 >> hdr.norm_re >> hdr.norm_im;
        } else if (type == "Decomposition" || type == "Version") {
            // skip top markers
        } else {
            // Everything else (NA, lambda, Lx, Ly, INFO block, etc.) is
            // appended verbatim so it can be round-tripped by the writer.
            hdr.info += line;
        }
    }

    if (hdr.dim <= 0 || hdr.kernel <= 0) {
        std::fclose(fp);
        throw std::runtime_error("invalid header: dim=" + std::to_string(hdr.dim) +
                                 " kernel=" + std::to_string(hdr.kernel));
    }

    int N = hdr.dim;
    int K = hdr.kernel;
    SocsStruct s(static_cast<size_t>(N), static_cast<size_t>(K));

    // Binary section
    std::vector<int> idx1(N), idx2(N);
    if (std::fread(idx1.data(), sizeof(int), N, fp) != static_cast<size_t>(N)) {
        std::fclose(fp);
        throw std::runtime_error("read error: index1");
    }
    if (std::fread(idx2.data(), sizeof(int), N, fp) != static_cast<size_t>(N)) {
        std::fclose(fp);
        throw std::runtime_error("read error: index2");
    }
    for (int i = 0; i < N; ++i) {
        s.x[i] = idx1[i];
        s.y[i] = idx2[i];
    }

    std::vector<double> ev(K);
    if (std::fread(ev.data(), sizeof(double), K, fp) != static_cast<size_t>(K)) {
        std::fclose(fp);
        throw std::runtime_error("read error: eigenvalue");
    }
    for (int k = 0; k < K; ++k) s.eigen[k] = ev[k];

    for (int k = 0; k < K; ++k) {
        std::vector<std::complex<double>> buf(N);
        if (std::fread(buf.data(), sizeof(std::complex<double>), N, fp) !=
            static_cast<size_t>(N)) {
            std::fclose(fp);
            throw std::runtime_error("read error: kernel " + std::to_string(k));
        }
        for (int i = 0; i < N; ++i) s.kernel[k][i] = buf[i];
    }

    std::fclose(fp);
    if (hdr_out) *hdr_out = hdr;
    return s;
}

}  // namespace solib
