#include "simple_socs_writer.h"

#include <cstdio>
#include <stdexcept>
#include <string>
#include <vector>

namespace solib {

void writeDecompositionSocs(const std::string& path,
                            const SocsStruct& s,
                            double norm_re,
                            double norm_im,
                            const std::string& info) {
    FILE* fp = std::fopen(path.c_str(), "wb");
    if (!fp) {
        throw std::runtime_error("cannot open SOCS file for writing: " + path);
    }

    int N = static_cast<int>(s.x.size());
    int K = static_cast<int>(s.eigen.size());

    // Header (same format as csocs::writeSOCS)
    std::fprintf(fp, "Decomposition SOCS\n");
    std::fprintf(fp, "Version 1\n");
    std::fprintf(fp, "index %d\n", N);
    std::fprintf(fp, "kernel %d\n", K);
    std::fprintf(fp, "norm (%15f,%15f)\n", norm_re, norm_im);
    std::fprintf(fp, "%s", info.c_str());
    std::fprintf(fp, "DATA\n");

    // Binary part
    std::vector<int> idx1(N), idx2(N);
    for (int i = 0; i < N; ++i) {
        idx1[i] = s.x[i];
        idx2[i] = s.y[i];
    }
    if (std::fwrite(idx1.data(), sizeof(int), N, fp) != static_cast<size_t>(N)) {
        std::fclose(fp);
        throw std::runtime_error("write error: index1");
    }
    if (std::fwrite(idx2.data(), sizeof(int), N, fp) != static_cast<size_t>(N)) {
        std::fclose(fp);
        throw std::runtime_error("write error: index2");
    }

    std::vector<double> ev(K);
    for (int k = 0; k < K; ++k) ev[k] = s.eigen[k];
    if (std::fwrite(ev.data(), sizeof(double), K, fp) != static_cast<size_t>(K)) {
        std::fclose(fp);
        throw std::runtime_error("write error: eigenvalue");
    }

    for (int k = 0; k < K; ++k) {
        std::vector<std::complex<double>> buf(N);
        for (int i = 0; i < N; ++i) buf[i] = s.kernel[k][i];
        if (std::fwrite(buf.data(), sizeof(std::complex<double>), N, fp) !=
            static_cast<size_t>(N)) {
            std::fclose(fp);
            throw std::runtime_error("write error: kernel " + std::to_string(k));
        }
    }

    std::fclose(fp);
}

}  // namespace solib
