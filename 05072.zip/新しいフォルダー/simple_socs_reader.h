// Minimal reader for "Decomposition SOCS" file format
// (output of maketcc_lsf3 / csocs::writeSOCS).
//
// Loads into a SocsStruct (defined in tk/mtcc/mtcc_api.h) so that
// solib::transposeXY() can be applied.

#ifndef SO_SIMPLE_SOCS_READER_H
#define SO_SIMPLE_SOCS_READER_H

#include <string>
#include <tk/mtcc/mtcc_api.h>

namespace solib {

struct SocsFileHeader {
    int dim = 0;
    int kernel = 0;
    double norm_re = 0.0;
    double norm_im = 0.0;
    std::string info;
};

/// Read "Decomposition SOCS" file and return SocsStruct.
/// Throws std::runtime_error on error.
SocsStruct readDecompositionSocs(const std::string& path,
                                 SocsFileHeader* hdr_out = nullptr);

}  // namespace solib

#endif
