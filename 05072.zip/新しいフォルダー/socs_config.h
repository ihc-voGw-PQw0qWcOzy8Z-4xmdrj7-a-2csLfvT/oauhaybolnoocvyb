/*!
 * @file socs_config.h
 * @brief socs_config.txt パーサー
 */

#ifndef SO_SOCS_CONFIG_H
#define SO_SOCS_CONFIG_H

#include <so/types.h>
#include <string>
#include <vector>
#include <map>
#include <utility>

namespace so {

/*!
 * @brief socs_config.txt 管理クラス
 * 
 * socs_set/socs_config.txt の読み込みを行う
 * 光学パラメータとnorm情報を保持する
 */
class SocsConfig {
private:
    OpticalParams m_opticalParams;
    std::vector<NormEntry> m_normEntries;
    
    /// (sourceID, defocus) -> norm_real のマップ
    std::map<std::pair<std::string, double>, double> m_normMap;
    
    /// defocusの丸め処理
    static double roundDefocus(double defocus);

public:
    SocsConfig();
    ~SocsConfig();

    /*!
     * @brief socs_config.txt を読み込む
     * @param filepath ファイルパス
     * @throw std::runtime_error ファイルが開けない、またはパースエラー
     */
    void load(const std::string& filepath);

    /// 光学パラメータを取得
    const OpticalParams& showOpticalParams() const;

    /// 全Norm情報を取得
    const std::vector<NormEntry>& showNormEntries() const;

    /*!
     * @brief sourceIDとdefocusからnorm実部を取得
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return norm実部
     * @throw std::runtime_error 見つからない場合
     */
    double getNorm(const std::string& sourceID, double defocus) const;

    /*!
     * @brief (sourceID, defocus)ペアが存在するか確認
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return 存在すればtrue
     */
    bool hasNorm(const std::string& sourceID, double defocus) const;

    /*!
     * @brief デフォルトのdim値を計算
     * @return dim = 4 * floor(L_max * 2 * NA / lambda) + 2
     */
    int calcDefaultDim() const;
};

/*!
 * @brief SOCSファイル操作ユーティリティ
 */
class SocsFile {
public:
    /*!
     * @brief SOCSファイルパスを生成 (.socs 固定、互換性のため残置)
     * @param socsSetDir socs_setディレクトリ
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return ファイルパス (例: "socs_set/x0.500000_y0.300000_d40.socs")
     */
    static std::string makePath(const std::string& socsSetDir,
                                 const std::string& sourceID,
                                 double defocus);

    /*!
     * @brief 実在する SOCS パスを返す ( .socs 優先、なければ .msocs )
     * @param socsSetDir socs_setディレクトリ
     * @param sourceID 光源ID
     * @param defocus デフォーカス値
     * @return 実在パス (両方とも無い場合は空文字列)
     *
     * M3D の場合は .socs/ ディレクトリ もしくは .msocs ファイルが存在する。
     * 拡張子の優先順位: .socs > .msocs。両方無ければ空文字列。
     */
    static std::string resolveExtension(const std::string& socsSetDir,
                                        const std::string& sourceID,
                                        double defocus);

    /*!
     * @brief SOCSファイルが存在するか確認 (.socs / .msocs どちらでも OK)
     */
    static bool exists(const std::string& socsSetDir,
                       const std::string& sourceID,
                       double defocus);

    /*!
     * @brief SOCSファイル/ディレクトリから光学パラメータを読み取る
     * @param socsPath SOCSファイルパス（M2D の .socs）またはディレクトリパス（M3D）
     * @return 光学パラメータ
     *
     * .msocs を直接渡すことはできない。.msocs を扱う場合は、呼び出し側で
     * lithoKernel::ccalcs_m3d::set_socs() 経由で展開させた後、
     * 展開先 ${msocsPath}.socs を本関数に渡すこと。
     */
    static OpticalParams readOpticalParams(const std::string& socsPath);

private:
    /// M2D: 単一SOCSファイル(.socs)からパラメータを読み取る
    static OpticalParams readOpticalParamsFromFile(const std::string& socsFilePath);

    /// M3D: SOCSディレクトリ（m3dinfo + 複数.socs）からパラメータを読み取る
    static OpticalParams readOpticalParamsFromDir(const std::string& socsDirPath);
};

} // namespace so

#endif // SO_SOCS_CONFIG_H
