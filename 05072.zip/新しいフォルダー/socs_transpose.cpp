#include "socs_transpose.h"

#include <utility>

namespace solib {

SocsStruct transposeXY(const SocsStruct& s) {
    SocsStruct t = s;
    std::swap(t.x, t.y);
    return t;
}

}
