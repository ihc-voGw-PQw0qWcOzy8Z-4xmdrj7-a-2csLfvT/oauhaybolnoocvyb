// Minimal writer for "Decomposition SOCS" file format
// (companion to simple_socs_reader).

#ifndef SO_SIMPLE_SOCS_WRITER_H
#define SO_SIMPLE_SOCS_WRITER_H

#include <string>
#include <tk/mtcc/mtcc_api.h>

namespace solib {

/// Write SocsStruct + header info as Decomposition SOCS format.
/// `info` is the verbatim text block (e.g. "NA 1.25\nlambda 0.193\n...") that
/// appears between the basic header and the "DATA" marker.
void writeDecompositionSocs(const std::string& path,
                            const SocsStruct& s,
                            double norm_re,
                            double norm_im,
                            const std::string& info);

}  // namespace solib

#endif
