/*!
 * @file cost_calculator.cpp
 * @brief コスト計算クラスの実装（周波数空間ベース）
 */

#include "cost_calculator.h"
#include "epe_newton.h"
#include <so/types.h>
#include <cmath>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <stdexcept>

namespace so {

CostCalculator::CostCalculator() {
    m_options.anchorClips.push_back(0);
}

CostCalculator::~CostCalculator() = default;

void CostCalculator::setOptions(const CostOptions& options) {
    m_options = options;
}

const CostOptions& CostCalculator::showOptions() const {
    return m_options;
}

EpeCalcResult CostCalculator::calcEPE(
    const FrequencyImage& freqImage,
    double px, double py,
    double degree,
    double sliceLevel,
    int maxIter,
    double tolerance) const {

    return calcEpeNewton(freqImage, px, py, degree, sliceLevel, maxIter, tolerance);
}

double CostCalculator::findOptimalSliceLevel(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.5;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    std::vector<FrequencyImage> anchorFreqImages;
    std::vector<const ClipInfo*> anchorClipInfos;
    
    for (int clipID : m_options.anchorClips) {
        std::string filename = makeImageFileName(clipID, nominalPwc.defocus,
                                                          nominalPwc.mask_bias, 0.0);
        auto it = sourceContributions.find(filename);
        if (it != sourceContributions.end()) {
            FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
            if (std::abs(nominalPwc.delta_dose) > 1e-9) {
                freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
            }
            anchorFreqImages.push_back(std::move(freqImg));
            auto clipInfo = evpData.getClip(clipID);
            if (clipInfo) {
                anchorClipInfos.push_back(clipInfo);
            }
        }
    }

    if (anchorFreqImages.empty()) {
        std::cerr << "Warning: Specified anchor clips not found, searching for available clips..." << std::endl;
        
        const auto& clips = evpData.showClips();
        for (const auto& clip : clips) {
            std::string filename = makeImageFileName(clip.clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, 0.0);
            auto it = sourceContributions.find(filename);
            if (it != sourceContributions.end()) {
                FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
                if (std::abs(nominalPwc.delta_dose) > 1e-9) {
                    freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
                }
                anchorFreqImages.push_back(std::move(freqImg));
                anchorClipInfos.push_back(&clip);
                std::cerr << "  Using clipID=" << clip.clipID << " as anchor" << std::endl;
                break;
            }
        }
    }

    if (anchorFreqImages.empty()) {
        return 0.5;
    }

    double sumIntensity = 0.0;
    int countPoints = 0;
    for (size_t i = 0; i < anchorFreqImages.size() && i < anchorClipInfos.size(); ++i) {
        const auto& freqImg = anchorFreqImages[i];
        const auto* clipInfo = anchorClipInfos[i];
        
        for (const auto* ep : clipInfo->evalPoints) {
            auto pv = freqImg.evalAt(ep->px, ep->py);
            sumIntensity += pv.intensity;
            countPoints++;
        }
    }
    
    double avgEdgeIntensity = (countPoints > 0) ? sumIntensity / countPoints : 0.5;

    std::cerr << "Average intensity at evaluation points: " << avgEdgeIntensity << std::endl;

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);
    
    if (b - a < avgEdgeIntensity * 0.2) {
        a = avgEdgeIntensity * 0.5;
        b = avgEdgeIntensity * 1.5;
    }

    std::cerr << "Slice level search: range=[" << a << ", " << b << "]" << std::endl;

    const double goldenRatio = (std::sqrt(5.0) - 1.0) / 2.0;
    double c = b - goldenRatio * (b - a);
    double d = a + goldenRatio * (b - a);

    auto evalFunc = [&](double sliceLevel) {
        double totalDeltaCDSq = 0.0;
        
        for (size_t i = 0; i < anchorFreqImages.size() && i < anchorClipInfos.size(); ++i) {
            const auto& freqImg = anchorFreqImages[i];
            const auto* clipInfo = anchorClipInfos[i];
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clipInfo->clipID) continue;
                
                auto epe1 = calcEPE(freqImg, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(freqImg, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                double delta_CD = epe1.epe + epe2.epe;
                totalDeltaCDSq += delta_CD * delta_CD;
            }
        }
        
        return totalDeltaCDSq;
    };

    double fc = evalFunc(c);
    double fd = evalFunc(d);

    for (int iter = 0; iter < 50; ++iter) {
        if (fc < fd) {
            b = d;
            d = c;
            fd = fc;
            c = b - goldenRatio * (b - a);
            fc = evalFunc(c);
        } else {
            a = c;
            c = d;
            fc = fd;
            d = a + goldenRatio * (b - a);
            fd = evalFunc(d);
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

double CostCalculator::calcAnchorDeltaCDSum(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.0;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    double totalDeltaCD = 0.0;
    bool foundAnyClip = false;

    for (int clipID : m_options.anchorClips) {
        std::string filename = makeImageFileName(clipID, nominalPwc.defocus,
                                                          nominalPwc.mask_bias, 0.0);
        auto it = sourceContributions.find(filename);
        if (it == sourceContributions.end()) continue;
        
        foundAnyClip = true;
        FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
        if (std::abs(nominalPwc.delta_dose) > 1e-9) {
            freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
        }

        for (const auto& pair : evpData.showCutlinePairs()) {
            if (pair.clipID != clipID) continue;
            
            auto epe1 = calcEPE(freqImg, pair.point1->px, pair.point1->py,
                                pair.point1->degree, sliceLevel);
            auto epe2 = calcEPE(freqImg, pair.point2->px, pair.point2->py,
                                pair.point2->degree, sliceLevel);
            totalDeltaCD += epe1.epe + epe2.epe;
        }
    }

    if (!foundAnyClip) {
        const auto& clips = evpData.showClips();
        for (const auto& clip : clips) {
            std::string filename = makeImageFileName(clip.clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, 0.0);
            auto it = sourceContributions.find(filename);
            if (it == sourceContributions.end()) continue;
            
            FrequencyImage freqImg = it->second.combine(sourceData, gridConfig);
            if (std::abs(nominalPwc.delta_dose) > 1e-9) {
                freqImg.scale(1.0 + nominalPwc.delta_dose / 100.0);
            }

            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clip.clipID) continue;
                
                auto epe1 = calcEPE(freqImg, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(freqImg, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                totalDeltaCD += epe1.epe + epe2.epe;
            }
            break;
        }
    }

    return totalDeltaCD;
}

double CostCalculator::findSliceLevelForTargetDeltaCD(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double targetDeltaCD) const {

    double avgEdgeIntensity = 0.5;
    
    for (const auto& [filename, contribSet] : sourceContributions) {
        if (contribSet.empty()) continue;
        
        FrequencyImage freqImg = contribSet.combine(sourceData, gridConfig);
        const auto& clips = evpData.showClips();
        
        if (!clips.empty() && !clips[0].evalPoints.empty()) {
            auto pv = freqImg.evalAt(clips[0].evalPoints[0]->px, clips[0].evalPoints[0]->py);
            avgEdgeIntensity = pv.intensity;
            break;
        }
    }

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);

    std::cerr << "Target delta_CD search: range=[" << a << ", " << b << "]"
              << ", target=" << targetDeltaCD << std::endl;

    auto evalFunc = [&](double sliceLevel) {
        double deltaCDSum = calcAnchorDeltaCDSum(sourceContributions, sourceData, gridConfig,
                                                 evpData, processConfig, sliceLevel);
        return std::abs(targetDeltaCD - deltaCDSum);
    };

    for (int iter = 0; iter < 50; ++iter) {
        double m1 = a + (b - a) / 3.0;
        double m2 = b - (b - a) / 3.0;
        
        if (evalFunc(m1) < evalFunc(m2)) {
            b = m2;
        } else {
            a = m1;
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

CostResult CostCalculator::calculate(
    const std::map<std::string, SourceContributionSet>& sourceContributions,
    const SourceData& sourceData,
    const SourceGridConfig& gridConfig,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sourceFillRatio) const {

    CostResult result;

    double sliceLevel = m_options.sliceLevel;
    if (sliceLevel < 0) {
        if (m_options.useTargetDeltaCD) {
            sliceLevel = findSliceLevelForTargetDeltaCD(
                sourceContributions, sourceData, gridConfig,
                evpData, processConfig, m_options.targetDeltaCD);
        } else {
            sliceLevel = findOptimalSliceLevel(
                sourceContributions, sourceData, gridConfig,
                evpData, processConfig);
        }
    }
    result.sliceLevel = sliceLevel;

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            
            std::string filename = makeImageFileName(clip.clipID, pwc.defocus,
                                                              pwc.mask_bias, 0.0);
            auto it = sourceContributions.find(filename);
            if (it == sourceContributions.end()) {
                std::cerr << "Warning: Image not found for " << filename << std::endl;
                continue;
            }
            
            FrequencyImage freqImage = it->second.combine(sourceData, gridConfig);

            if (std::abs(pwc.delta_dose) > 1e-9) {
                freqImage.scale(1.0 + pwc.delta_dose / 100.0);
            }

            for (size_t evpIdx = 0; evpIdx < clip.evalPoints.size(); ++evpIdx) {
                const auto* ep = clip.evalPoints[evpIdx];
                
                auto epeCalc = calcEPE(freqImage, ep->px, ep->py, ep->degree, sliceLevel);
                
                EpeResult epeResult;
                epeResult.clipID = clip.clipID;
                epeResult.pwcIndex = static_cast<int>(pwcIdx);
                epeResult.evpIndex = static_cast<int>(evpIdx);
                epeResult.defocus = pwc.defocus;
                epeResult.maskBias = pwc.mask_bias;
                epeResult.deltaDose = pwc.delta_dose;
                epeResult.px = ep->px;
                epeResult.py = ep->py;
                epeResult.degree = ep->degree;
                epeResult.EPE = epeCalc.epe;
                epeResult.QEPE = epeCalc.qepe;
                epeResult.intensity = epeCalc.intensity;
                epeResult.gradient = epeCalc.gradient;
                epeResult.weight_p = ep->weight;
                epeResult.weight_pwc = pwc.weight;
                epeResult.converged = epeCalc.converged;
                epeResult.iterations = epeCalc.iterations;
                
                result.epeResults.push_back(epeResult);
            }
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clip.clipID) continue;
                
                auto epe1 = calcEPE(freqImage, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(freqImage, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                
                CutlineResult cutlineResult;
                cutlineResult.clipID = clip.clipID;
                cutlineResult.pwcIndex = static_cast<int>(pwcIdx);
                cutlineResult.defocus = pwc.defocus;
                cutlineResult.maskBias = pwc.mask_bias;
                cutlineResult.deltaDose = pwc.delta_dose;
                cutlineResult.direction = pair.direction;
                cutlineResult.CD = pair.CD;
                cutlineResult.delta_CD = epe1.epe + epe2.epe;
                cutlineResult.delta_CD_QEPE = epe1.qepe + epe2.qepe;
                cutlineResult.EPE1 = epe1.epe;
                cutlineResult.EPE2 = epe2.epe;
                cutlineResult.QEPE1 = epe1.qepe;
                cutlineResult.QEPE2 = epe2.qepe;
                
                result.cutlineResults.push_back(cutlineResult);
            }
        }
    }

    result.EPE_cost = calcEPECost(result.epeResults);
    result.QEPE_cost = calcQEPECost(result.epeResults);
    result.source_fill_cost = calcSourceFillCost(sourceFillRatio);
    result.total_cost = result.EPE_cost + m_options.weightFill * result.source_fill_cost;
    result.total_cost_QEPE = result.QEPE_cost + m_options.weightFill * result.source_fill_cost;

    // |EPE|, |QEPE| の最大値とそのインデックスを走査
    for (size_t i = 0; i < result.epeResults.size(); ++i) {
        const auto& er = result.epeResults[i];
        double aE = std::abs(er.EPE);
        double aQ = std::abs(er.QEPE);
        if (aE > result.maxAbsEPE) {
            result.maxAbsEPE = aE;
            result.maxAbsEPE_index = static_cast<int>(i);
        }
        if (aQ > result.maxAbsQEPE) {
            result.maxAbsQEPE = aQ;
            result.maxAbsQEPE_index = static_cast<int>(i);
        }
    }

    return result;
}

double CostCalculator::calcSourceFillCost(double sourceFillRatio) const {
    if (sourceFillRatio >= m_options.minSourceFillRatio) {
        return 0.0;
    }

    double diff = m_options.minSourceFillRatio - sourceFillRatio;

    if (m_options.useExponentialFillPenalty) {
        // 指数ペナルティ: exp(k * diff) - 1
        double k = m_options.fillPenaltyExponent;
        return std::exp(k * diff) - 1.0;
    } else {
        // 従来の二乗ペナルティ
        return diff * diff;
    }
}

double CostCalculator::calcEPECost(const std::vector<EpeResult>& epeResults) const {
    double totalCost = 0.0;
    double totalWeight = 0.0;

    for (const auto& result : epeResults) {
        totalCost += result.EPE * result.EPE * result.weight_p * result.weight_pwc;
        totalWeight += result.weight_p * result.weight_pwc;
    }

    if (totalWeight > 0) {
        return totalCost * EPE_SCALE / totalWeight;
    }
    return 0.0;
}

double CostCalculator::calcQEPECost(const std::vector<EpeResult>& epeResults) const {
    double totalCost = 0.0;
    double totalWeight = 0.0;

    for (const auto& result : epeResults) {
        totalCost += result.QEPE * result.QEPE * result.weight_p * result.weight_pwc;
        totalWeight += result.weight_p * result.weight_pwc;
    }

    if (totalWeight > 0) {
        return totalCost * EPE_SCALE / totalWeight;
    }
    return 0.0;
}

// =============================================================================
// FrequencyImage版（実空間ファイル読み込み用）
// =============================================================================

double CostCalculator::findOptimalSliceLevel(
    const std::map<std::string, FrequencyImage>& freqImages,
    const EvpData& evpData,
    const ProcessConfig& processConfig) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.5;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    std::vector<const FrequencyImage*> anchorFreqImages;
    std::vector<const ClipInfo*> anchorClipInfos;
    
    for (int clipID : m_options.anchorClips) {
        std::string filename = makeImageFileName(clipID, nominalPwc.defocus,
                                                          nominalPwc.mask_bias, nominalPwc.delta_dose);
        auto it = freqImages.find(filename);
        if (it != freqImages.end()) {
            anchorFreqImages.push_back(&it->second);
            auto clipInfo = evpData.getClip(clipID);
            if (clipInfo) {
                anchorClipInfos.push_back(clipInfo);
            }
        }
    }

    if (anchorFreqImages.empty()) {
        const auto& clips = evpData.showClips();
        for (const auto& clip : clips) {
            std::string filename = makeImageFileName(clip.clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, nominalPwc.delta_dose);
            auto it = freqImages.find(filename);
            if (it != freqImages.end()) {
                anchorFreqImages.push_back(&it->second);
                anchorClipInfos.push_back(&clip);
                break;
            }
        }
    }

    if (anchorFreqImages.empty()) {
        return 0.5;
    }

    double sumIntensity = 0.0;
    int countPoints = 0;
    for (size_t i = 0; i < anchorFreqImages.size() && i < anchorClipInfos.size(); ++i) {
        const auto* freqImg = anchorFreqImages[i];
        const auto* clipInfo = anchorClipInfos[i];
        
        for (const auto* ep : clipInfo->evalPoints) {
            auto pv = freqImg->evalAt(ep->px, ep->py);
            sumIntensity += pv.intensity;
            countPoints++;
        }
    }
    
    double avgEdgeIntensity = (countPoints > 0) ? sumIntensity / countPoints : 0.5;

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);
    
    if (b - a < avgEdgeIntensity * 0.2) {
        a = avgEdgeIntensity * 0.5;
        b = avgEdgeIntensity * 1.5;
    }

    const double goldenRatio = (std::sqrt(5.0) - 1.0) / 2.0;
    double c = b - goldenRatio * (b - a);
    double d = a + goldenRatio * (b - a);

    auto evalFunc = [&](double sliceLevel) {
        double totalDeltaCDSq = 0.0;
        
        for (size_t i = 0; i < anchorFreqImages.size() && i < anchorClipInfos.size(); ++i) {
            const auto* freqImg = anchorFreqImages[i];
            const auto* clipInfo = anchorClipInfos[i];
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clipInfo->clipID) continue;
                
                auto epe1 = calcEPE(*freqImg, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(*freqImg, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                double delta_CD = epe1.epe + epe2.epe;
                totalDeltaCDSq += delta_CD * delta_CD;
            }
        }
        
        return totalDeltaCDSq;
    };

    double fc = evalFunc(c);
    double fd = evalFunc(d);

    for (int iter = 0; iter < 50; ++iter) {
        if (fc < fd) {
            b = d;
            d = c;
            fd = fc;
            c = b - goldenRatio * (b - a);
            fc = evalFunc(c);
        } else {
            a = c;
            c = d;
            fc = fd;
            d = a + goldenRatio * (b - a);
            fd = evalFunc(d);
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

double CostCalculator::findSliceLevelForTargetDeltaCD(
    const std::map<std::string, FrequencyImage>& freqImages,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double targetDeltaCD) const {

    int nominalIndex = processConfig.findNominalIndex();
    const auto& pwcs = processConfig.showPwcConditions();
    
    if (pwcs.empty()) {
        return 0.5;
    }
    
    const auto& nominalPwc = pwcs[nominalIndex];

    double avgEdgeIntensity = 0.5;
    for (const auto& [filename, freqImg] : freqImages) {
        const auto& clips = evpData.showClips();
        if (!clips.empty() && !clips[0].evalPoints.empty()) {
            auto pv = freqImg.evalAt(clips[0].evalPoints[0]->px, clips[0].evalPoints[0]->py);
            avgEdgeIntensity = pv.intensity;
            break;
        }
    }

    double centerHint = (m_options.sliceLevelHint > 0) ? m_options.sliceLevelHint : avgEdgeIntensity;
    double range = avgEdgeIntensity * 0.5;
    double a = std::max(avgEdgeIntensity * 0.1, centerHint - range);
    double b = std::min(avgEdgeIntensity * 2.0, centerHint + range);

    auto calcDeltaCDSum = [&](double sliceLevel) {
        double totalDeltaCD = 0.0;
        
        for (int clipID : m_options.anchorClips) {
            std::string filename = makeImageFileName(clipID, nominalPwc.defocus,
                                                              nominalPwc.mask_bias, nominalPwc.delta_dose);
            auto it = freqImages.find(filename);
            if (it == freqImages.end()) continue;
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clipID) continue;
                
                auto epe1 = calcEPE(it->second, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(it->second, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                totalDeltaCD += epe1.epe + epe2.epe;
            }
        }
        
        return totalDeltaCD;
    };

    auto evalFunc = [&](double sliceLevel) {
        return std::abs(targetDeltaCD - calcDeltaCDSum(sliceLevel));
    };

    for (int iter = 0; iter < 50; ++iter) {
        double m1 = a + (b - a) / 3.0;
        double m2 = b - (b - a) / 3.0;
        
        if (evalFunc(m1) < evalFunc(m2)) {
            b = m2;
        } else {
            a = m1;
        }
        
        if (std::abs(b - a) < 1e-8) {
            break;
        }
    }

    return (a + b) / 2.0;
}

CostResult CostCalculator::calculate(
    const std::map<std::string, FrequencyImage>& freqImages,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sourceFillRatio) const {

    CostResult result;

    // デバッグ: 入力されたFrequencyImageの統計を出力
    std::cerr << "[DEBUG calculate] Number of freqImages: " << freqImages.size() << std::endl;
    int debugCount = 0;
    for (const auto& [filename, freqImg] : freqImages) {
        if (debugCount++ >= 2) break;  // 最初の2つだけ出力
        double maxMag = 0.0;
        std::complex<double> dc = freqImg.data()[0];
        for (const auto& v : freqImg.data()) {
            double mag = std::abs(v);
            if (mag > maxMag) maxMag = mag;
        }
        std::cerr << "[DEBUG calculate] " << filename 
                  << ": DC=" << dc << ", maxMag=" << maxMag 
                  << ", dim=" << freqImg.dimx() << "x" << freqImg.dimy() << std::endl;
    }

    double sliceLevel = m_options.sliceLevel;
    if (sliceLevel < 0) {
        if (m_options.useTargetDeltaCD) {
            sliceLevel = findSliceLevelForTargetDeltaCD(
                freqImages, evpData, processConfig, m_options.targetDeltaCD);
        } else {
            sliceLevel = findOptimalSliceLevel(freqImages, evpData, processConfig);
        }
    }
    result.sliceLevel = sliceLevel;

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // デバッグ: 最初のevalAt結果を出力
    bool firstEval = true;

    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            
            // 実空間ファイルはdelta_dose込みのファイル名
            std::string filename = makeImageFileName(clip.clipID, pwc.defocus,
                                                              pwc.mask_bias, pwc.delta_dose);
            auto it = freqImages.find(filename);
            if (it == freqImages.end()) {
                std::cerr << "Warning: Image not found for " << filename << std::endl;
                continue;
            }
            
            const auto& freqImage = it->second;
            
            for (size_t evpIdx = 0; evpIdx < clip.evalPoints.size(); ++evpIdx) {
                const auto* ep = clip.evalPoints[evpIdx];
                
                auto epeCalc = calcEPE(freqImage, ep->px, ep->py, ep->degree, sliceLevel);
                
                // デバッグ: 最初のevalAt結果
                if (firstEval) {
                    std::cerr << "[DEBUG calculate] First evalAt at (" << ep->px << ", " << ep->py << "): "
                              << "intensity=" << epeCalc.intensity 
                              << ", gradient=" << epeCalc.gradient 
                              << ", sliceLevel=" << sliceLevel << std::endl;
                    firstEval = false;
                }
                
                EpeResult epeResult;
                epeResult.clipID = clip.clipID;
                epeResult.pwcIndex = static_cast<int>(pwcIdx);
                epeResult.evpIndex = static_cast<int>(evpIdx);
                epeResult.defocus = pwc.defocus;
                epeResult.maskBias = pwc.mask_bias;
                epeResult.deltaDose = pwc.delta_dose;
                epeResult.px = ep->px;
                epeResult.py = ep->py;
                epeResult.degree = ep->degree;
                epeResult.EPE = epeCalc.epe;
                epeResult.QEPE = epeCalc.qepe;
                epeResult.intensity = epeCalc.intensity;
                epeResult.gradient = epeCalc.gradient;
                epeResult.weight_p = ep->weight;
                epeResult.weight_pwc = pwc.weight;
                epeResult.converged = epeCalc.converged;
                epeResult.iterations = epeCalc.iterations;
                
                result.epeResults.push_back(epeResult);
            }
            
            for (const auto& pair : evpData.showCutlinePairs()) {
                if (pair.clipID != clip.clipID) continue;
                
                auto epe1 = calcEPE(freqImage, pair.point1->px, pair.point1->py,
                                    pair.point1->degree, sliceLevel);
                auto epe2 = calcEPE(freqImage, pair.point2->px, pair.point2->py,
                                    pair.point2->degree, sliceLevel);
                
                CutlineResult cutlineResult;
                cutlineResult.clipID = clip.clipID;
                cutlineResult.pwcIndex = static_cast<int>(pwcIdx);
                cutlineResult.defocus = pwc.defocus;
                cutlineResult.maskBias = pwc.mask_bias;
                cutlineResult.deltaDose = pwc.delta_dose;
                cutlineResult.direction = pair.direction;
                cutlineResult.CD = pair.CD;
                cutlineResult.delta_CD = epe1.epe + epe2.epe;
                cutlineResult.delta_CD_QEPE = epe1.qepe + epe2.qepe;
                cutlineResult.EPE1 = epe1.epe;
                cutlineResult.EPE2 = epe2.epe;
                cutlineResult.QEPE1 = epe1.qepe;
                cutlineResult.QEPE2 = epe2.qepe;
                
                result.cutlineResults.push_back(cutlineResult);
            }
        }
    }

    result.EPE_cost = calcEPECost(result.epeResults);
    result.QEPE_cost = calcQEPECost(result.epeResults);
    result.source_fill_cost = calcSourceFillCost(sourceFillRatio);
    result.total_cost = result.EPE_cost + m_options.weightFill * result.source_fill_cost;
    result.total_cost_QEPE = result.QEPE_cost + m_options.weightFill * result.source_fill_cost;

    // |EPE|, |QEPE| の最大値とそのインデックスを走査
    for (size_t i = 0; i < result.epeResults.size(); ++i) {
        const auto& er = result.epeResults[i];
        double aE = std::abs(er.EPE);
        double aQ = std::abs(er.QEPE);
        if (aE > result.maxAbsEPE) {
            result.maxAbsEPE = aE;
            result.maxAbsEPE_index = static_cast<int>(i);
        }
        if (aQ > result.maxAbsQEPE) {
            result.maxAbsQEPE = aQ;
            result.maxAbsQEPE_index = static_cast<int>(i);
        }
    }

    return result;
}

void CostWriter::write(const std::string& filepath, const CostResult& result) {
    std::ofstream ofs(filepath);
    if (!ofs.is_open()) {
        throw std::runtime_error("Cannot open file for writing: " + filepath);
    }

    ofs << "# Summary\n";
    ofs << "sliceLevel," << result.sliceLevel << "\n";
    ofs << "EPE_cost," << result.EPE_cost << "\n";
    ofs << "QEPE_cost," << result.QEPE_cost << "\n";
    ofs << "source_fill_cost," << result.source_fill_cost << "\n";
    ofs << "total_cost," << result.total_cost << "\n";
    ofs << "total_cost_QEPE," << result.total_cost_QEPE << "\n";
    ofs << "maxAbsEPE," << result.maxAbsEPE << "\n";
    ofs << "maxAbsQEPE," << result.maxAbsQEPE << "\n";
    // ピーク点の評価点識別子（epeResults を参照するための ID 列）
    if (result.maxAbsEPE_index >= 0 &&
        result.maxAbsEPE_index < static_cast<int>(result.epeResults.size())) {
        const auto& er = result.epeResults[result.maxAbsEPE_index];
        ofs << "maxAbsEPE_location,clipID=" << er.clipID
            << ";pwcIndex=" << er.pwcIndex
            << ";evpIndex=" << er.evpIndex
            << ";px=" << er.px << ";py=" << er.py << ";degree=" << er.degree << "\n";
    } else {
        ofs << "maxAbsEPE_location,\n";
    }
    if (result.maxAbsQEPE_index >= 0 &&
        result.maxAbsQEPE_index < static_cast<int>(result.epeResults.size())) {
        const auto& er = result.epeResults[result.maxAbsQEPE_index];
        ofs << "maxAbsQEPE_location,clipID=" << er.clipID
            << ";pwcIndex=" << er.pwcIndex
            << ";evpIndex=" << er.evpIndex
            << ";px=" << er.px << ";py=" << er.py << ";degree=" << er.degree << "\n";
    } else {
        ofs << "maxAbsQEPE_location,\n";
    }

    ofs << "# Cutline Results\n";
    ofs << "clipID,pwcIndex,defocus,maskBias,deltaDose,direction,CD,delta_CD,delta_CD_QEPE,EPE1,EPE2,QEPE1,QEPE2\n";
    for (const auto& cr : result.cutlineResults) {
        ofs << cr.clipID << ","
            << cr.pwcIndex << ","
            << cr.defocus << ","
            << cr.maskBias << ","
            << cr.deltaDose << ","
            << cr.direction << ","
            << cr.CD << ","
            << cr.delta_CD << ","
            << cr.delta_CD_QEPE << ","
            << cr.EPE1 << ","
            << cr.EPE2 << ","
            << cr.QEPE1 << ","
            << cr.QEPE2 << "\n";
    }

    ofs << "# EPE Results\n";
    ofs << "clipID,pwcIndex,defocus,maskBias,deltaDose,evpIndex,px,py,degree,EPE,QEPE,intensity,gradient,weight_p,weight_pwc,converged,iterations\n";
    for (const auto& er : result.epeResults) {
        ofs << er.clipID << ","
            << er.pwcIndex << ","
            << er.defocus << ","
            << er.maskBias << ","
            << er.deltaDose << ","
            << er.evpIndex << ","
            << er.px << ","
            << er.py << ","
            << er.degree << ","
            << er.EPE << ","
            << er.QEPE << ","
            << er.intensity << ","
            << er.gradient << ","
            << er.weight_p << ","
            << er.weight_pwc << ","
            << (er.converged ? "true" : "false") << ","
            << er.iterations << "\n";
    }
}

} // namespace so
