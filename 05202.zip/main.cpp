/*!
 * @file main.cpp
 * @brief srcOptim - Source Optimization Tool
 *
 * L-BFGS or Adam を使用してピクセル化光源の強度を最適化し、
 * EPEコストを最小化する。
 */

#include <getopt.h>
#include <unistd.h>
#include <fcntl.h>

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

#include <so/source_grid.h>
#include <so/source_data.h>
#include <so/source_corrector.h>
#include <so/socs_config.h>
#include <so/process_config.h>
#include <so/evp_data.h>
#include <so/image_calculator.h>
#include <so/source_contribution_set.h>
#include <so/cost_calculator.h>
#include <so/source_optimizer.h>
#include <so/types.h>

void printHelp(const char* programName) {
    std::cerr << "srcOptim - Source Optimization Tool\n";
    std::cerr << "\n";
    std::cerr << "Usage:\n";
    std::cerr << "  " << programName << " -s <socs_set_dir> -g <source_grid> -p <process_config>\n";
    std::cerr << "                -f <source_file> -e <evp_csv> -l <layout_file> -o <output_source>\n";
    std::cerr << "                [options]\n";
    std::cerr << "\n";
    std::cerr << "Required arguments:\n";
    std::cerr << "  -s, --socs_set <dir>       SOCS set directory\n";
    std::cerr << "  -g, --source_config <file> source_config.txt file\n";
    std::cerr << "  -p, --process <file>       process_config.txt file\n";
    std::cerr << "  -f, --source <file>        Initial source intensity file (.illum)\n";
    std::cerr << "  -e, --evp <file>           evp.csv file\n";
    std::cerr << "  -l, --layout <file>        OASIS/GDS layout file\n";
    std::cerr << "  -o, --output <file>        Output optimized source file (.illum)\n";
    std::cerr << "\n";
    std::cerr << "Optimization options:\n";
    std::cerr << "  --optimizer <lbfgs|adam>   Optimizer type (default: lbfgs)\n";
    std::cerr << "  --max_iter <int>           各 round 内の L-BFGS 最大 iteration 数の上限 (default: 100)\n";
    std::cerr << "                             注: round 数や stage 数は別ループ (sliceLevelOptimizationRounds / epe_power_schedule)\n";
    std::cerr << "                             総 iter 数は概ね (stages × rounds × max_iter) が上限となる\n";
    std::cerr << "  --grad_tol <double>        Gradient tolerance (default: 1e-3)\n";
    std::cerr << "                             Note: EPE cost is scaled by 1/EPE_REF^n (n=2 => 1e6),\n";
    std::cerr << "                             so the gradient norm is on the same order.\n";
    std::cerr << "  --cost_tol <double>        Cost tolerance (default: 1e-8)\n";
    std::cerr << "  --min_intensity <double>   Minimum intensity constraint (default: 0.0)\n";
    std::cerr << "  --max_intensity <double>   Maximum intensity constraint (default: 1.0)\n";
    std::cerr << "  --min_fill_ratio <double>  Minimum source fill ratio (default: 0.07)\n";
    std::cerr << "  --tolerance <um>           Global EPE tolerance [um] that overrides evp.csv\n";
    std::cerr << "                             (default: -1 = use evp.csv tolerance column)\n";
    std::cerr << "                             |EPE| <= tolerance gives cost=0 (deadband).\n";
    std::cerr << "                             Set equal to calcMargin's --tolerance for\n";
    std::cerr << "                             consistent optimize/evaluate criterion.\n";
    std::cerr << "  --weight_fill <double>     Weight for source fill penalty (default: 1.0)\n";
    std::cerr << "  --exp_fill_penalty         Use exponential fill penalty (default: quadratic)\n";
    std::cerr << "  --fill_penalty_k <double>  Exponent k for exponential penalty (default: 100)\n";
    std::cerr << "  --weight_nils <double>     Weight for NILS penalty (default: 0=disabled)\n";
    std::cerr << "  --nils_min <double>        NILS lower bound; below this value is penalized (default: 2.0)\n";
    std::cerr << "  --nils_cd_ref <double>     Reference CD [um] for NILS normalization (default: 0.022)\n";
    std::cerr << "\n";
    std::cerr << "BT (Bossung Tilt) / BFS (Best Focus Shift) penalties:\n";
    std::cerr << "  --weight_bt <double>       BT penalty weight (default: 0=disabled)\n";
    std::cerr << "  --weight_bfs <double>      BFS penalty weight (default: 0=disabled)\n";
    std::cerr << "  --bt_power <int>           BT power p (default: 2)\n";
    std::cerr << "  --bfs_power <int>          BFS power p (default: 2)\n";
    std::cerr << "  --bfs_pwc_nom <int>        Nom PWC index (-1=auto, nominal, 全ペアで共通)\n";
    std::cerr << "  --bt_pairs <Fp,Fn;...>     BT ペア指定 (例: \"1,0;7,8;9,10\")。空なら defocus 極値ペア自動検出\n";
    std::cerr << "  --bfs_pairs <Fp,Fn[,Nom];...>  BFS ペア指定 (3つ組可、例: \"1,0,2;7,8,5\")。\n";
    std::cerr << "                             Nom 省略時は bfs_pwc_nom を使用。空なら bt_pairs を流用\n";
    std::cerr << "  --pair_clips <ids>         Comma-separated clip IDs to apply BT/BFS (empty=all)\n";
    std::cerr << "  --early_stop_patience <int>   Early stop patience iterations (default: 3, 0=disabled)\n";
    std::cerr << "  --early_stop_tol <double>     Early stop tolerance (default: 1e-4)\n";
    std::cerr << "  --max_cost_reduction <double> Max cost reduction per round (default: -1=disabled, e.g. 0.3=30%)\n";
    std::cerr << "  --round_conv_tol <double>     Round convergence tolerance (default: 1e-6)\n";
    std::cerr << "  --round_conv_window <int>     Round convergence window size (default: 1, >=2 for window-based)\n";
    std::cerr << "\n";
    std::cerr << "L-BFGS options:\n";
    std::cerr << "  --lbfgs_memory <int>       L-BFGS memory size (default: 10)\n";
    std::cerr << "  --lbfgs_window <int>       Convergence window size (default: 10)\n";
    std::cerr << "  --lbfgs_rel_tol <double>   Relative improvement tolerance (default: 1e-6)\n";
    std::cerr << "  --lbfgs_min_iter <int>     Minimum iterations before convergence check (default: 0)\n";
    std::cerr << "\n";
    std::cerr << "Adam options:\n";
    std::cerr << "  --adam_lr <double>         Adam learning rate (default: 0.01)\n";
    std::cerr << "  --adam_beta1 <double>      Adam beta1 (default: 0.9)\n";
    std::cerr << "  --adam_beta2 <double>      Adam beta2 (default: 0.999)\n";
    std::cerr << "\n";
    std::cerr << "Cost calculation options:\n";
    std::cerr << "  --sliceLevel <double>      Threshold value (auto if not specified)\n";
    std::cerr << "  --sliceLevelHint <double>  Initial hint for slice level search\n";
    std::cerr << "  --sliceLevelRounds <int>   Number of optimization rounds with sliceLevel recalculation (default: 1)\n";
    std::cerr << "  --anchor_clips <ids>       Anchor clip IDs (comma-separated, default: ALL clips)\n";
    std::cerr << "  --slice_objective <type>   sliceLevel optimization objective (default: max_abs_epe)\n";
    std::cerr << "                             max_abs_epe: max max(0,|EPE|-tol) over all evp (deadband)\n";
    std::cerr << "                             delta_cd2:   Σ delta_CD² (legacy)\n";
    std::cerr << "                             total_cost:  Σ max(0,|EPE|-tol)² × pwc.weight × evp.weight\n";
    std::cerr << "                                          (main 最適化の EPE_cost と整合)\n";
    std::cerr << "  --slice_pwc_mode <mode>    PWC for sliceLevel optimization (default: all)\n";
    std::cerr << "                             all:     consider all PWCs\n";
    std::cerr << "                             nominal: nominal PWC only (legacy)\n";
    std::cerr << "  --slice_recompute_per_round <0|1>  Recompute sliceLevel each round (default: 0=once per stage)\n";
    std::cerr << "\n";
    std::cerr << "Two-stage optimization (recommended):\n";
    std::cerr << "  --enable_two_stage         Enable two-stage optimization (Stage1: EPE², Stage2: EPE^n)\n";
    std::cerr << "  --epe_power <int>          EPE power for single-stage or Stage 1 (default: 2)\n";
    std::cerr << "  --epe_power_stage2 <int>   EPE power for Stage 2 (default: 4)\n";
    std::cerr << "  --epe_power_schedule <list> Multi-stage EPE powers (e.g. 2,3,4,6,8)\n";
    std::cerr << "                              指定すると enableTwoStage より優先\n";
    std::cerr << "  --adaptive_weight_p <d>      IRLS exponent (default: 0=disabled)\n";
    std::cerr << "                               >0 で round 末に worst 評価点へ重み集中\n";
    std::cerr << "  --adaptive_weight_floor <d>  Lower bound of relative weight (default: 0.01)\n";
    std::cerr << "  --adaptive_weight_p_schedule <list>     Stage ごとの IRLS p (e.g. 1,3,5,7)\n";
    std::cerr << "  --adaptive_weight_floor_schedule <list> Stage ごとの IRLS floor (e.g. 0.5,0.1,0.01,0.001)\n";
    std::cerr << "  --sa_amplitude_init <d>      SA perturbation amplitude (default: 0=disabled)\n";
    std::cerr << "                               Stage 1 で sliceLevel を意図的に揺さぶり局所解脱出\n";
    std::cerr << "  --sa_cooling <d>             SA cooling rate per round (default: 0.85)\n";
    std::cerr << "  --sa_max_rounds <int>        SA を適用する最大 round 数 (default: 20)\n";
    std::cerr << "  --sa_seed <int>              SA 乱数シード (default: 12345)\n";
    std::cerr << "  --slice_update_init <int>    各 round 内の L-BFGS iter 数 (default: 5)\n";
    std::cerr << "                               adaptive_round_length=OFF (default) 時は全 round 固定値\n";
    std::cerr << "  --enable_adaptive_round_length <0|1>  動的 round 長スケジューラ (default: 0=OFF)\n";
    std::cerr << "                               ON で改善率に応じて round 内 iter 数を動的調整\n";
    std::cerr << "  --slice_update_growth <d>    (動的調整時のみ) round ごとの倍率 (default: 1.5)\n";
    std::cerr << "  --slice_update_max <int>     (動的調整時のみ) 上限 (default: 200 iter)\n";
    std::cerr << "  --slice_method <str>         epe_zero (default) or minmax\n";
    std::cerr << "  --slice_anchor_clip <id>     Clip ID for epe_zero (default: first anchor clip)\n";
    std::cerr << "  --slice_anchor_dir <X|Y>     Cutline direction for epe_zero (default: X)\n";
    std::cerr << "  --slice_as_variable <0|1>    Optimize sliceLevel as a variable (default: 0)\n";
    std::cerr << "                               1 で (s, t) 同時最適化、block coord descent の発振を回避\n";
    std::cerr << "  --slice_min <d>              sliceLevel lower bound for slice_as_variable (default: 0.05)\n";
    std::cerr << "  --slice_max <d>              sliceLevel upper bound for slice_as_variable (default: 0.50)\n";
    std::cerr << "\n";
    std::cerr << "Gradient calculation options:\n";
    std::cerr << "  --gradient_method <1-4>    Gradient calculation method (default: 2)\n";
    std::cerr << "                             1: QEPE + analytical gradient\n";
    std::cerr << "                             2: EPE + analytical gradient (recommended)\n";
    std::cerr << "                             3: QEPE + numerical gradient (slow)\n";
    std::cerr << "                             4: EPE + numerical gradient (very slow)\n";
    std::cerr << "  --numerical_epsilon <d>    Epsilon for numerical gradient (default: 1e-6)\n";
    std::cerr << "\n";
    std::cerr << "Regularization options:\n";
    std::cerr << "  --regularization <type>    Regularization type (default: none)\n";
    std::cerr << "                             none: No regularization\n";
    std::cerr << "                             laplacian: Spatial smoothness (penalize deviation from neighbors)\n";
    std::cerr << "                             l2: Tikhonov regularization (penalize large intensities)\n";
    std::cerr << "                             tv: Total Variation (edge-preserving smoothness)\n";
    std::cerr << "                             isolated: Isolated point penalty (penalize isolated bright points)\n";
    std::cerr << "  --regularization_weight <d>  Regularization weight lambda (default: 0.0)\n";
    std::cerr << "\n";
    std::cerr << "Image calculation options:\n";
    std::cerr << "  --resistModel <file>       Base resistModel file\n";
    std::cerr << "  --dim0 <int>               Calculation dimension (small)\n";
    std::cerr << "  --dim <int>                Calculation dimension (large)\n";
    std::cerr << "  --kernel <int>             Number of SOCS kernels\n";
    std::cerr << "  --layer <L/D,...>          Layer/datatype pairs (default: 0/0)\n";
    std::cerr << "  --cellname <n>             Cell name\n";
    std::cerr << "  --brightfield              Bright field mode\n";
    std::cerr << "  --darkfield                Dark field mode (default)\n";
    std::cerr << "\n";
    std::cerr << "Source correction options:\n";
    std::cerr << "  --interpolation <method>   Interpolation method: nearest or bilinear (default: nearest)\n";
    std::cerr << "  --debug_source <path>      Output corrected source file for debugging\n";
    std::cerr << "\n";
    std::cerr << "Output options:\n";
    std::cerr << "  --cost_output <file>       Output final cost.csv file\n";
    std::cerr << "  --log_output <file>        Output optimization log.csv file\n";
    std::cerr << "  --round_output <prefix>    Output source PPM for each round (prefix_roundN.ppm)\n";
    std::cerr << "  --verify_gradient          Verify gradient against numerical gradient\n";
    std::cerr << "  --verbose                  Verbose output\n";
    std::cerr << "  -j, --jobs <int>           Number of threads (default: 1)\n";
    std::cerr << "  -h, --help                 Show this help message\n";
}

void writeLog(const std::string& filepath, const so::OptimizationResult& result) {
    std::ofstream ofs(filepath);
    if (!ofs.is_open()) {
        std::cerr << "Warning: Cannot open log file: " << filepath << std::endl;
        return;
    }

    ofs << "stage,round,iteration,cost,stageBestCost,stageBestSliceLevel,"
           "pickedEpeCost,pickedTotalCost,pickedFeasible,"
           "epeCost,sourceFillCost,nilsCost,nonConvergedCount,gradientNorm,"
           "stepSize,sourceFillRatio,sliceLevel\n";
    for (const auto& entry : result.log) {
        ofs << entry.stage << ","
            << entry.round << ","
            << entry.iteration << ","
            << entry.cost << ","
            << entry.stageBestCost << ","
            << entry.stageBestSliceLevel << ","
            << entry.pickedEpeCost << ","
            << entry.pickedTotalCost << ","
            << entry.pickedFeasible << ","
            << entry.epeCost << ","
            << entry.sourceFillCost << ","
            << entry.nilsCost << ","
            << entry.nonConvergedCount << ","
            << entry.gradientNorm << ","
            << entry.stepSize << ","
            << entry.sourceFillRatio << ","
            << entry.sliceLevel << "\n";
    }
}

std::string formatDuration(double seconds) {
    std::ostringstream oss;
    if (seconds < 60.0) {
        oss << std::fixed << std::setprecision(2) << seconds << " sec";
    } else if (seconds < 3600.0) {
        int min = static_cast<int>(seconds) / 60;
        double sec = seconds - min * 60;
        oss << min << " min " << std::fixed << std::setprecision(1) << sec << " sec";
    } else {
        int hour = static_cast<int>(seconds) / 3600;
        int min = (static_cast<int>(seconds) % 3600) / 60;
        double sec = seconds - hour * 3600 - min * 60;
        oss << hour << " hour " << min << " min " << std::fixed << std::setprecision(0) << sec << " sec";
    }
    return oss.str();
}

int main(int argc, char** argv) {
#ifdef HAVE_MPI_H
    MPI_Init(&argc, &argv);
    int mpiRank = 0, mpiSize = 1;
    MPI_Comm_rank(MPI_COMM_WORLD, &mpiRank);
    MPI_Comm_size(MPI_COMM_WORLD, &mpiSize);

    // 全ランクのノード情報を表示
    {
        char hostname[256];
        gethostname(hostname, sizeof(hostname));

        // ホスト名の最大長を揃える
        int nameLen = static_cast<int>(strlen(hostname)) + 1;
        int maxLen = 0;
        MPI_Allreduce(&nameLen, &maxLen, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);

        std::vector<char> myName(maxLen, 0);
        std::vector<char> allNames(mpiSize * maxLen, 0);
        strncpy(myName.data(), hostname, maxLen);
        MPI_Allgather(myName.data(), maxLen, MPI_CHAR,
                      allNames.data(), maxLen, MPI_CHAR, MPI_COMM_WORLD);

        if (mpiRank == 0) {
            std::cerr << "=== MPI Node Configuration ===" << std::endl;
            std::map<std::string, std::vector<int>> nodeMap;
            for (int i = 0; i < mpiSize; ++i) {
                std::string name(allNames.data() + i * maxLen);
                nodeMap[name].push_back(i);
            }
            for (const auto& [node, ranks] : nodeMap) {
                std::cerr << "  " << node << ": ranks ";
                for (size_t i = 0; i < ranks.size(); ++i) {
                    if (i > 0) std::cerr << ",";
                    std::cerr << ranks[i];
                }
                std::cerr << " (" << ranks.size() << " processes)" << std::endl;
            }
            std::cerr << "  Total: " << nodeMap.size() << " node(s), "
                      << mpiSize << " process(es)" << std::endl;
            std::cerr << "===============================" << std::endl;
        }
        MPI_Barrier(MPI_COMM_WORLD);
    }
#else
    int mpiRank = 0, mpiSize = 1;
#endif

    // rank 0以外はstderr/stdoutを抑制（ログ重複防止）
    // C++ストリーム(std::cerr)とCストリーム(fprintf)の両方を抑制するため、
    // ファイルディスクリプタレベルでリダイレクト
    int savedStderr = -1, savedStdout = -1;
    if (mpiRank != 0) {
        savedStderr = dup(STDERR_FILENO);
        savedStdout = dup(STDOUT_FILENO);
        int devNull = open("/dev/null", O_WRONLY);
        dup2(devNull, STDERR_FILENO);
        dup2(devNull, STDOUT_FILENO);
        close(devNull);
    }

#ifdef HAVE_MPI_H
    MPI_Comm workComm = MPI_COMM_WORLD;
#endif

    auto totalStartTime = std::chrono::high_resolution_clock::now();

    // 出力精度を6桁に設定
    std::cerr << std::fixed << std::setprecision(6);
    std::cout << std::fixed << std::setprecision(6);

    if (mpiRank == 0) {
        std::cerr << "===============================================" << std::endl;
        std::cerr << "srcOptim - Source Optimization Tool" << std::endl;
        std::cerr << "===============================================" << std::endl;
    }

    // 引数
    std::string socsSetDir;
    std::string sourceGridFile;
    std::string processConfigFile;
    std::string sourceFile;
    std::string evpFile;
    std::string layoutFile;
    std::string outputFile;
    std::string resistModelFile;
    std::string costOutputFile;
    std::string logOutputFile;

    so::CalcOptions imgOptions;
    so::OptimizationOptions optimOptions;
    so::CorrectionOptions correctionOptions;

    int flagBrightfield = 0;
    int flagVerifyGradient = 0;

    static struct option longopts[] = {
        {"help", no_argument, nullptr, 'h'},
        {"socs_set", required_argument, nullptr, 's'},
        {"source_config", required_argument, nullptr, 'g'},
        {"process", required_argument, nullptr, 'p'},
        {"source", required_argument, nullptr, 'f'},
        {"evp", required_argument, nullptr, 'e'},
        {"layout", required_argument, nullptr, 'l'},
        {"output", required_argument, nullptr, 'o'},
        {"jobs", required_argument, nullptr, 'j'},
        // Optimization options
        {"optimizer", required_argument, nullptr, 0},
        {"max_iter", required_argument, nullptr, 0},
        {"grad_tol", required_argument, nullptr, 0},
        {"cost_tol", required_argument, nullptr, 0},
        {"min_intensity", required_argument, nullptr, 0},
        {"max_intensity", required_argument, nullptr, 0},
        {"min_fill_ratio", required_argument, nullptr, 0},
        {"weight_fill", required_argument, nullptr, 0},
        {"exp_fill_penalty", no_argument, nullptr, 0},
        {"fill_penalty_k", required_argument, nullptr, 0},
        {"weight_nils", required_argument, nullptr, 0},
        {"nils_min", required_argument, nullptr, 0},
        {"nils_cd_ref", required_argument, nullptr, 0},
        {"tolerance", required_argument, nullptr, 0},
        {"weight_bt", required_argument, nullptr, 0},
        {"weight_bfs", required_argument, nullptr, 0},
        {"bt_power", required_argument, nullptr, 0},
        {"bfs_power", required_argument, nullptr, 0},
        {"bfs_pwc_nom", required_argument, nullptr, 0},
        {"bt_pairs", required_argument, nullptr, 0},
        {"bfs_pairs", required_argument, nullptr, 0},
        {"pair_clips", required_argument, nullptr, 0},
        {"early_stop_patience", required_argument, nullptr, 0},
        {"early_stop_tol", required_argument, nullptr, 0},
        {"max_cost_reduction", required_argument, nullptr, 0},
        {"round_conv_tol", required_argument, nullptr, 0},
        {"round_conv_window", required_argument, nullptr, 0},
        {"lbfgs_memory", required_argument, nullptr, 0},
        {"lbfgs_window", required_argument, nullptr, 0},
        {"lbfgs_rel_tol", required_argument, nullptr, 0},
        {"lbfgs_min_iter", required_argument, nullptr, 0},
        {"adam_lr", required_argument, nullptr, 0},
        {"adam_beta1", required_argument, nullptr, 0},
        {"adam_beta2", required_argument, nullptr, 0},
        // Cost calculation options
        {"sliceLevel", required_argument, nullptr, 0},
        {"sliceLevelHint", required_argument, nullptr, 0},
        {"sliceLevelRounds", required_argument, nullptr, 0},
        {"anchor_clips", required_argument, nullptr, 0},
        {"slice_objective", required_argument, nullptr, 0},
        {"slice_pwc_mode", required_argument, nullptr, 0},
        {"slice_recompute_per_round", required_argument, nullptr, 0},
        // Two-stage optimization options
        {"enable_two_stage", no_argument, nullptr, 0},
        {"epe_power", required_argument, nullptr, 0},
        {"epe_power_stage2", required_argument, nullptr, 0},
        {"epe_power_schedule", required_argument, nullptr, 0},
        {"adaptive_weight_p", required_argument, nullptr, 0},
        {"adaptive_weight_floor", required_argument, nullptr, 0},
        {"adaptive_weight_p_schedule", required_argument, nullptr, 0},
        {"adaptive_weight_floor_schedule", required_argument, nullptr, 0},
        {"sa_amplitude_init", required_argument, nullptr, 0},
        {"sa_cooling", required_argument, nullptr, 0},
        {"sa_max_rounds", required_argument, nullptr, 0},
        {"sa_seed", required_argument, nullptr, 0},
        {"sa_all_stages", required_argument, nullptr, 0},
        {"slice_update_init", required_argument, nullptr, 0},
        {"slice_update_growth", required_argument, nullptr, 0},
        {"slice_update_max", required_argument, nullptr, 0},
        {"enable_adaptive_round_length", required_argument, nullptr, 0},
        {"slice_method", required_argument, nullptr, 0},
        {"slice_anchor_clip", required_argument, nullptr, 0},
        {"slice_anchor_dir", required_argument, nullptr, 0},
        {"slice_as_variable", required_argument, nullptr, 0},
        {"slice_min", required_argument, nullptr, 0},
        {"slice_max", required_argument, nullptr, 0},
        {"slice_grad_scale", required_argument, nullptr, 0},
        // Gradient calculation options
        {"gradient_method", required_argument, nullptr, 0},
        {"numerical_epsilon", required_argument, nullptr, 0},
        // Regularization options
        {"regularization", required_argument, nullptr, 0},
        {"regularization_weight", required_argument, nullptr, 0},
        // Image calculation options
        {"resistModel", required_argument, nullptr, 0},
        {"dim0", required_argument, nullptr, 0},
        {"dim", required_argument, nullptr, 0},
        {"kernel", required_argument, nullptr, 0},
        {"layer", required_argument, nullptr, 0},
        {"cellname", required_argument, nullptr, 0},
        {"brightfield", no_argument, &flagBrightfield, 1},
        {"darkfield", no_argument, &flagBrightfield, 0},
        // Source correction options
        {"interpolation", required_argument, nullptr, 0},
        {"debug_source", required_argument, nullptr, 0},
        // Output options
        {"cost_output", required_argument, nullptr, 0},
        {"log_output", required_argument, nullptr, 0},
        {"round_output", required_argument, nullptr, 0},
        {"verify_gradient", no_argument, &flagVerifyGradient, 1},
        {"verbose", no_argument, nullptr, 'v'},
        {nullptr, 0, nullptr, 0}
    };

    int ch, optionIndex;
    while ((ch = getopt_long(argc, argv, "hs:g:p:f:e:l:o:j:v", longopts, &optionIndex)) != -1) {
        switch (ch) {
            case 'h':
                printHelp(argv[0]);
                return 0;
            case 's':
                socsSetDir = optarg;
                break;
            case 'g':
                sourceGridFile = optarg;
                break;
            case 'p':
                processConfigFile = optarg;
                break;
            case 'f':
                sourceFile = optarg;
                break;
            case 'e':
                evpFile = optarg;
                break;
            case 'l':
                layoutFile = optarg;
                break;
            case 'o':
                outputFile = optarg;
                break;
            case 'j':
                imgOptions.numThreads = std::atoi(optarg);
                optimOptions.numThreads = std::atoi(optarg);
                break;
            case 'v':
                optimOptions.verbose = true;
                break;
            case 0:
                // Optimization options
                if (strcmp(longopts[optionIndex].name, "optimizer") == 0) {
                    std::string opt = optarg;
                    if (opt == "adam" || opt == "Adam" || opt == "ADAM") {
                        optimOptions.optimizer = so::OptimizerType::Adam;
                    } else {
                        optimOptions.optimizer = so::OptimizerType::LBFGS;
                    }
                } else if (strcmp(longopts[optionIndex].name, "max_iter") == 0) {
                    optimOptions.maxIterations = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "grad_tol") == 0) {
                    optimOptions.gradientTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "cost_tol") == 0) {
                    optimOptions.costTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "min_intensity") == 0) {
                    optimOptions.minIntensity = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "max_intensity") == 0) {
                    optimOptions.maxIntensity = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "min_fill_ratio") == 0) {
                    optimOptions.minSourceFillRatio = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "weight_fill") == 0) {
                    optimOptions.weightFillPenalty = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "exp_fill_penalty") == 0) {
                    optimOptions.useExponentialFillPenalty = true;
                } else if (strcmp(longopts[optionIndex].name, "fill_penalty_k") == 0) {
                    optimOptions.fillPenaltyExponent = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "weight_nils") == 0) {
                    optimOptions.weightNilsPenalty = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "nils_min") == 0) {
                    optimOptions.nilsMin = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "nils_cd_ref") == 0) {
                    optimOptions.nilsCdReference = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "tolerance") == 0) {
                    optimOptions.globalTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "weight_bt") == 0) {
                    optimOptions.weightBt = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "weight_bfs") == 0) {
                    optimOptions.weightBfs = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "bt_power") == 0) {
                    optimOptions.btPower = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "bfs_power") == 0) {
                    optimOptions.bfsPower = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "bfs_pwc_nom") == 0) {
                    optimOptions.bfsPwcNom = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "bt_pairs") == 0) {
                    // BT: "Fp,Fn;Fp,Fn;..." を std::vector<std::pair<int,int>> にパース
                    optimOptions.btPairs.clear();
                    std::stringstream ss(optarg);
                    std::string pairStr;
                    while (std::getline(ss, pairStr, ';')) {
                        if (pairStr.empty()) continue;
                        size_t comma = pairStr.find(',');
                        if (comma == std::string::npos) continue;
                        int fp = std::stoi(pairStr.substr(0, comma));
                        int fn = std::stoi(pairStr.substr(comma + 1));
                        optimOptions.btPairs.emplace_back(fp, fn);
                    }
                } else if (strcmp(longopts[optionIndex].name, "bfs_pairs") == 0) {
                    // BFS: "Fp,Fn[,Nom];..." を std::vector<std::tuple<int,int,int>> にパース
                    // Nom 省略時は -1 (共通 bfsPwcNom or auto を使う)
                    optimOptions.bfsPairs.clear();
                    std::stringstream ss(optarg);
                    std::string tripletStr;
                    while (std::getline(ss, tripletStr, ';')) {
                        if (tripletStr.empty()) continue;
                        std::stringstream ts(tripletStr);
                        std::string tok;
                        std::vector<int> nums;
                        while (std::getline(ts, tok, ',')) {
                            if (tok.empty()) continue;
                            nums.push_back(std::stoi(tok));
                        }
                        if (nums.size() < 2) continue;
                        int fp = nums[0];
                        int fn = nums[1];
                        int nom = (nums.size() >= 3) ? nums[2] : -1;
                        optimOptions.bfsPairs.emplace_back(fp, fn, nom);
                    }
                } else if (strcmp(longopts[optionIndex].name, "pair_clips") == 0) {
                    optimOptions.pairClips.clear();
                    std::stringstream ss(optarg);
                    std::string tok;
                    while (std::getline(ss, tok, ',')) {
                        if (!tok.empty()) optimOptions.pairClips.push_back(std::stoi(tok));
                    }
                } else if (strcmp(longopts[optionIndex].name, "early_stop_patience") == 0) {
                    optimOptions.earlyStopPatience = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "early_stop_tol") == 0) {
                    optimOptions.earlyStopTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "max_cost_reduction") == 0) {
                    optimOptions.maxCostReduction = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "round_conv_tol") == 0) {
                    optimOptions.roundConvergenceTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "round_conv_window") == 0) {
                    optimOptions.roundConvergenceWindow = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_memory") == 0) {
                    optimOptions.lbfgsMemorySize = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_window") == 0) {
                    optimOptions.lbfgsConvergenceWindow = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_rel_tol") == 0) {
                    optimOptions.lbfgsRelativeTolerance = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "lbfgs_min_iter") == 0) {
                    optimOptions.lbfgsMinIterations = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adam_lr") == 0) {
                    optimOptions.adamLearningRate = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adam_beta1") == 0) {
                    optimOptions.adamBeta1 = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adam_beta2") == 0) {
                    optimOptions.adamBeta2 = std::atof(optarg);
                }
                // Cost calculation options
                else if (strcmp(longopts[optionIndex].name, "sliceLevel") == 0) {
                    optimOptions.sliceLevel = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sliceLevelHint") == 0) {
                    optimOptions.sliceLevelHint = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sliceLevelRounds") == 0) {
                    optimOptions.sliceLevelOptimizationRounds = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "anchor_clips") == 0) {
                    optimOptions.anchorClips.clear();
                    std::stringstream ss(optarg);
                    std::string token;
                    while (std::getline(ss, token, ',')) {
                        optimOptions.anchorClips.push_back(std::stoi(token));
                    }
                } else if (strcmp(longopts[optionIndex].name, "slice_objective") == 0) {
                    std::string s = optarg;
                    if (s == "delta_cd2" || s == "DeltaCD2" || s == "legacy") {
                        optimOptions.sliceObjective = so::SliceObjective::DeltaCD2;
                    } else if (s == "total_cost" || s == "TotalCost" || s == "total") {
                        optimOptions.sliceObjective = so::SliceObjective::TotalCost;
                    } else {
                        optimOptions.sliceObjective = so::SliceObjective::MaxAbsEPE;
                    }
                } else if (strcmp(longopts[optionIndex].name, "slice_pwc_mode") == 0) {
                    std::string s = optarg;
                    if (s == "nominal" || s == "Nominal" || s == "NominalOnly") {
                        optimOptions.slicePwcMode = so::SlicePwcMode::NominalOnly;
                    } else {
                        optimOptions.slicePwcMode = so::SlicePwcMode::AllPwc;
                    }
                } else if (strcmp(longopts[optionIndex].name, "slice_recompute_per_round") == 0) {
                    optimOptions.sliceRecomputePerRound = (std::atoi(optarg) != 0);
                }
                // Two-stage optimization options
                else if (strcmp(longopts[optionIndex].name, "enable_two_stage") == 0) {
                    optimOptions.enableTwoStage = true;
                } else if (strcmp(longopts[optionIndex].name, "epe_power") == 0) {
                    optimOptions.epePower = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "epe_power_stage2") == 0) {
                    optimOptions.epePowerStage2 = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "epe_power_schedule") == 0) {
                    optimOptions.epePowerSchedule.clear();
                    std::stringstream ss(optarg);
                    std::string tok;
                    while (std::getline(ss, tok, ',')) {
                        if (!tok.empty()) {
                            optimOptions.epePowerSchedule.push_back(std::stoi(tok));
                        }
                    }
                } else if (strcmp(longopts[optionIndex].name, "adaptive_weight_p") == 0) {
                    optimOptions.adaptiveWeightExponent = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adaptive_weight_floor") == 0) {
                    optimOptions.adaptiveWeightFloor = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "adaptive_weight_p_schedule") == 0) {
                    optimOptions.adaptiveWeightExponentSchedule.clear();
                    std::stringstream ss(optarg);
                    std::string tok;
                    while (std::getline(ss, tok, ',')) {
                        if (!tok.empty()) optimOptions.adaptiveWeightExponentSchedule.push_back(std::stod(tok));
                    }
                } else if (strcmp(longopts[optionIndex].name, "adaptive_weight_floor_schedule") == 0) {
                    optimOptions.adaptiveWeightFloorSchedule.clear();
                    std::stringstream ss(optarg);
                    std::string tok;
                    while (std::getline(ss, tok, ',')) {
                        if (!tok.empty()) optimOptions.adaptiveWeightFloorSchedule.push_back(std::stod(tok));
                    }
                } else if (strcmp(longopts[optionIndex].name, "sa_amplitude_init") == 0) {
                    optimOptions.saAmplitudeInit = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sa_cooling") == 0) {
                    optimOptions.saCoolingRate = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sa_max_rounds") == 0) {
                    optimOptions.saMaxRounds = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sa_seed") == 0) {
                    optimOptions.saSeed = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sa_all_stages") == 0) {
                    optimOptions.saAllStages = (std::atoi(optarg) != 0);
                } else if (strcmp(longopts[optionIndex].name, "slice_update_init") == 0) {
                    optimOptions.sliceUpdateIntervalInit = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "slice_update_growth") == 0) {
                    optimOptions.sliceUpdateIntervalGrowth = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "slice_update_max") == 0) {
                    optimOptions.sliceUpdateIntervalMax = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "enable_adaptive_round_length") == 0) {
                    optimOptions.enableAdaptiveRoundLength = (std::atoi(optarg) != 0);
                } else if (strcmp(longopts[optionIndex].name, "slice_method") == 0) {
                    std::string s = optarg;
                    optimOptions.sliceUseEpeZero = (s != "minmax" && s != "MinMax");
                } else if (strcmp(longopts[optionIndex].name, "slice_anchor_clip") == 0) {
                    optimOptions.sliceAnchorClipID = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "slice_anchor_dir") == 0) {
                    optimOptions.sliceAnchorDirection = optarg;
                } else if (strcmp(longopts[optionIndex].name, "slice_as_variable") == 0) {
                    optimOptions.sliceAsVariable = (std::atoi(optarg) != 0);
                } else if (strcmp(longopts[optionIndex].name, "slice_min") == 0) {
                    optimOptions.sliceMin = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "slice_max") == 0) {
                    optimOptions.sliceMax = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "slice_grad_scale") == 0) {
                    optimOptions.sliceGradScale = std::atof(optarg);
                }
                // Gradient calculation options
                else if (strcmp(longopts[optionIndex].name, "gradient_method") == 0) {
                    optimOptions.gradientMethod = so::parseGradientMethod(optarg);
                } else if (strcmp(longopts[optionIndex].name, "numerical_epsilon") == 0) {
                    optimOptions.numericalEpsilon = std::atof(optarg);
                }
                // Regularization options
                else if (strcmp(longopts[optionIndex].name, "regularization") == 0) {
                    std::string regType = optarg;
                    if (regType == "laplacian" || regType == "Laplacian" || regType == "LAPLACIAN") {
                        optimOptions.regularization = so::RegularizationType::Laplacian;
                    } else if (regType == "l2" || regType == "L2" || regType == "tikhonov" || regType == "Tikhonov") {
                        optimOptions.regularization = so::RegularizationType::L2;
                    } else if (regType == "tv" || regType == "TV" || regType == "totalvariation") {
                        optimOptions.regularization = so::RegularizationType::TV;
                    } else if (regType == "isolated" || regType == "Isolated" || regType == "ISOLATED") {
                        optimOptions.regularization = so::RegularizationType::Isolated;
                    } else {
                        optimOptions.regularization = so::RegularizationType::None;
                    }
                } else if (strcmp(longopts[optionIndex].name, "regularization_weight") == 0) {
                    optimOptions.regularizationWeight = std::atof(optarg);
                }
                // Image calculation options
                else if (strcmp(longopts[optionIndex].name, "resistModel") == 0) {
                    resistModelFile = optarg;
                } else if (strcmp(longopts[optionIndex].name, "dim0") == 0) {
                    imgOptions.dimx0 = imgOptions.dimy0 = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "dim") == 0) {
                    imgOptions.dimx = imgOptions.dimy = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "kernel") == 0) {
                    imgOptions.kernelNum = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "cellname") == 0) {
                    imgOptions.cellname = optarg;
                } else if (strcmp(longopts[optionIndex].name, "layer") == 0) {
                    std::stringstream ss(optarg);
                    std::string layerDatatype;
                    while (std::getline(ss, layerDatatype, ',')) {
                        size_t pos = layerDatatype.find('/');
                        if (pos != std::string::npos) {
                            int L = std::stoi(layerDatatype.substr(0, pos));
                            int D = std::stoi(layerDatatype.substr(pos + 1));
                            imgOptions.layers.emplace_back(L, D);
                        }
                    }
                }
                // Source correction options
                else if (strcmp(longopts[optionIndex].name, "interpolation") == 0) {
                    std::string method = optarg;
                    if (method == "bilinear" || method == "Bilinear" || method == "BILINEAR") {
                        correctionOptions.interpolation = so::InterpolationMethod::Bilinear;
                    } else {
                        correctionOptions.interpolation = so::InterpolationMethod::Nearest;
                    }
                } else if (strcmp(longopts[optionIndex].name, "debug_source") == 0) {
                    correctionOptions.debugOutputPath = optarg;
                }
                // Output options
                else if (strcmp(longopts[optionIndex].name, "cost_output") == 0) {
                    costOutputFile = optarg;
                } else if (strcmp(longopts[optionIndex].name, "log_output") == 0) {
                    logOutputFile = optarg;
                } else if (strcmp(longopts[optionIndex].name, "round_output") == 0) {
                    optimOptions.roundOutputPrefix = optarg;
                }
                break;
            case '?':
            default:
                printHelp(argv[0]);
                return 1;
        }
    }

    imgOptions.brightfield = (flagBrightfield == 1);
    correctionOptions.verbose = optimOptions.verbose;

    // 必須引数チェック
    if (socsSetDir.empty() || sourceGridFile.empty() || processConfigFile.empty() ||
        sourceFile.empty() || evpFile.empty() || layoutFile.empty() || outputFile.empty()) {
        std::cerr << "Error: Missing required arguments\n" << std::endl;
        printHelp(argv[0]);
        return 1;
    }

    try {
        // 入力ファイル読み込み
        if (mpiRank == 0) std::cerr << "Loading source_config: " << sourceGridFile << std::endl;
        so::SourceGrid sourceGrid;
        sourceGrid.load(sourceGridFile);

        if (mpiRank == 0) std::cerr << "Loading source_data: " << sourceFile << std::endl;
        so::SourceData sourceData;
        sourceData.load(sourceFile);

        if (mpiRank == 0) std::cerr << "Loading process_config: " << processConfigFile << std::endl;
        so::ProcessConfig processConfig;
        processConfig.load(processConfigFile);

        if (mpiRank == 0) std::cerr << "Loading evp_data: " << evpFile << std::endl;
        so::EvpData evpData;
        evpData.load(evpFile);

        // MPI並列数がclip数を超える場合、余剰ランクをスキップ
#ifdef HAVE_MPI_H
        bool isWorker = true;
        int numClips = evpData.showClipCount();
        if (mpiSize > 1 && mpiSize > numClips) {
            if (mpiRank == 0) {
                std::cerr << "Warning: MPI ranks (" << mpiSize << ") > clips ("
                          << numClips << "). Using only " << numClips << " ranks." << std::endl;
            }
            int color = (mpiRank < numClips) ? 0 : MPI_UNDEFINED;
            MPI_Comm_split(MPI_COMM_WORLD, color, mpiRank, &workComm);
            if (mpiRank >= numClips) {
                isWorker = false;
            } else {
                MPI_Comm_rank(workComm, &mpiRank);
                MPI_Comm_size(workComm, &mpiSize);
            }
        }
        if (!isWorker) {
            // 余剰ランク: stderr/stdoutを復元してfinalize
            if (savedStderr >= 0) {
                dup2(savedStderr, STDERR_FILENO);
                close(savedStderr);
                dup2(savedStdout, STDOUT_FILENO);
                close(savedStdout);
            }
            MPI_Finalize();
            return 0;
        }
#endif

        // 入力検証と自動修正
        if (mpiRank == 0) std::cerr << "Validating and correcting source data..." << std::endl;

        so::CorrectionResult correctionResult =
            so::validateAndCorrect(sourceData, sourceGrid, correctionOptions);

        if (mpiRank == 0) {
            if (correctionResult.hasCorrections()) {
                std::cerr << "Source data was corrected:" << std::endl;
                for (const auto& warning : correctionResult.warnings) {
                    std::cerr << "  " << warning << std::endl;
                }
            } else {
                std::cerr << "Source data validation passed." << std::endl;
            }
        }

        // SOCSファイル存在確認
        auto uniqueDefocuses = processConfig.showUniqueDefocuses();
        auto validPoints = sourceGrid.generateValidGridPoints();
        const auto& gridConfig = sourceGrid.showConfig();

        for (double defocus : uniqueDefocuses) {
            for (const auto& [gx, gy] : validPoints) {
                if (gridConfig.isD2Symmetry()) {
                    if (gx < 0 || gy < 0) continue;
                }

                std::string sourceID = so::SourceGrid::makeSourceID(std::abs(gx), std::abs(gy));
                if (!so::SocsFile::exists(socsSetDir, sourceID, defocus)) {
                    std::cerr << "Error: SOCS file not found for sourceID=" << sourceID
                              << ", defocus=" << defocus << std::endl;
                    return 1;
                }
            }
        }

        if (mpiRank == 0) std::cerr << "Validation passed." << std::endl;

        // Step 1: 光学像計算
        auto step1StartTime = std::chrono::high_resolution_clock::now();
        if (mpiRank == 0) {
            std::cerr << "===============================================" << std::endl;
            std::cerr << "Step 1: Calculating images in memory..." << std::endl;
            std::cerr << "  Clips: " << evpData.showClipCount() << std::endl;
            std::cerr << "  PWC conditions: " << processConfig.size() << std::endl;
            std::cerr << "  Threads: " << imgOptions.numThreads << std::endl;
            if (mpiSize > 1) {
                std::cerr << "  Image calculation distributed across " << mpiSize << " MPI ranks" << std::endl;
            }
        }

        so::ImageCalculator imageCalculator;
        imageCalculator.setSourceGrid(&sourceGrid);
        imageCalculator.setSourceData(&sourceData);
        imageCalculator.setProcessConfig(&processConfig);
        imageCalculator.setSocsSetDir(socsSetDir);
        imageCalculator.setOasisFile(layoutFile);
        imageCalculator.setResistModelFile(resistModelFile);
        imageCalculator.setOptions(imgOptions);
        imageCalculator.setMPI(mpiRank, mpiSize);

        std::string resistModelOutputDir = std::filesystem::path(outputFile).parent_path().string();
        if (resistModelOutputDir.empty()) {
            resistModelOutputDir = ".";
        }
        std::filesystem::create_directories(resistModelOutputDir);

        // resist modelファイル生成（rank 0のみ）+ バリアで同期
        if (mpiRank == 0) {
            auto uniqueMaskBiases = processConfig.showUniqueMaskBiases();
            so::ResistModelGenerator::generateAll(resistModelFile, resistModelOutputDir, uniqueMaskBiases);

            // デフォルトresistModelファイルを作成（resistModelFileが空/存在しない場合のフォールバック用）
            std::string defaultResistModelPath = resistModelOutputDir + "/resistModel_default.info";
            if (!std::filesystem::exists(defaultResistModelPath)) {
                if (!resistModelFile.empty() && std::filesystem::exists(resistModelFile)) {
                    std::filesystem::copy_file(resistModelFile, defaultResistModelPath);
                } else {
                    std::ofstream ofs(defaultResistModelPath);
                    ofs << "IntensityWeight 1" << std::endl;
                }
            }
        }
#ifdef HAVE_MPI_H
        MPI_Barrier(workComm);
#endif

        so::CalcResult calcResult = imageCalculator.calcImages(evpData, resistModelOutputDir);

        if (calcResult.sourceContributions.empty()) {
            std::cerr << "Error: No images calculated" << std::endl;
            return 1;
        }

        if (mpiRank == 0) std::cerr << "Calculated " << calcResult.sourceContributions.size() << " contribution sets." << std::endl;

        // MPI: 各ランクは自分の担当clipのcontribution setのみ保持。
        // 勾配・コストはMPI_Allreduceで集約されるため、データの共有は不要。

        // 座標系はμm単位で統一（calcCost, calcCostDirectと同じ）

        auto step1EndTime = std::chrono::high_resolution_clock::now();
        double step1Duration = std::chrono::duration<double>(step1EndTime - step1StartTime).count();
        if (mpiRank == 0) std::cerr << "Step 1 completed in " << formatDuration(step1Duration) << std::endl;

        // Step 2: 最適化
        auto step2StartTime = std::chrono::high_resolution_clock::now();
        if (mpiRank == 0) {
            std::cerr << "===============================================" << std::endl;
            std::cerr << "Step 2: Optimizing source..." << std::endl;
            std::cerr << "  Optimizer: " << (optimOptions.optimizer == so::OptimizerType::LBFGS ? "L-BFGS" : "Adam") << std::endl;
            std::cerr << "  Max iterations: " << optimOptions.maxIterations << std::endl;
            std::cerr << "  Gradient method: " << so::gradientMethodToString(optimOptions.gradientMethod)
                      << " (" << static_cast<int>(optimOptions.gradientMethod) << ")" << std::endl;
            if (optimOptions.gradientMethod == so::GradientMethod::QEPE_Numerical ||
                optimOptions.gradientMethod == so::GradientMethod::EPE_Numerical) {
                std::cerr << "  Numerical epsilon: " << optimOptions.numericalEpsilon << std::endl;
            }
            if (optimOptions.regularization != so::RegularizationType::None &&
                optimOptions.regularizationWeight > 0.0) {
                std::string regName;
                switch (optimOptions.regularization) {
                    case so::RegularizationType::Laplacian: regName = "Laplacian"; break;
                    case so::RegularizationType::L2: regName = "L2 (Tikhonov)"; break;
                    case so::RegularizationType::TV: regName = "TV (Total Variation)"; break;
                    default: regName = "None"; break;
                }
                std::cerr << "  Regularization: " << regName << " (weight=" << optimOptions.regularizationWeight << ")" << std::endl;
            }
            if (mpiSize > 1) {
                std::cerr << "  MPI ranks: " << mpiSize << std::endl;
            }
        }
        so::SourceOptimizer optimizer;
        optimizer.setOptions(optimOptions);
        optimizer.setSourceGrid(&sourceGrid);
        optimizer.setSourceData(&sourceData);
        optimizer.setEvpData(&evpData);
        optimizer.setProcessConfig(&processConfig);
        optimizer.setSourceContributions(&calcResult.sourceContributions);
        optimizer.setNA(calcResult.opticalParams.NA);
#ifdef HAVE_MPI_H
        optimizer.setMPIComm(workComm);
#endif

        // 勾配検証（オプション、rank 0のみ表示）
        if (flagVerifyGradient) {
            if (mpiRank == 0) {
                std::cerr << "-----------------------------------------------" << std::endl;
                std::cerr << "Verifying gradient..." << std::endl;
            }
            double maxRelError = optimizer.verifyGradient(1e-6);
            if (mpiRank == 0) {
                std::cerr << "Max relative error: " << std::scientific << std::setprecision(6) << maxRelError << std::endl;
                if (maxRelError > 1e-3) {
                    std::cerr << "Warning: Gradient verification failed!" << std::endl;
                } else {
                    std::cerr << "Gradient verification passed." << std::endl;
                }
                std::cerr << "-----------------------------------------------" << std::endl;
            }
            // verifyGradient内でストリームフォーマットが変更されるのでリセット
            std::cerr << std::fixed << std::setprecision(6);
        }

        // 初期コストを計算
        double initEpeCost, initFillCost;
        double initCost = optimizer.calculateCurrentCost(&initEpeCost, &initFillCost);
        if (mpiRank == 0) {
            std::cerr << "Initial cost: " << initCost
                      << " (EPE=" << initEpeCost << ", Fill=" << initFillCost << ")" << std::endl;
        }

        so::OptimizationResult result = optimizer.optimize();

        auto step2EndTime = std::chrono::high_resolution_clock::now();
        double step2Duration = std::chrono::duration<double>(step2EndTime - step2StartTime).count();

        // 結果出力（rank 0のみ）
        if (mpiRank == 0) {
            std::cerr << "\n===============================================" << std::endl;
            std::cerr << "Optimization completed!" << std::endl;
            std::cerr << "-----------------------------------------------" << std::endl;
            std::cerr << "  Converged:         " << (result.converged ? "Yes" : "No") << std::endl;
            std::cerr << "  Iterations:        " << result.iterations << std::endl;
            std::cerr << "  Termination:       " << result.terminationReason << std::endl;
            std::cerr << "  Final Cost:        " << result.finalCost << std::endl;
            std::cerr << "  Final EPE Cost:    " << result.finalEpeCost << std::endl;
            std::cerr << "  Final Fill Cost:   " << result.finalSourceFillCost << std::endl;
            std::cerr << "  Final Gradient:    " << result.finalGradientNorm << std::endl;
            std::cerr << "  Slice Level:       " << result.finalSliceLevel << std::endl;
            std::cerr << "  Source Fill Ratio: " << result.finalSourceFillRatio << std::endl;
            std::cerr << "-----------------------------------------------" << std::endl;

            // 最適化された光源を保存（stage-best復元済み）
            std::cerr << "Writing optimized source to: " << outputFile << std::endl;
            sourceData.save(outputFile);

            // PPMも同時に出力（outputFileの拡張子を.ppmに置き換え）
            std::string ppmFile = std::filesystem::path(outputFile).replace_extension(".ppm").string();
            try {
                std::cerr << "Writing optimized source PPM to: " << ppmFile << std::endl;
                sourceData.savePpm(ppmFile, sourceGrid);
            } catch (const std::exception& e) {
                std::cerr << "Warning: Failed to save PPM: " << e.what() << std::endl;
            }

            // ログ出力
            if (!logOutputFile.empty()) {
                std::cerr << "Writing optimization log to: " << logOutputFile << std::endl;
                writeLog(logOutputFile, result);
            }
        }

        // 最終コスト計算: calcCostDirect と同じ CostCalculator を使い、
        // per-evp の EPE/QEPE と |EPE|/|QEPE| のピーク情報まで含む cost.csv を書き出す。
        // ※ MPI 並列時は CostCalculator が clip を分散して計算し
        //   MPI_Allgatherv で集約するので、全 rank で同期して呼ぶ必要がある。
        if (!costOutputFile.empty()) {
            // 全 rank で実行（CostCalculator が内部で MPI 集約）
            so::CostOptions costOpts;
            costOpts.sliceLevel = optimizer.sliceLevel();
            costOpts.weightFill = optimOptions.weightFillPenalty;
            costOpts.minSourceFillRatio = optimOptions.minSourceFillRatio;
            costOpts.useExponentialFillPenalty = optimOptions.useExponentialFillPenalty;
            costOpts.fillPenaltyExponent = optimOptions.fillPenaltyExponent;
            costOpts.weightNils = optimOptions.weightNilsPenalty;
            costOpts.nilsMin = optimOptions.nilsMin;
            costOpts.nilsCdReference = optimOptions.nilsCdReference;

            so::CostCalculator costCalculator;
            costCalculator.setOptions(costOpts);
            costCalculator.setMPI(mpiRank, mpiSize);
#ifdef HAVE_MPI_H
            costCalculator.setMPIComm(workComm);
#endif

            double sourceFillRatio = sourceData.calcSourceFillRatio(calcResult.opticalParams.NA);
            so::CostResult costResult = costCalculator.calculate(
                calcResult.sourceContributions, sourceData, gridConfig,
                evpData, processConfig, sourceFillRatio);

            // 書き出し・表示は rank 0 のみ
            if (mpiRank == 0) {
                std::cerr << "Calculating final costs..." << std::endl;
                std::cerr << "Writing cost results to: " << costOutputFile << std::endl;
                so::CostWriter::write(costOutputFile, costResult);

                std::cerr << "-----------------------------------------------" << std::endl;
                std::cerr << "  Slice Level:       " << costResult.sliceLevel << std::endl;
                std::cerr << "  EPE Cost:          " << costResult.EPE_cost << std::endl;
                std::cerr << "  QEPE Cost:         " << costResult.QEPE_cost << std::endl;
                std::cerr << "  Source Fill Cost:  " << costResult.source_fill_cost << std::endl;
                std::cerr << "  NILS Cost:         " << costResult.NILS_cost << std::endl;
                std::cerr << "  Total Cost:        " << costResult.total_cost << std::endl;
                std::cerr << "  Total Cost (QEPE): " << costResult.total_cost_QEPE << std::endl;
                std::cerr << "  max |EPE|:         " << costResult.maxAbsEPE << std::endl;
                std::cerr << "  max |QEPE|:        " << costResult.maxAbsQEPE << std::endl;
                std::cerr << "  EPE Results:       " << costResult.epeResults.size() << std::endl;
            }
        }

        auto totalEndTime = std::chrono::high_resolution_clock::now();
        double totalDuration = std::chrono::duration<double>(totalEndTime - totalStartTime).count();

        if (mpiRank == 0) {
            std::cerr << "===============================================" << std::endl;
            std::cerr << "Execution Time Summary:" << std::endl;
            std::cerr << "  Step 1 (Image calc):   " << formatDuration(step1Duration) << std::endl;
            std::cerr << "  Step 2 (Optimization): " << formatDuration(step2Duration) << std::endl;
            std::cerr << "  Total:                 " << formatDuration(totalDuration) << std::endl;
            std::cerr << "===============================================" << std::endl;
        }

    } catch (const std::exception& e) {
        // エラー時はstderr/stdoutを復元してからメッセージ出力
        if (savedStderr >= 0) {
            dup2(savedStderr, STDERR_FILENO);
            close(savedStderr);
            dup2(savedStdout, STDOUT_FILENO);
            close(savedStdout);
        }
        std::cerr << "Error: " << e.what() << std::endl;
#ifdef HAVE_MPI_H
        MPI_Finalize();
#endif
        return 1;
    }

    // stderr/stdoutを復元
    if (savedStderr >= 0) {
        dup2(savedStderr, STDERR_FILENO);
        close(savedStderr);
        dup2(savedStdout, STDOUT_FILENO);
        close(savedStdout);
    }

#ifdef HAVE_MPI_H
    if (workComm != MPI_COMM_WORLD) {
        MPI_Comm_free(&workComm);
    }
    MPI_Finalize();
#endif
    return 0;
}
