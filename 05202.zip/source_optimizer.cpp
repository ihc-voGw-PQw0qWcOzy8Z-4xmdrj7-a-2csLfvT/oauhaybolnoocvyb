/*!
 * @file source_optimizer.cpp
 * @brief メイン最適化クラスの実装
 */

#include "source_optimizer.h"
#include "lbfgs_optimizer.h"
#include "adam_optimizer.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <random>

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

namespace so {

SourceOptimizer::SourceOptimizer() {}

SourceOptimizer::~SourceOptimizer() {}

void SourceOptimizer::setOptions(const OptimizationOptions& options) {
    m_options = options;
    m_constraintHandler.setOptions(options);
    m_gradientCalculator.setOptions(options);
}

void SourceOptimizer::setSourceGrid(const SourceGrid* sourceGrid) {
    m_sourceGrid = sourceGrid;
}

void SourceOptimizer::setSourceData(SourceData* sourceData) {
    m_sourceData = sourceData;
}

void SourceOptimizer::setEvpData(EvpData* evpData) {
    m_evpData = evpData;
}

void SourceOptimizer::setProcessConfig(const ProcessConfig* processConfig) {
    m_processConfig = processConfig;
}

void SourceOptimizer::setSourceContributions(
    const std::map<std::string, SourceContributionSet>* sourceContributions) {
    m_sourceContributions = sourceContributions;
    m_gradientCalculator.setSourceContributions(sourceContributions);
}

void SourceOptimizer::setNA(double NA) {
    m_NA = NA;
    m_gradientCalculator.setNA(NA);
}

void SourceOptimizer::createOptimizer() {
    if (m_options.optimizer == OptimizerType::LBFGS) {
        m_optimizer = std::make_unique<LBFGSOptimizer>();
    } else {
        m_optimizer = std::make_unique<AdamOptimizer>();
    }
    m_optimizer->setOptions(m_options);
}

// ============================================================================
// 公開API: Two-Stage対応の最適化エントリポイント
// ============================================================================

OptimizationResult SourceOptimizer::optimize() {
    int mpiRank = 0, mpiSize = 1;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
    MPI_Comm_size(m_mpiComm, &mpiSize);
#endif

    // ===== Multi-Stage（epePowerSchedule が指定されている場合は最優先）=====
    if (!m_options.epePowerSchedule.empty()) {
        if (m_options.verbose && mpiRank == 0) {
            std::cerr << "\n###############################################" << std::endl;
            std::cerr << "# Multi-Stage Optimization Enabled            #" << std::endl;
            std::cerr << "# Schedule:";
            for (int p : m_options.epePowerSchedule) std::cerr << " " << p;
            std::cerr << std::endl;
            std::cerr << "###############################################" << std::endl;
        }

        auto savedOptions = m_options;
        OptimizationResult mergedResult;
        mergedResult.iterations = 0;

        // 最終 stage の解をそのまま採用する。
        // stage 内では cost 基準で running best が keep されており、
        // stage 切り替わり時に前 stage 解の新 stage cost が初期値として登録されるため、
        // 「stage 内で改善できなくても前 stage 解が残る」構造的保証がある。
        // したがって maxAbsEPE 基準の Stage 間 rollback は不要 (BT/BFS 効果を捨てないため削除)。
        std::vector<double> globalBestVars;
        double globalBestSliceLevel = m_sliceLevel;
        std::string lastReason;

        m_options.enableTwoStage = false;  // 再帰防止

        for (size_t s = 0; s < savedOptions.epePowerSchedule.size(); ++s) {
            int p = savedOptions.epePowerSchedule[s];
            int stageIdx = static_cast<int>(s + 1);
            if (m_options.verbose && mpiRank == 0) {
                std::cerr << "\n=== Stage " << stageIdx << "/"
                          << savedOptions.epePowerSchedule.size()
                          << ": EPE^" << p << " ===" << std::endl;
            }

            m_options.epePower = p;
            // IRLS schedule 適用（指定があれば stage ごとに p / floor を切替）
            if (!savedOptions.adaptiveWeightExponentSchedule.empty()) {
                size_t idx = std::min(s, savedOptions.adaptiveWeightExponentSchedule.size() - 1);
                m_options.adaptiveWeightExponent = savedOptions.adaptiveWeightExponentSchedule[idx];
            }
            if (!savedOptions.adaptiveWeightFloorSchedule.empty()) {
                size_t idx = std::min(s, savedOptions.adaptiveWeightFloorSchedule.size() - 1);
                m_options.adaptiveWeightFloor = savedOptions.adaptiveWeightFloorSchedule[idx];
            }
            if (!savedOptions.roundOutputPrefix.empty()) {
                m_options.roundOutputPrefix = savedOptions.roundOutputPrefix
                    + "_stage" + std::to_string(stageIdx);
            }
            // Stage 1 以外: ユーザが --sliceLevel 未指定なら前 stage の sliceLevel を継承
            if (s > 0 && savedOptions.sliceLevel < 0 && m_sliceLevel >= 0) {
                m_options.sliceLevel = m_sliceLevel;
            }
            // Stage 切替時に LBFGS 履歴を必ずクリア:
            // epePower 変更でコスト関数のスケール (1/EPE_REF^n) が大きく変わるため、
            // 前 stage の (s, y) 履歴は陳腐化している。継承すると Line search が破綻。
            m_optimizer.reset();

            // SA 風摂動は Stage 1 のみ有効化（局所解脱出が目的なので初回のみ）
            m_saActive = (savedOptions.saAmplitudeInit > 0.0)
                       && (savedOptions.saAllStages || s == 0);

            auto stageResult = optimizeSingleStage();
            for (auto& entry : stageResult.log) entry.stage = stageIdx;

            // 各 stage 終了時の解をそのまま採用 (Stage 間 rollback 廃止)。
            // stage 内では cost 基準の running best が keep されているため、
            // stage 内で改善できなければ前 stage 解と同等の illum が finalVariables に入る。
            // よって BT/BFS の効果を維持しつつ「悪化しない保証」も満たされる。
            globalBestVars = stageResult.finalVariables;
            globalBestSliceLevel = m_sliceLevel;
            if (m_options.verbose && mpiRank == 0) {
                std::cerr << "Stage " << stageIdx << " final cost=" << stageResult.finalCost
                          << std::endl;
            }

            mergedResult.log.insert(mergedResult.log.end(),
                stageResult.log.begin(), stageResult.log.end());
            mergedResult.iterations += stageResult.iterations;
            mergedResult.converged = stageResult.converged;
            lastReason = stageResult.terminationReason;
        }

        // 最終 best を sourceData に書き戻す
        if (!globalBestVars.empty()) {
            size_t nSrc = m_variableMapping.numVariables();
            if (m_options.sliceAsVariable && globalBestVars.size() == nSrc + 1) {
                std::vector<double> srcVars(globalBestVars.begin(),
                                            globalBestVars.begin() + nSrc);
                m_variableMapping.variablesToSource(srcVars, *m_sourceData);
                m_sliceLevel = globalBestVars[nSrc];
            } else {
                m_variableMapping.variablesToSource(globalBestVars, *m_sourceData);
                m_sliceLevel = globalBestSliceLevel;
            }
        }

        m_options = savedOptions;
        // 最終 stage の epePower を保持してコスト再計算
        m_options.epePower = savedOptions.epePowerSchedule.back();

        // 最終結果 fields
        double epeCost, fillCost, nilsCost;
        mergedResult.finalCost = m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel,
            m_options.epePower, &epeCost, &fillCost, &nilsCost);
        mergedResult.finalEpeCost = epeCost;
        mergedResult.finalSourceFillCost = fillCost;
        mergedResult.finalNilsCost = nilsCost;
        mergedResult.finalSliceLevel = m_sliceLevel;
        mergedResult.finalSourceFillRatio = m_sourceData->calcSourceFillRatio(m_NA);
        mergedResult.finalVariables = globalBestVars;
        mergedResult.terminationReason = "Multi-stage: " + lastReason;
        return mergedResult;
    }

    if (!m_options.enableTwoStage) {
        return optimizeSingleStage();
    }

    // Two-Stage optimization
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\n###############################################" << std::endl;
        std::cerr << "# Two-Stage Optimization Enabled              #" << std::endl;
        std::cerr << "###############################################" << std::endl;
    }

    auto savedOptions = m_options;

    // Stage 1: epePower (デフォルト: EPE²)
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\n=== Stage 1: EPE^" << m_options.epePower << " optimization ===" << std::endl;
    }
    m_options.enableTwoStage = false;  // 再帰防止
    if (!m_options.roundOutputPrefix.empty()) {
        m_options.roundOutputPrefix = savedOptions.roundOutputPrefix + "_stage1";
    }
    auto stage1Result = optimizeSingleStage();
    // stage1のログエントリにstage=1を付与
    for (auto& entry : stage1Result.log) {
        entry.stage = 1;
    }
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\nStage 1 completed:" << std::endl;
        std::cerr << "  Cost: " << stage1Result.finalCost << std::endl;
        std::cerr << "  Iterations: " << stage1Result.iterations << std::endl;
    }

    // Stage 2: epePowerStage2 (デフォルト: EPE⁴)
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\n=== Stage 2: EPE^" << savedOptions.epePowerStage2 << " optimization ===" << std::endl;
    }
    m_options.epePower = savedOptions.epePowerStage2;
    if (!savedOptions.roundOutputPrefix.empty()) {
        m_options.roundOutputPrefix = savedOptions.roundOutputPrefix + "_stage2";
    }
    // Stage 1 末で確定した sliceLevel を Stage 2 の round=0 に引き継ぐ。
    // 引き継がない場合、optimizeSingleStage の round=0 で sliceLevel < 0 と
    // 判定されて findOptimalSliceLevel() が再呼出され、Stage 1 のチューニング
    // 結果が無駄になる。ユーザが明示的に --sliceLevel を指定していた場合は
    // savedOptions.sliceLevel が >=0 なのでその設定を尊重する。
    if (savedOptions.sliceLevel < 0 && m_sliceLevel >= 0) {
        m_options.sliceLevel = m_sliceLevel;
    }
    auto stage2Result = optimizeSingleStage();
    // stage2のログエントリにstage=2を付与
    for (auto& entry : stage2Result.log) {
        entry.stage = 2;
    }
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "\nStage 2 completed:" << std::endl;
        std::cerr << "  Cost: " << stage2Result.finalCost << std::endl;
        std::cerr << "  Iterations: " << stage2Result.iterations << std::endl;
    }

    // オプションを復元（ただしepePowerはstage2の値のままにして、
    // 後段のcalculateCurrentCost(=cost.csv)が最終stageのコスト関数を使うようにする）
    int finalEpePower = m_options.epePower;
    m_options = savedOptions;
    m_options.epePower = finalEpePower;

    // 結果をマージ（Stage 1のログをStage 2の前に挿入）
    OptimizationResult result = stage2Result;
    result.log.insert(result.log.begin(), stage1Result.log.begin(), stage1Result.log.end());
    result.iterations = stage1Result.iterations + stage2Result.iterations;
    result.terminationReason = "Two-stage: " + stage2Result.terminationReason;

    return result;
}

// ============================================================================
// 単一ステージの最適化（ラウンドループ含む）
// ============================================================================

OptimizationResult SourceOptimizer::optimizeSingleStage() {
    OptimizationResult result;

    // MPIランク情報を取得
    int mpiRank = 0, mpiSize = 1;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
    MPI_Comm_size(m_mpiComm, &mpiSize);
#endif
    m_gradientCalculator.setMPI(mpiRank, mpiSize);
#ifdef HAVE_MPI_H
    m_gradientCalculator.setMPIComm(m_mpiComm);
#endif

    // rank 0以外はverboseを無効化（ログ重複を防止）
    bool savedVerbose = m_options.verbose;
    if (mpiRank != 0) {
        m_options.verbose = false;
    }

    // OpenMPスレッド数を設定
#ifdef _OPENMP
    if (m_options.numThreads > 0) {
        omp_set_num_threads(m_options.numThreads);
    }
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "OpenMP threads: " << omp_get_max_threads() << std::endl;
    }
#endif

    // 時間計測用カウンターをリセット
    m_gradientCallCount = 0;
    m_totalGradientTime = 0.0;
    m_costCallCount = 0;
    m_totalCostTime = 0.0;

    // 前提条件チェック
    if (!m_sourceGrid || !m_sourceData || !m_evpData || !m_processConfig || !m_sourceContributions) {
        result.converged = false;
        result.terminationReason = "Missing required data";
        return result;
    }

    // 変数マッピングを初期化
    m_variableMapping.initialize(*m_sourceGrid, *m_sourceData);
    m_gradientCalculator.setVariableMapping(&m_variableMapping);

    // adaptive weighting (IRLS) 用に元の weight を保存
    // stage 開始時点の weight を覚えておき、各 round 末に
    //   w_i_new = max(floor, (|EPE_i|/maxEPE)^p) × w_i_orig
    // で更新する。stage 末で元に戻す。
    if (m_options.adaptiveWeightExponent > 0.0 && m_evpData) {
        const auto& eps = m_evpData->showEvalPoints();
        if (m_originalEvpWeights.size() != eps.size()) {
            m_originalEvpWeights.resize(eps.size());
            for (size_t i = 0; i < eps.size(); ++i) {
                m_originalEvpWeights[i] = eps[i].weight;
            }
        }
    }

    if (m_variableMapping.numVariables() == 0) {
        result.converged = false;
        result.terminationReason = "No variables to optimize";
        return result;
    }

    if (m_options.verbose) {
        std::cerr << "Optimization variables: " << m_variableMapping.numVariables() << std::endl;
        if (mpiSize > 1) {
            size_t numClips = m_evpData->showClips().size();
            std::cerr << "MPI ranks: " << mpiSize << std::endl;
            std::cerr << "  Total clips: " << numClips << std::endl;
            for (int r = 0; r < mpiSize; ++r) {
                size_t count = 0;
                for (size_t c = 0; c < numClips; ++c) {
                    if (c % static_cast<size_t>(mpiSize) == static_cast<size_t>(r)) ++count;
                }
                std::cerr << "  Rank " << r << ": " << count << " clips" << std::endl;
            }
        }
    }

    // 外部ループ回数
    int numRounds = std::max(1, m_options.sliceLevelOptimizationRounds);
    std::vector<double> roundCostHistory;

    // Stage内（round跨ぎ）のbest追跡
    // 最良cost時点のvariables/sliceLevelを保持し、stage終了時に復元する。
    // そのstage内で観測された最良costの累積（running min）もログに記録。
    double stageBestCost = std::numeric_limits<double>::infinity();
    std::vector<double> stageBestVariables;
    double stageBestSliceLevel = m_sliceLevel;

    // 注: 旧 picked* トラッカー (feasibility + EPE_cost 比較) は廃止した。
    // 理由: 最適化器が minimize する量 (cost、IRLS で動的変化) と
    //       picked 比較指標 (重み非依存 EPE_cost) が乖離し、
    //       「cost が減るのに picked が停滞して最適化しきれていない解が出力される」
    //       問題が発生していた。今は stageBestCost (= stage 内 running min cost) を
    //       唯一の最終選択基準とする。feasibility は cost の指数 fill penalty が強制する。

    // fill weight 連続化
    double baseFillWeight = m_options.weightFillPenalty;
    double currentFillWeight = baseFillWeight;

    // ====== 適応的 sliceLevel 更新スケジューラ ======
    // 各 round の長さ（iteration 数）を指数的に増加させる:
    //   round 0: K = sliceUpdateIntervalInit
    //   round k: K *= sliceUpdateIntervalGrowth (上限 sliceUpdateIntervalMax)
    // ただし直前 round の cost 改善率が大きいときは K をリセット（fast reset）、
    // 小さいときは K を増やさない（slow freeze）。
    // round 終了時の sliceLevel 再計算により、初期は頻繁・収束では低頻度になる。
    int currentRoundIter = std::max(1, m_options.sliceUpdateIntervalInit);
    double prevRoundCost = std::numeric_limits<double>::infinity();
    // iter=1 停滞検出: 連続して iter=1 で Line search failed が続くと
    // 計算リソースが無駄になるので、N 回連続で発生したら stage を打ち切る
    int consecutiveStallRounds = 0;
    constexpr int MAX_STALL_ROUNDS = 3;

    for (int round = 0; round < numRounds; ++round) {
        if (numRounds > 1 && mpiRank == 0) {
            std::cerr << "\n=== Optimization Round " << (round + 1) << "/" << numRounds
                      << " ===" << std::endl;
        }

        // この round に適用する fill weight を反映し、
        // gradient calculator（および既存 optimizer）へ伝搬する
        m_options.weightFillPenalty = currentFillWeight;
        m_gradientCalculator.setOptions(m_options);

        // sliceLevel の更新と LBFGS 履歴の取扱い:
        //   - round==0: 必ず再計算（stage 開始時）→ optimizer 新規作成
        //   - round>0:  再計算する → optimizer 新規作成（履歴クリアで再起動効果）
        //               再計算しない → 旧 optimizer を再利用（履歴を継承して深く掘る）
        bool sliceUpdated = false;
        if (m_options.sliceAsVariable) {
            // sliceLevel は最適化変数として LBFGS が動かすため、
            // round 末で再計算しない。round=0 のときだけ初期化。
            if (round == 0) {
                if (m_options.sliceLevel >= 0) {
                    m_sliceLevel = m_options.sliceLevel;
                } else {
                    m_sliceLevel = findOptimalSliceLevel();
                }
                sliceUpdated = true;
            }
        } else if (round == 0) {
            if (m_options.sliceLevel >= 0) {
                m_sliceLevel = m_options.sliceLevel;
            } else {
                m_sliceLevel = findOptimalSliceLevel();
            }
            sliceUpdated = true;
        } else {
            // 再計算: 適応的スケジューラ + 旧 sliceRecomputePerRound（後方互換）
            if (m_options.sliceRecomputePerRound || true /* default: recompute per round */) {
                double newSlice = findOptimalSliceLevel();
                // 相対閾値で「実質的に意味のある変化」のみ更新扱いにする。
                // 微小な drift で毎 round 履歴クリアされて深く掘れない問題への対処。
                // 0.5% 以下の変化なら sliceLevel は更新するが LBFGS 履歴は継承する。
                double relChange = std::abs(newSlice - m_sliceLevel)
                                   / std::max(std::abs(m_sliceLevel), 1e-9);
                m_sliceLevel = newSlice;  // 値は常に最新化
                if (relChange > 0.005) {  // 0.5% 以上の変化なら履歴クリア
                    sliceUpdated = true;
                }
            }
        }

        // ==== SA 風 sliceLevel 摂動 ====
        // Stage 1 の最初の saMaxRounds round で sliceLevel を意図的に大きく揺さぶり、
        // 局所最適解からの脱出を促す。amplitude は cooling^round で減衰。
        // amplitude が sliceMin 未満になったら摂動停止 → 普通の最適化へ移行。
        if (m_saActive && round < m_options.saMaxRounds) {
            // 初回呼出し時に乱数生成器を初期化（再現性のため stage ごとにシード固定）
            static thread_local std::mt19937 sa_rng(0);
            static thread_local int sa_last_seed = -1;
            if (m_options.saSeed != sa_last_seed) {
                sa_rng.seed(static_cast<unsigned>(m_options.saSeed));
                sa_last_seed = m_options.saSeed;
            }
            std::normal_distribution<double> normal(0.0, 1.0);

            double amplitude = m_options.saAmplitudeInit
                * std::pow(m_options.saCoolingRate, round);
            // amplitude が小さすぎる場合は摂動しない
            if (amplitude > 1e-4) {
                double perturbation = amplitude * normal(sa_rng);
                double perturbedSlice = m_sliceLevel + perturbation;
                // sliceMin/sliceMax で clamp（sliceAsVariable と共通の Box）
                if (perturbedSlice < m_options.sliceMin) perturbedSlice = m_options.sliceMin;
                if (perturbedSlice > m_options.sliceMax) perturbedSlice = m_options.sliceMax;

                if (mpiRank == 0) {
                    std::cerr << "  SA perturbation (round " << round
                              << ", amp=" << amplitude << "): slice "
                              << m_sliceLevel << " -> " << perturbedSlice << std::endl;
                }
                m_sliceLevel = perturbedSlice;
                sliceUpdated = true;  // 必ず履歴クリア（コスト関数が変わるため）
            }
        }

        if (m_options.verbose && mpiRank == 0) {
            std::cerr << "Slice level: " << m_sliceLevel
                      << (sliceUpdated ? " (updated)" : " (unchanged)") << std::endl;
            if (std::abs(currentFillWeight - baseFillWeight) > 0.0) {
                std::cerr << "weightFillPenalty: " << currentFillWeight
                          << " (base=" << baseFillWeight << ")" << std::endl;
            }
        }

        // optimizer 作成: sliceLevel 更新時または初回のみ新規作成（履歴クリア）。
        // sliceLevel が変わらないなら旧 optimizer を再利用して履歴を継承する。
        if (sliceUpdated || !m_optimizer) {
            createOptimizer();
        }

        // この round で実行する iteration 数を決定する。
        // - SA 期間中 (Stage 1 の最初の saMaxRounds round): K を短く (3〜8)
        //   して sliceLevel 更新を高頻度にし、coarse な解空間探索を促す。
        // - それ以外: 適応的スケジューラの currentRoundIter を使う。
        // - 最後にユーザー指定の m_options.maxIterations を round 内上限として適用。
        OptimizationOptions roundOptions = m_options;
        int effectiveRoundIter = currentRoundIter;
        if (m_saActive && round < m_options.saMaxRounds) {
            // SA 期間中は短い round を使う（毎 round sliceLevel が変わる）
            effectiveRoundIter = std::max(3, std::min(8, currentRoundIter));
        }
        // ユーザー指定 --max_iter を round 内 iter 上限として尊重する
        if (m_options.maxIterations > 0) {
            effectiveRoundIter = std::min(effectiveRoundIter, m_options.maxIterations);
        }
        roundOptions.maxIterations = effectiveRoundIter;
        if (round > 0) {
            roundOptions.lbfgsMinIterations = std::max(1, m_options.lbfgsMinIterations);
        }
        m_optimizer->setOptions(roundOptions);

        // 現在の変数を取得
        std::vector<double> x0 = m_variableMapping.sourceToVariables(*m_sourceData);
        // sliceAsVariable モード: 末尾に sliceLevel を追加
        if (m_options.sliceAsVariable) {
            x0.push_back(m_sliceLevel);
        }

        // 最適化を実行
        OptimizationResult roundResult = m_optimizer->optimize(
            x0,
            [this](const std::vector<double>& vars) { return costFunction(vars); },
            [this](const std::vector<double>& vars) { return gradientFunction(vars); },
            [this](std::vector<double>& vars) { projectionFunction(vars); }
        );

        // 最良解をsourceDataに復元
        if (!roundResult.finalVariables.empty()) {
            size_t nSrc = m_variableMapping.numVariables();
            if (m_options.sliceAsVariable && roundResult.finalVariables.size() == nSrc + 1) {
                std::vector<double> srcVars(roundResult.finalVariables.begin(),
                                            roundResult.finalVariables.begin() + nSrc);
                m_variableMapping.variablesToSource(srcVars, *m_sourceData);
                m_sliceLevel = roundResult.finalVariables[nSrc];
            } else {
                m_variableMapping.variablesToSource(roundResult.finalVariables, *m_sourceData);
            }
        }

        // ラウンド情報とsliceLevelをログに記録
        // iteration は optimizer 側で既にround-local値（0..N）なので、そのまま使用
        // stageBestCost はstage内running min（このroundの各entry.costを順次取り込む）
        double roundFillRatio = m_sourceData->calcSourceFillRatio(m_NA);

        // Round終了時のbreakdown（EPE/Fill/NILS）を最後の entry に記録するために先に計算
        // feasibility は浮動小数点誤差を考慮した tolerance 込みで判定。
        // 0.07000-ε の境界が「Round で十分到達した」のに infeasible 扱いされて
        // 永久にエスカレーションが続くのを防ぐ。
        const double feasibilityTol = 1e-6;
        bool roundFeasible = (roundFillRatio >= m_options.minSourceFillRatio - feasibilityTol);
        double roundEpeCost = 0.0;
        double roundFillCostOnly = 0.0;
        double roundNilsCost = 0.0;
        m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig,
            m_sliceLevel, m_options.epePower, &roundEpeCost, &roundFillCostOnly, &roundNilsCost);

        // breakdown（EPE/Fill/NILS）は round 末状態のものを全 entry に伝搬する。
        // 途中 iteration ごとに breakdown を再計算するコストは高いため、
        // round 末値で埋めることでログ可視化時のゼロ穴を防ぐ。
        // （途中値が必要なら entry.cost の総和から逆算可能。）
        for (size_t ei = 0; ei < roundResult.log.size(); ++ei) {
            auto& entry = roundResult.log[ei];
            entry.round = round;
            entry.sliceLevel = m_sliceLevel;
            entry.sourceFillRatio = roundFillRatio;
            if (entry.cost < stageBestCost) {
                stageBestCost = entry.cost;
                stageBestSliceLevel = m_sliceLevel;
            }
            entry.stageBestCost = stageBestCost;
            entry.stageBestSliceLevel = stageBestSliceLevel;
            entry.epeCost = roundEpeCost;
            entry.sourceFillCost = roundFillCostOnly;
            entry.nilsCost = roundNilsCost;
            // 旧 picked* カラムは log 互換性のため stageBest と同じ値で埋める。
            // (picked 廃止後、これらは実質 stageBest のミラー)
            entry.pickedEpeCost = stageBestCost;
            entry.pickedTotalCost = stageBestCost;
            entry.pickedFeasible = roundFeasible ? 1 : 0;
            result.log.push_back(entry);
        }

        // Round終了時のbest（=roundResult.finalCost）を用いてstage-best候補を更新
        if (!roundResult.finalVariables.empty() && roundResult.finalCost <= stageBestCost) {
            stageBestCost = roundResult.finalCost;
            stageBestVariables = roundResult.finalVariables;
            stageBestSliceLevel = m_sliceLevel;
        }

        // ====== Adaptive Weighting (IRLS) 重み更新 ======
        // round 末に各評価点の |EPE_i| を測定し、次 round の weight を更新する。
        //   w_i_new = max(floor, (|EPE_i| / maxEPE)^p) × w_i_orig
        // p (adaptiveWeightExponent) を上げるほど worst 点に集中する近似 minimax。
        // feasible なときのみ適用（infeasible 中は fill 制約を優先）。
        if (m_options.adaptiveWeightExponent > 0.0
            && roundFeasible
            && !m_originalEvpWeights.empty()) {
            so::CostOptions costOpts;
            costOpts.sliceLevel = m_sliceLevel;
            costOpts.weightFill = 0.0;
            costOpts.minSourceFillRatio = 0.0;
            so::CostCalculator costCalc;
            costCalc.setOptions(costOpts);
            costCalc.setMPI(mpiRank, mpiSize);
#ifdef HAVE_MPI_H
            costCalc.setMPIComm(m_mpiComm);
#endif

            const auto& gridConfig = m_sourceGrid->showConfig();
            double sourceFillRatio = m_sourceData->calcSourceFillRatio(m_NA);
            so::CostResult cr = costCalc.calculate(
                *m_sourceContributions, *m_sourceData, gridConfig,
                *m_evpData, *m_processConfig, sourceFillRatio);

            const auto& origEps = m_evpData->showEvalPoints();
            std::vector<double> maxAbsEpePerEvp(origEps.size(), 0.0);
            for (const auto& er : cr.epeResults) {
                if (er.evpIndex >= 0 && static_cast<size_t>(er.evpIndex) < origEps.size()) {
                    double a = std::abs(er.EPE);
                    if (a > maxAbsEpePerEvp[er.evpIndex]) {
                        maxAbsEpePerEvp[er.evpIndex] = a;
                    }
                }
            }

            double globalMaxAbs = 0.0;
            for (double v : maxAbsEpePerEvp) {
                if (v > globalMaxAbs) globalMaxAbs = v;
            }

            if (globalMaxAbs > 1e-12) {
                std::vector<double> newWeights(origEps.size());
                double p = m_options.adaptiveWeightExponent;
                double floor = m_options.adaptiveWeightFloor;
                for (size_t i = 0; i < origEps.size(); ++i) {
                    double rel = maxAbsEpePerEvp[i] / globalMaxAbs;
                    double scale = std::max(floor, std::pow(rel, p));
                    newWeights[i] = m_originalEvpWeights[i] * scale;
                }
                m_evpData->setEvalPointWeights(newWeights);
                if (mpiRank == 0) {
                    std::cerr << "  Adaptive weighting (IRLS, p=" << p
                              << ", floor=" << floor
                              << "): max|EPE|=" << globalMaxAbs
                              << " μm, weights updated" << std::endl;
                }
            }
        }

        // fill weight 連続化: infeasible なら次 round で重みを増倍
        if (!roundFeasible
            && m_options.fillWeightMultiplier > 1.0
            && currentFillWeight < m_options.fillWeightMax) {
            double newWeight = std::min(
                currentFillWeight * m_options.fillWeightMultiplier,
                m_options.fillWeightMax);
            if (mpiRank == 0) {
                std::cerr << "  Fill ratio " << roundFillRatio
                          << " < min " << m_options.minSourceFillRatio
                          << ", escalating weightFillPenalty: "
                          << currentFillWeight << " -> " << newWeight << std::endl;
            }
            currentFillWeight = newWeight;
        }

        // 結果を統合
        result.iterations += roundResult.iterations;
        result.converged = roundResult.converged;
        result.terminationReason = roundResult.terminationReason;
        result.finalCost = roundResult.finalCost;
        result.finalGradientNorm = roundResult.finalGradientNorm;

        if (numRounds > 1 && mpiRank == 0) {
            std::cerr << "Round " << (round + 1) << " completed: cost=" << std::fixed << std::setprecision(6)
                      << roundResult.finalCost
                      << ", iterations=" << roundResult.iterations
                      << ", reason=" << roundResult.terminationReason << std::endl;
        }

        // ラウンドごとのPPM出力（rank 0のみ）
        if (!m_options.roundOutputPrefix.empty() && m_sourceGrid && mpiRank == 0) {
            std::string ppmFilename = m_options.roundOutputPrefix
                + "_round" + std::to_string(round + 1) + ".ppm";
            try {
                m_sourceData->savePpm(ppmFilename, *m_sourceGrid);
                std::cerr << "  Saved round " << (round + 1) << " source to: " << ppmFilename << std::endl;
            } catch (const std::exception& e) {
                std::cerr << "  Warning: Failed to save PPM: " << e.what() << std::endl;
            }
        }

        // ラウンド間収束判定
        // ただし infeasible（fill 制約未達）の round では fill weight を
        // エスカレーションしている最中なのでコスト変化が小さくても収束扱いしない。
        // feasible 領域に入るまでは収束判定をスキップする。
        double currentCost = roundResult.finalCost;
        roundCostHistory.push_back(currentCost);
        int w = m_options.roundConvergenceWindow;
        bool inSAPeriod = (m_saActive && round < m_options.saMaxRounds);
        if (!roundFeasible) {
            // infeasible: 収束判定をスキップ（fill 制約を満たすまで続行）
        } else if (inSAPeriod) {
            // SA 期間中: cost は摂動で振動するので収束判定無効
        } else if (w <= 1) {
            // 従来の2点比較
            if (round > 0 && m_options.roundConvergenceTolerance > 0) {
                double prev = roundCostHistory[roundCostHistory.size() - 2];
                double relImprovement = (prev - currentCost)
                                        / std::max(std::abs(prev), 1e-12);
                if (relImprovement < m_options.roundConvergenceTolerance) {
                    result.converged = true;
                    result.terminationReason = "Round convergence";
                    if (mpiRank == 0) {
                        std::cerr << "Round convergence at round " << (round + 1)
                                  << ", relImprovement=" << relImprovement << std::endl;
                    }
                    break;
                }
            }
        } else {
            // ウィンドウベース判定
            if (static_cast<int>(roundCostHistory.size()) >= w * 2) {
                auto recentBest = *std::min_element(
                    roundCostHistory.end() - w, roundCostHistory.end());
                auto previousBest = *std::min_element(
                    roundCostHistory.end() - w * 2, roundCostHistory.end() - w);
                double relImprovement = std::abs(recentBest - previousBest)
                                        / (std::abs(previousBest) + 1e-12);
                if (relImprovement < m_options.roundConvergenceTolerance) {
                    result.converged = true;
                    result.terminationReason = "Round convergence (window)";
                    if (mpiRank == 0) {
                        std::cerr << "Round convergence (window=" << w
                                  << ") at round " << (round + 1)
                                  << ", relImprovement=" << relImprovement << std::endl;
                    }
                    break;
                }
            }
        }

        // 内側ループの収束判定（従来の動作）
        // 早期終了（A: cost stagnation, B: sufficient cost reduction）は
        // ラウンド内の打ち切りなので外側ループは続行する。
        // infeasible 中も外側 round で fill weight をエスカレーションするため
        // 続行する（内側で収束扱いされても即終了しない）。
        // ※ ただし「maxIter に到達して止まった round」は今回の動的長制限で
        //   起きうる正常終了なので、外側 break しない。
        bool reachedMaxIter = (roundResult.terminationReason.find("Maximum iterations") != std::string::npos);
        if (roundFeasible &&
            roundResult.converged &&
            !reachedMaxIter &&
            roundResult.terminationReason.find("Early stop") == std::string::npos) {
            if (m_options.verbose && mpiRank == 0) {
                std::cerr << "Converged in round " << (round + 1) << ", stopping." << std::endl;
            }
            break;
        }

        // ====== 適応的 round 長スケジューラ更新 ======
        // enableAdaptiveRoundLength = false (default) なら skip:
        //   currentRoundIter は sliceUpdateIntervalInit のまま固定。
        //   max_iter で上限制御するだけのシンプルな運用。
        // enableAdaptiveRoundLength = true なら従来の改善率ベース動的調整を実行。
        if (m_options.enableAdaptiveRoundLength) {
            double curCost = roundResult.finalCost;
            double relImp = (prevRoundCost > 0 && std::isfinite(prevRoundCost))
                ? (prevRoundCost - curCost) / std::max(std::abs(prevRoundCost), 1e-12)
                : 1.0;
            prevRoundCost = curCost;

            int kInit = std::max(1, m_options.sliceUpdateIntervalInit);
            int kMax = std::max(kInit, m_options.sliceUpdateIntervalMax);

            // SA 期間が終わった直後は currentRoundIter を kInit にリセットし、
            // 通常の adaptive スケジューラを再起動する。
            if (m_saActive && round == m_options.saMaxRounds - 1) {
                currentRoundIter = kInit;
                if (m_options.verbose && mpiRank == 0) {
                    std::cerr << "  SA period ended, resetting K to " << kInit << std::endl;
                }
            } else if (m_saActive && round < m_options.saMaxRounds) {
                // SA 期間中: currentRoundIter を更新しない（固定 3〜8 を使う）
            } else if (relImp > m_options.sliceUpdateFastResetThreshold) {
                // 大きな改善があった: 重要な動きが続いているので頻度をリセット
                currentRoundIter = kInit;
            } else if (relImp < m_options.sliceUpdateSlowFreezeThreshold) {
                // 改善小さい: 既に収束気味なので interval を増やさない
                // currentRoundIter はそのまま
            } else {
                // 通常時: 指数増加
                double next = currentRoundIter * m_options.sliceUpdateIntervalGrowth;
                currentRoundIter = std::min(kMax, std::max(kInit, static_cast<int>(next + 0.5)));
            }
            if (m_options.verbose && mpiRank == 0) {
                std::cerr << "  Adaptive round len: relImp=" << relImp
                          << ", next K=" << currentRoundIter << std::endl;
            }
        }
        // else: currentRoundIter は sliceUpdateIntervalInit のまま固定

        // iter=1 停滞検出: round が iter=1 で終わった（= LBFGS が即停止）
        // ことが連続 MAX_STALL_ROUNDS 回続いたら stage を打ち切る。
        // ただし stage 開始直後 (round < STAGE_WARMUP_ROUNDS) は cost 関数が
        // 変わったばかりで LBFGS が再起動中のため、stall 検知を無効化する。
        // また、cost が「真の停滞」であることを確認するため、
        // 直近 round と前 round の cost 差も見る。
        constexpr int STAGE_WARMUP_ROUNDS = 5;
        bool inWarmup = (round < STAGE_WARMUP_ROUNDS);
        bool roundIter1Stall =
            (roundResult.iterations <= 1
             && roundResult.terminationReason.find("Line search failed") != std::string::npos);
        if (roundIter1Stall && !inWarmup) {
            consecutiveStallRounds++;
        } else if (!roundIter1Stall) {
            consecutiveStallRounds = 0;
        }
        if (consecutiveStallRounds >= MAX_STALL_ROUNDS) {
            if (mpiRank == 0) {
                std::cerr << "Stalled (iter=1 × " << consecutiveStallRounds
                          << " consecutive rounds, after warmup), terminating stage early" << std::endl;
            }
            result.terminationReason = "Stalled at iter=1";
            break;
        }
    }

    // Stage内best追跡の復元
    auto restoreVars = [&](const std::vector<double>& vars, double sliceLv) {
        size_t nSrc = m_variableMapping.numVariables();
        if (m_options.sliceAsVariable && vars.size() == nSrc + 1) {
            std::vector<double> srcVars(vars.begin(), vars.begin() + nSrc);
            m_variableMapping.variablesToSource(srcVars, *m_sourceData);
            m_sliceLevel = vars[nSrc];
        } else {
            m_variableMapping.variablesToSource(vars, *m_sourceData);
            m_sliceLevel = sliceLv;
        }
    };
    // 最終出力選択: stage 内で running min cost を保持してきた stageBest を採用。
    // 旧 picked 系の選択 (feasibility + EPE_cost) は最適化目的と乖離していたので廃止。
    if (!stageBestVariables.empty()) {
        restoreVars(stageBestVariables, stageBestSliceLevel);
        result.finalCost = stageBestCost;
        result.finalVariables = stageBestVariables;
        if (mpiRank == 0) {
            double finalFillRatio = m_sourceData->calcSourceFillRatio(m_NA);
            bool finalFeasible = (finalFillRatio >= m_options.minSourceFillRatio - 1e-6);
            std::cerr << "Stage final selection: cost=" << stageBestCost
                      << ", fillRatio=" << finalFillRatio
                      << (finalFeasible ? " (feasible)" : " (INFEASIBLE - check fill penalty)")
                      << std::endl;
            if (!finalFeasible) {
                std::cerr << "WARNING: 最終解が fill_ratio 制約違反です。"
                          << "weightFill / fillPenaltyExponent を上げる必要があるかもしれません。"
                          << std::endl;
            }
        }
    }

    // fill weight を stage 開始時の baseline に戻す（cost.csv の再現性のため）
    m_options.weightFillPenalty = baseFillWeight;
    m_gradientCalculator.setOptions(m_options);

    // adaptive weighting で書き換えた evp weight を元に戻す
    // （cost.csv 計算は元の weight で行いたいため）
    if (m_options.adaptiveWeightExponent > 0.0
        && !m_originalEvpWeights.empty() && m_evpData) {
        m_evpData->setEvalPointWeights(m_originalEvpWeights);
    }

    // 追加の結果情報を設定
    result.finalSliceLevel = m_sliceLevel;
    result.finalSourceFillRatio = m_sourceData->calcSourceFillRatio(m_NA);

    // EPEコストとSourceFillCostとNILSコストを分けて計算（最適化と同じ方法で、
    // 復元されたstage-best状態に対して）
    // ※ baseline 重み (m_options.weightFillPenalty=baseFillWeight) で再計算した値を採用。
    //   cost.csv 出力との一貫性を保つため、result.finalCost も baseline 重みでの
    //   合計に上書きする（picked 採用時の重み込み値ではなく）。
    double epeCost, fillCost, nilsCost;
    double finalTotalCost = m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, m_options.epePower,
        &epeCost, &fillCost, &nilsCost);
    result.finalEpeCost = epeCost;
    result.finalSourceFillCost = fillCost;
    result.finalNilsCost = nilsCost;
    // finalCost を baseline 重みで再計算した合計に揃える。
    // 表示される "Final Cost" と breakdown / cost.csv の total_cost が一致する。
    result.finalCost = finalTotalCost;

    // 時間計測の統計を出力
    if (m_options.verbose && m_gradientCallCount > 0) {
        double avgGradTime = m_totalGradientTime / m_gradientCallCount;
        std::cerr << "-----------------------------------------------" << std::endl;
        std::cerr << "Timing Statistics:" << std::endl;
        std::cerr << "  Gradient calculations: " << m_gradientCallCount << " calls" << std::endl;
        std::cerr << "  Total gradient time:   " << std::fixed << std::setprecision(2)
                  << m_totalGradientTime << " sec" << std::endl;
        std::cerr << "  Avg gradient time:     " << std::fixed << std::setprecision(3)
                  << avgGradTime << " sec/call" << std::endl;
    }

    // verboseを復元
    m_options.verbose = savedVerbose;

    return result;
}

double SourceOptimizer::costFunction(const std::vector<double>& variables) {
    // sliceAsVariable モード時は variables の最後を sliceLevel として扱う
    size_t nSrc = m_variableMapping.numVariables();
    if (m_options.sliceAsVariable && variables.size() == nSrc + 1) {
        std::vector<double> srcVars(variables.begin(), variables.begin() + nSrc);
        m_variableMapping.variablesToSource(srcVars, *m_sourceData);
        m_sliceLevel = variables[nSrc];
    } else {
        m_variableMapping.variablesToSource(variables, *m_sourceData);
    }
    return m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, m_options.epePower);
}

std::vector<double> SourceOptimizer::gradientFunction(const std::vector<double>& variables) {
    auto startTime = std::chrono::high_resolution_clock::now();

    size_t nSrc = m_variableMapping.numVariables();
    bool sliceVar = (m_options.sliceAsVariable && variables.size() == nSrc + 1);
    if (sliceVar) {
        std::vector<double> srcVars(variables.begin(), variables.begin() + nSrc);
        m_variableMapping.variablesToSource(srcVars, *m_sourceData);
        m_sliceLevel = variables[nSrc];
    } else {
        m_variableMapping.variablesToSource(variables, *m_sourceData);
    }

    // 光源変数についての勾配
    std::vector<double> gradient = m_gradientCalculator.calculateGradient(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, m_options.epePower);

    if (sliceVar) {
        // sliceLevel についての勾配を末尾に追加（スケール調整）
        double dCost_dt = m_gradientCalculator.calculateSliceLevelGradient(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, m_options.epePower);
        // 光源側勾配の典型値と比較できるよう、初回数回だけログ出力
        if (m_options.verbose && m_gradientCallCount <= 3) {
            int rk = 0;
#ifdef HAVE_MPI_H
            MPI_Comm_rank(m_mpiComm, &rk);
#endif
            if (rk == 0) {
                double srcGradMax = 0.0;
                for (size_t i = 0; i < gradient.size(); ++i)
                    if (std::abs(gradient[i]) > srcGradMax) srcGradMax = std::abs(gradient[i]);
                std::cerr << "  [sliceVar] dCost/dt=" << dCost_dt
                          << " (scaled=" << dCost_dt * m_options.sliceGradScale << "), "
                          << "max|dCost/ds|=" << srcGradMax << std::endl;
            }
        }
        gradient.push_back(dCost_dt * m_options.sliceGradScale);
    }

    auto endTime = std::chrono::high_resolution_clock::now();
    double duration = std::chrono::duration<double>(endTime - startTime).count();
    m_totalGradientTime += duration;
    ++m_gradientCallCount;

    int mpiRank = 0;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
#endif
    if (m_options.verbose && m_gradientCallCount <= 3 && mpiRank == 0) {
        std::cerr << "  [Timing] Gradient calculation #" << m_gradientCallCount
                  << ": " << std::fixed << std::setprecision(3) << duration << " sec" << std::endl;
    }

    return gradient;
}

void SourceOptimizer::projectionFunction(std::vector<double>& variables) {
    size_t nSrc = m_variableMapping.numVariables();
    bool sliceVar = (m_options.sliceAsVariable && variables.size() == nSrc + 1);
    if (sliceVar) {
        // 光源側だけ既存の射影
        std::vector<double> srcVars(variables.begin(), variables.begin() + nSrc);
        m_constraintHandler.projectInPlace(srcVars);
        for (size_t i = 0; i < nSrc; ++i) variables[i] = srcVars[i];
        // sliceLevel 末尾要素は [sliceMin, sliceMax] に clamp
        double t = variables[nSrc];
        if (t < m_options.sliceMin) t = m_options.sliceMin;
        if (t > m_options.sliceMax) t = m_options.sliceMax;
        variables[nSrc] = t;
    } else {
        m_constraintHandler.projectInPlace(variables);
    }
}

double SourceOptimizer::verifyGradient(double epsilon) {
    if (!m_sourceGrid || !m_sourceData || !m_evpData || !m_processConfig || !m_sourceContributions) {
        return -1.0;
    }

    // MPIランク情報を設定（optimize()前に呼ばれても正しく動作するように）
    int mpiRank = 0, mpiSize = 1;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
    MPI_Comm_size(m_mpiComm, &mpiSize);
#endif
    m_gradientCalculator.setMPI(mpiRank, mpiSize);

    // 変数マッピングを初期化（まだの場合）
    if (m_variableMapping.numVariables() == 0) {
        m_variableMapping.initialize(*m_sourceGrid, *m_sourceData);
        m_gradientCalculator.setVariableMapping(&m_variableMapping);
    }

    // slice levelの自動決定（まだの場合）
    if (m_sliceLevel < 0) {
        m_sliceLevel = findOptimalSliceLevel();
    }

    std::cerr << "-----------------------------------------------" << std::endl;
    std::cerr << "Gradient Verification (epsilon=" << epsilon << ")" << std::endl;
    std::cerr << "  Variables: " << m_variableMapping.numVariables() << std::endl;
    std::cerr << "  Slice level: " << m_sliceLevel << std::endl;
    std::cerr << "  D2 symmetry: " << (m_variableMapping.isD2Symmetry() ? "yes" : "no") << std::endl;

    // 変数情報（最初の3つ）を表示
    const auto& varInfos = m_variableMapping.variableInfos();
    std::cerr << "  First 3 variables:" << std::endl;
    for (size_t i = 0; i < std::min<size_t>(3, varInfos.size()); ++i) {
        const auto& info = varInfos[i];
        double intensity = m_sourceData->getIntensityFirstQuadrant(info.gx, info.gy);
        std::cerr << "    [" << i << "] gx=" << info.gx << ", gy=" << info.gy
                  << ", mult=" << info.multiplier << ", intensity=" << intensity << std::endl;
    }

    // 勾配計算方法を表示
    std::cerr << "  Gradient method: " << gradientMethodToString(m_options.gradientMethod) << std::endl;

    int epePower = m_options.epePower;

    // 現在のコストを表示（選択された方法に基づく）
    double currentCost = m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);
    std::cerr << "  Current cost: " << currentCost << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    // 単一変数の詳細検証（最初の変数）
    if (!varInfos.empty()) {
        std::cerr << "Detailed check for variable 0:" << std::endl;
        std::vector<double> vars = m_variableMapping.sourceToVariables(*m_sourceData);
        double origVal = vars[0];

        // +epsilon
        vars[0] = origVal + epsilon;
        m_variableMapping.variablesToSource(vars, *m_sourceData);
        double costPlus = m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);

        // -epsilon
        vars[0] = origVal - epsilon;
        m_variableMapping.variablesToSource(vars, *m_sourceData);
        double costMinus = m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);

        // restore
        vars[0] = origVal;
        m_variableMapping.variablesToSource(vars, *m_sourceData);

        double numGrad0 = (costPlus - costMinus) / (2.0 * epsilon);
        std::cerr << "  cost(+eps)=" << std::scientific << std::setprecision(10) << costPlus << std::endl;
        std::cerr << "  cost(-eps)=" << costMinus << std::endl;
        std::cerr << "  cost_diff=" << (costPlus - costMinus) << std::endl;
        std::cerr << "  numerical_grad=" << numGrad0 << std::endl;
        std::cerr << "-----------------------------------------------" << std::endl;
    }

    // 解析勾配と数値勾配の対応を決定
    // gradientMethod が解析的 → そのまま解析勾配、対応する数値勾配と比較
    // gradientMethod が数値的 → 対応する解析勾配と比較
    GradientMethod analyticMethod, numericalMethod;
    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
        case GradientMethod::QEPE_Numerical:
            analyticMethod = GradientMethod::QEPE_Analytical;
            numericalMethod = GradientMethod::QEPE_Numerical;
            break;
        case GradientMethod::EPE_Analytical:
        case GradientMethod::EPE_Numerical:
        default:
            analyticMethod = GradientMethod::EPE_Analytical;
            numericalMethod = GradientMethod::EPE_Numerical;
            break;
    }

    std::cerr << "  Analytic method:  " << gradientMethodToString(analyticMethod) << std::endl;
    std::cerr << "  Numerical method: " << gradientMethodToString(numericalMethod) << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    // 解析勾配と数値勾配を同じ optimizer 状態（saved）から計算する。
    // 例外が起きても元の gradientMethod / m_options を確実に戻すため、
    // RAII 風のスコープガードで保護する。
    const auto savedMethod = m_options.gradientMethod;
    struct MethodRestorer {
        GradientCalculator& gc;
        OptimizationOptions& opts;
        GradientMethod orig;
        ~MethodRestorer() {
            opts.gradientMethod = orig;
            gc.setGradientMethod(orig);
        }
    } restorer{m_gradientCalculator, m_options, savedMethod};

    std::vector<double> analyticGrad;
    std::vector<double> numericalGrad;
    double analyticTime = 0.0, numericalTime = 0.0;

    {
        m_gradientCalculator.setGradientMethod(analyticMethod);
        auto analyticStart = std::chrono::high_resolution_clock::now();
        analyticGrad = m_gradientCalculator.calculateGradient(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);
        auto analyticEnd = std::chrono::high_resolution_clock::now();
        analyticTime = std::chrono::duration<double>(analyticEnd - analyticStart).count();
    }

    std::cerr << "Analytic gradient:  " << std::fixed << std::setprecision(3)
              << analyticTime << " sec" << std::endl;

    {
        m_gradientCalculator.setGradientMethod(numericalMethod);
        auto numericalStart = std::chrono::high_resolution_clock::now();
        numericalGrad = m_gradientCalculator.calculateGradient(
            *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel, epePower);
        auto numericalEnd = std::chrono::high_resolution_clock::now();
        numericalTime = std::chrono::duration<double>(numericalEnd - numericalStart).count();
    }
    // restorer が破棄されるとき gradientMethod が savedMethod に戻る

    std::cerr << "Numerical gradient: " << std::fixed << std::setprecision(3)
              << numericalTime << " sec" << std::endl;

    // 速度比
    double actualRatio = (analyticTime > 0) ? (numericalTime / analyticTime) : 0;
    std::cerr << "Speed ratio:        " << std::fixed << std::setprecision(1)
              << actualRatio << "x slower (numerical)" << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    // 最大相対誤差を計算
    double maxRelError = 0.0;
    size_t maxErrorIdx = 0;
    double sumRatio = 0.0;
    int ratioCount = 0;

    for (size_t i = 0; i < analyticGrad.size(); ++i) {
        double a = analyticGrad[i];
        double n = numericalGrad[i];
        double absError = std::abs(a - n);
        double denom = std::max(std::abs(a) + std::abs(n), 1e-12);
        double relError = absError / denom;

        if (relError > maxRelError) {
            maxRelError = relError;
            maxErrorIdx = i;
        }

        // 比率の統計（両方が有意な値の場合のみ）
        if (std::abs(a) > 1e-12 && std::abs(n) > 1e-12) {
            sumRatio += n / a;
            ++ratioCount;
        }

        if (m_options.verbose) {
            double ratio = (std::abs(a) > 1e-12) ? n / a : 0.0;
            std::cerr << "Gradient[" << i << "]: analytic=" << std::scientific << std::setprecision(4) << a
                      << ", numerical=" << n
                      << ", ratio=" << std::fixed << std::setprecision(2) << ratio
                      << ", relError=" << std::scientific << std::setprecision(2) << relError << std::endl;
        }
    }

    // 統計情報
    std::cerr << "Max relative error: " << std::scientific << std::setprecision(3)
              << maxRelError << " (at index " << maxErrorIdx << ")" << std::endl;
    if (ratioCount > 0) {
        double avgRatio = sumRatio / ratioCount;
        std::cerr << "Avg ratio (num/ana): " << std::fixed << std::setprecision(2)
                  << avgRatio << " (should be ~1.0)" << std::endl;
    }
    std::cerr << "Verification:       " << (maxRelError < 1e-3 ? "PASSED" : "FAILED") << std::endl;
    std::cerr << "-----------------------------------------------" << std::endl;

    return maxRelError;
}

double SourceOptimizer::calculateCurrentCost(double* outEpeCost, double* outSourceFillCost) {
    if (!m_sourceData || !m_evpData || !m_processConfig) {
        return 0.0;
    }

    // 変数マッピングを初期化（まだの場合）
    if (m_variableMapping.numVariables() == 0 && m_sourceGrid) {
        m_variableMapping.initialize(*m_sourceGrid, *m_sourceData);
        m_gradientCalculator.setVariableMapping(&m_variableMapping);
    }

    // slice levelの自動決定（まだの場合）
    if (m_sliceLevel < 0) {
        m_sliceLevel = findOptimalSliceLevel();
    }

    return m_gradientCalculator.calculateCostByMethod(
        *m_sourceData, *m_evpData, *m_processConfig, m_sliceLevel,
        m_options.epePower, outEpeCost, outSourceFillCost);
}

double SourceOptimizer::findOptimalSliceLevel() {
    if (!m_sourceData || !m_evpData || !m_processConfig || !m_sourceContributions) {
        return 0.5;
    }

    int mpiRank = 0, mpiSize = 1;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
    MPI_Comm_size(m_mpiComm, &mpiSize);
#endif

    double sliceLevel = 0.5;

    // 全 rank で同期的に呼び出す。CostCalculator 内で MPI_Allreduce / Bcast により
    // 全 rank で同じ結果が返る（mpiSize=1 なら従来動作）。
    const auto& gridConfig = m_sourceGrid->showConfig();

    CostCalculator costCalc;
    CostOptions costOptions;
    costOptions.sliceLevelHint = m_options.sliceLevelHint;
    costOptions.anchorClips = m_options.anchorClips;
    costOptions.sliceObjective = m_options.sliceObjective;
    costOptions.slicePwcMode = m_options.slicePwcMode;
    costCalc.setOptions(costOptions);
    costCalc.setMPI(mpiRank, mpiSize);
#ifdef HAVE_MPI_H
    costCalc.setMPIComm(m_mpiComm);
#endif

    if (m_options.sliceUseEpeZero) {
        sliceLevel = costCalc.findSliceLevelByEpeZero(
            *m_sourceContributions, *m_sourceData, gridConfig,
            *m_evpData, *m_processConfig,
            m_options.sliceAnchorClipID,
            m_options.sliceAnchorDirection);
    } else if (m_options.sliceObjective == SliceObjective::TotalCost) {
        // TotalCost モード: gradient_calculator.calculateCostByMethod() を sliceLevel 関数として
        // 黄金分割探索する。これにより BT/BFS/NILS/fill を含む main 最適化と完全に同じ
        // total cost が最小になる sliceLevel が決まる。
        // 計算は重いが、最適化目的との整合性は最大。
        sliceLevel = findOptimalSliceLevelByTotalCost();
    } else {
        sliceLevel = costCalc.findOptimalSliceLevel(
            *m_sourceContributions, *m_sourceData, gridConfig, *m_evpData, *m_processConfig);
    }

    return sliceLevel;
}

double SourceOptimizer::findOptimalSliceLevelByTotalCost() {
    int mpiRank = 0;
#ifdef HAVE_MPI_H
    MPI_Comm_rank(m_mpiComm, &mpiRank);
#endif

    // 探索範囲: sliceMin / sliceMax を使う (sliceAsVariable と同じ)
    double a = m_options.sliceMin;
    double b = m_options.sliceMax;
    if (a >= b || a < 0) { a = 0.05; b = 0.50; }

    const double goldenRatio = (std::sqrt(5.0) - 1.0) / 2.0;
    double c = b - goldenRatio * (b - a);
    double d = a + goldenRatio * (b - a);

    // 評価関数: 真の total cost を gradient_calculator 経由で取得
    auto evalFunc = [&](double sliceLv) -> double {
        double epeCost, fillCost, nilsCost;
        return m_gradientCalculator.calculateCostByMethod(
            *m_sourceData, *m_evpData, *m_processConfig, sliceLv,
            m_options.epePower, &epeCost, &fillCost, &nilsCost);
    };

    double fc = evalFunc(c);
    double fd = evalFunc(d);

    constexpr int MAX_ITER = 40;
    constexpr double TOL = 1e-5;
    for (int iter = 0; iter < MAX_ITER; ++iter) {
        if (fc < fd) {
            b = d; d = c; fd = fc;
            c = b - goldenRatio * (b - a);
            fc = evalFunc(c);
        } else {
            a = c; c = d; fc = fd;
            d = a + goldenRatio * (b - a);
            fd = evalFunc(d);
        }
        if (std::abs(b - a) < TOL) break;
    }

    double best = (a + b) * 0.5;
    if (m_options.verbose && mpiRank == 0) {
        std::cerr << "  sliceLevel (TotalCost): " << best
                  << " (cost=" << evalFunc(best) << ")" << std::endl;
    }
    return best;
}


} // namespace so
