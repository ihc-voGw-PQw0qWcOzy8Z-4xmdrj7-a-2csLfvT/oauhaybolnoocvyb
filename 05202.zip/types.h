/*!
 * @file types.h
 * @brief so ライブラリ共通型定義
 *
 * 全ての構造体、列挙型、定数を統合。
 */

#ifndef SO_TYPES_H
#define SO_TYPES_H

#include <string>
#include <vector>
#include <utility>
#include <tuple>
#include <map>
#include <sstream>
#include <cmath>

namespace so {

// ============================================================================
// 前方宣言
// ============================================================================
class FrequencyImage;
class SourceContributionSet;

// ============================================================================
// 定数
// ============================================================================

/*!
 * @brief EPE正規化のための定数
 *
 * EPEをμm単位で計算した後、正規化により数値的安定性を向上させる。
 * EPE_REF = 1nm = 0.001μm を基準として、コスト値を適切なスケールに調整。
 */
constexpr double EPE_REF = 0.001;  ///< 基準EPE値 (1nm in μm)
constexpr double EPE_SCALE = 1.0 / (EPE_REF * EPE_REF);  ///< = 1e6 (power=2用)

/*!
 * @brief 座標精度の定数（EVP用）
 */
constexpr double EVP_COORDINATE_PRECISION = 8000.0;

// ============================================================================
// 光源関連 (sourcelib)
// ============================================================================

/*!
 * @brief 光源グリッド設定
 */
struct SourceGridConfig {
    int grid = 33;                    ///< グリッド分割数
    double sigma_max = 1.0;           ///< 有効光源の最大sigma
    double sigma_min = 0.0;           ///< 有効光源の最小sigma
    std::string symmetry = "none";    ///< "D2" or "none"

    /// D2対称かどうか
    bool isD2Symmetry() const { return symmetry == "D2"; }
};

/*!
 * @brief 光源点
 */
struct SourcePoint {
    double x = 0.0;           ///< X座標 (-1.0 ~ 1.0)
    double y = 0.0;           ///< Y座標 (-1.0 ~ 1.0)
    double intensity = 0.0;   ///< 強度 (>= 0)
};

/*!
 * @brief 補間方法
 */
enum class InterpolationMethod {
    Nearest,    ///< 最近傍補間
    Bilinear    ///< バイリニア補間
};

/*!
 * @brief 光源データ修正オプション
 */
struct CorrectionOptions {
    InterpolationMethod interpolation = InterpolationMethod::Nearest;
    std::string debugOutputPath;
    bool verbose = false;
};

/*!
 * @brief 光源データ修正結果
 */
struct CorrectionResult {
    bool gridCorrected = false;
    bool missingPointsAdded = false;
    bool symmetryCorrected = false;
    bool outOfRangeWarning = false;
    bool negativeIntensityFixed = false;
    int numGridMismatches = 0;
    int numMissingPoints = 0;
    int numOutOfRangePoints = 0;
    int numAsymmetricPoints = 0;
    int numNegativePoints = 0;
    std::vector<std::string> warnings;

    bool hasCorrections() const {
        return gridCorrected || missingPointsAdded || symmetryCorrected ||
               outOfRangeWarning || negativeIntensityFixed;
    }
};

// ============================================================================
// プロセス関連 (processlib)
// ============================================================================

/*!
 * @brief PWC条件（Process Window Condition）
 */
struct PwcCondition {
    double defocus = 0.0;       ///< デフォーカス [nm]
    double mask_bias = 0.0;     ///< マスクバイアス [nm]
    double delta_dose = 0.0;    ///< ドーズ補正 [%]
    double weight = 1.0;        ///< 重み

    bool isNominal() const {
        return std::abs(defocus) < 1e-9 &&
               std::abs(mask_bias) < 1e-9 &&
               std::abs(delta_dose) < 1e-9;
    }

    std::string toFileSuffix() const {
        std::ostringstream oss;
        oss << static_cast<int>(defocus) << "_"
            << mask_bias << "_"
            << delta_dose;
        return oss.str();
    }
};

// ============================================================================
// SOCS関連 (socslib)
// ============================================================================

/*!
 * @brief 光学パラメータ
 */
struct OpticalParams {
    double lambda = 0.193;    ///< 波長 [μm]
    double NA = 1.35;         ///< 開口数
    double Lx = 1.0;          ///< X方向計算領域サイズ [μm]
    double Ly = 1.0;          ///< Y方向計算領域サイズ [μm]
    double norm_real = 0.0;
    double norm_imag = 0.0;

    double maxL() const { return (Lx > Ly) ? Lx : Ly; }
    double norm() const { return norm_real; }
};

/*!
 * @brief Norm情報
 */
struct NormEntry {
    double defocus = 0.0;
    std::string sourceID;
    double norm_real = 0.0;
    double norm_imag = 0.0;
};

// ============================================================================
// 評価点関連 (evplib)
// ============================================================================

/*!
 * @brief 矩形の座標情報
 */
struct Rectangle {
    double x_min;
    double x_max;
    double y_min;
    double y_max;

    double centerX() const { return (x_min + x_max) / 2.0; }
    double centerY() const { return (y_min + y_max) / 2.0; }
    double semiAxisA() const { return (x_max - x_min) / 2.0; }
    double semiAxisB() const { return (y_max - y_min) / 2.0; }
};

/*!
 * @brief 評価点の情報
 */
struct EvalPoint {
    int clipID;
    double cx;            ///< クリップの中心X座標
    double cy;            ///< クリップの中心Y座標
    double px;            ///< 評価点の相対X座標
    double py;            ///< 評価点の相対Y座標
    double degree;        ///< 法線方向の角度（度）
    double tolerance = 0.0;   ///< EPE デッドバンド（μm、|EPE|<=tolerance は無罰）
    double weight;
    std::string cutlineID;
};

/*!
 * @brief EVPジェネレータ設定
 */
struct EvpConfig {
    std::string inputFile;
    std::string outputFile;
    int n = 8;
    int d = 8000;
    double tolerance = 0.0;
    double weightHV = 1.0;
    double weightDiag = 0.1;
};

/*!
 * @brief Cutlineジェネレータ設定
 */
struct CutlineConfig {
    std::string inputFile;
    std::string outputFile;
    int n = 8;
    int d = 8000;
};

/*!
 * @brief Cutline情報
 */
struct CutlineInfo {
    int clipID;
    double hStartX, hStartY, hEndX, hEndY;  ///< 水平cutline
    double vStartX, vStartY, vEndX, vEndY;  ///< 垂直cutline
};

/*!
 * @brief 評価点の絶対座標情報
 */
struct EvalPointAbs {
    int clipID;
    double x;
    double y;
};

// ============================================================================
// 画像関連 (imglib)
// ============================================================================

/*!
 * @brief EPE計算メソッド
 */
enum class EpeMethod {
    Newton,     ///< ニュートン法
    QEPE        ///< 1次近似
};

/*!
 * @brief EPE計算結果（詳細情報付き）
 */
struct EpeCalcResult {
    double epe = 0.0;
    double qepe = 0.0;
    double intensity = 0.0;
    double gradient = 0.0;
    int iterations = 0;
    bool converged = false;
};

/*!
 * @brief 光学像計算オプション
 */
struct CalcOptions {
    int dimx0 = 0;
    int dimy0 = 0;
    int dimx = 0;
    int dimy = 0;
    int kernelNum = 0;
    bool brightfield = false;
    bool binary = false;
    std::vector<std::pair<int, int>> layers;
    std::string cellname;
    int numThreads = 1;
};

/*!
 * @brief calcImagesの戻り値
 */
struct CalcResult {
    std::map<std::string, SourceContributionSet> sourceContributions;
    OpticalParams opticalParams;
};

/*!
 * @brief 出力画像ファイル名を生成
 */
inline std::string makeImageFileName(int clipID, double defocus,
                                      double maskBias, double deltaDose) {
    return "clip" + std::to_string(clipID) + "_" +
           std::to_string(static_cast<int>(defocus)) + "_" +
           std::to_string(maskBias) + "_" +
           std::to_string(deltaDose) + ".out";
}

// ============================================================================
// コスト関連 (costlib)
// ============================================================================

/*!
 * @brief EPE計算結果（評価点単位）
 */
struct EpeResult {
    int clipID = 0;
    int pwcIndex = 0;
    double defocus = 0.0;
    double maskBias = 0.0;
    double deltaDose = 0.0;
    int evpIndex = 0;
    double px = 0.0;
    double py = 0.0;
    double degree = 0.0;
    double EPE = 0.0;
    double QEPE = 0.0;
    double intensity = 0.0;
    double gradient = 0.0;
    double weight_p = 1.0;
    double weight_pwc = 1.0;
    bool converged = false;
    int iterations = 0;
};

/*!
 * @brief Cutline計算結果
 */
struct CutlineResult {
    int clipID = 0;
    int pwcIndex = 0;
    double defocus = 0.0;
    double maskBias = 0.0;
    double deltaDose = 0.0;
    std::string direction;
    double CD = 0.0;
    double delta_CD = 0.0;
    double delta_CD_QEPE = 0.0;
    double EPE1 = 0.0;
    double EPE2 = 0.0;
    double QEPE1 = 0.0;
    double QEPE2 = 0.0;
};

/*!
 * @brief コスト計算結果全体
 */
struct CostResult {
    double sliceLevel = 0.0;
    double EPE_cost = 0.0;
    double QEPE_cost = 0.0;
    double source_fill_cost = 0.0;
    double NILS_cost = 0.0;        ///< NILS ペナルティ（重み未適用。total_cost で weightNils 倍）
    double BT_cost = 0.0;          ///< BT ペナルティ（重み未適用、total_cost で weightBt 倍）
    double BFS_cost = 0.0;         ///< BFS ペナルティ（重み未適用、total_cost で weightBfs 倍）
    double total_cost = 0.0;
    double total_cost_QEPE = 0.0;
    // 全評価点を走査したピーク統計（|EPE|, |QEPE| の最大値と付随情報）
    double maxAbsEPE = 0.0;       ///< |EPE| の最大値
    double maxAbsQEPE = 0.0;      ///< |QEPE| の最大値
    int maxAbsEPE_index = -1;     ///< |EPE| 最大点の epeResults 内インデックス（-1=なし）
    int maxAbsQEPE_index = -1;    ///< |QEPE| 最大点の epeResults 内インデックス（-1=なし）
    std::vector<EpeResult> epeResults;
    std::vector<CutlineResult> cutlineResults;
};

/*!
 * @brief sliceLevel 最適化の目的関数
 *
 * Phase B-2: max|EPE| 最小化を選べるようにする。
 * - DeltaCD2: Σ delta_CD² (cutline ペアの CD ずれ。後方互換)
 * - MaxAbsEPE: max(max(0, |EPE_i| - tol_i)) over all eval points
 *   （個別評価点の min-max。EPE 最大値を直接最小化）
 */
enum class SliceObjective {
    DeltaCD2 = 0,
    MaxAbsEPE = 1,
    TotalCost = 2,    ///< Σ max(0,|EPE|-tol)^p × pwc.weight × evp.weight (main 最適化と整合)
};

/*!
 * @brief sliceLevel 評価で使用する PWC モード
 *
 * Phase B-3: 全 PWC 評価をサポート。
 * - NominalOnly: nominal PWC のみで sliceLevel を決める（後方互換、軽量）
 * - AllPwc: 全 PWC で評価。各 PWC の合成画像を別個に保持し、
 *           pwc.weight を考慮した max|EPE| を最小化
 */
enum class SlicePwcMode {
    NominalOnly = 0,
    AllPwc = 1
};

/*!
 * @brief コスト計算オプション
 */
struct CostOptions {
    double sliceLevel = -1.0;
    double sliceLevelHint = -1.0;
    std::vector<int> anchorClips;
    // Phase B: sliceLevel 決定方法のチューニング
    SliceObjective sliceObjective = SliceObjective::MaxAbsEPE;  ///< デフォルトは max|EPE| 最小化
    SlicePwcMode slicePwcMode = SlicePwcMode::AllPwc;           ///< デフォルトは全 PWC 考慮
    double weightFill = 1.0;
    double minSourceFillRatio = 0.07;
    bool useExponentialFillPenalty = false;
    double fillPenaltyExponent = 100.0;
    EpeMethod epeMethod = EpeMethod::Newton;
    double targetDeltaCD = 0.0;
    bool useTargetDeltaCD = false;
    // NILS ペナルティ設定（NILS < nilsMin のとき (nilsMin - NILS)^2 を加算）
    double weightNils = 0.0;        ///< NILS ペナルティ重み（0 で無効）
    double nilsMin = 2.0;           ///< NILS の下限目標
    double nilsCdReference = 40.0;  ///< NILS 算出時の参照 CD [nm]

    // BT (Bossung Tilt) / BFS (Best Focus Shift) ペナルティ設定
    //
    //  BT  = (1/EPE_REF^p) · Σ_{c,ev} w_ev · w_clip · |EPE(Fp) - EPE(Fn)|^p / Σw
    //  BFS = (1/EPE_REF^p) · Σ_{c,ev} w_ev · w_clip · (
    //          |EPE(Fp) - EPE(Nom)|^p + |EPE(Fn) - EPE(Nom)|^p
    //        ) / Σw
    //
    // Fp / Fn / Nom はそれぞれ「最大 defocus」「最小 defocus」「nominal」の
    // PWC を指す。デフォルト (-1) では (mask_bias=0, delta_dose=0) の PWC の中で
    // defocus 極値と nominal を自動検出する。
    //
    // pairClips が空の場合は全 clip に適用、指定すれば対象 clip だけに適用される。
    double weightBt = 0.0;          ///< BT ペナルティ重み (0=無効)
    double weightBfs = 0.0;         ///< BFS ペナルティ重み (0=無効)
    int btPower = 2;                ///< BT のべき乗 p
    int bfsPower = 2;               ///< BFS のべき乗 p
    int bfsPwcNom = -1;             ///< 単一 BFS ペア時の Nom PWC index (-1=auto)
    // BT/BFS ペア指定 (空=自動検出: defocus 極値ペア 1 組)
    std::vector<std::pair<int,int>> btPairs;   ///< BT 用 (Fp,Fn) ペアの集合
    // BFS は (Fp, Fn, Nom) 三つ組指定。Nom < 0 なら全ペア共通の bfsPwcNom を使う
    std::vector<std::tuple<int,int,int>> bfsPairs;  ///< BFS 用 (Fp,Fn,Nom) 三つ組の集合
    std::vector<int> pairClips;     ///< 適用 clip ID (空=全 clip)

    // MPI 分散時、自 rank が担当しない clip の image が見つからないのは正常動作。
    // SourceOptimizer から呼ぶ際は true にして警告を抑制する。
    bool silentMissingImages = false;
};

/*!
 * @brief BT/BFS で使う PWC ペアの index 情報
 */
struct PwcPair {
    int pwc_index_p = -1;       ///< Fp (max defocus)
    int pwc_index_n = -1;       ///< Fn (min defocus)
    int pwc_index_nom = -1;     ///< Nominal (defocus=0)
    bool validBt()  const { return pwc_index_p >= 0 && pwc_index_n >= 0
                                   && pwc_index_p != pwc_index_n; }
    bool validBfs() const { return validBt() && pwc_index_nom >= 0
                                   && pwc_index_nom != pwc_index_p
                                   && pwc_index_nom != pwc_index_n; }
};

// ============================================================================
// 最適化関連 (optimlib)
// ============================================================================

/*!
 * @brief オプティマイザの種類
 */
enum class OptimizerType {
    LBFGS,
    Adam
};

/*!
 * @brief 勾配計算方法
 */
enum class GradientMethod {
    QEPE_Analytical = 1,
    EPE_Analytical = 2,
    QEPE_Numerical = 3,
    EPE_Numerical = 4
};

inline GradientMethod parseGradientMethod(const std::string& str) {
    if (str == "QEPE_Analytical" || str == "1") return GradientMethod::QEPE_Analytical;
    if (str == "EPE_Analytical" || str == "2") return GradientMethod::EPE_Analytical;
    if (str == "QEPE_Numerical" || str == "3") return GradientMethod::QEPE_Numerical;
    if (str == "EPE_Numerical" || str == "4") return GradientMethod::EPE_Numerical;
    return GradientMethod::EPE_Analytical;
}

inline std::string gradientMethodToString(GradientMethod method) {
    switch (method) {
        case GradientMethod::QEPE_Analytical: return "QEPE_Analytical";
        case GradientMethod::EPE_Analytical: return "EPE_Analytical";
        case GradientMethod::QEPE_Numerical: return "QEPE_Numerical";
        case GradientMethod::EPE_Numerical: return "EPE_Numerical";
        default: return "Unknown";
    }
}

/*!
 * @brief 正則化の種類
 */
enum class RegularizationType {
    None = 0,
    Laplacian = 1,    ///< ラプラシアン正則化（空間的滑らかさ）
    L2 = 2,           ///< L2正則化（ティホノフ正則化、強度の二乗和）
    TV = 3,           ///< TV正則化（Total Variation、エッジ保存滑らか化）
    Isolated = 4      ///< 孤立点ペナルティ（まとまりのある分布を促進）
};

/*!
 * @brief 最適化オプション
 */
struct OptimizationOptions {
    OptimizerType optimizer = OptimizerType::LBFGS;
    int maxIterations = 100;
    // EPE コストは 1/EPE_REF^n（n=2 で 1e6）スケールされるため、勾配ノルムも
    // 同オーダーになる。デフォルトは EPE スケール後の収束判定として有効に効く値。
    // 過去の 1e-6 は実質無効化されており「最大反復」「相対改善」で停止していた。
    double gradientTolerance = 1e-3;
    double costTolerance = 1e-8;

    // 制約
    double minIntensity = 0.0;
    double maxIntensity = 1.0;
    double minSourceFillRatio = 0.07;
    double weightFillPenalty = 1.0;
    bool useExponentialFillPenalty = false;
    double fillPenaltyExponent = 100.0;
    // ラウンド間の fill weight 連続化（外点ペナルティ連続法）
    // round 末に sourceFillRatio < minSourceFillRatio のとき、
    // 次 round 開始時に weightFillPenalty を multiplier 倍（上限 max）。
    double fillWeightMultiplier = 10.0;   ///< >1.0 で有効。<=1.0 で無効
    double fillWeightMax = 1e6;           ///< weightFillPenalty の上限

    // L-BFGS固有
    int lbfgsMemorySize = 10;
    int lbfgsConvergenceWindow = 10;
    double lbfgsRelativeTolerance = 1e-6;
    int lbfgsMaxSmallSteps = 5;
    double lbfgsSmallStepThreshold = 1e-6;
    bool lbfgsTrackBestSolution = true;
    int lbfgsMinIterations = 0;

    // Adam固有
    double adamLearningRate = 0.01;
    double adamBeta1 = 0.9;
    double adamBeta2 = 0.999;
    double adamEpsilon = 1e-8;

    // コスト計算
    double sliceLevel = -1.0;
    double sliceLevelHint = -1.0;
    std::vector<int> anchorClips;

    // sliceLevel自動調整
    int sliceLevelOptimizationRounds = 1;
    // Phase B: sliceLevel 決定方法のチューニング（findOptimalSliceLevel に伝搬）
    SliceObjective sliceObjective = SliceObjective::MaxAbsEPE;
    SlicePwcMode slicePwcMode = SlicePwcMode::AllPwc;
    // Phase C-1: stage 内 sliceLevel 固定 / round 毎再計算の切替
    //   true:  各 round 開始時に findOptimalSliceLevel を呼ぶ（旧動作）
    //   false: stage 開始時に 1 回だけ計算し stage 内は固定（cost ジャンプ抑制）
    bool sliceRecomputePerRound = false;

    // EPE power（コスト関数の次数）
    int epePower = 2;                 ///< EPEコストのべき乗（デフォルト: EPE²）

    // 2段階最適化（Stage 1: epePower=2 → Stage 2: epePower=epePowerStage2）
    bool enableTwoStage = false;      ///< 2段階最適化を有効化
    int epePowerStage2 = 4;           ///< Stage 2のEPEべき乗

    // Multi-Stage 最適化: stage を任意段数指定。enableTwoStage より優先される。
    //   epePowerSchedule = {2, 4, 6, 8} など
    // 空ベクトルなら従来動作（enableTwoStage 経由）。
    std::vector<int> epePowerSchedule;

    // picked 比較に max|EPE| を使うか roundEpeCost を使うか
    //   true:  max|EPE| (重み非依存、IRLS 利用時に公平な比較)
    //   false: roundEpeCost (Trial 16 時代の挙動、ときに良い解を拾う)
    bool pickByMaxAbsEpe = true;

    // Adaptive Weighting (IRLS, minimax 近似)
    // 各 round 終了時に評価点ごとの |EPE_i| を測定し、
    //   w_p_new = w_p_orig * max(floor, (|EPE_i| / maxEPE)^adaptiveWeightExponent)
    // で次 round の重みを更新する。指数を上げるほど worst 点に集中。
    // 0 で無効。3〜6 が実用的な範囲。
    double adaptiveWeightExponent = 0.0;  ///< 0=無効、>0 で IRLS 風重み更新
    double adaptiveWeightFloor = 0.01;    ///< 重みの下限（永久に死ぬ点を出さないため）

    // Stage ごとの IRLS スケジュール（指定なら stage ごとに切替、空なら全 stage 共通）
    std::vector<double> adaptiveWeightExponentSchedule;
    std::vector<double> adaptiveWeightFloorSchedule;

    // 適応的 sliceLevel 更新スケジュール
    // - 初期は頻繁、収束とともに低頻度
    // - 更新時に LBFGS 履歴をクリアし、再起動効果でローカルミニマから抜ける
    // ※ enableAdaptiveRoundLength = false (default) のときは動的調整を skip し、
    //   currentRoundIter は sliceUpdateIntervalInit で固定 (max_iter で上限制御)。
    //   true で従来の改善率ベース動的調整を有効化。
    bool enableAdaptiveRoundLength = false;  ///< 動的 round 長スケジューラの有効化
    int sliceUpdateIntervalInit = 5;       ///< 初期 round 長 (動的調整 OFF 時は固定値)
    double sliceUpdateIntervalGrowth = 1.5; ///< (動的調整時のみ) 更新ごとに倍率で増やす
    int sliceUpdateIntervalMax = 200;      ///< (動的調整時のみ) interval の上限

    // ==== Simulated Annealing 風 sliceLevel 摂動 ====
    // 局所最適解からの脱出を狙い、stage 1 の初期 round で sliceLevel を
    // 意図的に大きく揺さぶる。
    //   actual_sliceLevel = optimal_sliceLevel + amplitude × randn(0,1)
    //   amplitude_k = amplitude_init × cooling^k    (k = round 番号)
    // amplitude が sliceMin 未満になったら摂動停止 → 普通の最適化へ移行。
    // stage 2 以降では摂動なし。
    double saAmplitudeInit = 0.0;     ///< 0=無効。0.05 で sliceLevel ±0.05 程度の揺さぶり
    double saCoolingRate = 0.85;      ///< round ごとの amplitude 減衰率
    int saMaxRounds = 20;             ///< 各 stage の何 round まで適用するか
    int saSeed = 12345;               ///< 乱数シード（再現性のため）
    bool saAllStages = false;         ///< true なら全 stage で SA を有効化（既定: stage 1 のみ）
    // 改善率による interval 補正の閾値:
    //   relImp > FastReset: 大きな改善 → K をリセット（s が大きく動いている）
    //   relImp < SlowFreeze: 改善小 → K を増やさない（収束気味）
    //   その間: 通常通り指数増加で K を増やす
    // 5〜10% の改善が出続ける状況では K=5 に張り付いて深く掘れないので、
    // FastReset を 50% に上げて「劇的な変化」のみリセット対象に絞る。
    double sliceUpdateFastResetThreshold = 0.5;
    double sliceUpdateSlowFreezeThreshold = 1e-4;
    // sliceLevel 決定方法
    bool sliceUseEpeZero = true;  ///< true: 指定 cutline で EPE=0 になる二分探索（軽量）, false: minmax 黄金分割
    int sliceAnchorClipID = -1;   ///< -1=anchor_clips の最初の clip 自動選択
    std::string sliceAnchorDirection = "X";  ///< "X" or "Y" cutline ペア

    // 案 4: sliceLevel を最適化変数として L-BFGS で同時最適化する
    //   true なら variables ベクトルの最後に sliceLevel を追加し、
    //   (s, t) を 1 つの最適化問題として扱う。block coordinate の発振を回避。
    //   このとき sliceUseEpeZero / round 毎更新ロジックは無効化される。
    bool sliceAsVariable = false;
    double sliceMin = 0.05;       ///< sliceLevel の下限 (Box 制約)
    double sliceMax = 0.50;       ///< sliceLevel の上限
    // sliceLevel 勾配のスケール係数。
    // 光源強度 s と sliceLevel t は感度が大きく異なるため、
    // 単純な (s, t) 結合では LBFGS の line search が破綻しやすい。
    // この係数で t 方向の勾配を抑え、LBFGS の振る舞いを安定化する。
    // 0.01 〜 1.0 の範囲で要チューニング。
    double sliceGradScale = 0.01;

    // 勾配計算方法
    GradientMethod gradientMethod = GradientMethod::EPE_Analytical;
    double numericalEpsilon = 1e-6;

    // 出力
    bool verbose = false;
    std::string roundOutputPrefix;

    // 並列計算
    int numThreads = 1;

    // 正則化
    RegularizationType regularization = RegularizationType::None;  ///< 正則化の種類
    double regularizationWeight = 0.0;  ///< 正則化の重み（λ）

    // NILS (Normalized Image Log-Slope) ペナルティ
    // 評価点での contrast を明示的に担保するためのソフト制約。
    // 厳しいピッチで Newton 法が非収束になるのは contrast 崩壊が主因なので、
    // これを連続・微分可能な形で cost に組み込む。
    //
    //   NILS_i = nilsCdReference × |G_i| / slice_level    (G_i = ∂I/∂n at evp)
    //   penalty = Σ max(0, nilsMin - NILS_i)^2 × w_i / Σ w_i
    //
    // weightNilsPenalty = 0 で完全無効化（デフォルト）。
    double weightNilsPenalty = 0.0;     ///< NILS ペナルティの重み（0=無効）
    double nilsMin = 2.0;               ///< NILS 下限（この値を下回ると罰）
    double nilsCdReference = 0.022;     ///< NILS 正規化用 CD 参照 [μm]（22nm）

    // BT (Bossung Tilt) / BFS (Best Focus Shift) ペナルティ
    // M3D 効果による Bossung 曲線の非対称や best focus シフトを抑える。
    //   BT  = (1/EPE_REF^p) · Σ_{c,ev} w_ev · w_clip · |EPE(Fp)-EPE(Fn)|^p / Σw
    //   BFS = (1/EPE_REF^p) · Σ_{c,ev} w_ev · w_clip ·
    //         (|EPE(Fp)-EPE(Nom)|^p + |EPE(Fn)-EPE(Nom)|^p) / Σw
    // pairClips が空なら全 clip 適用、指定すれば対象 clip のみ。
    double weightBt = 0.0;              ///< BT ペナルティ重み (0=無効)
    double weightBfs = 0.0;             ///< BFS ペナルティ重み (0=無効)
    int btPower = 2;
    int bfsPower = 2;
    int bfsPwcNom = -1;                 ///< 単一 BFS ペア時の Nom PWC index (-1=auto)
    // BT/BFS ペア指定 (空=自動検出: defocus 極値ペア 1 組)
    std::vector<std::pair<int,int>> btPairs;   ///< BT 用 (Fp,Fn) ペア集合
    // BFS は (Fp, Fn, Nom) 三つ組指定。Nom < 0 なら bfsPwcNom (or auto) を fallback として使う
    std::vector<std::tuple<int,int,int>> bfsPairs;  ///< BFS 用 (Fp,Fn,Nom) 三つ組集合
    std::vector<int> pairClips;         ///< 適用 clip ID (空=全 clip)

    // EPE デッドバンドのグローバル上書き (μm 単位)
    //   -1 → evp.csv の tolerance 列を使う（従来動作）
    //   >=0 → 全評価点の tolerance をこの値で上書き
    // マージン計測 (calcMargin --tolerance) と一致させるとPW最大化が筋に合う。
    double globalTolerance = -1.0;

    // 内側ループ早期終了
    int earlyStopPatience = 3;           ///< 何イテレーション前と比較するか（0=無効）
    double earlyStopTolerance = 1e-4;    ///< 相対改善率がこれ以下なら打ち切り

    // ラウンドあたり最大コスト削減率
    double maxCostReduction = -1.0;      ///< ラウンド開始時から何%下がったら打ち切り（-1=無効、0.3=30%で打ち切り）

    // ラウンド間収束
    int roundConvergenceWindow = 1;           ///< ウィンドウサイズ（1=従来動作、2以上でウィンドウベース）
    double roundConvergenceTolerance = 1e-6;  ///< ラウンド間コスト改善率の閾値
};

/*!
 * @brief 最適化ログエントリ
 */
struct OptimizationLogEntry {
    int stage = 1;
    int round = 0;
    int iteration = 0;
    double cost = 0.0;
    double epeCost = 0.0;
    double sourceFillCost = 0.0;
    double nilsCost = 0.0;            ///< NILS ペナルティ（重み未適用、集計後に weightNilsPenalty × 値）
    int nonConvergedCount = 0;        ///< Newton が tolerance に収束しなかった評価点数（参考値。result.epe はそのまま採用）
    double gradientNorm = 0.0;
    double stepSize = 0.0;
    double sourceFillRatio = 0.0;
    double sliceLevel = 0.0;
    double stageBestCost = 0.0;       ///< そのstage内でここまでに観測された最良cost（重み込み総コスト基準）
    double stageBestSliceLevel = 0.0; ///< stageBestCost達成時のsliceLevel
    // 最終選択トラッカー（feasibility 優先、同クラス内では EPE コスト基準）の現在値
    // 最終出力（save する光源）はこの picked に基づくため、ログでも追跡できるようにする。
    double pickedEpeCost = 0.0;       ///< picked が現時点で保持する EPE コスト
    double pickedTotalCost = 0.0;     ///< picked が現時点で保持する重み込み総コスト
    int pickedFeasible = 0;           ///< picked が feasible (1) か infeasible (0) か
};

/*!
 * @brief 最適化結果
 */
struct OptimizationResult {
    bool converged = false;
    int iterations = 0;
    double finalCost = 0.0;
    double finalEpeCost = 0.0;
    double finalSourceFillCost = 0.0;
    double finalNilsCost = 0.0;       ///< 最終状態の NILS ペナルティ（重み未適用）
    double finalGradientNorm = 0.0;
    double finalSliceLevel = 0.0;
    double finalSourceFillRatio = 0.0;
    std::string terminationReason;
    std::vector<OptimizationLogEntry> log;
    std::vector<double> finalVariables;  ///< 最終（最良）変数ベクトル
};

/*!
 * @brief 変数マッピング情報
 */
struct VariableInfo {
    int varIndex = 0;
    double gx = 0.0;
    double gy = 0.0;
    int multiplier = 1;
};

} // namespace so

#endif // SO_TYPES_H
