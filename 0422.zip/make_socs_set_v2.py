#!/bin/env python3
"""
make_socs_set_v2: 点光源設定ファイルから全点光源・全デフォーカス条件に対するSOCSファイルセットを生成
M2D/M3D対応

v2の変更点:
  - 並列実装をSliding Window方式に変更
    （常にmax_jobs個のLSFジョブを投入中に保ち、1個でも完了したら即次を投入）
  - bjobsを一括クエリ化（複数ジョブIDをまとめて1回のbjobsで取得）
  - 進捗表示を追加（completed / total, RUN, PEND, in-flight, queued）
  - --poll_interval オプション追加（デフォルト5秒）
  - max_retries超過時、残存in-flightジョブをbkillでクリーンアップしてから終了

(c) K. Kodera, Kioxia 2024.
"""
import os
import subprocess
import re
import argparse
import sys
import time
import shutil
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Dict, Optional
from source_blur import parse_blur_config, create_method, generate_grid as blur_generate_grid

os.environ['tcc_version'] = "3.0"


@dataclass
class SourceConfig:
    """点光源設定"""
    src_grid: int
    src_sigma_max: float
    src_sigma_min: float
    src_symmetry: str  # "D2" or "none"


@dataclass
class SourcePoint:
    """点光源情報"""
    source_id: str
    coordinates: List[Tuple[float, float, float]]  # [(x, y, intensity), ...]
    filepath: str


def parse_source_config(config_path: str) -> SourceConfig:
    """source_config.txtをパースする（ソース設定のみ）"""
    with open(config_path, 'r') as f:
        content = f.read()

    lines = content.split('\n')

    src_grid = None
    src_sigma_max = None
    src_sigma_min = None
    src_symmetry = None

    for line in lines:
        line_stripped = line.strip()

        if '#' in line_stripped and not line_stripped.startswith('#'):
            line_stripped = line_stripped.split('#')[0].strip()

        match = re.match(r'^src_grid\s+(\d+)', line_stripped)
        if match:
            src_grid = int(match.group(1))
            continue

        match = re.match(r'^src_sigma_max\s+([\d.]+)', line_stripped)
        if match:
            src_sigma_max = float(match.group(1))
            continue

        match = re.match(r'^src_sigma_min\s+([\d.]+)', line_stripped)
        if match:
            src_sigma_min = float(match.group(1))
            continue

        match = re.match(r'^src_symmetry\s+(\S+)', line_stripped)
        if match:
            src_symmetry = match.group(1)
            continue

    if src_grid is None:
        raise ValueError("src_grid が指定されていません")
    if src_sigma_max is None:
        raise ValueError("src_sigma_max が指定されていません")
    if src_sigma_min is None:
        raise ValueError("src_sigma_min が指定されていません")
    if src_symmetry is None:
        raise ValueError("src_symmetry が指定されていません")
    if src_symmetry not in ['D2', 'none']:
        raise ValueError(f"src_symmetry は 'D2' または 'none' である必要があります: {src_symmetry}")

    return SourceConfig(
        src_grid=src_grid,
        src_sigma_max=src_sigma_max,
        src_sigma_min=src_sigma_min,
        src_symmetry=src_symmetry
    )


def parse_pwc_config(pwc_path: str) -> List[float]:
    """pwc_config.txtをパースしてユニークなdefocusリストを返す"""
    with open(pwc_path, 'r') as f:
        content = f.read()

    lines = content.split('\n')
    defocus_list = []
    in_pwc = False

    for line in lines:
        line_stripped = line.strip()

        if line_stripped.startswith('<pwc>'):
            in_pwc = True
            continue
        elif line_stripped.startswith('</pwc>'):
            in_pwc = False
            continue

        if in_pwc:
            if not line_stripped.startswith('#') and line_stripped:
                parts = line_stripped.split()
                if parts:
                    try:
                        defocus = float(parts[0])
                        defocus_list.append(defocus)
                    except ValueError:
                        pass

    defocus_list = sorted(list(set(defocus_list)))

    if not defocus_list:
        raise ValueError("pwc_config.txt に有効なdefocus値が見つかりません")

    return defocus_list


def generate_grid(src_grid: int) -> np.ndarray:
    """グリッド座標を生成する"""
    if src_grid % 2 == 1:
        coords = np.linspace(-1.0, 1.0, src_grid)
    else:
        half_step = 1.0 / src_grid
        coords = np.linspace(-1.0 + half_step, 1.0 - half_step, src_grid)
    return coords


def format_coord(val: float) -> str:
    """座標値を6桁固定でフォーマット"""
    return f"{val:.6f}"


def generate_source_id(x: float, y: float) -> str:
    """座標からsourceIDを生成"""
    return f"x{format_coord(x)}_y{format_coord(y)}"


def generate_sources(config: SourceConfig, output_dir: str) -> List[SourcePoint]:
    """点光源ファイルを生成する"""
    coords = generate_grid(config.src_grid)
    sources = []

    if config.src_symmetry == 'none':
        for x in coords:
            for y in coords:
                sigma = np.sqrt(x*x + y*y)
                if config.src_sigma_min <= sigma <= config.src_sigma_max:
                    source_id = generate_source_id(x, y)
                    filepath = os.path.join(output_dir, f"{source_id}.illum")
                    sources.append(SourcePoint(
                        source_id=source_id,
                        coordinates=[(x, y, 1.0)],
                        filepath=filepath
                    ))

    elif config.src_symmetry == 'D2':
        processed = set()

        for x in coords:
            for y in coords:
                sigma = np.sqrt(x*x + y*y)
                if not (config.src_sigma_min <= sigma <= config.src_sigma_max):
                    continue

                rep_x = abs(x)
                rep_y = abs(y)
                rep_key = (format_coord(rep_x), format_coord(rep_y))

                if rep_key in processed:
                    continue
                processed.add(rep_key)

                source_id = generate_source_id(rep_x, rep_y)
                filepath = os.path.join(output_dir, f"{source_id}.illum")

                coords_list = []

                is_origin = (abs(rep_x) < 1e-9 and abs(rep_y) < 1e-9)
                is_x_axis = (abs(rep_y) < 1e-9 and abs(rep_x) >= 1e-9)
                is_y_axis = (abs(rep_x) < 1e-9 and abs(rep_y) >= 1e-9)

                if is_origin:
                    coords_list.append((0.0, 0.0, 1.0))
                elif is_x_axis:
                    coords_list.append((rep_x, 0.0, 1.0))
                    coords_list.append((-rep_x, 0.0, 1.0))
                elif is_y_axis:
                    coords_list.append((0.0, rep_y, 1.0))
                    coords_list.append((0.0, -rep_y, 1.0))
                else:
                    coords_list.append((rep_x, rep_y, 1.0))
                    coords_list.append((-rep_x, rep_y, 1.0))
                    coords_list.append((-rep_x, -rep_y, 1.0))
                    coords_list.append((rep_x, -rep_y, 1.0))

                sources.append(SourcePoint(
                    source_id=source_id,
                    coordinates=coords_list,
                    filepath=filepath
                ))

    for source in sources:
        with open(source.filepath, 'w') as f:
            for x, y, intensity in source.coordinates:
                f.write(f"{x} {y} {intensity}\n")

    return sources


def get_mtcc_path() -> str:
    """MTCCPATHプレフィックスを取得"""
    path = os.environ.get('MTCCPATH', '')
    return path + '/' if path else ''


def make_defocus_str(defocus_nm: float) -> str:
    """デフォーカス値の文字列表現"""
    if defocus_nm == int(defocus_nm):
        return f"d{int(defocus_nm)}"
    return f"d{defocus_nm}"


def create_defocus_ini(ini_path: str, defocus_nm: float, output_ini_path: str):
    """デフォーカス値を変更したINIファイルを作成"""
    delta_um = defocus_nm / 1000.0

    with open(output_ini_path, 'w') as fout:
        with open(ini_path, 'r') as fin:
            for line in fin:
                match = re.match(r'^yok_defocus\s*([\d.eE+-]+)', line)
                if match:
                    original_defocus = float(match.group(1))
                    new_defocus = original_defocus + delta_um
                    fout.write(f'yok_defocus {new_defocus}\n')
                else:
                    fout.write(line)


def run_single_socs(source: SourcePoint, defocus_nm: float, ini_path: str,
                    output_dir: str, work_dir: str, kernel_num: int,
                    sgebunsan_num: int, openmp_num: int, quename: str,
                    jobname: str, cgrp: Optional[str] = None,
                    mask_kikaku: str = '4kikaku') -> Tuple[bool, str, str, Optional[str]]:
    """単一のSOCS計算を実行（逐次モード用）"""
    defocus_str = make_defocus_str(defocus_nm)
    socs_name = f"{source.source_id}_{defocus_str}.socs"
    socs_path = os.path.join(output_dir, socs_name)

    job_work_dir = os.path.join(work_dir, f"{source.source_id}_{defocus_str}")
    os.makedirs(job_work_dir, exist_ok=True)

    defocus_ini = os.path.join(job_work_dir, "config.ini")
    create_defocus_ini(ini_path, defocus_nm, defocus_ini)

    path = get_mtcc_path()
    norm_value = "N/A"

    try:
        if cgrp is None:
            tcc_path = os.path.join(job_work_dir, "tcc")
            cmd = f'{path}maketcc_lsf3 {source.filepath} {defocus_ini} {tcc_path}'
            cmd += f' -n {sgebunsan_num} -o {openmp_num}'
            cmd += f' -q {quename} -j {jobname}'
            cmd += f' -s --kernel_num {kernel_num}'

            ret = subprocess.run(cmd, shell=True, capture_output=True)
            if ret.returncode == 2:
                return False, socs_path, "0", "norm=0 warning"
            if ret.returncode != 0:
                return False, socs_path, "N/A", f"maketcc_lsf3 failed: {ret.stderr.decode()}"

            shutil.move(f"{tcc_path}.socs", socs_path)
        else:
            socsdir = os.path.join(job_work_dir, "socs")
            cmd = f'{path}maketcc_m3d {source.filepath} {defocus_ini} {socsdir}'
            cmd += f' --cgrp {cgrp}'
            cmd += f' -n {sgebunsan_num} -o {openmp_num}'
            cmd += f' -q {quename} -j {jobname}'
            cmd += f' -s --kernel_num {kernel_num}'
            cmd += f' --mask_kikaku {mask_kikaku}'

            ret = subprocess.run(cmd, shell=True, capture_output=True)
            if ret.returncode != 0:
                return False, socs_path, "N/A", f"maketcc_m3d failed: {ret.stderr.decode()}"

            shutil.move(socsdir, socs_path)
            norm_value = "M3D"

        return True, socs_path, norm_value, None

    except Exception as e:
        return False, socs_path, norm_value, str(e)


def bsub_job(cmd: str, quename: str, jobname: str, log_dir: str,
             openmp_num: int) -> Tuple[Optional[str], str]:
    """LSFジョブを投入してジョブIDを返す"""
    bsub_cmd = f'bsub -q {quename} -J {jobname} -oo {log_dir}/job.log '
    if openmp_num > 1:
        bsub_cmd += f'-n {openmp_num} -R "span[hosts=1]" '
    bsub_cmd += cmd

    result = subprocess.run(bsub_cmd, capture_output=True, shell=True)
    stdout = result.stdout.decode('utf8')
    stderr = result.stderr.decode('utf8')

    combined = stdout + '\n' + stderr
    match = re.search(r'Job <([0-9]+)>', combined)
    if match:
        return match.group(1), stdout
    return None, stdout + stderr


def submit_one_job(source: SourcePoint, defocus: float, ini_path: str,
                   output_dir: str, work_dir: str, kernel_num: int,
                   sgebunsan_num: int, openmp_num: int, quename: str,
                   jobname: str, cgrp: Optional[str], mask_kikaku: str,
                   path: str) -> Tuple[Optional[str], str, str]:
    """単一ジョブをLSFに投入し (job_id, socs_path, job_work_dir) を返す"""
    defocus_str = make_defocus_str(defocus)
    socs_name = f"{source.source_id}_{defocus_str}.socs"
    socs_path = os.path.join(output_dir, socs_name)

    job_work_dir = os.path.join(work_dir, f"{source.source_id}_{defocus_str}")
    os.makedirs(job_work_dir, exist_ok=True)

    defocus_ini = os.path.join(job_work_dir, "config.ini")
    create_defocus_ini(ini_path, defocus, defocus_ini)

    worker_script = os.path.join(job_work_dir, "worker.sh")

    if cgrp is None:
        tcc_path = os.path.join(job_work_dir, "tcc")
        script_content = f"""#!/bin/bash
set -e
{path}maketcc_lsf3 {source.filepath} {defocus_ini} {tcc_path} \
    -n {sgebunsan_num} -o {openmp_num} \
    -q {quename} -j {jobname}_sub \
    -s --kernel_num {kernel_num}
mv {tcc_path}.socs {socs_path}
rm -f {tcc_path}
rm -rf {tcc_path}.log
"""
    else:
        socsdir = os.path.join(job_work_dir, "socs")
        script_content = f"""#!/bin/bash
set -e
{path}maketcc_m3d {source.filepath} {defocus_ini} {socsdir} \
    --cgrp {cgrp} \
    -n {sgebunsan_num} -o {openmp_num} \
    -q {quename} -j {jobname}_sub \
    -s --kernel_num {kernel_num} \
    --mask_kikaku {mask_kikaku}
mv {socsdir} {socs_path}
rm -rf {socsdir}.log
"""

    with open(worker_script, 'w') as f:
        f.write(script_content)
    os.chmod(worker_script, 0o755)

    job_id, _ = bsub_job(
        worker_script, quename,
        f"{jobname}_{source.source_id}_{defocus_str}",
        job_work_dir, openmp_num
    )

    return job_id, socs_path, job_work_dir


def poll_jobs_batch(job_ids: List[str], chunk_size: int = 500) -> Dict[str, str]:
    """複数ジョブの状態を一括取得する

    Returns:
        Dict[job_id, state]  state: 'PEND','RUN','DONE','EXIT','NOT_FOUND','UNKNOWN' 等
    """
    if not job_ids:
        return {}

    states: Dict[str, str] = {}

    for i in range(0, len(job_ids), chunk_size):
        chunk = job_ids[i:i + chunk_size]
        cmd = "bjobs -noheader -o 'jobid stat' " + " ".join(chunk)
        result = subprocess.run(cmd, capture_output=True, shell=True)
        stdout = result.stdout.decode('utf8')
        stderr = result.stderr.decode('utf8')

        for line in stdout.split('\n'):
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 2:
                jid, state = parts[0], parts[1]
                states[jid] = state

        for m in re.finditer(r'Job <(\d+)> is not found', stderr):
            jid = m.group(1)
            if jid not in states:
                states[jid] = 'NOT_FOUND'

    for jid in job_ids:
        if jid not in states:
            states[jid] = 'UNKNOWN'

    return states


def bkill_jobs(job_ids: List[str]):
    """残っているLSFジョブを強制終了"""
    if not job_ids:
        return
    print(f"[Cleanup] killing {len(job_ids)} remaining jobs...", file=sys.stderr)
    cmd = "bkill " + " ".join(job_ids)
    subprocess.run(cmd, shell=True, capture_output=True)


def run_socs_sequential(sources: List[SourcePoint], defocus_list: List[float],
                        ini_path: str, output_dir: str, work_dir: str,
                        kernel_num: int, sgebunsan_num: int, openmp_num: int,
                        quename: str, jobname: str, max_retries: int,
                        cgrp: Optional[str] = None,
                        mask_kikaku: str = '4kikaku') -> Dict[str, str]:
    """逐次でSOCS計算を実行"""
    norm_info = {}

    total_jobs = len(sources) * len(defocus_list)
    current = 0

    for source in sources:
        for defocus in defocus_list:
            current += 1
            print(f"[{current}/{total_jobs}] Processing {source.source_id} defocus={defocus}nm",
                  file=sys.stderr)

            retries = 0
            while retries <= max_retries:
                success, socs_path, norm_value, error = run_single_socs(
                    source, defocus, ini_path, output_dir, work_dir,
                    kernel_num, sgebunsan_num, openmp_num,
                    quename, jobname, cgrp, mask_kikaku
                )

                if success:
                    norm_info[(defocus, source.source_id)] = norm_value
                    break
                else:
                    retries += 1
                    print(f"  Retry {retries}/{max_retries}: {error}", file=sys.stderr)
                    if retries > max_retries:
                        print(f"Error: Max retries exceeded for {source.source_id} defocus={defocus}",
                              file=sys.stderr)
                        sys.exit(1)

    return norm_info


def run_socs_parallel(sources: List[SourcePoint], defocus_list: List[float],
                      ini_path: str, output_dir: str, work_dir: str,
                      kernel_num: int, sgebunsan_num: int, openmp_num: int,
                      quename: str, jobname: str, max_jobs: int,
                      max_retries: int, cgrp: Optional[str] = None,
                      mask_kikaku: str = '4kikaku',
                      poll_interval: float = 5.0) -> Dict[str, str]:
    """並列でSOCS計算を実行（Sliding Window方式）

    常にmax_jobs個のLSFジョブを投入中に保ち、1個完了するたびに次を投入する。
    """
    norm_info: Dict[Tuple[float, str], str] = {}
    path = get_mtcc_path()

    all_jobs = [(source, defocus) for source in sources for defocus in defocus_list]
    total_jobs = len(all_jobs)
    pending: List[Tuple[SourcePoint, float]] = list(all_jobs)
    retry_count: Dict[Tuple[str, float], int] = {}
    in_flight: Dict[str, Tuple[SourcePoint, float, str, str]] = {}
    completed = 0
    total_retries = 0

    last_progress_time = 0.0

    print(f"[Parallel] total_jobs={total_jobs}, max_jobs={max_jobs}, "
          f"poll_interval={poll_interval}s", file=sys.stderr)

    def _fail_and_exit(reason: str):
        """エラー終了：残存ジョブをbkillしてからexit"""
        print(f"Error: {reason}", file=sys.stderr)
        bkill_jobs(list(in_flight.keys()))
        sys.exit(1)

    while pending or in_flight:
        # ---------- 1. in_flight を max_jobs まで埋める ----------
        submitted_this_round = 0
        while len(in_flight) < max_jobs and pending:
            source, defocus = pending.pop(0)
            job_id, socs_path, job_work_dir = submit_one_job(
                source, defocus, ini_path, output_dir, work_dir,
                kernel_num, sgebunsan_num, openmp_num,
                quename, jobname, cgrp, mask_kikaku, path
            )
            if job_id:
                in_flight[job_id] = (source, defocus, socs_path, job_work_dir)
                submitted_this_round += 1
            else:
                key = (source.source_id, defocus)
                retry_count[key] = retry_count.get(key, 0) + 1
                total_retries += 1
                if retry_count[key] <= max_retries:
                    print(f"  Retry submit {retry_count[key]}/{max_retries}: "
                          f"{source.source_id} defocus={defocus}", file=sys.stderr)
                    pending.append((source, defocus))
                else:
                    _fail_and_exit(
                        f"Job submission failed (max retries) for "
                        f"{source.source_id} defocus={defocus}"
                    )

        if submitted_this_round > 0:
            print(f"[Submit] +{submitted_this_round} job(s) (in-flight={len(in_flight)}, "
                  f"queued={len(pending)})", file=sys.stderr)

        if not in_flight:
            break

        # ---------- 2. 投入中ジョブの状態を一括取得 ----------
        states = poll_jobs_batch(list(in_flight.keys()))

        running = 0
        pending_lsf = 0
        unknown = 0
        finished: List[Tuple[str, bool]] = []  # (job_id, success)

        for jid, state in states.items():
            if state == 'DONE':
                finished.append((jid, True))
            elif state == 'EXIT':
                finished.append((jid, False))
            elif state == 'NOT_FOUND':
                # 履歴から消えた → 成功扱い（最終判定はファイル存在チェック）
                finished.append((jid, True))
            elif state == 'RUN':
                running += 1
            elif state in ('PEND', 'PSUSP', 'USUSP', 'SSUSP', 'WAIT'):
                pending_lsf += 1
            else:
                unknown += 1

        # ---------- 3. 完了ジョブの処理 ----------
        for jid, success in finished:
            source, defocus, socs_path, job_work_dir = in_flight.pop(jid)
            actual_success = success and os.path.exists(socs_path)

            if actual_success:
                norm_info[(defocus, source.source_id)] = (
                    "M3D" if cgrp is not None else "N/A"
                )
                completed += 1
            else:
                key = (source.source_id, defocus)
                retry_count[key] = retry_count.get(key, 0) + 1
                total_retries += 1

                if retry_count[key] <= max_retries:
                    print(f"  Retry {retry_count[key]}/{max_retries}: "
                          f"{source.source_id} defocus={defocus} (jobid={jid})",
                          file=sys.stderr)
                    pending.append((source, defocus))
                else:
                    _fail_and_exit(
                        f"Max retries exceeded for "
                        f"{source.source_id} defocus={defocus}"
                    )

        # ---------- 4. 進捗表示 ----------
        now = time.time()
        if finished or (now - last_progress_time) >= poll_interval:
            unknown_suffix = f" UNKNOWN={unknown}" if unknown else ""
            print(f"[Progress] done={completed}/{total_jobs} | "
                  f"RUN={running} PEND={pending_lsf}{unknown_suffix} | "
                  f"in-flight={len(in_flight)} queued={len(pending)} | "
                  f"retries={total_retries}",
                  file=sys.stderr)
            last_progress_time = now

        # ---------- 5. 完了ジョブがなければスリープ ----------
        if not finished:
            time.sleep(poll_interval)

    print(f"[Parallel] all {total_jobs} jobs completed (total retries: {total_retries})",
          file=sys.stderr)
    return norm_info


def write_debug_info(config: SourceConfig, defocus_list: List[float],
                     norm_info: Dict, output_path: str,
                     cgrp: Optional[str] = None,
                     mask_kikaku: str = '4kikaku'):
    """デバッグ情報を出力"""
    with open(output_path, 'w') as f:
        f.write('[SOURCE_CONFIG]\n')
        f.write(f'src_grid {config.src_grid}\n')
        f.write(f'src_sigma_max {config.src_sigma_max}\n')
        f.write(f'src_sigma_min {config.src_sigma_min}\n')
        f.write(f'src_symmetry {config.src_symmetry}\n')
        if cgrp is not None:
            f.write(f'mode M3D\n')
            f.write(f'cgrp {cgrp}\n')
            f.write(f'mask_kikaku {mask_kikaku}\n')
        else:
            f.write(f'mode M2D\n')
        f.write('\n')

        f.write('[DEFOCUS]\n')
        f.write('#defocus[nm]\n')
        for defocus in defocus_list:
            defocus_out = int(defocus) if defocus == int(defocus) else defocus
            f.write(f'{defocus_out}\n')
        f.write('\n')

        f.write('[NORM]\n')
        if cgrp is not None:
            f.write('#defocus sourceID norm (M3D: see m3dinfo in each .socs directory)\n')
        else:
            f.write('#defocus sourceID norm\n')
        for (defocus, source_id), norm in sorted(norm_info.items()):
            defocus_out = int(defocus) if defocus == int(defocus) else defocus
            f.write(f'{defocus_out} {source_id} {norm}\n')


def main():
    parser = argparse.ArgumentParser(
        description='Generate SOCS file set from point source configuration (v2). '
                    'Supports M2D and M3D modes. Parallel mode uses sliding-window '
                    'scheduling to keep max_jobs concurrent jobs on LSF. '
                    '(c) xxxxxx.')

    parser.add_argument('--source', required=True, help='Source configuration file')
    parser.add_argument('--pwc', required=True, help='PWC configuration file')
    parser.add_argument('--ini', required=True, help='TCC configuration file (TCCinfo)')

    parser.add_argument('-o', '--output', default='socs_set',
                        help='Output directory name (default: socs_set)')
    parser.add_argument('--debug', action='store_true',
                        help='Output debug information file')
    parser.add_argument('-n', '--sgebunsan_num', default=1, type=int,
                        help='LSF parallel job count (default: 1)')
    parser.add_argument('-j', '--openmp_num', default=1, type=int,
                        help='OpenMP thread count (default: 1)')
    parser.add_argument('-q', '--quename', default='LITHOALL',
                        help='LSF queue name (default: LITHOALL)')
    parser.add_argument('--jobname', default='SOCS',
                        help='LSF job name prefix (default: SOCS)')
    parser.add_argument('--kernel_num', default=100, type=int,
                        help='SOCS kernel count (default: 100)')
    parser.add_argument('--parallel', action='store_true',
                        help='Enable parallel execution for source x defocus combinations')
    parser.add_argument('--max_jobs', default=1000, type=int,
                        help='Maximum concurrent jobs for parallel mode (default: 1000)')
    parser.add_argument('--max_retries', default=3, type=int,
                        help='Maximum retry count for failed jobs (default: 3)')
    parser.add_argument('--poll_interval', default=5.0, type=float,
                        help='Polling interval in seconds for parallel mode (default: 5.0)')

    parser.add_argument('--cgrp', default=None,
                        help='Coherent group file (enables M3D mode)')
    parser.add_argument('--mask_kikaku', default='4kikaku',
                        help='Mask standard for M3D (default: 4kikaku)')

    args = parser.parse_args()

    mode = 'M3D' if args.cgrp else 'M2D'

    print('=' * 80, file=sys.stderr)
    print(f'make_socs_set_v2: SOCS file set generator ({mode} mode)', file=sys.stderr)
    print('(c) xxxxxx.', file=sys.stderr)
    print('=' * 80, file=sys.stderr)

    if os.path.exists(args.output):
        print(f"Error: Output directory '{args.output}' already exists.", file=sys.stderr)
        sys.exit(1)

    for filepath, name in [(args.source, 'Source config'),
                           (args.pwc, 'PWC config'),
                           (args.ini, 'INI file')]:
        if not os.path.exists(filepath):
            print(f"Error: {name} file '{filepath}' not found.", file=sys.stderr)
            sys.exit(1)

    if args.cgrp and not os.path.exists(args.cgrp):
        print(f"Error: Coherent group file '{args.cgrp}' not found.", file=sys.stderr)
        sys.exit(1)

    print(f"Reading source configuration: {args.source}", file=sys.stderr)
    config = parse_source_config(args.source)

    print(f"  src_grid: {config.src_grid}", file=sys.stderr)
    print(f"  src_sigma_max: {config.src_sigma_max}", file=sys.stderr)
    print(f"  src_sigma_min: {config.src_sigma_min}", file=sys.stderr)
    print(f"  src_symmetry: {config.src_symmetry}", file=sys.stderr)

    blur_config = parse_blur_config(args.source)
    blur_method = None
    if blur_config.method != 'none':
        print(f"  src_blur: method={blur_config.method}, "
              f"output_grid={blur_config.output_grid}, "
              f"param={blur_config.param}",
              file=sys.stderr)
        blur_method = create_method(blur_config, ini_path=args.ini)

    print(f"Reading PWC configuration: {args.pwc}", file=sys.stderr)
    defocus_list = parse_pwc_config(args.pwc)
    print(f"  defocus values: {defocus_list}", file=sys.stderr)

    if args.cgrp:
        print(f"M3D mode: cgrp={args.cgrp}, mask_kikaku={args.mask_kikaku}", file=sys.stderr)

    os.makedirs(args.output)
    work_dir = os.path.join(args.output, '.work')
    os.makedirs(work_dir)

    print("Generating point source files...", file=sys.stderr)
    sources = generate_sources(config, args.output)
    print(f"  Generated {len(sources)} source files", file=sys.stderr)

    if blur_method is not None:
        print(f"Applying blur to source files (output_grid={blur_config.output_grid})...",
              file=sys.stderr)
        in_coords = generate_grid(config.src_grid)
        out_coords = blur_generate_grid(blur_config.output_grid)
        n_in = len(in_coords)

        for source in sources:
            delta = np.zeros((n_in, n_in))
            for sx, sy, intensity in source.coordinates:
                ix = np.argmin(np.abs(in_coords - sx))
                iy = np.argmin(np.abs(in_coords - sy))
                delta[iy, ix] = intensity

            blurred = blur_method.interpolate_2d(in_coords, delta, out_coords)

            with open(source.filepath, 'w') as f:
                for iy in range(len(out_coords)):
                    for ix in range(len(out_coords)):
                        val = blurred[iy, ix]
                        if abs(val) > 1e-6:
                            f.write(f"{out_coords[ix]} {out_coords[iy]} {val}\n")

        print(f"  Blur applied to {len(sources)} source files", file=sys.stderr)

    total_socs = len(sources) * len(defocus_list)
    print(f"Starting SOCS calculation ({total_socs} files, {mode})...", file=sys.stderr)

    if args.parallel:
        print(f"  Mode: Parallel (sliding-window, max_jobs={args.max_jobs}, "
              f"poll_interval={args.poll_interval}s)", file=sys.stderr)
        norm_info = run_socs_parallel(
            sources, defocus_list, args.ini,
            args.output, work_dir, args.kernel_num,
            args.sgebunsan_num, args.openmp_num,
            args.quename, args.jobname, args.max_jobs,
            args.max_retries, args.cgrp, args.mask_kikaku,
            args.poll_interval
        )
    else:
        print("  Mode: Sequential", file=sys.stderr)
        norm_info = run_socs_sequential(
            sources, defocus_list, args.ini,
            args.output, work_dir, args.kernel_num,
            args.sgebunsan_num, args.openmp_num,
            args.quename, args.jobname,
            args.max_retries, args.cgrp, args.mask_kikaku
        )

    if args.debug:
        debug_path = os.path.join(args.output, 'debug_info.txt')
        print(f"Writing debug info: {debug_path}", file=sys.stderr)
        write_debug_info(config, defocus_list, norm_info, debug_path,
                         args.cgrp, args.mask_kikaku)

    shutil.rmtree(work_dir)

    print('=' * 80, file=sys.stderr)
    print('make_socs_set_v2: Successfully completed', file=sys.stderr)
    print('=' * 80, file=sys.stderr)

    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
