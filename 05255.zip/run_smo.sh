#!/bin/bash
#
# SMO (Source-Mask Optimization) driver
#
# Iterates source optimization and OPC N times, and runs a ternary
# search over NA at every cycle to pick the best value.
#
# Flow (one cycle):
#   1. For each NA: generate ini -> SOCS -> source optimization -> cost
#   2. Ternary search to choose the best NA
#   3. With the best NA: generate MSOCS (blurred illum if configured) -> run OPC
#   4. Feed the OPC output .oas into the next cycle
#
# Usage: ./run_smo.sh [options]
#   --num_cycles <N>       source-opt / OPC iteration count (default: 3)
#   --na_search_mode <m>   ternary | parallel (default: ternary)
#                          ternary : 三分探索 (適応的・シーケンシャル)
#                          parallel: 全 NA 候補を NA_PRECISION 刻みで列挙し同時並列実行
#   --na_min <val>         NA search lower bound (default: 1.0)
#   --na_max <val>         NA search upper bound (default: 1.35)
#   --na_tol <val>         NA convergence threshold (ternary のみ) (default: 0.01)
#   --max_iter <N>         srcOptim max iterations (default: 16)
#   --gradient_method <N>  gradient method (default: 2)
#   --optimizer <str>      optimizer (default: lbfgs)
#   -j <N>                 OpenMP threads (default: 8)
#   --np <N>               MPI ranks (default: 2)
#   --kernel_num <N>       SOCS kernel count (default: 100)
#   --m3d_so               enable M3D mode for source optimization (SOCS)
#   --m3d_opc              enable M3D mode for OPC (MSOCS)
#   --cgrp <file>          coherent-group file (used when --m3d_opc is set)
#   --mask_kikaku <str>    mask specification (default: 4kikaku)
#   --layout_org_dir <d>   layout source directory (overrides setup.sh default)
#   --layout_org_name <n>  layout name relative to layout_org_dir (e.g. AAA/BBB.gds)
#   --evp <file>           evaluation points csv (overrides setup.sh default)
#   --opc_mode <m>         OPC execution mode (default: wait)
#                          wait   : wait for ./run.csh to finish
#                          kill   : poll for output, kill ./run.csh on appear
#                          detach : poll for output, leave ./run.csh in background
#   --num_starts <N>       Multi-Start: SO を異なる SA seed で N 並列実行 (default: 1)
#   --start_seeds "..."    seed リスト (e.g. "11,22,33,44") (default: 1..N)
#   --use_socs_half <0|1>  半数 SOCS 生成 (--socs_skip_y_gt_x) を有効化 (default: 0)
#   --use_socs_tarxz <0|1> 生成後 socs_set.tar.xz に圧縮、LSF ジョブ内で展開 (default: 0)
#   --no_blur              source_config に src_blur が書かれていても
#                          MSOCS 生成前の blur を強制 skip する
#
#   ===== srcOptim 新規ペナルティ / tolerance / 正則化 =====
#   --tolerance <val>           EPE deadband (nm)。マージン計測の tolerance と
#                               一致させると DoF が伸びる傾向あり。空ならスキップし
#                               evp.csv の tolerance 列を使う (default: "")
#   --weight_nils <val>         NILS ペナルティ重み。0 で無効 (default: 0)
#   --nils_min <val>            NILS 下限 (default: 2.0)
#   --nils_cd_ref <val>         NILS 計算用 CD ref (default: 0.022)
#   --weight_bt <val>           Bossung Tilt ペナルティ重み。0 で無効 (default: 0)
#   --bt_power <int>            BT 指数 (default: 2)
#   --weight_bfs <val>          Best Focus Shift ペナルティ重み。0 で無効 (default: 0)
#   --bfs_power <int>           BFS 指数 (default: 2)
#   --pair_clips "<list>"       BT/BFS 適用 clip ID (default: "" = 全 clip)
#   --bt_pairs "<F,N;F,N;..>"   複数 BT ペア (例: "1,0;7,8;9,10")。空なら defocus 極値ペア自動検出
#   --bfs_pairs "<F,N[,Nom];...>"  複数 BFS ペア。3つ組指定可 (例: "1,0,2;7,8,5")。
#                               Nom 省略時は --bfs_pwc_nom 共通値を使用
#   --bfs_pwc_nom <int>         BFS の共通 Nom PWC index (空=auto: defocus=0,bias=0,dose=0)
#   --regularization <kind>     正則化種別 (none|L1|L2 等) (default: none)
#   --regularization_weight <v> 正則化重み (default: 0)
#
#   ===== sliceLevel 範囲制限 / OPC sliceLevel ソース =====
#   --slice_min <val>           sliceLevel 下限 (全 objective で clamp) (default: 0.05)
#   --slice_max <val>           sliceLevel 上限 (default: 0.50)
#   --opc_slice_mode <m>        OPC の sliceLevel ソース so|fixed (default: so)
#                               so   : SO の cost.csv の sliceLevel を flow03/flow10 に設定
#                               fixed: --opc_slice_fixed の固定値を設定
#   --opc_slice_fixed <val>     opc_slice_mode=fixed のときの固定 sliceLevel (default: 0.30)
#
#   ===== srcOptim warmup (各 stage 序盤の round を粗く回す) =====
#   --warmup_rounds <N>         各 stage の最初の N round を warmup 扱い。0 で無効 (default: 0)
#   --warmup_max_iter <N>       warmup round 内の L-BFGS 最大反復 (default: 4)
#   --so_warmup_rounds_per_cycle "<csv>"    cycle 別 warmup_rounds (例: "20,10,0")
#   --so_warmup_max_iter_per_cycle "<csv>"  cycle 別 warmup_max_iter (例: "4,4,4")
#
#   --config <file>        extra shell script sourced after setup.sh to override
#                          any variable defined there
#

set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd)

# ========== Pre-parse: --config を先に拾う ==========
# setup.sh より後、他ライブラリより前で source する必要があるため、ここで抽出する
CONFIG_FILE=""
_pre_args=()
while [[ $# -gt 0 ]]; do
    case $1 in
        --config) CONFIG_FILE="$2"; shift 2 ;;
        *)        _pre_args+=("$1"); shift ;;
    esac
done
set -- "${_pre_args[@]}"

# ========== Load libraries ==========
source "$SCRIPT_DIR/smo_lib/setup.sh"

# ユーザー設定ファイルで setup.sh の変数を上書き
if [ -n "$CONFIG_FILE" ]; then
    if [ ! -f "$CONFIG_FILE" ]; then
        echo "Error: --config file not found: $CONFIG_FILE" >&2
        exit 1
    fi
    source "$CONFIG_FILE"
fi

source "$SCRIPT_DIR/smo_lib/helpers.sh"
source "$SCRIPT_DIR/smo_lib/srcoptim.sh"
source "$SCRIPT_DIR/smo_lib/opc.sh"
source "$SCRIPT_DIR/smo_lib/na_search.sh"

# ========== Parse options ==========
while [[ $# -gt 0 ]]; do
    case $1 in
        --num_cycles)   NUM_CYCLES="$2";       shift 2 ;;
        --na_search_mode) NA_SEARCH_MODE="$2"; shift 2 ;;
        --na_min)       NA_MIN="$2";           shift 2 ;;
        --na_max)       NA_MAX="$2";           shift 2 ;;
        --na_tol)       NA_TOL="$2";           shift 2 ;;
        --na_precision) NA_PRECISION="$2";     shift 2 ;;
        --max_iter)     MAX_ITER="$2";         shift 2 ;;
        --gradient_method) GRADIENT_METHOD="$2"; shift 2 ;;
        --optimizer)    OPTIMIZER="$2";        shift 2 ;;
        -j)             OPENMP_NUM="$2";       shift 2 ;;
        --np)           MPI_NP="$2";           shift 2 ;;
        --kernel_num)   KERNEL_NUM="$2";       shift 2 ;;
        --m3d_so)       M3D_SO=1;              shift ;;
        --m3d_opc)      M3D_OPC=1;             shift ;;
        --cgrp)         CGRP="$2";             shift 2 ;;
        --tko_max_epoch_per_cycle) TKO_MAX_EPOCH_PER_CYCLE="$2"; shift 2 ;;
        --tko_conv_per_cycle)      TKO_CONV_PER_CYCLE="$2";      shift 2 ;;
        --max_iter_per_cycle)                 MAX_ITER_PER_CYCLE="$2";                 shift 2 ;;
        --so_num_starts_per_cycle)            SO_NUM_STARTS_PER_CYCLE="$2";            shift 2 ;;
        --so_bh_stall_rounds_per_cycle)       SO_BH_STALL_ROUNDS_PER_CYCLE="$2";       shift 2 ;;
        --so_slicelevel_rounds_per_cycle)     SO_SLICELEVEL_ROUNDS_PER_CYCLE="$2";     shift 2 ;;
        --so_lbfgs_min_iter_per_cycle)        SO_LBFGS_MIN_ITER_PER_CYCLE="$2";        shift 2 ;;
        --so_bh_amplitude_init_per_cycle)     SO_BH_AMPLITUDE_INIT_PER_CYCLE="$2";     shift 2 ;;
        --so_bh_cooling_per_cycle)            SO_BH_COOLING_PER_CYCLE="$2";            shift 2 ;;
        --so_epe_power_schedule_per_cycle)            SO_EPE_POWER_SCHEDULE_PER_CYCLE="$2";            shift 2 ;;
        --so_adaptive_weight_p_schedule_per_cycle)    SO_ADAPTIVE_WEIGHT_P_SCHEDULE_PER_CYCLE="$2";    shift 2 ;;
        --so_adaptive_weight_floor_schedule_per_cycle) SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE_PER_CYCLE="$2"; shift 2 ;;
        --tko_num_hosts)     TK_OMP_NUM_HOSTS_TKO="$2";     shift 2 ;;
        --tko_num_threads)   TK_OMP_NUM_THREADS_TKO="$2";   shift 2 ;;
        --light_num_hosts)   TK_OMP_NUM_HOSTS_LIGHT="$2";   shift 2 ;;
        --light_num_threads) TK_OMP_NUM_THREADS_LIGHT="$2"; shift 2 ;;
        --tkqilt_slice_init) TKQILT_SLICE_INIT="$2";        shift 2 ;;
        --tkqilt_slice_step) TKQILT_SLICE_STEP="$2";        shift 2 ;;
        --tkqilt_max_retry)  TKQILT_MAX_RETRY="$2";         shift 2 ;;
        --mask_kikaku)  MASK_KIKAKU="$2";      shift 2 ;;
        --layout_org_dir)  LAYOUT_ORG_DIR="$2";  shift 2 ;;
        --layout_org_name) LAYOUT_ORG_NAME="$2"; shift 2 ;;
        --layout_oas)      LAYOUT_OAS="$2";      shift 2 ;;
        --evp)             EVP="$2";             shift 2 ;;
        --opc_mode)        OPC_MODE="$2";        shift 2 ;;
        --num_starts)      SO_NUM_STARTS="$2";   shift 2 ;;
        --start_seeds)     SO_START_SEEDS="$2";  shift 2 ;;
        --use_socs_half)   USE_SOCS_HALF="$2";   shift 2 ;;
        --use_socs_tarxz)  USE_SOCS_TARXZ="$2";  shift 2 ;;
        --no_blur)         DISABLE_BLUR=1;       shift ;;
        # ===== srcOptim 新規ペナルティ / tolerance / 正則化 =====
        --tolerance)       SO_TOLERANCE="$2";    shift 2 ;;
        --weight_nils)     SO_WEIGHT_NILS="$2";  shift 2 ;;
        --nils_min)        SO_NILS_MIN="$2";     shift 2 ;;
        --nils_cd_ref)     SO_NILS_CD_REF="$2";  shift 2 ;;
        --weight_bt)       SO_WEIGHT_BT="$2";    shift 2 ;;
        --bt_power)        SO_BT_POWER="$2";     shift 2 ;;
        --weight_bfs)      SO_WEIGHT_BFS="$2";   shift 2 ;;
        --bfs_power)       SO_BFS_POWER="$2";    shift 2 ;;
        --pair_clips)      SO_PAIR_CLIPS="$2";   shift 2 ;;
        --bt_pairs)        SO_BT_PAIRS="$2";     shift 2 ;;
        --bfs_pairs)       SO_BFS_PAIRS="$2";    shift 2 ;;
        --bfs_pwc_nom)     SO_BFS_PWC_NOM="$2";  shift 2 ;;
        --regularization)         SO_REGULARIZATION="$2";        shift 2 ;;
        --regularization_weight)  SO_REGULARIZATION_WEIGHT="$2"; shift 2 ;;
        # ===== sliceLevel 範囲制限 / OPC sliceLevel ソース =====
        --slice_min)       SO_SLICE_MIN="$2";    shift 2 ;;
        --slice_max)       SO_SLICE_MAX="$2";    shift 2 ;;
        --opc_slice_mode)  OPC_SLICE_MODE="$2";  shift 2 ;;
        --opc_slice_fixed) OPC_SLICE_FIXED="$2"; shift 2 ;;
        # ===== srcOptim warmup (各 stage 序盤の round を粗く回す) =====
        --warmup_rounds)   SO_WARMUP_ROUNDS="$2";   shift 2 ;;
        --warmup_max_iter) SO_WARMUP_MAX_ITER="$2"; shift 2 ;;
        --so_warmup_rounds_per_cycle)   SO_WARMUP_ROUNDS_PER_CYCLE="$2";   shift 2 ;;
        --so_warmup_max_iter_per_cycle) SO_WARMUP_MAX_ITER_PER_CYCLE="$2"; shift 2 ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# ========== Derive layout paths (CLI で上書きされた場合にも対応) ==========
LAYOUT_ORIGINAL="$LAYOUT_ORG_DIR/$LAYOUT_ORG_NAME"
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME##*/}"
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME_DASH%.*}"
LAYOUT_WORK_DIR="$WORK_DIR/$LAYOUT_ORG_NAME_DASH"

# no-vis OPC 用: cycle 1 入力 OAS を導出 (未指定なら LAYOUT_ORIGINAL の .gds → .oas)
if [ -z "$LAYOUT_OAS" ]; then
    LAYOUT_OAS="${LAYOUT_ORIGINAL%.gds}.oas"
fi

# ========== Validate OPC_MODE ==========
case "$OPC_MODE" in
    wait|kill|detach) ;;
    *)
        echo "Error: invalid --opc_mode '$OPC_MODE' (valid: wait|kill|detach)" >&2
        exit 1
        ;;
esac

# ========== Initialization ==========
mkdir -p "$WORK_DIR" "$SOCS_CACHE_DIR" "$LAYOUT_WORK_DIR"

SMO_LOG="$LAYOUT_WORK_DIR/smo_log.csv"
echo "cycle,na,cost,illum,opc_layout" > "$SMO_LOG"

# ========== Info banner ==========
echo "=============================================="
echo "SMO (Source-Mask Optimization)"
echo "=============================================="
echo "Num cycles:       $NUM_CYCLES"
echo "NA search mode:   $NA_SEARCH_MODE"
echo "NA search range:  [$NA_MIN, $NA_MAX]"
echo "NA tolerance:     $NA_TOL$([ "$NA_SEARCH_MODE" = "parallel" ] && echo "  (ternary のみ・未使用)")"
echo "NA precision:     $NA_PRECISION"
echo "Optimizer:        $OPTIMIZER"
echo "Gradient method:  $GRADIENT_METHOD"
echo "Max iterations:   $MAX_ITER"
echo "OpenMP threads:   $OPENMP_NUM"
echo "MPI ranks:        $MPI_NP"
echo "Kernel num:       $KERNEL_NUM"
echo "Layout:           $LAYOUT_ORIGINAL"
echo "Layout OAS:       $LAYOUT_OAS"
echo "Layout dash:      $LAYOUT_ORG_NAME_DASH"
echo "Layout layer (1): $LAYOUT_LAYER_INI"
echo "Layout layer (N): $LAYOUT_LAYER"
echo "EVP:              $EVP"
echo "OPC mode:         $OPC_MODE"
echo "OPC template:     $OPC_TEMPLATE_DIR"
echo "Mode (SO):        $([ "$M3D_SO" = "1" ] && echo M3D || echo M2D)"
echo "SO Multi-Start:   num_starts=${SO_NUM_STARTS}, seeds=${SO_START_SEEDS:-auto}"
echo "SOCS half (y>=x): $([ "$USE_SOCS_HALF" = "1" ] && echo "ON (--socs_skip_y_gt_x; transpose-expand via NA-shared cache)" || echo OFF)"
echo "SOCS tar.xz:      $([ "$USE_SOCS_TARXZ" = "1" ] && echo "ON (pack on gen; extract once per NA into NA-shared cache)" || echo OFF)"
echo "Mode (OPC):       $([ "$M3D_OPC" = "1" ] && echo M3D || echo M2D)"
if [ "$M3D_SO" = "1" ] || [ "$M3D_OPC" = "1" ]; then
    echo "Mask kikaku:      $MASK_KIKAKU"
fi
if [ "$M3D_OPC" = "1" ]; then
    if [ -n "$CGRP" ]; then
        echo "CGRP:             $CGRP"
    else
        echo "CGRP:             (auto-generated per cycle)"
    fi
fi
echo "TKO MaxEpoch:     ${TKO_MAX_EPOCH_PER_CYCLE:-template}  (per-cycle CSV; last value repeats)"
echo "TKO Convergence:  ${TKO_CONV_PER_CYCLE:-template}  (per-cycle CSV; last value repeats)"

# ===== srcOptim 新規ペナルティ / tolerance =====
echo "SO tolerance:     ${SO_TOLERANCE:-(use evp.csv tolerance column)}"
if awk -v w="${SO_WEIGHT_NILS:-0}" 'BEGIN{exit !(w>0)}'; then
    echo "SO NILS:          weight=$SO_WEIGHT_NILS, min=$SO_NILS_MIN, cd_ref=$SO_NILS_CD_REF"
else
    echo "SO NILS:          disabled"
fi
if awk -v w="${SO_WEIGHT_BT:-0}" 'BEGIN{exit !(w>0)}'; then
    echo "SO BT:            weight=$SO_WEIGHT_BT, power=$SO_BT_POWER"
else
    echo "SO BT:            disabled"
fi
if awk -v w="${SO_WEIGHT_BFS:-0}" 'BEGIN{exit !(w>0)}'; then
    echo "SO BFS:           weight=$SO_WEIGHT_BFS, power=$SO_BFS_POWER"
else
    echo "SO BFS:           disabled"
fi
if [ -n "$SO_PAIR_CLIPS" ]; then
    echo "SO pair_clips:    $SO_PAIR_CLIPS"
fi
if [ -n "$SO_BT_PAIRS" ]; then
    echo "SO bt_pairs:      $SO_BT_PAIRS"
fi
if [ -n "$SO_BFS_PAIRS" ]; then
    echo "SO bfs_pairs:     $SO_BFS_PAIRS"
fi
if [ -n "$SO_BFS_PWC_NOM" ]; then
    echo "SO bfs_pwc_nom:   $SO_BFS_PWC_NOM"
fi
if [ -n "$SO_REGULARIZATION" ] && [ "$SO_REGULARIZATION" != "none" ]; then
    echo "SO regularization: $SO_REGULARIZATION (weight=$SO_REGULARIZATION_WEIGHT)"
else
    echo "SO regularization: none"
fi
if [ -n "$SO_WARMUP_ROUNDS" ] && [ "$SO_WARMUP_ROUNDS" -gt 0 ] 2>/dev/null; then
    echo "SO warmup:        rounds=$SO_WARMUP_ROUNDS, max_iter=$SO_WARMUP_MAX_ITER"
fi
echo "SO sliceLevel:    range=[$SO_SLICE_MIN, $SO_SLICE_MAX]"
if [ "$OPC_SLICE_MODE" = "fixed" ]; then
    echo "OPC sliceLevel:   fixed=$OPC_SLICE_FIXED"
else
    echo "OPC sliceLevel:   from SO (cost.csv)"
fi

# SO per-cycle (set されているものだけ表示)
[ -n "$MAX_ITER_PER_CYCLE" ]                            && echo "SO MAX_ITER:                         $MAX_ITER_PER_CYCLE"
[ -n "$SO_NUM_STARTS_PER_CYCLE" ]                       && echo "SO NUM_STARTS:                       $SO_NUM_STARTS_PER_CYCLE"
[ -n "$SO_BH_STALL_ROUNDS_PER_CYCLE" ]                  && echo "SO BH_STALL_ROUNDS:                  $SO_BH_STALL_ROUNDS_PER_CYCLE"
[ -n "$SO_SLICELEVEL_ROUNDS_PER_CYCLE" ]                && echo "SO SLICELEVEL_ROUNDS:                $SO_SLICELEVEL_ROUNDS_PER_CYCLE"
[ -n "$SO_LBFGS_MIN_ITER_PER_CYCLE" ]                   && echo "SO LBFGS_MIN_ITER:                   $SO_LBFGS_MIN_ITER_PER_CYCLE"
[ -n "$SO_BH_AMPLITUDE_INIT_PER_CYCLE" ]                && echo "SO BH_AMPLITUDE_INIT:                $SO_BH_AMPLITUDE_INIT_PER_CYCLE"
[ -n "$SO_BH_COOLING_PER_CYCLE" ]                       && echo "SO BH_COOLING:                       $SO_BH_COOLING_PER_CYCLE"
[ -n "$SO_WARMUP_ROUNDS_PER_CYCLE" ]                    && echo "SO WARMUP_ROUNDS:                    $SO_WARMUP_ROUNDS_PER_CYCLE"
[ -n "$SO_WARMUP_MAX_ITER_PER_CYCLE" ]                  && echo "SO WARMUP_MAX_ITER:                  $SO_WARMUP_MAX_ITER_PER_CYCLE"
[ -n "$SO_EPE_POWER_SCHEDULE_PER_CYCLE" ]               && echo "SO EPE_POWER_SCHEDULE:               $SO_EPE_POWER_SCHEDULE_PER_CYCLE"
[ -n "$SO_ADAPTIVE_WEIGHT_P_SCHEDULE_PER_CYCLE" ]       && echo "SO ADAPTIVE_WEIGHT_P_SCHEDULE:       $SO_ADAPTIVE_WEIGHT_P_SCHEDULE_PER_CYCLE"
[ -n "$SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE_PER_CYCLE" ]   && echo "SO ADAPTIVE_WEIGHT_FLOOR_SCHEDULE:   $SO_ADAPTIVE_WEIGHT_FLOOR_SCHEDULE_PER_CYCLE"
echo "TKO parallel:     hosts=$TK_OMP_NUM_HOSTS_TKO, threads=$TK_OMP_NUM_THREADS_TKO  (flow03,10)"
echo "LIGHT parallel:   hosts=$TK_OMP_NUM_HOSTS_LIGHT, threads=$TK_OMP_NUM_THREADS_LIGHT  (tkl/tkq/tkv)"
echo "tkqilt retry:     init=$TKQILT_SLICE_INIT, step=$TKQILT_SLICE_STEP, max=$TKQILT_MAX_RETRY (flow02+flow03)"
if has_blur; then
    echo "Blur:             enabled (src_blur set in source_config)"
elif [ "${DISABLE_BLUR:-0}" = "1" ]; then
    echo "Blur:             disabled (forced by --no_blur / DISABLE_BLUR=1)"
else
    echo "Blur:             disabled (no src_blur in source_config)"
fi
echo "Work dir:         $WORK_DIR"
echo "Layout work dir:  $LAYOUT_WORK_DIR"
echo "SOCS cache dir:   $SOCS_CACHE_DIR"
if [ -n "$CONFIG_FILE" ]; then
    echo "Config file:      $CONFIG_FILE"
fi
echo "=============================================="
echo ""

# ========== Main loop ==========
CURRENT_LAYOUT="$LAYOUT_ORIGINAL"
CURRENT_SOURCE="$INITIAL_SOURCE"
# no-vis OPC 用: cycle 1 は ユーザー提供 OAS、cycle 2+ は前 cycle の OPC 出力
CURRENT_OAS="$LAYOUT_OAS"

# LAYOUT_LAYER は cycle ごとに上書きするため、オリジナル値を保存しておく
LAYOUT_LAYER_ORIG="$LAYOUT_LAYER"

for cycle in $(seq 1 "$NUM_CYCLES"); do
    echo ""
    echo "######################################################"
    echo "# Cycle $cycle / $NUM_CYCLES"
    echo "######################################################"
    echo ""

    # 1ループ目は INI レイヤ、2ループ目以降は通常レイヤを使う
    if [ "$cycle" -eq 1 ]; then
        LAYOUT_LAYER="$LAYOUT_LAYER_INI"
    else
        LAYOUT_LAYER="$LAYOUT_LAYER_ORIG"
    fi
    echo "  Layout layer: $LAYOUT_LAYER"

    CYCLE_DIR="$LAYOUT_WORK_DIR/cycle${cycle}"
    mkdir -p "$CYCLE_DIR"

    # ==========================================
    # Step 1: NA ternary search + source optimization
    # ==========================================
    echo "=== Step 1: NA search + source optimization ==="

    BEST_NA=$(search_optimal_na "$cycle" "$CURRENT_LAYOUT" "$CURRENT_SOURCE")
    BEST_NA_STR=$(printf "%.6f" "$BEST_NA")

    echo ""
    echo "  best NA: $BEST_NA"

    # Final source optimization at the best NA (skip if already evaluated)
    BEST_NA_DIR="$CYCLE_DIR/na_${BEST_NA_STR}"
    if [ ! -f "$BEST_NA_DIR/optimized_source.illum" ]; then
        evaluate_na "$BEST_NA" "$cycle" "$CURRENT_LAYOUT" "$CURRENT_SOURCE" "NA-final"
    fi

    OPTIMIZED_SOURCE="$BEST_NA_DIR/optimized_source.illum"
    BEST_INI="$BEST_NA_DIR/ini.txt"
    BEST_COST=$(cat "$BEST_NA_DIR/final_cost.txt")

    echo "  optimized source: $OPTIMIZED_SOURCE"
    echo "  cost:             $BEST_COST"

    # ==========================================
    # Step 2: MSOCS generation
    # ==========================================
    echo ""
    echo "=== Step 2: MSOCS generation ==="

    # If blur is configured, feed a blurred illum into MSOCS
    MSOCS_INPUT_SOURCE="$OPTIMIZED_SOURCE"
    if has_blur; then
        BLURRED_SOURCE="$CYCLE_DIR/optimized_source_blurred.illum"
        generate_blurred_illum "$OPTIMIZED_SOURCE" "$BEST_INI" "$BLURRED_SOURCE"
        MSOCS_INPUT_SOURCE="$BLURRED_SOURCE"
    fi

    MSOCS_DIR="$CYCLE_DIR/msocs"
    run_make_msocs "$MSOCS_INPUT_SOURCE" "$BEST_INI" "$BEST_NA" "$MSOCS_DIR"

    # ==========================================
    # Step 3: OPC run
    # ==========================================
    echo ""
    echo "=== Step 3: OPC run ==="

    # OPC (flow03/flow10) に渡す sliceLevel を決定
    #   OPC_SLICE_MODE=so    : ソース最適化の cost.csv の sliceLevel を使う
    #   OPC_SLICE_MODE=fixed : OPC_SLICE_FIXED の固定値を使う
    OPC_SLICE_LEVEL=""
    if [ "$OPC_SLICE_MODE" = "fixed" ]; then
        OPC_SLICE_LEVEL="$OPC_SLICE_FIXED"
        echo "  OPC sliceLevel:   $OPC_SLICE_LEVEL  (fixed -> flow03/flow10)"
    else
        if [ -f "$BEST_NA_DIR/cost.csv" ]; then
            OPC_SLICE_LEVEL=$(grep '^sliceLevel,' "$BEST_NA_DIR/cost.csv" | head -1 | cut -d, -f2)
            echo "  OPC sliceLevel:   $OPC_SLICE_LEVEL  (from SO -> flow03/flow10)"
        fi
    fi

    OPC_LAYOUT="$CYCLE_DIR/opc_output.oas"
    run_opc "$MSOCS_DIR" "$OPC_LAYOUT" "$cycle" "$CURRENT_OAS" "$CYCLE_DIR" "$OPC_SLICE_LEVEL"

    # ==========================================
    # Record cycle result
    # ==========================================
    echo "$cycle,$BEST_NA,$BEST_COST,$OPTIMIZED_SOURCE,$OPC_LAYOUT" >> "$SMO_LOG"

    echo ""
    echo "--- Cycle $cycle done ---"
    echo "  best NA:          $BEST_NA"
    echo "  cost:             $BEST_COST"
    echo "  optimized source: $OPTIMIZED_SOURCE"
    echo "  OPC output layout: $OPC_LAYOUT"

    # Update inputs for the next cycle
    CURRENT_LAYOUT="$OPC_LAYOUT"
    CURRENT_SOURCE="$OPTIMIZED_SOURCE"
    CURRENT_OAS="$OPC_LAYOUT"
done

# ========== Final result ==========
echo ""
echo "=============================================="
echo "SMO completed"
echo "=============================================="
echo ""
echo "Result log: $SMO_LOG"
echo ""
echo "Per-cycle results:"
column -t -s',' "$SMO_LOG"
echo ""
echo "Final output:"
echo "  source: $CURRENT_SOURCE"
echo "  layout: $CURRENT_LAYOUT"
