#!/bin/bash
#
# smo_lib/helpers.sh - utility functions
#

# Print a prominent start banner (goes to stderr so it is visible
# even when called inside $(...) command substitution).
# Usage: banner_start <label> [extra_info ...]
banner_start() {
    local label="$1"
    shift
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    {
        echo ""
        echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
        echo ">>> [$ts] START: $label"
        for info in "$@"; do
            echo ">>>   $info"
        done
        echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    } >&2
}

# Print a prominent done banner with elapsed time.
# Usage: banner_end <label> <start_epoch> [extra_info ...]
banner_end() {
    local label="$1"
    local start_epoch="$2"
    shift 2
    local ts end_epoch elapsed
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    end_epoch=$(date +%s)
    elapsed=$((end_epoch - start_epoch))
    local mm=$((elapsed / 60))
    local ss=$((elapsed % 60))
    {
        echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
        echo "<<< [$ts] DONE : $label  (elapsed ${mm}m ${ss}s)"
        for info in "$@"; do
            echo "<<<   $info"
        done
        echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
        echo ""
    } >&2
}

# Plain info message (stderr).
log_info() {
    echo "$@" >&2
}

# 区切り文字付き CSV (デフォルト ',') から cycle 番目 (1-indexed) の値を取り出す。
# - 空文字なら何も出力せず return 0
# - cycle がリスト長を超えたら最後の値を返す
# - 区切り文字を指定すれば CSV-of-CSV ("a,b;c,d;e" 等) もサポート
# 例: get_cycle_value "30,100,500" 4              -> "500"
# 例: get_cycle_value "2,4;2,4,6;2,4,6,8" 2 ";"   -> "2,4,6"
get_cycle_value() {
    local list="$1"
    local cycle="$2"
    local sep="${3:-,}"
    [ -z "$list" ] && return 0
    [ "$cycle" -lt 1 ] && cycle=1

    local arr
    IFS="$sep" read -ra arr <<< "$list"
    local n=${#arr[@]}
    [ "$n" -eq 0 ] && return 0

    local idx=$((cycle - 1))
    [ "$idx" -ge "$n" ] && idx=$((n - 1))

    echo "${arr[$idx]}"
}

# Generate an ini file for the given NA
generate_ini() {
    local na_val="$1"
    local output_ini="$2"
    sed "s/^NA .*/NA ${na_val}/" "$INI_TEMPLATE" > "$output_ini"
}

# Extract the final total_cost value from a cost.csv
get_final_cost() {
    local cost_csv="$1"
    grep "^total_cost," "$cost_csv" | head -1 | cut -d',' -f2
}

# Check whether source_config has a src_blur setting
# DISABLE_BLUR=1 のときは src_blur 設定の有無に関わらず常に false を返し、
# MSOCS 生成前の blur を skip する。
has_blur() {
    if [ "${DISABLE_BLUR:-0}" = "1" ]; then
        return 1
    fi
    grep -q '^src_blur ' "$SOURCE_CONFIG" 2>/dev/null
}

# Generate a blurred .illum file (only if src_blur is configured)
generate_blurred_illum() {
    local input_illum="$1"
    local ini_file="$2"
    local output_illum="$3"

    if has_blur; then
        log_info "  [blur] $input_illum -> $output_illum"
        python3 "$BLUR_ILLUM" \
            -f "$input_illum" \
            -g "$SOURCE_CONFIG" \
            --ini "$ini_file" \
            -o "$output_illum"
    else
        cp "$input_illum" "$output_illum"
    fi
}
