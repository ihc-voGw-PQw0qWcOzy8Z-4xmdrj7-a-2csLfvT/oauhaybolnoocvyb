#!/bin/bash
#
# SMO (Source-Mask Optimization) driver
#
# Iterates source optimization and OPC N times, and runs a ternary
# search over NA at every cycle to pick the best value.
#
# Flow (one cycle):
#   1. For each NA: generate ini -> SOCS -> source optimization -> cost
#   2. Ternary search to choose the best NA
#   3. With the best NA: generate MSOCS (blurred illum if configured) -> run OPC
#   4. Feed the OPC output .oas into the next cycle
#
# Usage: ./run_smo.sh [options]
#   --num_cycles <N>       source-opt / OPC iteration count (default: 3)
#   --na_min <val>         NA search lower bound (default: 1.0)
#   --na_max <val>         NA search upper bound (default: 1.35)
#   --na_tol <val>         NA convergence threshold (default: 0.01)
#   --max_iter <N>         srcOptim max iterations (default: 16)
#   --gradient_method <N>  gradient method (default: 2)
#   --optimizer <str>      optimizer (default: lbfgs)
#   -j <N>                 OpenMP threads (default: 8)
#   --np <N>               MPI ranks (default: 2)
#   --kernel_num <N>       SOCS kernel count (default: 100)
#   --m3d_so               enable M3D mode for source optimization (SOCS)
#   --m3d_opc              enable M3D mode for OPC (MSOCS)
#   --cgrp <file>          coherent-group file (used when --m3d_opc is set)
#   --mask_kikaku <str>    mask specification (default: 4kikaku)
#

set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd)

# ========== Load libraries ==========
source "$SCRIPT_DIR/smo_lib/setup.sh"
source "$SCRIPT_DIR/smo_lib/helpers.sh"
source "$SCRIPT_DIR/smo_lib/srcoptim.sh"
source "$SCRIPT_DIR/smo_lib/opc.sh"
source "$SCRIPT_DIR/smo_lib/na_search.sh"

# ========== Parse options ==========
while [[ $# -gt 0 ]]; do
    case $1 in
        --num_cycles)   NUM_CYCLES="$2";       shift 2 ;;
        --na_min)       NA_MIN="$2";           shift 2 ;;
        --na_max)       NA_MAX="$2";           shift 2 ;;
        --na_tol)       NA_TOL="$2";           shift 2 ;;
        --na_precision) NA_PRECISION="$2";     shift 2 ;;
        --max_iter)     MAX_ITER="$2";         shift 2 ;;
        --gradient_method) GRADIENT_METHOD="$2"; shift 2 ;;
        --optimizer)    OPTIMIZER="$2";        shift 2 ;;
        -j)             OPENMP_NUM="$2";       shift 2 ;;
        --np)           MPI_NP="$2";           shift 2 ;;
        --kernel_num)   KERNEL_NUM="$2";       shift 2 ;;
        --m3d_so)       M3D_SO=1;              shift ;;
        --m3d_opc)      M3D_OPC=1;             shift ;;
        --cgrp)         CGRP="$2";             shift 2 ;;
        --mask_kikaku)  MASK_KIKAKU="$2";      shift 2 ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# ========== Initialization ==========
mkdir -p "$WORK_DIR"

SMO_LOG="$WORK_DIR/smo_log.csv"
echo "cycle,na,cost,illum,opc_layout" > "$SMO_LOG"

# ========== Info banner ==========
echo "=============================================="
echo "SMO (Source-Mask Optimization)"
echo "=============================================="
echo "Num cycles:       $NUM_CYCLES"
echo "NA search range:  [$NA_MIN, $NA_MAX]"
echo "NA tolerance:     $NA_TOL"
echo "NA precision:     $NA_PRECISION"
echo "Optimizer:        $OPTIMIZER"
echo "Gradient method:  $GRADIENT_METHOD"
echo "Max iterations:   $MAX_ITER"
echo "OpenMP threads:   $OPENMP_NUM"
echo "MPI ranks:        $MPI_NP"
echo "Kernel num:       $KERNEL_NUM"
echo "Layout:           $LAYOUT_ORIGINAL"
echo "Layout dash:      $LAYOUT_ORG_NAME_DASH"
echo "Layout layer (1): $LAYOUT_LAYER_INI"
echo "Layout layer (N): $LAYOUT_LAYER"
echo "OPC work dir:     $OPC_WORK_DIR"
echo "Mode (SO):        $([ "$M3D_SO" = "1" ] && echo M3D || echo M2D)"
echo "Mode (OPC):       $([ "$M3D_OPC" = "1" ] && echo M3D || echo M2D)"
if [ "$M3D_SO" = "1" ] || [ "$M3D_OPC" = "1" ]; then
    echo "Mask kikaku:      $MASK_KIKAKU"
fi
if [ "$M3D_OPC" = "1" ]; then
    echo "CGRP:             $CGRP"
fi
if has_blur; then
    echo "Blur:             enabled (src_blur set in source_config)"
else
    echo "Blur:             disabled"
fi
echo "Work dir:         $WORK_DIR"
echo "=============================================="
echo ""

# ========== Main loop ==========
CURRENT_LAYOUT="$LAYOUT_ORIGINAL"
CURRENT_SOURCE="$INITIAL_SOURCE"

# LAYOUT_LAYER は cycle ごとに上書きするため、オリジナル値を保存しておく
LAYOUT_LAYER_ORIG="$LAYOUT_LAYER"

for cycle in $(seq 1 "$NUM_CYCLES"); do
    echo ""
    echo "######################################################"
    echo "# Cycle $cycle / $NUM_CYCLES"
    echo "######################################################"
    echo ""

    # 1ループ目は INI レイヤ、2ループ目以降は通常レイヤを使う
    if [ "$cycle" -eq 1 ]; then
        LAYOUT_LAYER="$LAYOUT_LAYER_INI"
    else
        LAYOUT_LAYER="$LAYOUT_LAYER_ORIG"
    fi
    echo "  Layout layer: $LAYOUT_LAYER"

    CYCLE_DIR="$WORK_DIR/cycle${cycle}"
    mkdir -p "$CYCLE_DIR"

    # ==========================================
    # Step 1: NA ternary search + source optimization
    # ==========================================
    echo "=== Step 1: NA search + source optimization ==="

    BEST_NA=$(search_optimal_na "$cycle" "$CURRENT_LAYOUT" "$CURRENT_SOURCE")
    BEST_NA_STR=$(printf "%.6f" "$BEST_NA")

    echo ""
    echo "  best NA: $BEST_NA"

    # Final source optimization at the best NA (skip if already evaluated)
    BEST_NA_DIR="$CYCLE_DIR/na_${BEST_NA_STR}"
    if [ ! -f "$BEST_NA_DIR/optimized_source.illum" ]; then
        evaluate_na "$BEST_NA" "$cycle" "$CURRENT_LAYOUT" "$CURRENT_SOURCE" "NA-final"
    fi

    OPTIMIZED_SOURCE="$BEST_NA_DIR/optimized_source.illum"
    BEST_INI="$BEST_NA_DIR/ini.txt"
    BEST_COST=$(cat "$BEST_NA_DIR/final_cost.txt")

    echo "  optimized source: $OPTIMIZED_SOURCE"
    echo "  cost:             $BEST_COST"

    # ==========================================
    # Step 2: MSOCS generation
    # ==========================================
    echo ""
    echo "=== Step 2: MSOCS generation ==="

    # If blur is configured, feed a blurred illum into MSOCS
    MSOCS_INPUT_SOURCE="$OPTIMIZED_SOURCE"
    if has_blur; then
        BLURRED_SOURCE="$CYCLE_DIR/optimized_source_blurred.illum"
        generate_blurred_illum "$OPTIMIZED_SOURCE" "$BEST_INI" "$BLURRED_SOURCE"
        MSOCS_INPUT_SOURCE="$BLURRED_SOURCE"
    fi

    MSOCS_DIR="$CYCLE_DIR/msocs"
    run_make_msocs "$MSOCS_INPUT_SOURCE" "$BEST_INI" "$BEST_NA" "$MSOCS_DIR"

    # ==========================================
    # Step 3: OPC run
    # ==========================================
    echo ""
    echo "=== Step 3: OPC run ==="

    OPC_LAYOUT="$CYCLE_DIR/opc_output.oas"
    run_opc "$MSOCS_DIR" "$OPC_LAYOUT" "$cycle"

    # ==========================================
    # Record cycle result
    # ==========================================
    echo "$cycle,$BEST_NA,$BEST_COST,$OPTIMIZED_SOURCE,$OPC_LAYOUT" >> "$SMO_LOG"

    echo ""
    echo "--- Cycle $cycle done ---"
    echo "  best NA:          $BEST_NA"
    echo "  cost:             $BEST_COST"
    echo "  optimized source: $OPTIMIZED_SOURCE"
    echo "  OPC output layout: $OPC_LAYOUT"

    # Update inputs for the next cycle
    CURRENT_LAYOUT="$OPC_LAYOUT"
    CURRENT_SOURCE="$OPTIMIZED_SOURCE"
done

# ========== Final result ==========
echo ""
echo "=============================================="
echo "SMO completed"
echo "=============================================="
echo ""
echo "Result log: $SMO_LOG"
echo ""
echo "Per-cycle results:"
column -t -s',' "$SMO_LOG"
echo ""
echo "Final output:"
echo "  source: $CURRENT_SOURCE"
echo "  layout: $CURRENT_LAYOUT"
