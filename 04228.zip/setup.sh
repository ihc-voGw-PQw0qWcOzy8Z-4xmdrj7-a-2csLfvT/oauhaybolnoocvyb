#!/bin/bash
#
# smo_lib/setup.sh - defaults, input files, tool paths
#

# ========== Defaults ==========
NUM_CYCLES=3
NA_MIN=1.0
NA_MAX=1.35
NA_TOL=0.05
NA_PRECISION=0.01
MAX_ITER=16
GRADIENT_METHOD=2
OPTIMIZER="lbfgs"
OPENMP_NUM=8
MPI_NP=2
KERNEL_NUM=100
M3D_SO=0
M3D_OPC=0
CGRP=""
MASK_KIKAKU="4kikaku"

# ========== Input files ==========
SOURCE_CONFIG="$SCRIPT_DIR/in/source_config_32.txt"
PWC_CONFIG="$SCRIPT_DIR/in/pwc_config.txt"
INITIAL_SOURCE="$SCRIPT_DIR/in/initial_source.illum"
EVP="$SCRIPT_DIR/in/evp_0_6.csv"
INI_TEMPLATE="$SCRIPT_DIR/in/ini.txt"

# ========== Layout ==========
LAYOUT_ORG_DIR="/home/hoge/Layout"
LAYOUT_ORG_NAME="AAA/BBB.gds"
LAYOUT_ORIGINAL="$LAYOUT_ORG_DIR/$LAYOUT_ORG_NAME"
# LAYOUT_ORG_NAME からディレクトリ部分と拡張子を除いた文字列（AAA/BBB.gds -> BBB）
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME##*/}"
LAYOUT_ORG_NAME_DASH="${LAYOUT_ORG_NAME_DASH%.*}"
# 1ループ目のソース最適化用レイヤ
LAYOUT_LAYER_INI="2/1,60/0"
# 2ループ目以降のソース最適化用レイヤ
LAYOUT_LAYER="0/0,60/0"

# ========== Tools ==========
SRCOPTIM="$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim"
MAKE_SOCS="$PROJECT_ROOT/mkSocsSet/make_socs_set_v2.py"
BLUR_ILLUM="$PROJECT_ROOT/mkSocsSet/blur_illum.py"
MAKETCC_MTCC3="maketcc_mtcc3.py"
MAKETCC_M3DMTCC3="maketcc_m3dmtcc3"

# ========== OPC ==========
OPC_WORK_DIR="/home/opchoge"

# ========== Work directory ==========
WORK_DIR="$SCRIPT_DIR/smo_work"
