/*!
 * @file main.cpp
 * @brief calcCostDirect - SOCSセットから直接コストを計算（imgセットのファイルI/Oを省略）
 */

#include <getopt.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include <so/source_grid.h>
#include <so/source_data.h>
#include <so/source_corrector.h>
#include <so/socs_config.h>
#include <so/process_config.h>
#include <so/evp_data.h>
#include <so/image_calculator.h>
#include <so/clip_exporter.h>
#include <so/source_contribution_set.h>
#include <so/cost_calculator.h>
#include <so/types.h>

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

void printHelp(const char* programName) {
    std::cerr << "calcCostDirect - Calculate cost directly from SOCS set (no intermediate files)\n";
    std::cerr << "\n";
    std::cerr << "Usage:\n";
    std::cerr << "  " << programName << " -s <socs_set_dir> -g <source_grid> -p <process_config>\n";
    std::cerr << "                -f <source_file> -e <evp_csv> -l <layout_file> -o <cost_csv>\n";
    std::cerr << "                [options]\n";
    std::cerr << "\n";
    std::cerr << "Required arguments:\n";
    std::cerr << "  -s, --socs_set <dir>       SOCS set directory\n";
    std::cerr << "  -g, --source_config <file> source_config.txt file\n";
    std::cerr << "  -p, --process <file>       process_config.txt file\n";
    std::cerr << "  -f, --source <file>        Source intensity file (.illum)\n";
    std::cerr << "  -e, --evp <file>           evp.csv file\n";
    std::cerr << "  -l, --layout <file>        OASIS/GDS layout file\n";
    std::cerr << "  -o, --output <file>        Output cost.csv file\n";
    std::cerr << "\n";
    std::cerr << "Image calculation options:\n";
    std::cerr << "  --resistModel <file>       Base resistModel file\n";
    std::cerr << "  --dim0 <int>               Calculation dimension (small)\n";
    std::cerr << "  --dim <int>                Calculation dimension (large)\n";
    std::cerr << "  --dimx0 <int>              X calculation dimension (small)\n";
    std::cerr << "  --dimy0 <int>              Y calculation dimension (small)\n";
    std::cerr << "  --dimx <int>               X calculation dimension (large)\n";
    std::cerr << "  --dimy <int>               Y calculation dimension (large)\n";
    std::cerr << "  --kernel <int>             Number of SOCS kernels\n";
    std::cerr << "  --layer <L/D,...>          Layer/datatype pairs (default: 0/0)\n";
    std::cerr << "  --cellname <n>             Cell name\n";
    std::cerr << "  --brightfield              Bright field mode\n";
    std::cerr << "  --darkfield                Dark field mode (default)\n";
    std::cerr << "  --binary                   Binary mask mode\n";
    std::cerr << "  --halftone                 Halftone mask mode (default)\n";
    std::cerr << "\n";
    std::cerr << "Cost calculation options:\n";
    std::cerr << "  --sliceLevel <double>      Threshold value (auto if not specified)\n";
    std::cerr << "  --sliceLevelHint <double>  Initial hint for slice level search\n";
    std::cerr << "  --anchor_clips <ids>       Anchor clip IDs (comma-separated, default: 0)\n";
    std::cerr << "  --weight_fill <double>     Weight for source_fill_cost (default: 1.0)\n";
    std::cerr << "  --min_fill_ratio <double>  Minimum source fill ratio (default: 0.07)\n";
    std::cerr << "  --epe_method <method>      EPE calculation method: newton or qepe (default: newton)\n";
    std::cerr << "  --target_delta_cd <double> Target delta_CD for slice level optimization\n";
    std::cerr << "  --tolerance <double>       Override evp.csv tolerance column for all eval points\n";
    std::cerr << "                             [um]. srcOptim --tolerance と一致させるとPW最大化が筋に合う。\n";
    std::cerr << "\n";
    std::cerr << "Source correction options:\n";
    std::cerr << "  --interpolation <method>   Interpolation method: nearest or bilinear (default: nearest)\n";
    std::cerr << "  --debug_source <path>      Output corrected source file for debugging\n";
    std::cerr << "\n";
    std::cerr << "Other options:\n";
    std::cerr << "  -j, --jobs <int>           Number of threads (default: 1)\n";
    std::cerr << "  --export_clips <dir>       Export clip regions as OASIS files\n";
    std::cerr << "  -h, --help                 Show this help message\n";
}

namespace {
struct MpiGuard {
    MpiGuard(int& argc, char**& argv) {
#ifdef HAVE_MPI_H
        int initialized = 0;
        MPI_Initialized(&initialized);
        if (!initialized) {
            MPI_Init(&argc, &argv);
        }
#else
        (void)argc; (void)argv;
#endif
    }
    ~MpiGuard() {
#ifdef HAVE_MPI_H
        int finalized = 0;
        MPI_Finalized(&finalized);
        if (!finalized) {
            MPI_Finalize();
        }
#endif
    }
};
}

int main(int argc, char** argv) {
    MpiGuard mpiGuard(argc, argv);

    std::cerr << "===============================================" << std::endl;
    std::cerr << "calcCostDirect - Direct Cost Calculator" << std::endl;
    std::cerr << "===============================================" << std::endl;

    // 引数
    std::string socsSetDir;
    std::string sourceGridFile;
    std::string processConfigFile;
    std::string sourceFile;
    std::string evpFile;
    std::string layoutFile;
    std::string outputFile;
    std::string resistModelFile;

    so::CalcOptions imgOptions;
    so::CostOptions costOptions;
    so::CorrectionOptions correctionOptions;

    int flagBrightfield = 0;
    int flagBinary = 0;
    std::string exportClipsDir;

    // --tolerance: 指定されていれば EvpData 読み込み後に全 EvalPoint の tolerance を上書き。
    // 未指定 (negative sentinel) なら evp.csv の tolerance 列をそのまま使う。
    double cliTolerance = -1.0;

    static struct option longopts[] = {
        {"help", no_argument, nullptr, 'h'},
        {"socs_set", required_argument, nullptr, 's'},
        {"source_config", required_argument, nullptr, 'g'},
        {"process", required_argument, nullptr, 'p'},
        {"source", required_argument, nullptr, 'f'},
        {"evp", required_argument, nullptr, 'e'},
        {"layout", required_argument, nullptr, 'l'},
        {"output", required_argument, nullptr, 'o'},
        {"jobs", required_argument, nullptr, 'j'},
        // Image calculation options
        {"resistModel", required_argument, nullptr, 0},
        {"dim0", required_argument, nullptr, 0},
        {"dim", required_argument, nullptr, 0},
        {"dimx0", required_argument, nullptr, 0},
        {"dimy0", required_argument, nullptr, 0},
        {"dimx", required_argument, nullptr, 0},
        {"dimy", required_argument, nullptr, 0},
        {"kernel", required_argument, nullptr, 0},
        {"layer", required_argument, nullptr, 0},
        {"cellname", required_argument, nullptr, 0},
        {"brightfield", no_argument, &flagBrightfield, 1},
        {"darkfield", no_argument, &flagBrightfield, 0},
        {"binary", no_argument, &flagBinary, 1},
        {"halftone", no_argument, &flagBinary, 0},
        // Cost calculation options
        {"sliceLevel", required_argument, nullptr, 0},
        {"sliceLevelHint", required_argument, nullptr, 0},
        {"anchor_clips", required_argument, nullptr, 0},
        {"weight_fill", required_argument, nullptr, 0},
        {"min_fill_ratio", required_argument, nullptr, 0},
        {"epe_method", required_argument, nullptr, 0},
        {"target_delta_cd", required_argument, nullptr, 0},
        {"tolerance", required_argument, nullptr, 0},
        // Source correction options
        {"interpolation", required_argument, nullptr, 0},
        {"debug_source", required_argument, nullptr, 0},
        // Other options
        {"export_clips", required_argument, nullptr, 0},
        {nullptr, 0, nullptr, 0}
    };

    int ch, optionIndex;
    while ((ch = getopt_long(argc, argv, "hs:g:p:f:e:l:o:j:", longopts, &optionIndex)) != -1) {
        switch (ch) {
            case 'h':
                printHelp(argv[0]);
                return 0;
            case 's':
                socsSetDir = optarg;
                break;
            case 'g':
                sourceGridFile = optarg;
                break;
            case 'p':
                processConfigFile = optarg;
                break;
            case 'f':
                sourceFile = optarg;
                break;
            case 'e':
                evpFile = optarg;
                break;
            case 'l':
                layoutFile = optarg;
                break;
            case 'o':
                outputFile = optarg;
                break;
            case 'j':
                imgOptions.numThreads = std::atoi(optarg);
                break;
            case 0:
                // Image calculation options
                if (strcmp(longopts[optionIndex].name, "resistModel") == 0) {
                    resistModelFile = optarg;
                } else if (strcmp(longopts[optionIndex].name, "dim0") == 0) {
                    imgOptions.dimx0 = imgOptions.dimy0 = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "dim") == 0) {
                    imgOptions.dimx = imgOptions.dimy = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "dimx0") == 0) {
                    imgOptions.dimx0 = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "dimy0") == 0) {
                    imgOptions.dimy0 = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "dimx") == 0) {
                    imgOptions.dimx = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "dimy") == 0) {
                    imgOptions.dimy = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "kernel") == 0) {
                    imgOptions.kernelNum = std::atoi(optarg);
                } else if (strcmp(longopts[optionIndex].name, "cellname") == 0) {
                    imgOptions.cellname = optarg;
                } else if (strcmp(longopts[optionIndex].name, "layer") == 0) {
                    std::stringstream ss(optarg);
                    std::string layerDatatype;
                    while (std::getline(ss, layerDatatype, ',')) {
                        size_t pos = layerDatatype.find('/');
                        if (pos != std::string::npos) {
                            int L = std::stoi(layerDatatype.substr(0, pos));
                            int D = std::stoi(layerDatatype.substr(pos + 1));
                            imgOptions.layers.emplace_back(L, D);
                        }
                    }
                }
                // Cost calculation options
                else if (strcmp(longopts[optionIndex].name, "sliceLevel") == 0) {
                    costOptions.sliceLevel = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "sliceLevelHint") == 0) {
                    costOptions.sliceLevelHint = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "anchor_clips") == 0) {
                    costOptions.anchorClips.clear();
                    std::stringstream ss(optarg);
                    std::string token;
                    while (std::getline(ss, token, ',')) {
                        costOptions.anchorClips.push_back(std::stoi(token));
                    }
                } else if (strcmp(longopts[optionIndex].name, "weight_fill") == 0) {
                    costOptions.weightFill = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "min_fill_ratio") == 0) {
                    costOptions.minSourceFillRatio = std::atof(optarg);
                } else if (strcmp(longopts[optionIndex].name, "epe_method") == 0) {
                    std::string method = optarg;
                    if (method == "qepe" || method == "QEPE") {
                        costOptions.epeMethod = so::EpeMethod::QEPE;
                    } else {
                        costOptions.epeMethod = so::EpeMethod::Newton;
                    }
                } else if (strcmp(longopts[optionIndex].name, "target_delta_cd") == 0) {
                    costOptions.targetDeltaCD = std::atof(optarg);
                    costOptions.useTargetDeltaCD = true;
                } else if (strcmp(longopts[optionIndex].name, "tolerance") == 0) {
                    cliTolerance = std::atof(optarg);
                }
                // Source correction options
                else if (strcmp(longopts[optionIndex].name, "interpolation") == 0) {
                    std::string method = optarg;
                    if (method == "bilinear" || method == "Bilinear" || method == "BILINEAR") {
                        correctionOptions.interpolation = so::InterpolationMethod::Bilinear;
                    } else {
                        correctionOptions.interpolation = so::InterpolationMethod::Nearest;
                    }
                } else if (strcmp(longopts[optionIndex].name, "debug_source") == 0) {
                    correctionOptions.debugOutputPath = optarg;
                }
                // Other options
                else if (strcmp(longopts[optionIndex].name, "export_clips") == 0) {
                    exportClipsDir = optarg;
                }
                break;
            case '?':
            default:
                printHelp(argv[0]);
                return 1;
        }
    }

    imgOptions.brightfield = (flagBrightfield == 1);
    imgOptions.binary = (flagBinary == 1);

    // 必須引数チェック
    if (socsSetDir.empty() || sourceGridFile.empty() || processConfigFile.empty() ||
        sourceFile.empty() || evpFile.empty() || layoutFile.empty() || outputFile.empty()) {
        std::cerr << "Error: Missing required arguments\n" << std::endl;
        printHelp(argv[0]);
        return 1;
    }

    try {
        // 入力ファイル読み込み
        std::cerr << "Loading source_config: " << sourceGridFile << std::endl;
        so::SourceGrid sourceGrid;
        sourceGrid.load(sourceGridFile);

        std::cerr << "Loading source_data: " << sourceFile << std::endl;
        so::SourceData sourceData;
        sourceData.load(sourceFile);

        std::cerr << "Loading process_config: " << processConfigFile << std::endl;
        so::ProcessConfig processConfig;
        processConfig.load(processConfigFile);

        std::cerr << "Loading evp_data: " << evpFile << std::endl;
        so::EvpData evpData;
        evpData.load(evpFile);

        // --tolerance が指定されていれば evp.csv の tolerance 列を一括上書き
        if (cliTolerance >= 0.0) {
            evpData.setAllTolerance(cliTolerance);
            std::cerr << "Override all eval-point tolerance to: " << cliTolerance
                      << " [um]" << std::endl;
        }

        // 入力検証と自動修正
        std::cerr << "Validating and correcting source data..." << std::endl;

        so::CorrectionResult correctionResult =
            so::validateAndCorrect(sourceData, sourceGrid, correctionOptions);

        if (correctionResult.hasCorrections()) {
            std::cerr << "Source data was corrected:" << std::endl;
            for (const auto& warning : correctionResult.warnings) {
                std::cerr << "  " << warning << std::endl;
            }
        } else {
            std::cerr << "Source data validation passed." << std::endl;
        }

        // SOCSファイル存在確認
        auto uniqueDefocuses = processConfig.showUniqueDefocuses();
        auto validPoints = sourceGrid.generateValidGridPoints();
        const auto& gridConfig = sourceGrid.showConfig();
        
        for (double defocus : uniqueDefocuses) {
            for (const auto& [gx, gy] : validPoints) {
                if (gridConfig.isD2Symmetry()) {
                    if (gx < 0 || gy < 0) continue;
                }
                double intensity = gridConfig.isD2Symmetry() 
                    ? sourceData.getIntensityFirstQuadrant(gx, gy)
                    : sourceData.getIntensity(gx, gy);
                if (intensity <= 0.0) continue;
                
                std::string sourceID = so::SourceGrid::makeSourceID(std::abs(gx), std::abs(gy));
                if (!so::SocsFile::exists(socsSetDir, sourceID, defocus)) {
                    std::cerr << "Error: SOCS file not found for sourceID=" << sourceID 
                              << ", defocus=" << defocus << std::endl;
                    return 1;
                }
            }
        }

        std::cerr << "Validation passed." << std::endl;

        // Clip出力（オプション）- Phase 1の前に実行
        if (!exportClipsDir.empty()) {
            // 最初のSOCSファイルから光学パラメータを取得
            so::OpticalParams optical;
            double firstDefocus = uniqueDefocuses.empty() ? 0.0 : uniqueDefocuses[0];
            for (const auto& [gx, gy] : validPoints) {
                if (gridConfig.isD2Symmetry() && (gx < 0 || gy < 0)) continue;
                double intensity = gridConfig.isD2Symmetry() 
                    ? sourceData.getIntensityFirstQuadrant(gx, gy)
                    : sourceData.getIntensity(gx, gy);
                if (intensity <= 0.0) continue;
                std::string sourceID = so::SourceGrid::makeSourceID(std::abs(gx), std::abs(gy));
                std::string socsPath = so::SocsFile::makePath(socsSetDir, sourceID, firstDefocus);
                if (std::filesystem::exists(socsPath)) {
                    optical = so::SocsFile::readOpticalParams(socsPath);
                    break;
                }
            }

            std::vector<std::pair<int, int>> layers = imgOptions.layers;
            if (layers.empty()) {
                layers.emplace_back(0, 0);
            }

            so::ClipExporter clipExporter;
            clipExporter.setOasisFile(layoutFile);
            clipExporter.setCellname(imgOptions.cellname);
            clipExporter.setLayers(layers);
            clipExporter.setSize(optical.Lx, optical.Ly);
            clipExporter.exportAllClips(evpData, exportClipsDir);
        }

        // Step 1: 光学像計算（メモリ上、常に周波数空間）
        std::cerr << "===============================================" << std::endl;
        std::cerr << "Step 1: Calculating images in memory..." << std::endl;
        std::cerr << "  Clips: " << evpData.showClipCount() << std::endl;
        std::cerr << "  PWC conditions: " << processConfig.size() << std::endl;
        std::cerr << "  Threads: " << imgOptions.numThreads << std::endl;

        so::ImageCalculator imageCalculator;
        imageCalculator.setSourceGrid(&sourceGrid);
        imageCalculator.setSourceData(&sourceData);
        imageCalculator.setProcessConfig(&processConfig);
        imageCalculator.setSocsSetDir(socsSetDir);
        imageCalculator.setOasisFile(layoutFile);
        imageCalculator.setResistModelFile(resistModelFile);
        imageCalculator.setOptions(imgOptions);

        // resistModelファイルは出力ファイルと同じディレクトリに保存
        std::string resistModelOutputDir = std::filesystem::path(outputFile).parent_path().string();
        if (resistModelOutputDir.empty()) {
            resistModelOutputDir = ".";
        }

        so::CalcResult calcResult = imageCalculator.calcImages(evpData, resistModelOutputDir);

        // Step 2: コスト計算
        std::cerr << "===============================================" << std::endl;
        std::cerr << "Step 2: Calculating costs..." << std::endl;

        // source_fill_ratio計算（SOCSファイルから取得したNAを使用）
        double sourceFillRatio = sourceData.calcSourceFillRatio(calcResult.opticalParams.NA);
        std::cerr << "Source fill ratio: " << sourceFillRatio 
                  << " (NA=" << calcResult.opticalParams.NA << ")" << std::endl;

        so::CostCalculator costCalculator;
        costCalculator.setOptions(costOptions);

        std::cerr << "Calculated " << calcResult.sourceContributions.size() << " contribution sets." << std::endl;

        if (calcResult.sourceContributions.empty()) {
            std::cerr << "Error: No images calculated" << std::endl;
            return 1;
        }

        so::CostResult result = costCalculator.calculate(
            calcResult.sourceContributions, sourceData, gridConfig, evpData, processConfig, sourceFillRatio);

        // 結果出力
        std::cerr << "Writing results to: " << outputFile << std::endl;
        so::CostWriter::write(outputFile, result);

        // サマリ表示
        std::cerr << "===============================================" << std::endl;
        std::cerr << "Calculation completed successfully!" << std::endl;
        std::cerr << "-----------------------------------------------" << std::endl;
        std::cerr << "  Slice Level:       " << result.sliceLevel << std::endl;
        std::cerr << "  EPE Cost:          " << result.EPE_cost << std::endl;
        std::cerr << "  QEPE Cost:         " << result.QEPE_cost << std::endl;
        std::cerr << "  Source Fill Cost:  " << result.source_fill_cost << std::endl;
        std::cerr << "  Total Cost:        " << result.total_cost << std::endl;
        std::cerr << "  Total Cost (QEPE): " << result.total_cost_QEPE << std::endl;
        std::cerr << "-----------------------------------------------" << std::endl;
        std::cerr << "  EPE Results:       " << result.epeResults.size() << std::endl;
        std::cerr << "  Cutline Results:   " << result.cutlineResults.size() << std::endl;
        std::cerr << "===============================================" << std::endl;

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
