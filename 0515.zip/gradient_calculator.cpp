/*!
 * @file gradient_calculator.cpp
 * @brief コスト勾配計算の実装
 */

#include "gradient_calculator.h"
#include "coord_utils.h"
#include "epe_newton.h"
#include <so/types.h>
#include <cmath>
#include <iostream>
#include <chrono>
#include <set>

#ifdef _OPENMP
#include <omp.h>
#endif

#ifdef HAVE_MPI_H
#include <mpi.h>
#endif

namespace so {

namespace {
    constexpr double MIN_GRADIENT = 1e-12;
}

GradientCalculator::GradientCalculator() {}

GradientCalculator::~GradientCalculator() {}

void GradientCalculator::setVariableMapping(const VariableMapping* mapping) {
    m_mapping = mapping;
}

void GradientCalculator::setOptions(const OptimizationOptions& options) {
    m_options = options;
}

void GradientCalculator::setNA(double NA) {
    m_NA = NA;
}

void GradientCalculator::setSourceContributions(
    const std::map<std::string, SourceContributionSet>* sourceContributions) {
    m_sourceContributions = sourceContributions;
}

GradientIntermediates GradientCalculator::calcIntermediates(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData) const {

    GradientIntermediates inter;
    const auto& gridConfig = m_mapping->gridConfig();

    for (const auto& contrib : contribSet.contributions()) {
        double intensity;
        if (gridConfig.isD2Symmetry()) {
            intensity = sourceData.getIntensityFirstQuadrant(contrib.gx, contrib.gy);
        } else {
            intensity = sourceData.getIntensity(contrib.gx, contrib.gy);
        }

        double weight = contrib.norm * intensity;
        inter.totalWeight += weight;
        inter.weightPerSource[makeCoordKey(contrib.gx, contrib.gy)] = weight;
    }

    return inter;
}

std::map<std::pair<double, double>, double> GradientCalculator::calcQepeGradientAtPoint(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    const GradientIntermediates& inter,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose) const {

    std::map<std::pair<double, double>, double> gradients;
    const auto& gridConfig = m_mapping->gridConfig();

    if (inter.totalWeight < MIN_GRADIENT) {
        return gradients;
    }

    // 合成画像を計算（delta_dose適用）
    FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
    if (std::abs(delta_dose) > 1e-9) {
        combinedImg.scale(1.0 + delta_dose / 100.0);
    }
    auto pv = combinedImg.evalAt(px, py);

    // 法線方向を計算
    double rad = degree * M_PI / 180.0;
    double nx = std::cos(rad);
    double ny = std::sin(rad);

    // 法線方向の勾配 G = ∂I/∂n
    double G = pv.gradX * nx + pv.gradY * ny;

    // G が非常に小さい場合は勾配を計算しない
    if (std::abs(G) < MIN_GRADIENT) {
        return gradients;
    }

    // QEPE = -(I - sliceLevel) / G
    // ∂QEPE/∂s_j = -1/G × ∂I/∂s_j
    //
    // ∂I/∂s_j = norm_j × (I_j - I) / W
    //   where I = 合成画像の強度、I_j = 光源点jの寄与画像の強度
    //   W = Σ(norm_i × s_i)

    double W = inter.totalWeight;
    double I_combined = pv.intensity;

    for (const auto& contrib : contribSet.contributions()) {
        // 光源点jの寄与画像での強度
        auto pv_j = contrib.freqImage.evalAt(px, py);
        double I_j = pv_j.intensity;

        // delta_dose補正を適用（I_combinedと同じスケールにする）
        if (std::abs(delta_dose) > 1e-9) {
            I_j *= (1.0 + delta_dose / 100.0);
        }

        // ∂I/∂s_j = norm_j × (I_j - I) / W
        double dI_dsj = contrib.norm * (I_j - I_combined) / W;

        // 法線方向の勾配変化も考慮（2次効果は無視）
        // ∂G/∂s_j の影響は小さいので無視

        // ∂QEPE/∂s_j = -1/G × ∂I/∂s_j
        double dQEPE_dsj = -dI_dsj / G;

        auto key = makeCoordKey(contrib.gx, contrib.gy);
        gradients[key] = dQEPE_dsj;
    }

    return gradients;
}

std::vector<double> GradientCalculator::calculate(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    // クリップ毎の勾配と重みを保持（MPI決定的集約用）
    size_t numClips = clips.size();
    size_t numVars = m_mapping->numVariables();
    std::vector<std::map<std::pair<double, double>, double>> clipGradientMaps(numClips);
    std::vector<double> clipWeights(numClips, 0.0);

#ifdef _OPENMP
    // タスク毎の結果を格納（OpenMP決定的な加算順序を保証）
    std::vector<std::map<std::pair<double, double>, double>> taskGradients(tasks.size());
    std::vector<double> taskWeights(tasks.size(), 0.0);

    #pragma omp parallel for schedule(dynamic)
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ: このランクが担当しないクリップはスキップ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        // 合成画像を計算（delta_dose適用）
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        // 各評価点について勾配を計算
        for (const auto* ep : clip.evalPoints) {
            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double I = pv.intensity;

            // delta_dose補正後の強度でQEPEを計算
            double QEPE = 0.0;
            if (std::abs(G) > MIN_GRADIENT) {
                QEPE = -(I - sliceLevel) / G;
            }

            double w_total = ep->weight * pwc.weight;
            taskWeights[taskIdx] += w_total;

            // 勾配を計算（delta_dose適用）
            auto pointGrad = calcQepeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose);

            // tolerance デッドバンド:
            //   cost_i = (max(0,|QEPE|-tol))^2
            //   d cost_i / ds_j = 2 * QEPE_eff * sign(QEPE) * dQEPE/ds_j   (|QEPE|>tol時)
            //                   = 0                                        (|QEPE|<=tol時)
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - effectiveTolerance(ep->tolerance));
            double QEPE_sign = (QEPE >= 0.0) ? 1.0 : -1.0;
            double factor = 2.0 * QEPE_eff * QEPE_sign;  // デッドバンド内なら0

            // ∂cost/∂s_j = factor × w × ∂QEPE/∂s_j
            for (const auto& [key, dQEPE] : pointGrad) {
                double contribution = factor * w_total * dQEPE;
                taskGradients[taskIdx][key] += contribution;
            }
        }
    }

    // タスクインデックス順にクリップ毎に集約
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        size_t c = tasks[taskIdx].clipIdx;
        for (const auto& [key, val] : taskGradients[taskIdx]) {
            clipGradientMaps[c][key] += val;
        }
        clipWeights[c] += taskWeights[taskIdx];
    }
#else
    // シングルスレッド版
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ: このランクが担当しないクリップはスキップ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        // 合成画像を計算（delta_dose適用）
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        // 各評価点について勾配を計算
        for (const auto* ep : clip.evalPoints) {
            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double I = pv.intensity;

            // delta_dose補正後の強度でQEPEを計算
            double QEPE = 0.0;
            if (std::abs(G) > MIN_GRADIENT) {
                QEPE = -(I - sliceLevel) / G;
            }

            double w_total = ep->weight * pwc.weight;
            clipWeights[task.clipIdx] += w_total;

            // 勾配を計算（delta_dose適用）
            auto pointGrad = calcQepeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose);

            // tolerance デッドバンド:
            //   cost_i = (max(0,|QEPE|-tol))^2
            //   d cost_i / ds_j = 2 * QEPE_eff * sign(QEPE) * dQEPE/ds_j   (|QEPE|>tol時)
            //                   = 0                                        (|QEPE|<=tol時)
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - effectiveTolerance(ep->tolerance));
            double QEPE_sign = (QEPE >= 0.0) ? 1.0 : -1.0;
            double factor = 2.0 * QEPE_eff * QEPE_sign;  // デッドバンド内なら0

            // ∂cost/∂s_j = factor × w × ∂QEPE/∂s_j
            for (const auto& [key, dQEPE] : pointGrad) {
                double contribution = factor * w_total * dQEPE;
                clipGradientMaps[task.clipIdx][key] += contribution;
            }
        }
    }
#endif

    // デバッグ出力（verbose時、MPI交換前のローカル勾配を表示）
    if (m_options.verbose) {
        // ローカルのfullGradientを構築（デバッグ用）
        std::map<std::pair<double, double>, double> fullGradient;
        for (size_t c = 0; c < numClips; ++c) {
            for (const auto& [key, val] : clipGradientMaps[c]) {
                fullGradient[key] += val;
            }
        }
        if (!fullGradient.empty()) {
            const auto& varInfos = m_mapping->variableInfos();
            if (!varInfos.empty()) {
                const auto& info = varInfos[0];
                std::cerr << "  [GradCalc Debug] Variable 0: gx=" << info.gx << ", gy=" << info.gy << std::endl;
                std::cerr << "    fullGradient entries for symmetric points:" << std::endl;

                auto key1 = std::make_pair(roundCoord(info.gx), roundCoord(info.gy));
                auto it1 = fullGradient.find(key1);
                std::cerr << "      (" << info.gx << "," << info.gy << "): "
                          << (it1 != fullGradient.end() ? std::to_string(it1->second) : "NOT FOUND") << std::endl;

                if (gridConfig.isD2Symmetry()) {
                    if (std::abs(info.gx) > 1e-6) {
                        auto key2 = std::make_pair(roundCoord(-info.gx), roundCoord(info.gy));
                        auto it2 = fullGradient.find(key2);
                        std::cerr << "      (" << -info.gx << "," << info.gy << "): "
                                  << (it2 != fullGradient.end() ? std::to_string(it2->second) : "NOT FOUND") << std::endl;
                    }
                    if (std::abs(info.gy) > 1e-6) {
                        auto key3 = std::make_pair(roundCoord(info.gx), roundCoord(-info.gy));
                        auto it3 = fullGradient.find(key3);
                        std::cerr << "      (" << info.gx << "," << -info.gy << "): "
                                  << (it3 != fullGradient.end() ? std::to_string(it3->second) : "NOT FOUND") << std::endl;
                    }
                    if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) {
                        auto key4 = std::make_pair(roundCoord(-info.gx), roundCoord(-info.gy));
                        auto it4 = fullGradient.find(key4);
                        std::cerr << "      (" << -info.gx << "," << -info.gy << "): "
                                  << (it4 != fullGradient.end() ? std::to_string(it4->second) : "NOT FOUND") << std::endl;
                    }
                }
            }
        }
    }

    // クリップ毎の勾配マップをベクトルに変換し、フラット配列に格納
    std::vector<double> flatGradients(numClips * numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        if (clipGradientMaps[c].empty()) continue;
        std::vector<double> clipVec = m_mapping->gradientMapToVector(clipGradientMaps[c]);
        std::copy(clipVec.begin(), clipVec.end(), flatGradients.begin() + c * numVars);
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalFlat(numClips * numVars, 0.0);
        MPI_Allreduce(flatGradients.data(), globalFlat.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        flatGradients = std::move(globalFlat);

        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    std::vector<double> gradient(numVars, 0.0);
    double totalWeight = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        for (size_t j = 0; j < numVars; ++j) {
            gradient[j] += flatGradients[c * numVars + j];
        }
        totalWeight += clipWeights[c];
    }

    // 重みで正規化 + EPEスケーリング
    if (totalWeight > 0.0) {
        for (size_t i = 0; i < gradient.size(); ++i) {
            gradient[i] *= EPE_SCALE / totalWeight;
        }
    }

    if (m_options.verbose) {
        std::cerr << "    totalWeight (for normalization): " << totalWeight << std::endl;
    }

    // source_fill_cost の勾配を追加（全ランクで同一計算）
    std::vector<double> fillGrad = calcSourceFillGradient(sourceData);
    for (size_t i = 0; i < gradient.size(); ++i) {
        gradient[i] += m_options.weightFillPenalty * fillGrad[i];
    }

    // 正則化の勾配を追加（全ランクで同一計算）
    if (m_options.regularizationWeight > 0.0) {
        std::vector<double> regGrad;
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regGrad = calcLaplacianGradient(sourceData);
                break;
            case RegularizationType::L2:
                regGrad = calcL2Gradient(sourceData);
                break;
            case RegularizationType::TV:
                regGrad = calcTVGradient(sourceData);
                break;
            case RegularizationType::Isolated:
                regGrad = calcIsolatedGradient(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
        for (size_t i = 0; i < gradient.size() && i < regGrad.size(); ++i) {
            gradient[i] += regGrad[i];
        }
    }

    // NILS ペナルティの勾配を追加
    if (m_options.weightNilsPenalty > 0.0) {
        auto nilsGrad = calcNilsGradientTotal(sourceData, evpData, processConfig, sliceLevel);
        for (size_t i = 0; i < gradient.size() && i < nilsGrad.size(); ++i) {
            gradient[i] += m_options.weightNilsPenalty * nilsGrad[i];
        }
    }

    // BT / BFS ペナルティの勾配を追加
    if (m_options.weightBt > 0.0 || m_options.weightBfs > 0.0) {
        auto btBfsGrad = calcBtBfsGradient(sourceData, evpData, processConfig, sliceLevel);
        for (size_t i = 0; i < gradient.size() && i < btBfsGrad.size(); ++i) {
            gradient[i] += btBfsGrad[i];
        }
    }

    // デバッグ出力（最初の変数の勾配）
    if (m_options.verbose && !gradient.empty()) {
        std::cerr << "    Folded gradient[0]: " << gradient[0] << std::endl;
        std::cerr << "    source_fill gradient[0]: " << (fillGrad.empty() ? 0.0 : fillGrad[0]) << std::endl;
    }

    return gradient;
}

std::vector<double> GradientCalculator::calcSourceFillGradient(
    const SourceData& sourceData) const {

    double sourceFillRatio = calcSourceFillRatio(sourceData);

    std::vector<double> grad(m_mapping->numVariables(), 0.0);

    constexpr double FEAS_TOL_GRAD = 1e-6;
    if (sourceFillRatio >= m_options.minSourceFillRatio - FEAS_TOL_GRAD) {
        return grad;  // 制約を満たしている場合は勾配ゼロ（cost 側と整合）
    }

    double diff = m_options.minSourceFillRatio - sourceFillRatio;
    double dCost_dRatio;
    if (m_options.useExponentialFillPenalty) {
        // 指数ペナルティ: cost = exp(k * diff) - 1
        double k = m_options.fillPenaltyExponent;
        dCost_dRatio = -k * std::exp(k * diff);
    } else {
        // 二乗ペナルティ: cost = diff^2
        dCost_dRatio = -2.0 * diff;
    }

    // 単位円内の物理点数 n
    const auto& points = sourceData.showPoints();
    size_t n = 0;
    for (const auto& point : points) {
        if (point.x * point.x + point.y * point.y <= 1.0) {
            ++n;
        }
    }
    if (n == 0) {
        return grad;
    }

    double maxIntensity = sourceData.showMaxIntensity();
    double totalIntensity = sourceData.showTotalIntensity();
    if (maxIntensity <= 0.0) {
        return grad;
    }

    // ratio = c·total/(max·n), c = (NA/1.35)^2
    //
    // スケール不変性 (ratio(α·s) = ratio(s)) から ∂ratio/∂s_j は max の依存を
    // 含めて計算しなければならない。一意ピーク点 j* では
    //   ∂ratio/∂s_j    =  c/(max·n)                         (j ≠ j*)
    //   ∂ratio/∂s_{j*} =  c/(max·n) - c·total/(max²·n)
    // タイブレーク(m個同点)時はピーク集合へ均等分配:
    //   ピーク点 k     :  c/(max·n) - (1/m)·c·total/(max²·n)
    //
    // D2 対称では 1 変数 i の multiplier_i 個の物理コピーは常に同値なので、
    // 変数 i がピークなら全コピーがピーク集合に属する。
    double naFactor = (m_NA / 1.35) * (m_NA / 1.35);
    double common = naFactor / (maxIntensity * static_cast<double>(n));
    double peakCorr = -naFactor * totalIntensity
                      / (maxIntensity * maxIntensity * static_cast<double>(n));

    // ピーク重みの連続化（softmax 風）
    // 従来は peakRelTol = 1e-9 のハード閾値でピーク集合を確定し、
    // 集合内に peakCorr を均等分配していたが、最適化中に max 近傍の変数が
    // 出入りすると勾配が不連続にジャンプし、L-BFGS の曲率近似を乱す。
    //
    // 本実装では w_i = mult_i × exp(β × (s_i - max) / max) で重み付けし、
    // ピーク補正を (w_i / Σ w_k) で連続的に分配する。β を十分大きく取れば
    // 従来の hard-max 挙動と数値的にほぼ一致するが、勾配は滑らか。
    std::vector<double> varValues = m_mapping->sourceToVariables(sourceData);
    const double peakBeta = 1e3;  // β：大きいほど hard-max に近く、小さいほど滑らか

    const auto& infos = m_mapping->variableInfos();
    std::vector<double> peakWeight(infos.size(), 0.0);
    double peakWeightSum = 0.0;
    for (size_t i = 0; i < infos.size(); ++i) {
        double mult = static_cast<double>(infos[i].multiplier);
        // (s_i - max) / max は [-1, 0] の範囲。max=0 のケースは関数冒頭で弾いている。
        double scaled = (varValues[i] - maxIntensity) / maxIntensity;
        double w = mult * std::exp(peakBeta * scaled);
        peakWeight[i] = w;
        peakWeightSum += w;
    }
    if (peakWeightSum <= 0.0) {
        peakWeightSum = 1.0;  // 念のためのガード
    }

    for (size_t i = 0; i < infos.size(); ++i) {
        double mult = static_cast<double>(infos[i].multiplier);
        double dRatio_dxi = mult * common;
        // ピーク補正を softmax 重みで分配。
        // 物理コピーは同強度なので変数 i に属する全 multiplier 個ぶん寄与する
        // ＝ peakWeight[i]（既に mult を含む）を使えばよい。
        dRatio_dxi += (peakWeight[i] / peakWeightSum) * peakCorr;
        grad[i] = dCost_dRatio * dRatio_dxi;
    }

    return grad;
}

double GradientCalculator::calcSourceFillRatio(
    const SourceData& sourceData) const {
    return sourceData.calcSourceFillRatio(m_NA);
}

double GradientCalculator::calcSourceFillCost(double sourceFillRatio) const {
    // 浮動小数点 tolerance（feasibility 判定と整合）
    constexpr double FEAS_TOL = 1e-6;
    if (sourceFillRatio >= m_options.minSourceFillRatio - FEAS_TOL) {
        return 0.0;
    }

    double diff = m_options.minSourceFillRatio - sourceFillRatio;

    if (m_options.useExponentialFillPenalty) {
        // 指数ペナルティ: exp(k * diff) - 1
        // diff → 0 で cost → 0、diff が大きいと急激に増加
        double k = m_options.fillPenaltyExponent;
        return std::exp(k * diff) - 1.0;
    } else {
        // 従来の二乗ペナルティ
        return diff * diff;
    }
}

// ============================================================================
// NILS ペナルティ
// ============================================================================

double GradientCalculator::calcNilsAtPoint(
    const FrequencyImage& combinedImg,
    double px, double py, double degree,
    double sliceLevel,
    double* outG) const {

    double rad = degree * M_PI / 180.0;
    double nx = std::cos(rad);
    double ny = std::sin(rad);

    auto pv = combinedImg.evalAt(px, py);
    double G = pv.gradX * nx + pv.gradY * ny;
    if (outG) *outG = G;

    if (sliceLevel < MIN_GRADIENT) {
        return 0.0;
    }
    return m_options.nilsCdReference * std::abs(G) / sliceLevel;
}

double GradientCalculator::calcNilsCostTotal(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    // weightNilsPenalty == 0 でもログ/cost.csv 出力のため値を計算する。
    // （最適化ループ側は outNilsCost=nullptr のときだけ本関数の呼び出しを
    //   スキップしているので、毎 iteration の FFT 合成コストは増えない。）
    if (!m_mapping || !m_sourceContributions) return 0.0;

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    struct Task { size_t clipIdx; size_t pwcIdx; };
    std::vector<Task> tasks;
    for (size_t c = 0; c < clips.size(); ++c)
        for (size_t p = 0; p < pwcs.size(); ++p)
            tasks.push_back({c, p});

    std::vector<double> taskPenalty(tasks.size(), 0.0);
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) continue;

        FrequencyImage combinedImg = it->second.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            double nils = calcNilsAtPoint(combinedImg, ep->px, ep->py, ep->degree, sliceLevel, nullptr);
            double deficit = std::max(0.0, m_options.nilsMin - nils);
            double w = ep->weight * pwc.weight;
            taskPenalty[taskIdx] += deficit * deficit * w;
            taskWeights[taskIdx] += w;
        }
    }

    size_t numClips = clips.size();
    std::vector<double> clipPenalty(numClips, 0.0);
    std::vector<double> clipWeights(numClips, 0.0);
    for (size_t t = 0; t < tasks.size(); ++t) {
        clipPenalty[tasks[t].clipIdx] += taskPenalty[t];
        clipWeights[tasks[t].clipIdx] += taskWeights[t];
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> gP(numClips, 0.0), gW(numClips, 0.0);
        MPI_Allreduce(clipPenalty.data(), gP.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeights.data(), gW.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipPenalty = std::move(gP);
        clipWeights = std::move(gW);
    }
#endif

    double totalP = 0.0, totalW = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        totalP += clipPenalty[c];
        totalW += clipWeights[c];
    }
    return (totalW > 0.0) ? (totalP / totalW) : 0.0;
}

std::vector<double> GradientCalculator::calcNilsGradientTotal(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    size_t numVars = m_mapping ? m_mapping->numVariables() : 0;
    std::vector<double> zero(numVars, 0.0);
    if (m_options.weightNilsPenalty <= 0.0) return zero;
    if (!m_mapping || !m_sourceContributions) return zero;

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    struct Task { size_t clipIdx; size_t pwcIdx; };
    std::vector<Task> tasks;
    for (size_t c = 0; c < clips.size(); ++c)
        for (size_t p = 0; p < pwcs.size(); ++p)
            tasks.push_back({c, p});

    size_t numClips = clips.size();
    std::vector<std::map<std::pair<double, double>, double>> clipGradMaps(numClips);
    std::vector<double> clipWeights(numClips, 0.0);

    std::vector<std::map<std::pair<double, double>, double>> taskGrads(tasks.size());
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) continue;

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);
        if (inter.totalWeight < MIN_GRADIENT) continue;

        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }
        double W = inter.totalWeight;

        for (const auto* ep : clip.evalPoints) {
            double w_total = ep->weight * pwc.weight;
            taskWeights[taskIdx] += w_total;

            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double absG = std::abs(G);
            double nils = m_options.nilsCdReference * absG / sliceLevel;

            double deficit = m_options.nilsMin - nils;
            if (deficit <= 0.0) continue;  // ペナルティ領域外

            // penalty_i = deficit^2, ∂deficit/∂s = -∂NILS/∂s
            // NILS = cdRef/slice × |G|, ∂|G|/∂s = sign(G) × ∂G/∂s
            // ∂G/∂s_j = norm_j × (G_j - G_combined) / W
            double sG = (G >= 0.0) ? 1.0 : -1.0;
            double coef = -2.0 * deficit * m_options.nilsCdReference / sliceLevel * sG;
            double factor = coef * w_total;

            for (const auto& contrib : contribSet.contributions()) {
                auto pv_j = contrib.freqImage.evalAt(ep->px, ep->py);
                double Gj = pv_j.gradX * nx + pv_j.gradY * ny;
                if (std::abs(pwc.delta_dose) > 1e-9) {
                    Gj *= (1.0 + pwc.delta_dose / 100.0);
                }
                double dG_dsj = contrib.norm * (Gj - G) / W;
                double dPen_dsj = factor * dG_dsj;

                auto key = makeCoordKey(contrib.gx, contrib.gy);
                taskGrads[taskIdx][key] += dPen_dsj;
            }
        }
    }

    for (size_t t = 0; t < tasks.size(); ++t) {
        size_t c = tasks[t].clipIdx;
        for (const auto& [k, v] : taskGrads[t]) clipGradMaps[c][k] += v;
        clipWeights[c] += taskWeights[t];
    }

    std::vector<double> flat(numClips * numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        if (clipGradMaps[c].empty()) continue;
        auto v = m_mapping->gradientMapToVector(clipGradMaps[c]);
        std::copy(v.begin(), v.end(), flat.begin() + c * numVars);
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> gFlat(numClips * numVars, 0.0);
        MPI_Allreduce(flat.data(), gFlat.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        flat = std::move(gFlat);
        std::vector<double> gW(numClips, 0.0);
        MPI_Allreduce(clipWeights.data(), gW.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipWeights = std::move(gW);
    }
#endif

    std::vector<double> gradient(numVars, 0.0);
    double totalW = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        for (size_t j = 0; j < numVars; ++j) gradient[j] += flat[c * numVars + j];
        totalW += clipWeights[c];
    }
    if (totalW > 0.0) {
        for (auto& v : gradient) v /= totalW;
    }
    return gradient;
}

// ============================================================================
// BT (Bossung Tilt) / BFS (Best Focus Shift) ペナルティ
// ============================================================================
//
// 数式:
//   BT  = (1/EPE_REF^p) · Σ_{c,ev} w_clip · w_ev · |EPE(Fp) - EPE(Fn)|^p / Σw
//   BFS = (1/EPE_REF^p) · Σ_{c,ev} w_clip · w_ev ·
//         (|EPE(Fp)-EPE(Nom)|^p + |EPE(Fn)-EPE(Nom)|^p) / Σw
//
// Fp / Fn / Nom はそれぞれ「max defocus / min defocus / nominal」の PWC index。
// 自動検出は (mask_bias=0, delta_dose=0) の PWC を対象に行う。
//
// 勾配は各評価点 ev について
//   ∂(EPE(A)-EPE(B))/∂s_j = ∂EPE(A)/∂s_j - ∂EPE(B)/∂s_j
//   ∂|delta|^p / ∂s_j      = p · |delta|^(p-1) · sign(delta) · ∂delta/∂s_j
// で組み立てる。各 ∂EPE/∂s_j は calcStrictEpeGradientAtPoint() を流用する。
// ============================================================================

// 複数ペアモード対応: btPairs / bfsPairs が指定されていればそれを使う。
// 空なら従来の単一ペア検出に fallback。
// BFS の Nom はペアごとに独立指定可。tuple の第 3 要素が < 0 なら全ペア共通 bfsPwcNom (or auto) を使う。
GradientCalculator::BtBfsPairSets GradientCalculator::resolveBtBfsPairs(
    const ProcessConfig& processConfig) const {
    BtBfsPairSets out;
    const auto& pwcs = processConfig.showPwcConditions();

    // 共通 Nom (ペアごとの Nom が指定されない場合の fallback)
    int defaultNomIdx = -1;
    if (m_options.bfsPwcNom >= 0 && static_cast<size_t>(m_options.bfsPwcNom) < pwcs.size()) {
        defaultNomIdx = m_options.bfsPwcNom;
    } else {
        for (size_t i = 0; i < pwcs.size(); ++i) {
            if (pwcs[i].isNominal()) { defaultNomIdx = static_cast<int>(i); break; }
        }
    }

    auto pushIfValid = [&](std::vector<PwcPair>& sink, int fp, int fn, int nom) {
        if (fp < 0 || fn < 0) return;
        if (static_cast<size_t>(fp) >= pwcs.size()) return;
        if (static_cast<size_t>(fn) >= pwcs.size()) return;
        if (fp == fn) return;
        PwcPair p;
        p.pwc_index_p = fp;
        p.pwc_index_n = fn;
        p.pwc_index_nom = nom;
        sink.push_back(p);
    };

    // ===== BT 用ペア =====
    if (!m_options.btPairs.empty()) {
        for (const auto& [fp, fn] : m_options.btPairs)
            pushIfValid(out.btPairs, fp, fn, defaultNomIdx);
    } else {
        PwcPair single = detectBtBfsPair(processConfig);
        if (single.validBt()) out.btPairs.push_back(single);
    }

    // ===== BFS 用ペア (Fp, Fn, Nom の三つ組指定) =====
    if (!m_options.bfsPairs.empty()) {
        for (const auto& [fp, fn, nomReq] : m_options.bfsPairs) {
            int nom = (nomReq >= 0 && static_cast<size_t>(nomReq) < pwcs.size())
                      ? nomReq : defaultNomIdx;
            pushIfValid(out.bfsPairs, fp, fn, nom);
        }
    } else if (!m_options.btPairs.empty()) {
        // btPairs だけ指定された場合は BFS にも同じペアを流用 (Nom は共通)
        for (const auto& [fp, fn] : m_options.btPairs)
            pushIfValid(out.bfsPairs, fp, fn, defaultNomIdx);
    } else {
        PwcPair single = detectBtBfsPair(processConfig);
        if (single.validBfs()) out.bfsPairs.push_back(single);
    }

    return out;
}

PwcPair GradientCalculator::detectBtBfsPair(const ProcessConfig& processConfig) const {
    PwcPair p;
    const auto& pwcs = processConfig.showPwcConditions();

    // Nom のみユーザー明示指定があれば優先 (Fp/Fn は常に自動検出: defocus 極値)
    if (m_options.bfsPwcNom >= 0 && static_cast<size_t>(m_options.bfsPwcNom) < pwcs.size())
        p.pwc_index_nom = m_options.bfsPwcNom;

    // 自動検出: (mask_bias=0, delta_dose=0) のうち defocus 極値と nominal
    double maxDefocus = -1e30, minDefocus = 1e30;
    for (size_t i = 0; i < pwcs.size(); ++i) {
        const auto& pwc = pwcs[i];
        if (std::abs(pwc.mask_bias) > 1e-9) continue;
        if (std::abs(pwc.delta_dose) > 1e-9) continue;
        if (p.pwc_index_p < 0 && pwc.defocus > maxDefocus) {
            maxDefocus = pwc.defocus;
            // 候補として保存（最後に書き戻す）
        }
        if (p.pwc_index_n < 0 && pwc.defocus < minDefocus) {
            minDefocus = pwc.defocus;
        }
    }
    if (p.pwc_index_p < 0) {
        for (size_t i = 0; i < pwcs.size(); ++i) {
            const auto& pwc = pwcs[i];
            if (std::abs(pwc.mask_bias) > 1e-9 || std::abs(pwc.delta_dose) > 1e-9) continue;
            if (std::abs(pwc.defocus - maxDefocus) < 1e-9) { p.pwc_index_p = static_cast<int>(i); break; }
        }
    }
    if (p.pwc_index_n < 0) {
        for (size_t i = 0; i < pwcs.size(); ++i) {
            const auto& pwc = pwcs[i];
            if (std::abs(pwc.mask_bias) > 1e-9 || std::abs(pwc.delta_dose) > 1e-9) continue;
            if (std::abs(pwc.defocus - minDefocus) < 1e-9) { p.pwc_index_n = static_cast<int>(i); break; }
        }
    }
    if (p.pwc_index_nom < 0) {
        for (size_t i = 0; i < pwcs.size(); ++i) {
            if (pwcs[i].isNominal()) { p.pwc_index_nom = static_cast<int>(i); break; }
        }
    }
    return p;
}

// PWC index k での Newton EPE と ∂EPE/∂s 勾配マップを 1 評価点について返す
// 内部ヘルパ（calcBtBfsCost / calcBtBfsGradient 用）。
//
// 注: getter は同じ計算を 2 回行うのを避けるため、CalcStrictEpeGradientAtPoint を
// 1 回呼んで EPE と grad map を同時に得る。
namespace {

struct EvPwcSample {
    double epe = 0.0;
    bool valid = false;
    std::map<std::pair<double, double>, double> grad;  // ∂EPE/∂s_j の各光源点別
};

}  // namespace

void GradientCalculator::calcBtBfsCost(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    double* outBt,
    double* outBfs) const {

    if (outBt) *outBt = 0.0;
    if (outBfs) *outBfs = 0.0;
    if (!m_mapping || !m_sourceContributions) return;

    bool needBt = (m_options.weightBt > 0.0) || (outBt != nullptr);
    bool needBfs = (m_options.weightBfs > 0.0) || (outBfs != nullptr);
    if (!needBt && !needBfs) return;

    BtBfsPairSets pairSets = resolveBtBfsPairs(processConfig);
    if (needBt && pairSets.btPairs.empty()) needBt = false;
    if (needBfs && pairSets.bfsPairs.empty()) needBfs = false;
    if (!needBt && !needBfs) return;

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();
    const auto& gridConfig = m_mapping->gridConfig();

    // clip ID フィルタ
    auto clipApplies = [&](int clipID) {
        if (m_options.pairClips.empty()) return true;
        for (int id : m_options.pairClips) if (id == clipID) return true;
        return false;
    };

    // 全 pair で参照する PWC index の集合 (clip 単位 image cache 構築用)
    std::set<int> neededPwc;
    if (needBt) for (const auto& p : pairSets.btPairs) {
        neededPwc.insert(p.pwc_index_p); neededPwc.insert(p.pwc_index_n);
    }
    if (needBfs) for (const auto& p : pairSets.bfsPairs) {
        neededPwc.insert(p.pwc_index_p); neededPwc.insert(p.pwc_index_n);
        if (p.pwc_index_nom >= 0) neededPwc.insert(p.pwc_index_nom);
    }

    // clip 単位で部分和を作って MPI 集約 (bit-identical 化)
    size_t numClips = clips.size();
    std::vector<double> clipBt(numClips, 0.0);
    std::vector<double> clipBfs(numClips, 0.0);
    std::vector<double> clipWeight(numClips, 0.0);

    for (size_t ci = 0; ci < numClips; ++ci) {
        if (m_mpiSize > 1 && ci % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;
        const auto& clip = clips[ci];
        if (!clipApplies(clip.clipID)) continue;

        // 各 PWC 用に合成画像を 1 回ずつ作る (pair 間で再利用)
        std::map<int, FrequencyImage> imgs;
        for (int pi : neededPwc) {
            const auto& pwc = pwcs[pi];
            std::string fname = makeImageFileName(clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
            auto it = m_sourceContributions->find(fname);
            if (it == m_sourceContributions->end()) continue;
            FrequencyImage img = it->second.combine(sourceData, gridConfig);
            if (std::abs(pwc.delta_dose) > 1e-9) img.scale(1.0 + pwc.delta_dose / 100.0);
            imgs[pi] = std::move(img);
        }

        // 各評価点について、有効な全ペアで cost を積算
        for (const auto* ep : clip.evalPoints) {
            double evW = ep->weight;
            bool counted = false;
            // BT ペア
            if (needBt) for (const auto& pair : pairSets.btPairs) {
                auto itP = imgs.find(pair.pwc_index_p);
                auto itN = imgs.find(pair.pwc_index_n);
                if (itP == imgs.end() || itN == imgs.end()) continue;
                double epeP = findContourPositionFull(itP->second,
                                                       ep->px, ep->py, ep->degree, sliceLevel).epe;
                double epeN = findContourPositionFull(itN->second,
                                                       ep->px, ep->py, ep->degree, sliceLevel).epe;
                double w = evW * pwcs[pair.pwc_index_p].weight;
                double deltaBt = epeP - epeN;
                clipBt[ci] += std::pow(std::abs(deltaBt), m_options.btPower) * w;
                clipWeight[ci] += w; counted = true;
            }
            // BFS ペア
            if (needBfs) for (const auto& pair : pairSets.bfsPairs) {
                if (pair.pwc_index_nom < 0) continue;
                auto itP = imgs.find(pair.pwc_index_p);
                auto itN = imgs.find(pair.pwc_index_n);
                auto itM = imgs.find(pair.pwc_index_nom);
                if (itP == imgs.end() || itN == imgs.end() || itM == imgs.end()) continue;
                double epeP = findContourPositionFull(itP->second,
                                                       ep->px, ep->py, ep->degree, sliceLevel).epe;
                double epeN = findContourPositionFull(itN->second,
                                                       ep->px, ep->py, ep->degree, sliceLevel).epe;
                double epeNom = findContourPositionFull(itM->second,
                                                       ep->px, ep->py, ep->degree, sliceLevel).epe;
                double w = evW * pwcs[pair.pwc_index_p].weight;
                double d1 = epeP - epeNom;
                double d2 = epeN - epeNom;
                clipBfs[ci] += (std::pow(std::abs(d1), m_options.bfsPower)
                              + std::pow(std::abs(d2), m_options.bfsPower)) * w;
                if (!counted) { clipWeight[ci] += w; counted = true; }
            }
        }
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> gBt(numClips, 0.0), gBfs(numClips, 0.0), gW(numClips, 0.0);
        MPI_Allreduce(clipBt.data(), gBt.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipBfs.data(), gBfs.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeight.data(), gW.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipBt = std::move(gBt);
        clipBfs = std::move(gBfs);
        clipWeight = std::move(gW);
    }
#endif

    double sumBt = 0.0, sumBfs = 0.0, sumW = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        sumBt += clipBt[c];
        sumBfs += clipBfs[c];
        sumW += clipWeight[c];
    }
    double scaleBt = 1.0 / std::pow(EPE_REF, m_options.btPower);
    double scaleBfs = 1.0 / std::pow(EPE_REF, m_options.bfsPower);
    if (sumW > 0.0) {
        if (outBt) *outBt = scaleBt * sumBt / sumW;
        if (outBfs) *outBfs = scaleBfs * sumBfs / sumW;
    }
}

std::vector<double> GradientCalculator::calcBtBfsGradient(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    size_t numVars = m_mapping ? m_mapping->numVariables() : 0;
    std::vector<double> result(numVars, 0.0);
    if (numVars == 0) return result;
    if (m_options.weightBt <= 0.0 && m_options.weightBfs <= 0.0) return result;
    if (!m_sourceContributions) return result;

    BtBfsPairSets pairSets = resolveBtBfsPairs(processConfig);
    bool needBt = (m_options.weightBt > 0.0) && !pairSets.btPairs.empty();
    bool needBfs = (m_options.weightBfs > 0.0) && !pairSets.bfsPairs.empty();
    if (!needBt && !needBfs) return result;

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    auto clipApplies = [&](int clipID) {
        if (m_options.pairClips.empty()) return true;
        for (int id : m_options.pairClips) if (id == clipID) return true;
        return false;
    };

    // 全 pair で参照する PWC index の集合
    std::set<int> neededPwc;
    if (needBt) for (const auto& p : pairSets.btPairs) {
        neededPwc.insert(p.pwc_index_p); neededPwc.insert(p.pwc_index_n);
    }
    if (needBfs) for (const auto& p : pairSets.bfsPairs) {
        neededPwc.insert(p.pwc_index_p); neededPwc.insert(p.pwc_index_n);
        if (p.pwc_index_nom >= 0) neededPwc.insert(p.pwc_index_nom);
    }

    // BT と BFS の勾配を別に集計 (重み込み分母も別に持つ)
    size_t numClips = clips.size();
    std::vector<std::map<std::pair<double, double>, double>> clipGradBt(numClips);
    std::vector<std::map<std::pair<double, double>, double>> clipGradBfs(numClips);
    std::vector<double> clipWeight(numClips, 0.0);

    for (size_t ci = 0; ci < numClips; ++ci) {
        if (m_mpiSize > 1 && ci % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;
        const auto& clip = clips[ci];
        if (!clipApplies(clip.clipID)) continue;

        // この clip で必要な全 PWC の contribution と intermediates をキャッシュ
        std::map<int, const SourceContributionSet*> contribs;
        std::map<int, GradientIntermediates> inters;
        for (int pi : neededPwc) {
            const auto& pwc = pwcs[pi];
            std::string fn = makeImageFileName(clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
            auto it = m_sourceContributions->find(fn);
            if (it == m_sourceContributions->end()) continue;
            contribs[pi] = &it->second;
            inters[pi] = calcIntermediates(*contribs[pi], sourceData);
        }

        for (const auto* ep : clip.evalPoints) {
            // 各 PWC で EPE と勾配を 1 回だけ計算してキャッシュ
            std::map<int, double> epeMap;
            std::map<int, std::map<std::pair<double, double>, double>> gradMap;
            for (const auto& [pi, contrib] : contribs) {
                const auto& pwc = pwcs[pi];
                double epe = 0.0; bool conv = false;
                auto g = calcStrictEpeGradientAtPoint(*contrib, sourceData, inters[pi],
                    ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose, &epe, &conv);
                epeMap[pi] = epe;
                gradMap[pi] = std::move(g);
            }

            bool counted = false;
            // 各 BT pair で勾配と weight を積算
            if (needBt) for (const auto& pair : pairSets.btPairs) {
                int ip = pair.pwc_index_p, in = pair.pwc_index_n;
                if (epeMap.find(ip) == epeMap.end()) continue;
                if (epeMap.find(in) == epeMap.end()) continue;
                double w = ep->weight * pwcs[ip].weight;
                double delta = epeMap[ip] - epeMap[in];
                double absD = std::abs(delta);
                if (absD > 0.0) {
                    double factor = static_cast<double>(m_options.btPower)
                                    * std::pow(absD, m_options.btPower - 1)
                                    * (delta >= 0 ? 1.0 : -1.0) * w;
                    for (const auto& [k, v] : gradMap[ip]) clipGradBt[ci][k] += factor * v;
                    for (const auto& [k, v] : gradMap[in]) clipGradBt[ci][k] += -factor * v;
                }
                clipWeight[ci] += w; counted = true;
            }
            // 各 BFS pair で勾配と weight を積算 (BT で既にカウント済みなら weight 重複しない)
            if (needBfs) for (const auto& pair : pairSets.bfsPairs) {
                int ip = pair.pwc_index_p, in = pair.pwc_index_n, im = pair.pwc_index_nom;
                if (im < 0) continue;
                if (epeMap.find(ip) == epeMap.end()) continue;
                if (epeMap.find(in) == epeMap.end()) continue;
                if (epeMap.find(im) == epeMap.end()) continue;
                double w = ep->weight * pwcs[ip].weight;
                double epeP = epeMap[ip], epeN = epeMap[in], epeNom = epeMap[im];

                double d1 = epeP - epeNom;
                double ad1 = std::abs(d1);
                if (ad1 > 0.0) {
                    double f1 = static_cast<double>(m_options.bfsPower)
                                * std::pow(ad1, m_options.bfsPower - 1)
                                * (d1 >= 0 ? 1.0 : -1.0) * w;
                    for (const auto& [k, v] : gradMap[ip]) clipGradBfs[ci][k] += f1 * v;
                    for (const auto& [k, v] : gradMap[im]) clipGradBfs[ci][k] += -f1 * v;
                }
                double d2 = epeN - epeNom;
                double ad2 = std::abs(d2);
                if (ad2 > 0.0) {
                    double f2 = static_cast<double>(m_options.bfsPower)
                                * std::pow(ad2, m_options.bfsPower - 1)
                                * (d2 >= 0 ? 1.0 : -1.0) * w;
                    for (const auto& [k, v] : gradMap[in]) clipGradBfs[ci][k] += f2 * v;
                    for (const auto& [k, v] : gradMap[im]) clipGradBfs[ci][k] += -f2 * v;
                }
                if (!counted) { clipWeight[ci] += w; counted = true; }
            }
        }
    }

    // flat 化 + MPI 集約
    std::vector<double> flatBt(numClips * numVars, 0.0);
    std::vector<double> flatBfs(numClips * numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        if (!clipGradBt[c].empty()) {
            auto v = m_mapping->gradientMapToVector(clipGradBt[c]);
            std::copy(v.begin(), v.end(), flatBt.begin() + c * numVars);
        }
        if (!clipGradBfs[c].empty()) {
            auto v = m_mapping->gradientMapToVector(clipGradBfs[c]);
            std::copy(v.begin(), v.end(), flatBfs.begin() + c * numVars);
        }
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> gBt(numClips * numVars, 0.0);
        std::vector<double> gBfs(numClips * numVars, 0.0);
        std::vector<double> gW(numClips, 0.0);
        MPI_Allreduce(flatBt.data(), gBt.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(flatBfs.data(), gBfs.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeight.data(), gW.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        flatBt = std::move(gBt);
        flatBfs = std::move(gBfs);
        clipWeight = std::move(gW);
    }
#endif

    double totalBt = 0.0, totalBfs = 0.0, totalW = 0.0;
    std::vector<double> gradBt(numVars, 0.0);
    std::vector<double> gradBfs(numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        for (size_t j = 0; j < numVars; ++j) {
            gradBt[j] += flatBt[c * numVars + j];
            gradBfs[j] += flatBfs[c * numVars + j];
        }
        totalW += clipWeight[c];
    }
    (void)totalBt; (void)totalBfs;
    if (totalW <= 0.0) return result;

    double scaleBt = 1.0 / std::pow(EPE_REF, m_options.btPower);
    double scaleBfs = 1.0 / std::pow(EPE_REF, m_options.bfsPower);
    double normBt = needBt ? m_options.weightBt * scaleBt / totalW : 0.0;
    double normBfs = needBfs ? m_options.weightBfs * scaleBfs / totalW : 0.0;
    for (size_t i = 0; i < numVars; ++i) {
        result[i] = normBt * gradBt[i] + normBfs * gradBfs[i];
    }
    return result;
}

double GradientCalculator::calculateCost(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    double* outEpeCost,
    double* outSourceFillCost,
    double* outNilsCost) const {

    if (!m_mapping || !m_sourceContributions) {
        if (outEpeCost) *outEpeCost = 0.0;
        if (outSourceFillCost) *outSourceFillCost = 0.0;
        if (outNilsCost) *outNilsCost = 0.0;
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    double totalWeightedQEPESq = 0.0;
    double totalWeight = 0.0;

    // タスク毎の結果を格納（決定的な加算順序を保証）
    std::vector<double> taskQEPESq(tasks.size(), 0.0);
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        FrequencyImage combinedImg = it->second.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            double rad = ep->degree * M_PI / 180.0;
            double nx = std::cos(rad);
            double ny = std::sin(rad);

            auto pv = combinedImg.evalAt(ep->px, ep->py);
            double G = pv.gradX * nx + pv.gradY * ny;
            double I = pv.intensity;

            double QEPE = 0.0;
            if (std::abs(G) > MIN_GRADIENT) {
                QEPE = -(I - sliceLevel) / G;
            }

            double w = ep->weight * pwc.weight;
            // tolerance デッドバンド: |QEPE|<=tolerance は無罰
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - effectiveTolerance(ep->tolerance));
            taskQEPESq[taskIdx] += QEPE_eff * QEPE_eff * w;
            taskWeights[taskIdx] += w;
        }
    }

    // タスク結果をクリップ単位に集約（MPI決定的集約用）
    size_t numClips = clips.size();
    std::vector<double> clipCosts(numClips, 0.0);
    std::vector<double> clipWeights(numClips, 0.0);
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        clipCosts[tasks[taskIdx].clipIdx] += taskQEPESq[taskIdx];
        clipWeights[tasks[taskIdx].clipIdx] += taskWeights[taskIdx];
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalClipCosts(numClips, 0.0);
        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipCosts.data(), globalClipCosts.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipCosts = std::move(globalClipCosts);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    for (size_t c = 0; c < numClips; ++c) {
        totalWeightedQEPESq += clipCosts[c];
        totalWeight += clipWeights[c];
    }

    double epeCost = (totalWeight > 0.0) ? totalWeightedQEPESq * EPE_SCALE / totalWeight : 0.0;
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double sourceFillCost = calcSourceFillCost(sourceFillRatio);

    // 正則化コストを追加
    double regularizationCost = 0.0;
    if (m_options.regularizationWeight > 0.0) {
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regularizationCost = calcLaplacianCost(sourceData);
                break;
            case RegularizationType::L2:
                regularizationCost = calcL2Cost(sourceData);
                break;
            case RegularizationType::TV:
                regularizationCost = calcTVCost(sourceData);
                break;
            case RegularizationType::Isolated:
                regularizationCost = calcIsolatedCost(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
    }

    // NILS ペナルティ
    // 最適化ループでは outNilsCost=nullptr かつ weight=0 の場合はスキップしてFFT合成コストを節約。
    // ログ/cost.csv 出力で outNilsCost が要求された場合は weight=0 でも値を返す。
    bool needNils = (outNilsCost != nullptr) || (m_options.weightNilsPenalty > 0.0);
    double nilsCost = needNils
        ? calcNilsCostTotal(sourceData, evpData, processConfig, sliceLevel)
        : 0.0;

    // BT / BFS ペナルティ (weight が 0 ならスキップ)
    double btCost = 0.0, bfsCost = 0.0;
    if (m_options.weightBt > 0.0 || m_options.weightBfs > 0.0) {
        calcBtBfsCost(sourceData, evpData, processConfig, sliceLevel,
                      &btCost, &bfsCost);
    }

    if (outEpeCost) *outEpeCost = epeCost;
    if (outSourceFillCost) *outSourceFillCost = sourceFillCost;
    if (outNilsCost) *outNilsCost = nilsCost;

    return epeCost + m_options.weightFillPenalty * sourceFillCost + regularizationCost
         + m_options.weightNilsPenalty * nilsCost
         + m_options.weightBt * btCost
         + m_options.weightBfs * bfsCost;
}

std::vector<double> GradientCalculator::calculateNumerical(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    double epsilon) const {

    if (!m_mapping) {
        return {};
    }

    std::vector<double> gradient(m_mapping->numVariables());
    std::vector<double> variables = m_mapping->sourceToVariables(sourceData);

    for (size_t i = 0; i < variables.size(); ++i) {
        // 中心差分
        double originalValue = variables[i];

        // +epsilon
        variables[i] = originalValue + epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costPlus = calculateCost(sourceData, evpData, processConfig, sliceLevel);

        // -epsilon
        variables[i] = originalValue - epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costMinus = calculateCost(sourceData, evpData, processConfig, sliceLevel);

        gradient[i] = (costPlus - costMinus) / (2.0 * epsilon);

        // 元に戻す
        variables[i] = originalValue;
    }

    // 光源データを元に戻す
    m_mapping->variablesToSource(variables, sourceData);

    return gradient;
}

std::vector<double> GradientCalculator::calculateNumericalEfficient(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    // GradientMethodに基づいて効率版を選択
    // QEPE系(1,3) → QEPE効率版、EPE系(2,4) → EPE効率版
    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
        case GradientMethod::QEPE_Numerical:
            return calculateQepeNumericalEfficient(sourceData, evpData, processConfig, sliceLevel);

        case GradientMethod::EPE_Analytical:
        case GradientMethod::EPE_Numerical:
        default:
            return calculateEpeNumericalEfficient(sourceData, evpData, processConfig, sliceLevel, epePower);
    }
}

// ============================================================================
// 厳密EPE、EPE^n コスト/勾配計算
// ============================================================================

double GradientCalculator::findContourPosition(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose,
    bool* outConverged,
    int /* debugClipID */,
    int /* debugPwcIdx */,
    double /* debugMaskBias */) const {

    EpeCalcResult result = findContourPositionFull(
        contribSet, sourceData, px, py, degree, sliceLevel, delta_dose);

    if (outConverged) {
        *outConverged = result.converged;
    }
    return result.epe;
}

EpeCalcResult GradientCalculator::findContourPositionFull(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose) const {

    const auto& gridConfig = m_mapping->gridConfig();

    FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
    if (std::abs(delta_dose) > 1e-9) {
        combinedImg.scale(1.0 + delta_dose / 100.0);
    }

    return calcEpeNewton(combinedImg, px, py, degree, sliceLevel);
}

EpeCalcResult GradientCalculator::findContourPositionFull(
    const FrequencyImage& combinedImg,
    double px, double py, double degree,
    double sliceLevel) const {
    return calcEpeNewton(combinedImg, px, py, degree, sliceLevel);
}

std::map<std::pair<double, double>, double> GradientCalculator::calcStrictEpeGradientAtPoint(
    const SourceContributionSet& contribSet,
    const SourceData& sourceData,
    const GradientIntermediates& inter,
    double px, double py, double degree,
    double sliceLevel,
    double delta_dose,
    double* outEpe,
    bool* outConverged,
    int /* debugClipID */,
    int /* debugPwcIdx */,
    double /* debugMaskBias */,
    const FrequencyImage* preCombinedImg) const {

    std::map<std::pair<double, double>, double> gradients;
    const auto& gridConfig = m_mapping->gridConfig();

    if (inter.totalWeight < MIN_GRADIENT) {
        if (outEpe) *outEpe = 0.0;
        if (outConverged) *outConverged = false;
        return gradients;
    }

    // 合成画像を再利用または新規作成
    // preCombinedImg が渡されていれば呼出し側で combine + scale 済みなのでそのまま使う
    // （多評価点ループで combine を共有するため）
    // 渡されていなければ後方互換のため内部で combine + scale する。
    FrequencyImage combinedImgLocal;
    if (preCombinedImg == nullptr) {
        combinedImgLocal = contribSet.combine(sourceData, gridConfig);
        if (std::abs(delta_dose) > 1e-9) {
            combinedImgLocal.scale(1.0 + delta_dose / 100.0);
        }
    }
    const FrequencyImage& combinedImg = (preCombinedImg != nullptr) ? *preCombinedImg : combinedImgLocal;

    // Newton法でコントア位置を取得。収束の可否に関わらず result.epe を採用する
    //（＝「たまたま tolerance に入らなかっただけ」扱い）。
    EpeCalcResult result = findContourPositionFull(
        combinedImg, px, py, degree, sliceLevel);

    if (outConverged) *outConverged = result.converged;

    double epe = result.epe;
    if (outEpe) *outEpe = epe;

    double rad = degree * M_PI / 180.0;
    double nx = std::cos(rad);
    double ny = std::sin(rad);

    // コントア位置
    double cx = px + epe * nx;
    double cy = py + epe * ny;

    // コントア位置での合成画像強度と勾配（上で作った combinedImg を再利用）
    auto pv_c = combinedImg.evalAt(cx, cy);
    double I_c = pv_c.intensity;

    // コントア位置での法線勾配 G_c
    double G_c = pv_c.gradX * nx + pv_c.gradY * ny;

    if (std::abs(G_c) < MIN_GRADIENT) {
        // G_c ≈ 0 では ∂EPE/∂s_j = -∂I/∂s_j / G_c が発散するため
        // この点の勾配寄与のみ空マップでスキップ（重みは呼び出し側で加算される）。
        return gradients;
    }

    double W = inter.totalWeight;

    // 各光源点について、コントア位置での勾配を計算
    // ∂EPE/∂s_j = -∂I(C)/∂s_j / G_c
    // ∂I(C)/∂s_j = norm_j × (I_j(C) - I(C)) / W
    for (const auto& contrib : contribSet.contributions()) {
        auto pv_j = contrib.freqImage.evalAt(cx, cy);
        double I_j_c = pv_j.intensity;
        if (std::abs(delta_dose) > 1e-9) {
            I_j_c *= (1.0 + delta_dose / 100.0);
        }

        double dI_dsj = contrib.norm * (I_j_c - I_c) / W;
        double dEPE_dsj = -dI_dsj / G_c;

        auto key = makeCoordKey(contrib.gx, contrib.gy);
        gradients[key] = dEPE_dsj;
    }

    return gradients;
}

std::vector<double> GradientCalculator::calculateEpeAnalytical(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    // クリップ毎の勾配と重みを保持（MPI決定的集約用）
    size_t numClips = clips.size();
    size_t numVars = m_mapping->numVariables();
    std::vector<std::map<std::pair<double, double>, double>> clipGradientMaps(numClips);
    std::vector<double> clipWeights(numClips, 0.0);

#ifdef _OPENMP
    // タスク毎の結果を格納（OpenMP決定的な加算順序を保証）
    std::vector<std::map<std::pair<double, double>, double>> taskGradients(tasks.size());
    std::vector<double> taskWeights(tasks.size(), 0.0);

    #pragma omp parallel for schedule(dynamic)
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        // 合成画像を (clip, pwc) あたり 1 回だけ作って evp ループ内で再利用する
        // （二重合成回避: 旧実装では calcStrictEpeGradientAtPoint 内部で
        //   evp ごとに combine を呼んでいたため、合成回数が evp 数だけ増えていた）
        const auto& gridConfig = m_mapping->gridConfig();
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            double w_total = ep->weight * pwc.weight;

            // 厳密EPEと勾配を計算（Newton 非収束でも result.epe を採用）
            double epe = 0.0;
            bool converged = false;
            auto pointGrad = calcStrictEpeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose,
                &epe, &converged, -1, -1, 0.0, &combinedImg);

            // 収束/非収束に関わらず重みを加算（cost 側と totalWeight を一致させる）。
            taskWeights[taskIdx] += w_total;

            if (pointGrad.empty()) {
                // G_c≈0 等で勾配が計算不能な点は勾配寄与 0 として扱う（weight は加算済み）
                continue;
            }

            // tolerance デッドバンド:
            //   cost_i = (max(0,|EPE|-tol))^n
            //   |EPE|>tol: d cost_i / ds_j = n * (|EPE|-tol)^(n-1) * sign(EPE) * dEPE/ds_j
            //   |EPE|<=tol: 0
            double epeAbs = std::abs(epe);
            double epe_eff = std::max(0.0, epeAbs - effectiveTolerance(ep->tolerance));
            double epePowM1 = (epe_eff > 0.0) ? std::pow(epe_eff, epePower - 1) : 0.0;
            double sign = (epe >= 0) ? 1.0 : -1.0;

            for (auto& [key, dEPE] : pointGrad) {
                double contribution = static_cast<double>(epePower) * epePowM1 * sign * w_total * dEPE;
                taskGradients[taskIdx][key] += contribution;
            }
        }
    }

    // タスクインデックス順にクリップ毎に集約
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        size_t c = tasks[taskIdx].clipIdx;
        for (const auto& [key, val] : taskGradients[taskIdx]) {
            clipGradientMaps[c][key] += val;
        }
        clipWeights[c] += taskWeights[taskIdx];
    }
#else
    // シングルスレッド版
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;
        auto inter = calcIntermediates(contribSet, sourceData);

        // 合成画像を (clip, pwc) あたり 1 回だけ作って evp ループ内で再利用する
        const auto& gridConfig = m_mapping->gridConfig();
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            double w_total = ep->weight * pwc.weight;

            double epe = 0.0;
            bool converged = false;
            auto pointGrad = calcStrictEpeGradientAtPoint(
                contribSet, sourceData, inter,
                ep->px, ep->py, ep->degree, sliceLevel, pwc.delta_dose,
                &epe, &converged, -1, -1, 0.0, &combinedImg);

            clipWeights[task.clipIdx] += w_total;

            if (pointGrad.empty()) {
                continue;
            }

            double epeAbs = std::abs(epe);
            double epe_eff = std::max(0.0, epeAbs - effectiveTolerance(ep->tolerance));
            double epePowM1 = (epe_eff > 0.0) ? std::pow(epe_eff, epePower - 1) : 0.0;
            double sign = (epe >= 0) ? 1.0 : -1.0;

            for (auto& [key, dEPE] : pointGrad) {
                double contribution = static_cast<double>(epePower) * epePowM1 * sign * w_total * dEPE;
                clipGradientMaps[task.clipIdx][key] += contribution;
            }
        }
    }
#endif

    // クリップ毎の勾配マップをベクトルに変換し、フラット配列に格納
    std::vector<double> flatGradients(numClips * numVars, 0.0);
    for (size_t c = 0; c < numClips; ++c) {
        if (clipGradientMaps[c].empty()) continue;
        std::vector<double> clipVec = m_mapping->gradientMapToVector(clipGradientMaps[c]);
        std::copy(clipVec.begin(), clipVec.end(), flatGradients.begin() + c * numVars);
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalFlat(numClips * numVars, 0.0);
        MPI_Allreduce(flatGradients.data(), globalFlat.data(),
                      static_cast<int>(numClips * numVars), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        flatGradients = std::move(globalFlat);

        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    std::vector<double> gradient(numVars, 0.0);
    double totalWeight = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        for (size_t j = 0; j < numVars; ++j) {
            gradient[j] += flatGradients[c * numVars + j];
        }
        totalWeight += clipWeights[c];
    }

    // 重みで正規化 + べき乗に応じたEPEスケーリング
    double epeScaleForPower = 1.0 / std::pow(EPE_REF, epePower);
    if (totalWeight > 0.0) {
        for (size_t i = 0; i < gradient.size(); ++i) {
            gradient[i] *= epeScaleForPower / totalWeight;
        }
    }

    // source_fill_cost の勾配を追加
    std::vector<double> fillGrad = calcSourceFillGradient(sourceData);
    for (size_t i = 0; i < gradient.size(); ++i) {
        gradient[i] += m_options.weightFillPenalty * fillGrad[i];
    }

    // 正則化の勾配を追加
    if (m_options.regularizationWeight > 0.0) {
        std::vector<double> regGrad;
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regGrad = calcLaplacianGradient(sourceData);
                break;
            case RegularizationType::L2:
                regGrad = calcL2Gradient(sourceData);
                break;
            case RegularizationType::TV:
                regGrad = calcTVGradient(sourceData);
                break;
            case RegularizationType::Isolated:
                regGrad = calcIsolatedGradient(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
        for (size_t i = 0; i < gradient.size() && i < regGrad.size(); ++i) {
            gradient[i] += regGrad[i];
        }
    }

    // NILS ペナルティの勾配を追加
    if (m_options.weightNilsPenalty > 0.0) {
        auto nilsGrad = calcNilsGradientTotal(sourceData, evpData, processConfig, sliceLevel);
        for (size_t i = 0; i < gradient.size() && i < nilsGrad.size(); ++i) {
            gradient[i] += m_options.weightNilsPenalty * nilsGrad[i];
        }
    }

    // BT / BFS ペナルティの勾配を追加 (calcBtBfsGradient は weightBt/weightBfs 込みで返す)
    if (m_options.weightBt > 0.0 || m_options.weightBfs > 0.0) {
        auto btBfsGrad = calcBtBfsGradient(sourceData, evpData, processConfig, sliceLevel);
        for (size_t i = 0; i < gradient.size() && i < btBfsGrad.size(); ++i) {
            gradient[i] += btBfsGrad[i];
        }
    }

    return gradient;
}

double GradientCalculator::calculateCostEpe(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower,
    double* outEpeCost,
    double* outSourceFillCost,
    double* outNilsCost) const {

    if (!m_mapping || !m_sourceContributions) {
        if (outEpeCost) *outEpeCost = 0.0;
        if (outSourceFillCost) *outSourceFillCost = 0.0;
        if (outNilsCost) *outNilsCost = 0.0;
        return 0.0;
    }

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    // タスクリストを作成（並列化用）
    struct Task {
        size_t clipIdx;
        size_t pwcIdx;
    };
    std::vector<Task> tasks;
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            tasks.push_back({clipIdx, pwcIdx});
        }
    }

    double totalWeightedEpePow = 0.0;
    double totalWeight = 0.0;

    // タスク毎の結果を格納（決定的な加算順序を保証）
    std::vector<double> taskEpePow(tasks.size(), 0.0);
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        // MPIクリップフィルタ
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;

        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];

        std::string filename = makeImageFileName(
            clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) {
            continue;
        }

        const auto& contribSet = it->second;

        // 合成画像を (clip, pwc) あたり 1 回だけ作り、evp ループ内で再利用する
        // （二重合成回避: 旧実装では evp ごとに findContourPositionFull 内で
        //   combine を呼んでいたため、合成回数が evp 数だけ増えていた）
        const auto& gridConfig = m_mapping->gridConfig();
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            // Newton で EPE を取得。収束の可否に関わらず result.epe を採用する
            //（QEPE へのフォールバックは行わない）。
            EpeCalcResult r = findContourPositionFull(
                combinedImg, ep->px, ep->py, ep->degree, sliceLevel);
            double epe = r.epe;

            double w = ep->weight * pwc.weight;
            // tolerance デッドバンド: |EPE|<=tolerance は無罰
            double epe_eff = std::max(0.0, std::abs(epe) - effectiveTolerance(ep->tolerance));
            taskEpePow[taskIdx] += std::pow(epe_eff, epePower) * w;
            taskWeights[taskIdx] += w;
        }
    }

    // タスク結果をクリップ単位に集約（MPI決定的集約用）
    size_t numClips = clips.size();
    std::vector<double> clipCosts(numClips, 0.0);
    std::vector<double> clipWeights(numClips, 0.0);
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        clipCosts[tasks[taskIdx].clipIdx] += taskEpePow[taskIdx];
        clipWeights[tasks[taskIdx].clipIdx] += taskWeights[taskIdx];
    }

#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> globalClipCosts(numClips, 0.0);
        std::vector<double> globalClipWeights(numClips, 0.0);
        MPI_Allreduce(clipCosts.data(), globalClipCosts.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeights.data(), globalClipWeights.data(),
                      static_cast<int>(numClips), MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipCosts = std::move(globalClipCosts);
        clipWeights = std::move(globalClipWeights);
    }
#endif

    // クリップ順に決定的に集約
    for (size_t c = 0; c < numClips; ++c) {
        totalWeightedEpePow += clipCosts[c];
        totalWeight += clipWeights[c];
    }

    // べき乗に応じた正規化: 1 / EPE_REF^n
    // EPE_REF = 0.001μm (1nm) を基準に、EPE=1nmでcost≈1となるようにスケーリング
    double epeScaleForPower = 1.0 / std::pow(EPE_REF, epePower);
    double epeCost = (totalWeight > 0.0) ? totalWeightedEpePow * epeScaleForPower / totalWeight : 0.0;
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double sourceFillCost = calcSourceFillCost(sourceFillRatio);

    // 正則化コストを追加
    double regularizationCost = 0.0;
    if (m_options.regularizationWeight > 0.0) {
        switch (m_options.regularization) {
            case RegularizationType::Laplacian:
                regularizationCost = calcLaplacianCost(sourceData);
                break;
            case RegularizationType::L2:
                regularizationCost = calcL2Cost(sourceData);
                break;
            case RegularizationType::TV:
                regularizationCost = calcTVCost(sourceData);
                break;
            case RegularizationType::Isolated:
                regularizationCost = calcIsolatedCost(sourceData);
                break;
            case RegularizationType::None:
            default:
                break;
        }
    }

    // NILS ペナルティ
    // 最適化ループでは outNilsCost=nullptr かつ weight=0 の場合はスキップしてFFT合成コストを節約。
    // ログ/cost.csv 出力で outNilsCost が要求された場合は weight=0 でも値を返す。
    bool needNils = (outNilsCost != nullptr) || (m_options.weightNilsPenalty > 0.0);
    double nilsCost = needNils
        ? calcNilsCostTotal(sourceData, evpData, processConfig, sliceLevel)
        : 0.0;

    // BT / BFS ペナルティ
    double btCost = 0.0, bfsCost = 0.0;
    if (m_options.weightBt > 0.0 || m_options.weightBfs > 0.0) {
        calcBtBfsCost(sourceData, evpData, processConfig, sliceLevel,
                      &btCost, &bfsCost);
    }

    if (outEpeCost) *outEpeCost = epeCost;
    if (outSourceFillCost) *outSourceFillCost = sourceFillCost;
    if (outNilsCost) *outNilsCost = nilsCost;

    return epeCost + m_options.weightFillPenalty * sourceFillCost + regularizationCost
         + m_options.weightNilsPenalty * nilsCost
         + m_options.weightBt * btCost
         + m_options.weightBfs * bfsCost;
}

// ============================================================================
// 統一勾配計算インターフェース
// ============================================================================

std::vector<double> GradientCalculator::calculateGradient(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    if (m_options.verbose) {
        std::cerr << "  [calculateGradient] Dispatching to method: "
                  << static_cast<int>(m_options.gradientMethod) << std::endl;
    }

    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
            // 選択肢1: QEPE + 解析勾配
            return calculate(sourceData, evpData, processConfig, sliceLevel);

        case GradientMethod::EPE_Analytical:
            // 選択肢2: EPE + 解析勾配
            return calculateEpeAnalytical(sourceData, evpData, processConfig, sliceLevel, epePower);

        case GradientMethod::QEPE_Numerical:
            // 選択肢3: QEPE + 数値差分
            return calculateQepeNumerical(sourceData, evpData, processConfig, sliceLevel);

        case GradientMethod::EPE_Numerical:
            // 選択肢4: EPE + 数値差分
            return calculateEpeNumerical(sourceData, evpData, processConfig, sliceLevel, epePower);

        default:
            // デフォルトは選択肢2
            return calculateEpeAnalytical(sourceData, evpData, processConfig, sliceLevel, epePower);
    }
}

// ============================================================================
// sliceLevel に対する EPE^n コストの解析勾配 ∂cost/∂t
// ============================================================================
// EPE = -(I - t)/G の関係から ∂EPE/∂t = -1/G。
// EPE^n コスト = (1/EPE_REF^n) × Σ w_i × (max(0, |EPE_i|-tol_i))^n / Σw_i
// ∂cost/∂t = (1/EPE_REF^n) × Σ w_i × n × (|EPE|-tol)^(n-1) × sign(EPE) × (-1/G_c) / Σw_i
// G_c は Newton 収束時はコントア位置、非収束時は evp 位置の値を使う
// （cost 計算と同じ EPE 値を生む状態で評価）。
double GradientCalculator::calculateSliceLevelGradient(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    if (!m_mapping || !m_sourceContributions) return 0.0;

    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();

    struct Task { size_t clipIdx; size_t pwcIdx; };
    std::vector<Task> tasks;
    for (size_t c = 0; c < clips.size(); ++c)
        for (size_t p = 0; p < pwcs.size(); ++p)
            tasks.push_back({c, p});

    std::vector<double> taskGrad(tasks.size(), 0.0);
    std::vector<double> taskWeights(tasks.size(), 0.0);

#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t taskIdx = 0; taskIdx < tasks.size(); ++taskIdx) {
        const auto& task = tasks[taskIdx];
        if (m_mpiSize > 1 && task.clipIdx % static_cast<size_t>(m_mpiSize) != static_cast<size_t>(m_mpiRank))
            continue;
        const auto& clip = clips[task.clipIdx];
        const auto& pwc = pwcs[task.pwcIdx];
        std::string filename = makeImageFileName(clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);
        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) continue;

        const auto& contribSet = it->second;
        // 合成画像を 1 回だけ作って、Newton 法とコントア位置の G_c 評価で再利用する
        // （二重合成回避: 旧実装では evp ごとに findContourPositionFull 内で
        //   もう 1 回 combine を呼んでいた）
        const auto& gridConfig = m_mapping->gridConfig();
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);
        if (std::abs(pwc.delta_dose) > 1e-9) {
            combinedImg.scale(1.0 + pwc.delta_dose / 100.0);
        }

        for (const auto* ep : clip.evalPoints) {
            EpeCalcResult r = findContourPositionFull(
                combinedImg, ep->px, ep->py, ep->degree, sliceLevel);
            double epe = r.epe;

            // G の評価:
            //  - Newton 収束時: コントア位置 (cx,cy) で再評価 (G_c)
            //    陰関数定理 I(C(t),s)=t の両辺を t で微分すると G_c × ∂EPE/∂t = 1
            //    → ∂EPE/∂t = 1/G_c
            //  - Newton 非収束時: evp 位置の G を使う（QEPE のフォールバック）
            //    QEPE = -(I-t)/G の t 偏微分も ∂QEPE/∂t = 1/G で同形
            double G;
            if (r.converged) {
                double rad = ep->degree * M_PI / 180.0;
                double nx = std::cos(rad);
                double ny = std::sin(rad);
                double cx = ep->px + epe * nx;
                double cy = ep->py + epe * ny;
                auto pv = combinedImg.evalAt(cx, cy);
                G = pv.gradX * nx + pv.gradY * ny;
            } else {
                G = r.gradient;  // evp 位置の G
            }
            if (std::abs(G) < MIN_GRADIENT) continue;

            double w = ep->weight * pwc.weight;
            taskWeights[taskIdx] += w;

            double absEpe = std::abs(epe);
            double epe_eff = std::max(0.0, absEpe - effectiveTolerance(ep->tolerance));
            if (epe_eff <= 0.0) continue;
            double epePowM1 = std::pow(epe_eff, epePower - 1);
            double sign = (epe >= 0) ? 1.0 : -1.0;
            // ∂EPE/∂t = +1/G  （符号: EPE=-(I-t)/G を t で偏微分、または陰関数定理）
            double dEpe_dt = 1.0 / G;
            taskGrad[taskIdx] += static_cast<double>(epePower) * epePowM1 * sign * w * dEpe_dt;
        }
    }

    // クリップ単位で集約（決定的）
    size_t numClips = clips.size();
    std::vector<double> clipGrad(numClips, 0.0), clipWeights(numClips, 0.0);
    for (size_t t = 0; t < tasks.size(); ++t) {
        clipGrad[tasks[t].clipIdx] += taskGrad[t];
        clipWeights[tasks[t].clipIdx] += taskWeights[t];
    }
#ifdef HAVE_MPI_H
    if (m_mpiSize > 1) {
        std::vector<double> gG(numClips, 0.0), gW(numClips, 0.0);
        MPI_Allreduce(clipGrad.data(), gG.data(), numClips, MPI_DOUBLE, MPI_SUM, m_mpiComm);
        MPI_Allreduce(clipWeights.data(), gW.data(), numClips, MPI_DOUBLE, MPI_SUM, m_mpiComm);
        clipGrad = std::move(gG);
        clipWeights = std::move(gW);
    }
#endif
    double totalGrad = 0.0, totalWeight = 0.0;
    for (size_t c = 0; c < numClips; ++c) {
        totalGrad += clipGrad[c];
        totalWeight += clipWeights[c];
    }
    double epeScale = 1.0 / std::pow(EPE_REF, epePower);
    return (totalWeight > 0.0) ? totalGrad * epeScale / totalWeight : 0.0;
}

double GradientCalculator::calculateCostByMethod(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower,
    double* outEpeCost,
    double* outSourceFillCost,
    double* outNilsCost) const {

    // QEPE系（選択肢1,3）はQEPEコスト、EPE系（選択肢2,4）はEPEコストを使用
    switch (m_options.gradientMethod) {
        case GradientMethod::QEPE_Analytical:
        case GradientMethod::QEPE_Numerical:
            return calculateCost(sourceData, evpData, processConfig, sliceLevel,
                               outEpeCost, outSourceFillCost, outNilsCost);

        case GradientMethod::EPE_Analytical:
        case GradientMethod::EPE_Numerical:
            return calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower,
                                      outEpeCost, outSourceFillCost, outNilsCost);

        default:
            return calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower,
                                      outEpeCost, outSourceFillCost, outNilsCost);
    }
}

std::vector<double> GradientCalculator::calculateQepeNumerical(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    // 選択肢3: QEPE + 数値差分（効率版を使用）
    return calculateQepeNumericalEfficient(sourceData, evpData, processConfig, sliceLevel);
}

std::vector<double> GradientCalculator::calculateEpeNumerical(
    SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    // 選択肢4: EPE + 数値差分
    if (!m_mapping) {
        return {};
    }

    std::vector<double> gradient(m_mapping->numVariables());
    std::vector<double> variables = m_mapping->sourceToVariables(sourceData);
    double epsilon = m_options.numericalEpsilon;

    for (size_t i = 0; i < variables.size(); ++i) {
        double originalValue = variables[i];

        // +epsilon
        variables[i] = originalValue + epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costPlus = calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower);

        // -epsilon
        variables[i] = originalValue - epsilon;
        m_mapping->variablesToSource(variables, sourceData);
        double costMinus = calculateCostEpe(sourceData, evpData, processConfig, sliceLevel, epePower);

        gradient[i] = (costPlus - costMinus) / (2.0 * epsilon);

        // 元に戻す
        variables[i] = originalValue;
    }

    // 光源データを元に戻す
    m_mapping->variablesToSource(variables, sourceData);

    return gradient;
}

// ============================================================================
// 効率的な数値差分（評価点×光源点キャッシュ + 並列化）
// ============================================================================

std::vector<double> GradientCalculator::calculateQepeNumericalEfficient(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();
    double epsilon = m_options.numericalEpsilon;

    std::vector<double> gradient(numVars, 0.0);

    // 評価点情報を収集
    struct EvalPointInfo {
        const EvalPoint* ep;
        double pwcWeight;
        double deltaDose;
        std::string filename;
        double nx, ny;  // 法線方向（事前計算）
    };
    std::vector<EvalPointInfo> evalPoints;

    // 注: 数値勾配では全クリップのコストの比率 A/B を計算するため、
    // クリップ分散は不適切（Σ d(A_i/B_i)/dx ≠ d(A_total/B_total)/dx）。
    // 各ランクが全クリップを処理し、独立に正確な勾配を計算する。
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        const auto& clip = clips[clipIdx];
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            for (const auto* ep : clip.evalPoints) {
                EvalPointInfo info;
                info.ep = ep;
                info.pwcWeight = pwc.weight;
                info.deltaDose = pwc.delta_dose;
                info.filename = filename;
                double rad = ep->degree * M_PI / 180.0;
                info.nx = std::cos(rad);
                info.ny = std::sin(rad);
                evalPoints.push_back(info);
            }
        }
    }

    const size_t numEvalPoints = evalPoints.size();

    // 光源点座標からインデックスへのマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        coordToVarIdx[makeCoordKey(varInfos[i].gx, varInfos[i].gy)] = i;
    }

    // 条件ごとのキャッシュ構造
    struct ConditionCache {
        double totalWeight = 0.0;
        std::vector<size_t> contribVarIndices;  // 各寄与の変数インデックス（-1なら非最適化変数）
        std::vector<double> contribNorms;       // 各寄与のnorm
        std::vector<size_t> evalPointIndices;   // この条件の評価点インデックス
    };
    std::map<std::string, ConditionCache> conditionCacheMap;

    // 条件キャッシュを構築
    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            if (conditionCacheMap.find(filename) != conditionCacheMap.end()) continue;

            auto it = m_sourceContributions->find(filename);
            if (it == m_sourceContributions->end()) continue;

            const auto& contribSet = it->second;
            ConditionCache cache;

            for (const auto& contrib : contribSet.contributions()) {
                double intensity;
                if (gridConfig.isD2Symmetry()) {
                    intensity = sourceData.getIntensityFirstQuadrant(contrib.gx, contrib.gy);
                } else {
                    intensity = sourceData.getIntensity(contrib.gx, contrib.gy);
                }
                cache.totalWeight += contrib.norm * intensity;

                auto coordKey = makeCoordKey(contrib.gx, contrib.gy);
                auto varIt = coordToVarIdx.find(coordKey);
                if (varIt != coordToVarIdx.end()) {
                    cache.contribVarIndices.push_back(varIt->second);
                } else {
                    cache.contribVarIndices.push_back(SIZE_MAX);  // 非最適化変数
                }
                cache.contribNorms.push_back(contrib.norm);
            }

            conditionCacheMap[filename] = std::move(cache);
        }
    }

    // 各評価点の条件キャッシュインデックスを設定
    for (size_t epIdx = 0; epIdx < numEvalPoints; ++epIdx) {
        auto& condCache = conditionCacheMap[evalPoints[epIdx].filename];
        condCache.evalPointIndices.push_back(epIdx);
    }

    // ========== 評価点×光源点のキャッシュを事前計算 ==========
    // evalPointCache[epIdx] = {combinedPV, contribPVs[]}
    struct EvalPointCache {
        PointValue combinedPV;                      // 合成画像の強度・勾配
        std::vector<PointValue> contribPVs;         // 各光源点寄与の強度・勾配
        double W;                                   // 重み合計
        const ConditionCache* condCache;            // 条件キャッシュへのポインタ
    };
    std::vector<EvalPointCache> evalPointCache(numEvalPoints);

    // 各条件について評価点キャッシュを計算
    for (auto& [filename, condCache] : conditionCacheMap) {
        auto it = m_sourceContributions->find(filename);
        if (it == m_sourceContributions->end()) continue;

        const auto& contribSet = it->second;
        const auto& contribs = contribSet.contributions();

        // 合成画像を計算
        FrequencyImage combinedImg = contribSet.combine(sourceData, gridConfig);

        // この条件の評価点について
        for (size_t epIdx : condCache.evalPointIndices) {
            const auto& epInfo = evalPoints[epIdx];
            auto& epCache = evalPointCache[epIdx];

            epCache.condCache = &condCache;
            epCache.W = condCache.totalWeight;

            // 合成画像のevalAt
            epCache.combinedPV = combinedImg.evalAt(epInfo.ep->px, epInfo.ep->py);

            // delta_dose補正
            if (std::abs(epInfo.deltaDose) > 1e-9) {
                double scale = 1.0 + epInfo.deltaDose / 100.0;
                epCache.combinedPV.intensity *= scale;
                epCache.combinedPV.gradX *= scale;
                epCache.combinedPV.gradY *= scale;
            }

            // 各光源点の寄与のevalAt
            epCache.contribPVs.resize(contribs.size());
            for (size_t cIdx = 0; cIdx < contribs.size(); ++cIdx) {
                epCache.contribPVs[cIdx] = contribs[cIdx].freqImage.evalAt(epInfo.ep->px, epInfo.ep->py);

                // delta_dose補正
                if (std::abs(epInfo.deltaDose) > 1e-9) {
                    double scale = 1.0 + epInfo.deltaDose / 100.0;
                    epCache.contribPVs[cIdx].intensity *= scale;
                    epCache.contribPVs[cIdx].gradX *= scale;
                    epCache.contribPVs[cIdx].gradY *= scale;
                }
            }
        }
    }

    // source_fill関連の事前計算
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double naFactor = (m_NA / 1.35) * (m_NA / 1.35);
    double maxIntensity = sourceData.showMaxIntensity();
    if (maxIntensity <= 0.0) maxIntensity = 1.0;
    size_t numPoints = sourceData.showPoints().size();

    // コスト計算関数（キャッシュを使用、変数インデックスと差分値を受け取る）
    auto calcCostWithDelta = [&](size_t varIdx, double delta) -> double {
        double totalWeightedQEPESq = 0.0;
        double totalWeight = 0.0;

        for (size_t epIdx = 0; epIdx < numEvalPoints; ++epIdx) {
            const auto& epCache = evalPointCache[epIdx];
            const auto& epInfo = evalPoints[epIdx];
            const auto* condCache = epCache.condCache;

            if (!condCache || epCache.W < MIN_GRADIENT) continue;

            double W = epCache.W;
            double deltaW = 0.0;
            double deltaI = 0.0;
            double deltaGx = 0.0;
            double deltaGy = 0.0;

            // この変数がこの条件に含まれているか確認し、差分を計算
            for (size_t cIdx = 0; cIdx < condCache->contribVarIndices.size(); ++cIdx) {
                if (condCache->contribVarIndices[cIdx] == varIdx) {
                    double norm = condCache->contribNorms[cIdx];
                    const auto& pv_j = epCache.contribPVs[cIdx];

                    deltaW += norm * delta;
                    deltaI += norm * delta * pv_j.intensity;
                    deltaGx += norm * delta * pv_j.gradX;
                    deltaGy += norm * delta * pv_j.gradY;
                    break;
                }
            }

            double W_new = W + deltaW;
            if (W_new < MIN_GRADIENT) continue;

            // 新しい強度と勾配
            double I_new = (W * epCache.combinedPV.intensity + deltaI) / W_new;
            double Gx_new = (W * epCache.combinedPV.gradX + deltaGx) / W_new;
            double Gy_new = (W * epCache.combinedPV.gradY + deltaGy) / W_new;
            double G_new = Gx_new * epInfo.nx + Gy_new * epInfo.ny;

            // QEPE計算
            double QEPE = 0.0;
            if (std::abs(G_new) > MIN_GRADIENT) {
                QEPE = -(I_new - sliceLevel) / G_new;
            }

            double w = epInfo.ep->weight * epInfo.pwcWeight;
            // tolerance デッドバンド
            double QEPE_eff = std::max(0.0, std::abs(QEPE) - effectiveTolerance(epInfo.ep->tolerance));
            totalWeightedQEPESq += QEPE_eff * QEPE_eff * w;
            totalWeight += w;
        }

        double epeCost = (totalWeight > 0.0) ? totalWeightedQEPESq * EPE_SCALE / totalWeight : 0.0;

        // source_fill_cost（差分補正）
        const auto& info = varInfos[varIdx];
        int multiplier = 1;
        if (gridConfig.isD2Symmetry()) {
            if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) multiplier = 4;
            else if (std::abs(info.gx) > 1e-6 || std::abs(info.gy) > 1e-6) multiplier = 2;
        }
        double deltaRatio = delta * multiplier * naFactor / (maxIntensity * numPoints);
        double newRatio = sourceFillRatio + deltaRatio;
        double sourceFillCost = calcSourceFillCost(newRatio);
        return epeCost + m_options.weightFillPenalty * sourceFillCost;
    };

    // ========== 並列化: 各変数について勾配を計算 ==========
#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t varIdx = 0; varIdx < numVars; ++varIdx) {
        double costPlus = calcCostWithDelta(varIdx, epsilon);
        double costMinus = calcCostWithDelta(varIdx, -epsilon);
        gradient[varIdx] = (costPlus - costMinus) / (2.0 * epsilon);
    }

    return gradient;
}

std::vector<double> GradientCalculator::calculateEpeNumericalEfficient(
    const SourceData& sourceData,
    const EvpData& evpData,
    const ProcessConfig& processConfig,
    double sliceLevel,
    int epePower) const {

    if (!m_mapping || !m_sourceContributions) {
        return std::vector<double>(m_mapping ? m_mapping->numVariables() : 0, 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& clips = evpData.showClips();
    const auto& pwcs = processConfig.showPwcConditions();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();
    double epsilon = m_options.numericalEpsilon;

    std::vector<double> gradient(numVars, 0.0);

    // 評価点情報を収集
    struct EvalPointInfo {
        const EvalPoint* ep;
        double pwcWeight;
        double deltaDose;
        std::string filename;
        int clipID;
        int pwcIdx;
        double maskBias;
    };
    std::vector<EvalPointInfo> evalPoints;

    // 注: 数値勾配では全クリップのコストの比率 A/B を計算するため、
    // クリップ分散は不適切（Σ d(A_i/B_i)/dx ≠ d(A_total/B_total)/dx）。
    // 各ランクが全クリップを処理し、独立に正確な勾配を計算する。
    for (size_t clipIdx = 0; clipIdx < clips.size(); ++clipIdx) {
        const auto& clip = clips[clipIdx];
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            for (const auto* ep : clip.evalPoints) {
                EvalPointInfo info;
                info.ep = ep;
                info.pwcWeight = pwc.weight;
                info.deltaDose = pwc.delta_dose;
                info.filename = filename;
                info.clipID = clip.clipID;
                info.pwcIdx = static_cast<int>(pwcIdx);
                info.maskBias = pwc.mask_bias;
                evalPoints.push_back(info);
            }
        }
    }

    const size_t numEvalPoints = evalPoints.size();

    // 各条件のキャッシュ
    struct ConditionCache {
        const SourceContributionSet* contribSet = nullptr;
    };
    std::map<std::string, ConditionCache> conditionCache;

    for (const auto& clip : clips) {
        for (size_t pwcIdx = 0; pwcIdx < pwcs.size(); ++pwcIdx) {
            const auto& pwc = pwcs[pwcIdx];
            std::string filename = makeImageFileName(
                clip.clipID, pwc.defocus, pwc.mask_bias, 0.0);

            if (conditionCache.find(filename) != conditionCache.end()) continue;

            auto it = m_sourceContributions->find(filename);
            if (it == m_sourceContributions->end()) continue;

            ConditionCache cache;
            cache.contribSet = &(it->second);
            conditionCache[filename] = cache;
        }
    }

    // source_fill関連の事前計算
    double sourceFillRatio = calcSourceFillRatio(sourceData);
    double naFactor = (m_NA / 1.35) * (m_NA / 1.35);
    double maxIntensity = sourceData.showMaxIntensity();
    if (maxIntensity <= 0.0) maxIntensity = 1.0;
    size_t numPoints = sourceData.showPoints().size();
    double epeScaleForPower = 1.0 / std::pow(EPE_REF, epePower);

    // EPEコスト計算関数（変数インデックスと差分値を受け取る）
    // スレッドセーフ: sourceData をコピーして使用
    auto calcEpeCostWithDelta = [&](size_t varIdx, double delta) -> double {
        const auto& info = varInfos[varIdx];

        // 一時的なSourceDataを作成（差分を適用）
        SourceData tempSourceData = sourceData;
        double currentIntensity;
        if (gridConfig.isD2Symmetry()) {
            currentIntensity = tempSourceData.getIntensityFirstQuadrant(info.gx, info.gy);
        } else {
            currentIntensity = tempSourceData.getIntensity(info.gx, info.gy);
        }
        double newIntensity = std::max(0.0, currentIntensity + delta);

        if (gridConfig.isD2Symmetry()) {
            tempSourceData.setIntensity(info.gx, info.gy, newIntensity);
            if (std::abs(info.gx) > 1e-6) {
                tempSourceData.setIntensity(-info.gx, info.gy, newIntensity);
            }
            if (std::abs(info.gy) > 1e-6) {
                tempSourceData.setIntensity(info.gx, -info.gy, newIntensity);
            }
            if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) {
                tempSourceData.setIntensity(-info.gx, -info.gy, newIntensity);
            }
        } else {
            tempSourceData.setIntensity(info.gx, info.gy, newIntensity);
        }

        double totalWeightedEpePow = 0.0;
        double totalWeight = 0.0;

        for (size_t epIdx = 0; epIdx < numEvalPoints; ++epIdx) {
            const auto& epInfo = evalPoints[epIdx];

            auto cacheIt = conditionCache.find(epInfo.filename);
            if (cacheIt == conditionCache.end()) continue;
            const auto* contribSet = cacheIt->second.contribSet;
            if (!contribSet) continue;

            // EPEを計算（delta_dose適用）
            bool converged = false;
            double epe = findContourPosition(
                *contribSet, tempSourceData,
                epInfo.ep->px, epInfo.ep->py, epInfo.ep->degree, sliceLevel, epInfo.deltaDose, &converged,
                epInfo.clipID, epInfo.pwcIdx, epInfo.maskBias);

            double w = epInfo.ep->weight * epInfo.pwcWeight;
            // tolerance デッドバンド
            double epe_eff = std::max(0.0, std::abs(epe) - effectiveTolerance(epInfo.ep->tolerance));
            totalWeightedEpePow += std::pow(epe_eff, epePower) * w;
            totalWeight += w;
        }

        double epeCost = (totalWeight > 0.0) ? totalWeightedEpePow * epeScaleForPower / totalWeight : 0.0;

        // source_fill_cost（差分補正）
        int multiplier = 1;
        if (gridConfig.isD2Symmetry()) {
            if (std::abs(info.gx) > 1e-6 && std::abs(info.gy) > 1e-6) multiplier = 4;
            else if (std::abs(info.gx) > 1e-6 || std::abs(info.gy) > 1e-6) multiplier = 2;
        }
        double deltaRatio = delta * multiplier * naFactor / (maxIntensity * numPoints);
        double newRatio = sourceFillRatio + deltaRatio;
        double sourceFillCost = calcSourceFillCost(newRatio);
        return epeCost + m_options.weightFillPenalty * sourceFillCost;
    };

    // ========== 並列化: 各変数について勾配を計算 ==========
#ifdef _OPENMP
    #pragma omp parallel for schedule(dynamic)
#endif
    for (size_t varIdx = 0; varIdx < numVars; ++varIdx) {
        double costPlus = calcEpeCostWithDelta(varIdx, epsilon);
        double costMinus = calcEpeCostWithDelta(varIdx, -epsilon);
        gradient[varIdx] = (costPlus - costMinus) / (2.0 * epsilon);
    }

    return gradient;
}

// ============================================================================
// ラプラシアン正則化
// ============================================================================

std::vector<std::pair<double, double>> GradientCalculator::getNeighbors(
    double gx, double gy) const {

    std::vector<std::pair<double, double>> neighbors;
    const auto& gridConfig = m_mapping->gridConfig();

    // グリッド間隔を計算
    // 座標範囲は -1.0 から 1.0、グリッド数は grid
    double delta = 2.0 / (gridConfig.grid > 1 ? (gridConfig.grid - 1) : 1);

    // 4近傍（上下左右）
    const double offsets[4][2] = {
        {delta, 0.0},   // 右
        {-delta, 0.0},  // 左
        {0.0, delta},   // 上
        {0.0, -delta}   // 下
    };

    for (const auto& offset : offsets) {
        double nx = gx + offset[0];
        double ny = gy + offset[1];

        // グリッド範囲内かチェック（-1.0 ~ 1.0）
        if (nx < -1.0 - 1e-6 || nx > 1.0 + 1e-6 ||
            ny < -1.0 - 1e-6 || ny > 1.0 + 1e-6) {
            continue;
        }

        // sigma範囲内かチェック
        double r = std::sqrt(nx * nx + ny * ny);
        if (r < gridConfig.sigma_min - 1e-6 || r > gridConfig.sigma_max + 1e-6) {
            continue;
        }

        neighbors.push_back({nx, ny});
    }

    return neighbors;
}

double GradientCalculator::calcLaplacianCost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization == RegularizationType::None) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    double totalCost = 0.0;

    // 各最適化変数（第1象限の点）についてラプラシアンコストを計算
    for (const auto& info : varInfos) {
        double gx = info.gx;
        double gy = info.gy;

        // この点の強度
        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(gx, gy);
        } else {
            s_i = sourceData.getIntensity(gx, gy);
        }

        // 隣接点を取得
        auto neighbors = getNeighbors(gx, gy);
        if (neighbors.empty()) {
            continue;
        }

        // 隣接点の強度の平均を計算
        double sumNeighborIntensity = 0.0;
        for (const auto& [nx, ny] : neighbors) {
            if (gridConfig.isD2Symmetry()) {
                sumNeighborIntensity += sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                sumNeighborIntensity += sourceData.getIntensity(nx, ny);
            }
        }
        double avgNeighborIntensity = sumNeighborIntensity / neighbors.size();

        // (s_i - avg(N_i))²
        double diff = s_i - avgNeighborIntensity;
        totalCost += diff * diff * info.multiplier;  // D2対称のmultiplierを考慮
    }

    return lambda * totalCost;
}

std::vector<double> GradientCalculator::calcLaplacianGradient(
    const SourceData& sourceData) const {

    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization == RegularizationType::None) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    std::vector<double> gradient(numVars, 0.0);

    // 変数のインデックスを座標から引けるようにマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        auto key = makeCoordKey(varInfos[i].gx, varInfos[i].gy);
        coordToVarIdx[key] = i;
    }

    // 各変数についてラプラシアン勾配を計算
    // ∂R_Lap/∂s_k = 2λ × [(s_k - avg(N_k)) - Σ_{i: k∈N_i} (s_i - avg(N_i)) / |N_i|]
    for (size_t k = 0; k < numVars; ++k) {
        const auto& infoK = varInfos[k];
        double gx_k = infoK.gx;
        double gy_k = infoK.gy;

        // s_kの強度
        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(gx_k, gy_k);
        } else {
            s_k = sourceData.getIntensity(gx_k, gy_k);
        }

        // 第1項: s_k - avg(N_k)
        auto neighbors_k = getNeighbors(gx_k, gy_k);
        double term1 = 0.0;
        if (!neighbors_k.empty()) {
            double sumNeighborK = 0.0;
            for (const auto& [nx, ny] : neighbors_k) {
                if (gridConfig.isD2Symmetry()) {
                    sumNeighborK += sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    sumNeighborK += sourceData.getIntensity(nx, ny);
                }
            }
            double avgNeighborK = sumNeighborK / neighbors_k.size();
            term1 = s_k - avgNeighborK;
        }

        // 第2項: Σ_{i: k∈N_i} (s_i - avg(N_i)) / |N_i|
        // kがiの隣接点である場合の寄与を集める
        double term2 = 0.0;

        for (size_t i = 0; i < numVars; ++i) {
            const auto& infoI = varInfos[i];
            double gx_i = infoI.gx;
            double gy_i = infoI.gy;

            // iの隣接点を取得
            auto neighbors_i = getNeighbors(gx_i, gy_i);
            if (neighbors_i.empty()) {
                continue;
            }

            // kがiの隣接点かチェック
            bool k_is_neighbor_of_i = false;
            for (const auto& [nx, ny] : neighbors_i) {
                // D2対称の場合、第1象限に折りたたんで比較
                double check_x = nx;
                double check_y = ny;
                if (gridConfig.isD2Symmetry()) {
                    check_x = std::abs(nx);
                    check_y = std::abs(ny);
                }
                if (std::abs(check_x - gx_k) < 1e-6 && std::abs(check_y - gy_k) < 1e-6) {
                    k_is_neighbor_of_i = true;
                    break;
                }
            }

            if (!k_is_neighbor_of_i) {
                continue;
            }

            // s_iの強度
            double s_i;
            if (gridConfig.isD2Symmetry()) {
                s_i = sourceData.getIntensityFirstQuadrant(gx_i, gy_i);
            } else {
                s_i = sourceData.getIntensity(gx_i, gy_i);
            }

            // avg(N_i)を計算
            double sumNeighborI = 0.0;
            for (const auto& [nx, ny] : neighbors_i) {
                if (gridConfig.isD2Symmetry()) {
                    sumNeighborI += sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    sumNeighborI += sourceData.getIntensity(nx, ny);
                }
            }
            double avgNeighborI = sumNeighborI / neighbors_i.size();

            // (s_i - avg(N_i)) / |N_i| の寄与
            // kがN_iに含まれる回数をカウント（D2対称の場合、対称点も考慮）
            int countK = 0;
            for (const auto& [nx, ny] : neighbors_i) {
                double check_x = nx;
                double check_y = ny;
                if (gridConfig.isD2Symmetry()) {
                    check_x = std::abs(nx);
                    check_y = std::abs(ny);
                }
                if (std::abs(check_x - gx_k) < 1e-6 && std::abs(check_y - gy_k) < 1e-6) {
                    ++countK;
                }
            }

            // ∂avg(N_i)/∂s_k = countK / |N_i|
            // ∂(s_i - avg(N_i))²/∂s_k = 2(s_i - avg(N_i)) × (-countK / |N_i|)
            term2 += (s_i - avgNeighborI) * countK / neighbors_i.size() * infoI.multiplier;
        }

        // 勾配 = 2λ × (term1 × multiplier - term2)
        gradient[k] = 2.0 * lambda * (term1 * infoK.multiplier - term2);
    }

    return gradient;
}

// ============================================================================
// L2正則化
// ============================================================================

double GradientCalculator::calcL2Cost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::L2) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    double totalCost = 0.0;

    // L2正則化: 各最適化変数を均等に正則化
    // D2対称性のmultiplierは使用しない（軸上と軸外を同等に扱う）
    for (const auto& info : varInfos) {
        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(info.gx, info.gy);
        } else {
            s_i = sourceData.getIntensity(info.gx, info.gy);
        }

        // s_i²（multiplierなし：各変数を均等に正則化）
        totalCost += s_i * s_i;
    }

    return lambda * totalCost;
}

std::vector<double> GradientCalculator::calcL2Gradient(const SourceData& sourceData) const {
    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::L2) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    std::vector<double> gradient(numVars, 0.0);

    // L2正則化の勾配: 各最適化変数を均等に正則化
    // D2対称性のmultiplierは使用しない
    for (size_t k = 0; k < numVars; ++k) {
        const auto& info = varInfos[k];

        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(info.gx, info.gy);
        } else {
            s_k = sourceData.getIntensity(info.gx, info.gy);
        }

        // ∂(λ × s_k²)/∂s_k = 2λ × s_k（multiplierなし）
        gradient[k] = 2.0 * lambda * s_k;
    }

    return gradient;
}

// ============================================================================
// TV正則化（Total Variation）
// ============================================================================

double GradientCalculator::calcTVCost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::TV) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    // 微分可能な近似のためのε
    constexpr double TV_EPSILON = 1e-8;

    double totalCost = 0.0;

    for (const auto& info : varInfos) {
        double gx = info.gx;
        double gy = info.gy;

        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(gx, gy);
        } else {
            s_i = sourceData.getIntensity(gx, gy);
        }

        auto neighbors = getNeighbors(gx, gy);

        for (const auto& [nx, ny] : neighbors) {
            double s_j;
            if (gridConfig.isD2Symmetry()) {
                s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                s_j = sourceData.getIntensity(nx, ny);
            }

            // smooth approximation: sqrt((s_i - s_j)² + ε)
            double diff = s_i - s_j;
            totalCost += std::sqrt(diff * diff + TV_EPSILON) * info.multiplier;
        }
    }

    // 各エッジを2回カウントしているので2で割る
    return lambda * totalCost / 2.0;
}

std::vector<double> GradientCalculator::calcTVGradient(const SourceData& sourceData) const {
    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::TV) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    // 微分可能な近似のためのε
    constexpr double TV_EPSILON = 1e-8;

    std::vector<double> gradient(numVars, 0.0);

    // 変数のインデックスマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        auto key = makeCoordKey(varInfos[i].gx, varInfos[i].gy);
        coordToVarIdx[key] = i;
    }

    for (size_t k = 0; k < numVars; ++k) {
        const auto& infoK = varInfos[k];
        double gx_k = infoK.gx;
        double gy_k = infoK.gy;

        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(gx_k, gy_k);
        } else {
            s_k = sourceData.getIntensity(gx_k, gy_k);
        }

        auto neighbors_k = getNeighbors(gx_k, gy_k);

        // kの隣接点からの勾配寄与
        // ∂/∂s_k [ sqrt((s_k - s_j)² + ε) ] = (s_k - s_j) / sqrt((s_k - s_j)² + ε)
        for (const auto& [nx, ny] : neighbors_k) {
            double s_j;
            if (gridConfig.isD2Symmetry()) {
                s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                s_j = sourceData.getIntensity(nx, ny);
            }

            double diff = s_k - s_j;
            double denom = std::sqrt(diff * diff + TV_EPSILON);

            // 勾配に加算（各エッジを2回カウントするため/2は後で）
            gradient[k] += lambda * diff / denom * infoK.multiplier;
        }
    }

    return gradient;
}

// ============================================================================
// 孤立点ペナルティ正則化
// ============================================================================

double GradientCalculator::calcIsolatedCost(const SourceData& sourceData) const {
    if (!m_mapping) {
        return 0.0;
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::Isolated) {
        return 0.0;
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();

    double totalCost = 0.0;

    // 孤立点ペナルティ: R_isolated = λ × Σ_i max(0, s_i - max(s_neighbors))²
    // ある点の強度がすべての隣接点より高い場合にペナルティを与える
    for (const auto& info : varInfos) {
        double gx = info.gx;
        double gy = info.gy;

        double s_i;
        if (gridConfig.isD2Symmetry()) {
            s_i = sourceData.getIntensityFirstQuadrant(gx, gy);
        } else {
            s_i = sourceData.getIntensity(gx, gy);
        }

        // 隣接点を取得
        auto neighbors = getNeighbors(gx, gy);
        if (neighbors.empty()) {
            continue;
        }

        // 隣接点の最大強度を計算
        double maxNeighborIntensity = 0.0;
        for (const auto& [nx, ny] : neighbors) {
            double s_j;
            if (gridConfig.isD2Symmetry()) {
                s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
            } else {
                s_j = sourceData.getIntensity(nx, ny);
            }
            maxNeighborIntensity = std::max(maxNeighborIntensity, s_j);
        }

        // max(0, s_i - max(s_neighbors))²
        double excess = s_i - maxNeighborIntensity;
        if (excess > 0.0) {
            totalCost += excess * excess * info.multiplier;
        }
    }

    return lambda * totalCost;
}

std::vector<double> GradientCalculator::calcIsolatedGradient(
    const SourceData& sourceData) const {

    if (!m_mapping) {
        return {};
    }

    double lambda = m_options.regularizationWeight;
    if (lambda <= 0.0 || m_options.regularization != RegularizationType::Isolated) {
        return std::vector<double>(m_mapping->numVariables(), 0.0);
    }

    const auto& gridConfig = m_mapping->gridConfig();
    const auto& varInfos = m_mapping->variableInfos();
    const size_t numVars = m_mapping->numVariables();

    std::vector<double> gradient(numVars, 0.0);

    // 変数のインデックスマップを作成
    std::map<std::pair<double, double>, size_t> coordToVarIdx;
    for (size_t i = 0; i < varInfos.size(); ++i) {
        auto key = makeCoordKey(varInfos[i].gx, varInfos[i].gy);
        coordToVarIdx[key] = i;
    }

    // 孤立点ペナルティの勾配
    // R_isolated = λ × Σ_i max(0, s_i - max(s_neighbors))²
    //
    // ∂R_isolated/∂s_k:
    // - もしkがある点iの場合: excess > 0 なら 2λ × excess
    // - もしkがある点iの最大隣接点の場合: excess > 0 なら -2λ × excess
    //
    // ただし、max(s_neighbors)に対する微分はsubgradientとして扱う
    // （最大値を取る隣接点のみに勾配が伝播）

    for (size_t k = 0; k < numVars; ++k) {
        const auto& infoK = varInfos[k];
        double gx_k = infoK.gx;
        double gy_k = infoK.gy;

        double s_k;
        if (gridConfig.isD2Symmetry()) {
            s_k = sourceData.getIntensityFirstQuadrant(gx_k, gy_k);
        } else {
            s_k = sourceData.getIntensity(gx_k, gy_k);
        }

        // 第1項: k自身が孤立点である場合
        auto neighbors_k = getNeighbors(gx_k, gy_k);
        if (!neighbors_k.empty()) {
            // 隣接点の最大強度を計算
            double maxNeighborIntensity = 0.0;
            for (const auto& [nx, ny] : neighbors_k) {
                double s_j;
                if (gridConfig.isD2Symmetry()) {
                    s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    s_j = sourceData.getIntensity(nx, ny);
                }
                maxNeighborIntensity = std::max(maxNeighborIntensity, s_j);
            }

            double excess = s_k - maxNeighborIntensity;
            if (excess > 0.0) {
                // ∂(excess²)/∂s_k = 2 × excess
                gradient[k] += 2.0 * lambda * excess * infoK.multiplier;
            }
        }

        // 第2項: kが他の点iの最大隣接点である場合
        // iの各隣接点をチェックし、kが最大の隣接点ならiからの勾配寄与を受ける
        for (size_t i = 0; i < numVars; ++i) {
            if (i == k) continue;

            const auto& infoI = varInfos[i];
            double gx_i = infoI.gx;
            double gy_i = infoI.gy;

            double s_i;
            if (gridConfig.isD2Symmetry()) {
                s_i = sourceData.getIntensityFirstQuadrant(gx_i, gy_i);
            } else {
                s_i = sourceData.getIntensity(gx_i, gy_i);
            }

            auto neighbors_i = getNeighbors(gx_i, gy_i);
            if (neighbors_i.empty()) continue;

            // kがiの隣接点かチェックし、最大かどうかも確認
            bool k_is_neighbor = false;
            bool k_is_max_neighbor = false;
            double maxNeighborI = 0.0;

            for (const auto& [nx, ny] : neighbors_i) {
                double s_j;
                if (gridConfig.isD2Symmetry()) {
                    s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
                } else {
                    s_j = sourceData.getIntensity(nx, ny);
                }
                maxNeighborI = std::max(maxNeighborI, s_j);

                // kがこの隣接点かチェック
                double check_x = nx;
                double check_y = ny;
                if (gridConfig.isD2Symmetry()) {
                    check_x = std::abs(nx);
                    check_y = std::abs(ny);
                }
                if (std::abs(check_x - gx_k) < 1e-6 && std::abs(check_y - gy_k) < 1e-6) {
                    k_is_neighbor = true;
                }
            }

            if (!k_is_neighbor) continue;

            // kがiの隣接点の中で最大かチェック
            if (std::abs(s_k - maxNeighborI) < 1e-9) {
                k_is_max_neighbor = true;
            }

            if (!k_is_max_neighbor) continue;

            // iが孤立点（excess > 0）の場合のみ勾配に寄与
            double excess_i = s_i - maxNeighborI;
            if (excess_i > 0.0) {
                // ∂(excess_i²)/∂s_k = 2 × excess_i × ∂excess_i/∂s_k
                //                   = 2 × excess_i × (-1)  (kが最大隣接点の場合)
                // ただし、同値の隣接点が複数ある場合は分割する必要がある
                // 簡易的に、最大値を取る隣接点にのみ勾配を伝播
                int numMaxNeighbors = 0;
                for (const auto& [nx, ny] : neighbors_i) {
                    double s_j;
                    if (gridConfig.isD2Symmetry()) {
                        s_j = sourceData.getIntensityFirstQuadrant(nx, ny);
                    } else {
                        s_j = sourceData.getIntensity(nx, ny);
                    }
                    if (std::abs(s_j - maxNeighborI) < 1e-9) {
                        ++numMaxNeighbors;
                    }
                }

                // 勾配を最大隣接点の数で分割
                gradient[k] -= 2.0 * lambda * excess_i * infoI.multiplier / numMaxNeighbors;
            }
        }
    }

    return gradient;
}

} // namespace so
