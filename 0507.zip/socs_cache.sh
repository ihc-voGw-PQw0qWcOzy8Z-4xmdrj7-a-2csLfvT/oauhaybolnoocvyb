#!/bin/bash
#
# socs_cache.sh - SMO ループ等で SOCS cache を「最初に展開、最後に削除」する
#                ためのヘルパ関数群
#
# 使い方 (例: run_smo.sh):
#
#   source <path>/socs_cache.sh
#   socs_cache_init  "$WORK_DIR/.socs_cache"
#   # ... 各 cycle で run_srcoptim.sh --cache_dir "$WORK_DIR/.socs_cache" -- ...
#   # SMO 全体終了時、trap で socs_cache_finalize が走る
#
# 仕組み:
#   - socs_cache_init は cache_dir に .parent_lock を作る
#   - run_srcoptim.sh は cleanup で .parent_lock があれば cache を残す
#   - socs_cache_finalize で .parent_lock を消し、cache 内容を全削除
#

# 親 lock を作成し、SMO 終了時のクリーンアップを trap に登録する。
# 引数: $1 = cache_dir (絶対パス推奨)
socs_cache_init() {
    local cache_dir="$1"
    if [ -z "$cache_dir" ]; then
        echo "[socs_cache] ERROR: socs_cache_init requires cache_dir" >&2
        return 1
    fi
    mkdir -p "$cache_dir"
    local cache_dir_abs
    cache_dir_abs="$(cd "$cache_dir" && pwd)"
    echo "$$" > "$cache_dir_abs/.parent_lock"
    export SOCS_CACHE_DIR_ABS="$cache_dir_abs"

    # 既存 trap を温存しつつ追加する手段は環境依存なので、
    # ここでは単純に trap を上書きする (利用者は別 trap を別途登録すること)
    trap "socs_cache_finalize" EXIT INT TERM
    echo "[socs_cache] initialized: $cache_dir_abs (parent pid=$$)" >&2
}

# 親 lock を削除し、cache 内容を一掃する。
# 通常は trap で自動呼び出し。明示的に呼ぶことも可。
socs_cache_finalize() {
    local cache_dir_abs="${SOCS_CACHE_DIR_ABS:-}"
    if [ -z "$cache_dir_abs" ] || [ ! -d "$cache_dir_abs" ]; then
        return 0
    fi
    rm -f "$cache_dir_abs/.parent_lock" 2>/dev/null || true

    # 他に生きてる .pid_* があるか?
    local remaining=0
    local f
    for f in "$cache_dir_abs"/.pid_*; do
        [ -e "$f" ] || continue
        # PID 生存確認 (LSF 環境では別ノードの可能性があるため、ここでは控えめに skip)
        local pid="${f##*.pid_}"
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            remaining=$((remaining + 1))
        fi
    done

    if [ "$remaining" -eq 0 ]; then
        echo "[socs_cache] finalize: removing cache contents at $cache_dir_abs" >&2
        find "$cache_dir_abs" -mindepth 1 -maxdepth 1 \
             ! -name '.pid_*' \
             -exec rm -rf {} + 2>/dev/null || true
    else
        echo "[socs_cache] finalize: $remaining live srcOptim processes detected, keeping cache" >&2
    fi
}
