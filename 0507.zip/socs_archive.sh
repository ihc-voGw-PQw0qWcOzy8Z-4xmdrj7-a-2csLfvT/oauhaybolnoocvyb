#!/bin/bash
#
# socs_archive.sh
#
# socs_set ディレクトリの圧縮・展開・転置展開を統合したツール。
# 圧縮 (pack) と展開 (unpack) を対称に提供する。
#
# Subcommands:
#   pack    <socs_set_dir> [out.tar.xz] [--keep] [--preset N]
#       socs_set/ を tar.xz に圧縮 (Python tarfile + lzma、外部依存なし)。
#       --keep      圧縮後も元ディレクトリを残す (デフォルトは削除)
#       --preset N  xz preset レベル 0-9 (デフォルト 6)
#
#   unpack  <src> <dest_dir>
#       src が .tar.xz   : tar 展開
#       src がディレクトリ : dest_dir/<basename(src)>/ に内容を symlink
#
#   expand  <socs_dir>
#       .socs_skip_y_gt_x マーカーがあれば x<y SOCS を転置で生成。
#       M2D (.socs ファイル) / M3D (.socs ディレクトリ) を自動判定。
#
#   prepare <src> <dest_dir>
#       unpack + expand を順に実行。展開後ディレクトリの絶対パスを
#       標準出力に 1 行で返す。
#
# Env:
#   TRANSPOSE_SOCS_BIN  transpose_socs_file のパス (M2D 用)
#   TRANSPOSE_M3D_BIN   transpose_msocs_dir のパス (M3D 用)
#
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

DEFAULT_TRANSPOSE="$PROJECT_ROOT/build/src/bin/transpose_socs_file/transpose_socs_file"
DEFAULT_TRANSPOSE_M3D="$PROJECT_ROOT/build/src/bin/transpose_msocs_dir/transpose_msocs_dir"
TRANSPOSE_BIN="${TRANSPOSE_SOCS_BIN:-$DEFAULT_TRANSPOSE}"
TRANSPOSE_M3D_BIN="${TRANSPOSE_M3D_BIN:-$DEFAULT_TRANSPOSE_M3D}"

err() { echo "[socs_archive] ERROR: $*" >&2; }
log() { echo "[socs_archive] $*" >&2; }

usage() {
    sed -n '2,29p' "$0"
    exit 2
}

# -------- pack --------
cmd_pack() {
    local SRC="" OUT="" KEEP=0 PRESET=6
    while [ $# -gt 0 ]; do
        case "$1" in
            --keep)    KEEP=1; shift ;;
            --preset)  PRESET="$2"; shift 2 ;;
            -h|--help) usage ;;
            -*)        err "unknown option: $1"; exit 2 ;;
            *)
                if   [ -z "$SRC" ]; then SRC="$1"
                elif [ -z "$OUT" ]; then OUT="$1"
                else err "too many positional args"; exit 2; fi
                shift
                ;;
        esac
    done

    if [ -z "$SRC" ];      then err "src dir not specified"; exit 2; fi
    if [ ! -d "$SRC" ];    then err "not a directory: $SRC"; exit 1; fi

    local SRC_NORM="${SRC%/}"
    if [ -z "$OUT" ]; then OUT="${SRC_NORM}.tar.xz"; fi
    if [ -e "$OUT" ]; then err "output already exists: $OUT"; exit 1; fi

    local ARCNAME
    ARCNAME=$(basename "$SRC_NORM")
    log "pack: $SRC_NORM -> $OUT (xz preset=$PRESET)"

    python3 - "$SRC_NORM" "$OUT" "$ARCNAME" "$PRESET" <<'PYEOF'
import sys, tarfile, lzma
src, out, arcname, preset = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
with lzma.open(out, 'wb', preset=preset) as xzf:
    with tarfile.open(fileobj=xzf, mode='w') as tar:
        tar.add(src, arcname=arcname)
PYEOF

    local SIZE
    SIZE=$(stat -c%s "$OUT" 2>/dev/null || stat -f%z "$OUT")
    log "archive size: $SIZE bytes"

    if [ "$KEEP" -eq 0 ]; then
        log "removing original: $SRC_NORM"
        rm -rf "$SRC_NORM"
    fi
}

# -------- unpack --------
# src が .tar.xz   : tar 展開 (dest_dir 配下に socs_set/ ができる)
# src がディレクトリ : dest_dir/<basename(src)>/ に内容を symlink で展開
cmd_unpack() {
    local SRC="${1:-}" DEST="${2:-}"
    if [ -z "$SRC" ] || [ -z "$DEST" ]; then
        err "usage: socs_archive.sh unpack <src> <dest_dir>"
        exit 2
    fi
    mkdir -p "$DEST"
    DEST="$(cd "$DEST" && pwd)"

    if [ -f "$SRC" ]; then
        case "$SRC" in
            *.tar.xz) ;;
            *) err "unknown archive type (expect .tar.xz): $SRC"; exit 2 ;;
        esac
        local SRC_ABS
        SRC_ABS="$(readlink -f "$SRC")"
        log "unpack tar.xz: $SRC_ABS -> $DEST"
        if ! tar -xJf "$SRC_ABS" -C "$DEST"; then
            err "tar extraction failed"
            exit 1
        fi
    elif [ -d "$SRC" ]; then
        local SRC_ABS subdir name entry
        SRC_ABS="$(cd "$SRC" && pwd)"
        subdir="$DEST/$(basename "$SRC_ABS")"
        log "unpack dir (symlink): $SRC_ABS -> $subdir"
        mkdir -p "$subdir"
        for entry in "$SRC_ABS"/*; do
            [ -e "$entry" ] || continue
            name=$(basename "$entry")
            [ -e "$subdir/$name" ] && continue
            ln -s "$entry" "$subdir/$name"
        done
        if [ -f "$SRC_ABS/.socs_skip_y_gt_x" ] && [ ! -e "$subdir/.socs_skip_y_gt_x" ]; then
            ln -s "$SRC_ABS/.socs_skip_y_gt_x" "$subdir/.socs_skip_y_gt_x"
        fi
    else
        err "src not found: $SRC"
        exit 1
    fi
}

# -------- expand --------
# y=x mirror で x<y SOCS を転置生成 (.socs_skip_y_gt_x マーカーが必要)
cmd_expand() {
    local SOCS_DIR="${1:-}"
    if [ -z "$SOCS_DIR" ]; then
        err "usage: socs_archive.sh expand <socs_dir>"
        exit 2
    fi
    if [ ! -d "$SOCS_DIR" ]; then
        err "not a directory: $SOCS_DIR"
        exit 1
    fi
    local marker="$SOCS_DIR/.socs_skip_y_gt_x"
    if [ ! -f "$marker" ]; then
        log "no .socs_skip_y_gt_x marker, skipping (already full set)"
        return 0
    fi
    log "expanding x<y SOCS by transposing (y, x) ..."
    local count_m2d=0 count_m3d=0
    local f base sx sy sd is_gt target
    for f in "$SOCS_DIR"/x*_y*_d*.socs; do
        [ -e "$f" ] || continue
        base=$(basename "$f")
        if [[ "$base" =~ ^x([-0-9.]+)_y([-0-9.]+)_d(.+)\.socs$ ]]; then
            sx="${BASH_REMATCH[1]}"
            sy="${BASH_REMATCH[2]}"
            sd="${BASH_REMATCH[3]}"
        else
            continue
        fi
        is_gt=$(awk -v a="$sx" -v b="$sy" 'BEGIN{print (a+0 > b+0 + 1e-9) ? 1 : 0}')
        if [ "$is_gt" != "1" ]; then continue; fi
        target="$SOCS_DIR/x${sy}_y${sx}_d${sd}.socs"
        if [ -e "$target" ]; then continue; fi

        if [ -d "$f" ]; then
            if [ ! -x "$TRANSPOSE_M3D_BIN" ] && [ ! -f "$TRANSPOSE_M3D_BIN" ]; then
                err "transpose_msocs_dir not found: $TRANSPOSE_M3D_BIN"
                return 1
            fi
            if ! "$TRANSPOSE_M3D_BIN" "$f" "$target" >/dev/null 2>&1; then
                err "transpose_msocs_dir failed: $f -> $target"
                return 1
            fi
            count_m3d=$((count_m3d + 1))
        else
            if [ ! -x "$TRANSPOSE_BIN" ] && [ ! -f "$TRANSPOSE_BIN" ]; then
                err "transpose_socs_file not found: $TRANSPOSE_BIN"
                return 1
            fi
            if ! "$TRANSPOSE_BIN" "$f" "$target" >/dev/null 2>&1; then
                err "transpose_socs_file failed: $f -> $target"
                return 1
            fi
            count_m2d=$((count_m2d + 1))
        fi
    done
    log "expanded M2D=$count_m2d, M3D=$count_m3d x<y SOCS"
}

# -------- prepare --------
# unpack + expand。展開後の socs_set ディレクトリ絶対パスを stdout に出す。
cmd_prepare() {
    local SRC="${1:-}" DEST="${2:-}"
    if [ -z "$SRC" ] || [ -z "$DEST" ]; then
        err "usage: socs_archive.sh prepare <src> <dest_dir>"
        exit 2
    fi
    cmd_unpack "$SRC" "$DEST"
    DEST="$(cd "$DEST" && pwd)"
    local extracted="" entry
    for entry in "$DEST"/*; do
        [ -d "$entry" ] || continue
        extracted="$entry"
        break
    done
    if [ -z "$extracted" ]; then
        err "no extracted directory found in $DEST"
        exit 1
    fi
    cmd_expand "$extracted"
    echo "$extracted"
}

# -------- ディスパッチ --------
SUB="${1:-}"
if [ $# -gt 0 ]; then shift; fi

case "$SUB" in
    pack)         cmd_pack    "$@" ;;
    unpack)       cmd_unpack  "$@" ;;
    expand)       cmd_expand  "$@" ;;
    prepare)      cmd_prepare "$@" ;;
    -h|--help|"") usage ;;
    *)            err "unknown subcommand: $SUB"; usage ;;
esac
