#!/bin/bash
#
# Test script that runs the OPC part of run_smo.sh for a single NA value.
#
# Flow:
#   1. Generate an ini file for the given NA     (upstream)
#   2. Generate the SOCS set                      (upstream)
#   3. Run srcOptim to get optimized_source.illum (upstream)
#   4. Apply illum blur if src_blur is configured (upstream)
#   5. Run run_make_msocs                         (upstream)
#   6. Run run_opc                                (target)
#
# Upstream artifacts are reused if they already exist.
# --force only removes and re-runs the OPC try_<tag> directory.
#
# Usage: ./run_test_opc_one_na.sh [options]
#   --na <val>         NA value to test (default: 1.20)
#   --kernel_num <N>   SOCS kernel count (default: 100)
#   --m3d_so           enable M3D mode for source optimization
#   --m3d_opc          enable M3D mode for MSOCS/OPC
#   --cgrp <file>      coherent-group file (used when --m3d_opc is set)
#   --mask_kikaku <s>  mask specification (default: 4kikaku)
#   --layout <file>    input layout (default: LAYOUT_ORIGINAL)
#   --input_source <f> initial illum for srcOptim (default: INITIAL_SOURCE)
#   --max_iter <N>     srcOptim max iterations
#   --gradient_method <N>  gradient method
#   --optimizer <str>  optimizer
#   -j <N>             OpenMP threads
#   --np <N>           MPI ranks
#   --tag <str>        tag for try_<tag> dir name (default: test)
#   --force            remove existing OPC try dir and regenerate
#

set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd)

# ========== Load libraries ==========
source "$SCRIPT_DIR/smo_lib/setup.sh"
source "$SCRIPT_DIR/smo_lib/helpers.sh"
source "$SCRIPT_DIR/smo_lib/srcoptim.sh"
source "$SCRIPT_DIR/smo_lib/opc.sh"

# ========== Test defaults ==========
TEST_NA=1.20
FORCE=false
LAYOUT_INPUT="$LAYOUT_ORIGINAL"
SOURCE_INPUT="$INITIAL_SOURCE"
OPC_TAG="test"

# Override WORK_DIR so the test does not touch the real smo_work
WORK_DIR="$SCRIPT_DIR/test_opc_one_na_work"

# ========== Parse options ==========
while [[ $# -gt 0 ]]; do
    case $1 in
        --na)              TEST_NA="$2";          shift 2 ;;
        --kernel_num)      KERNEL_NUM="$2";       shift 2 ;;
        --m3d_so)          M3D_SO=1;              shift ;;
        --m3d_opc)         M3D_OPC=1;             shift ;;
        --cgrp)            CGRP="$2";             shift 2 ;;
        --mask_kikaku)     MASK_KIKAKU="$2";      shift 2 ;;
        --layout)          LAYOUT_INPUT="$2";     shift 2 ;;
        --input_source)    SOURCE_INPUT="$2";     shift 2 ;;
        --max_iter)        MAX_ITER="$2";         shift 2 ;;
        --gradient_method) GRADIENT_METHOD="$2";  shift 2 ;;
        --optimizer)       OPTIMIZER="$2";        shift 2 ;;
        -j)                OPENMP_NUM="$2";       shift 2 ;;
        --np)              MPI_NP="$2";           shift 2 ;;
        --tag)             OPC_TAG="$2";          shift 2 ;;
        --force)           FORCE=true;            shift ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# ========== Info banner ==========
echo "=============================================="
echo "OPC test (single NA)"
echo "=============================================="
echo "Project root:     $PROJECT_ROOT"
echo "Script dir:       $SCRIPT_DIR"
echo "Test NA:          $TEST_NA"
echo "Kernel num:       $KERNEL_NUM"
echo "Layout:           $LAYOUT_INPUT"
echo "Input source:     $SOURCE_INPUT"
echo "Source config:    $SOURCE_CONFIG"
echo "PWC config:       $PWC_CONFIG"
echo "OPC work dir:     $OPC_WORK_DIR"
echo "Layout:           $LAYOUT_ORIGINAL"
echo "Layout dash:      $LAYOUT_ORG_NAME_DASH"
echo "OPC tag:          $OPC_TAG"
echo "Mode (SO):        $([ "$M3D_SO" = "1" ] && echo M3D || echo M2D)"
echo "Mode (OPC):       $([ "$M3D_OPC" = "1" ] && echo M3D || echo M2D)"
if [ "$M3D_SO" = "1" ] || [ "$M3D_OPC" = "1" ]; then
    echo "Mask kikaku:      $MASK_KIKAKU"
fi
if [ "$M3D_OPC" = "1" ]; then
    echo "CGRP:             $CGRP"
fi
if has_blur; then
    echo "Blur:             enabled (src_blur set in source_config)"
else
    echo "Blur:             disabled"
fi
echo "Work dir:         $WORK_DIR"
echo "=============================================="
echo ""

# ========== Prepare output dir ==========
NA_STR=$(printf "%.6f" "$TEST_NA")
NA_DIR="$WORK_DIR/na_${NA_STR}"
SOCS_DIR="$NA_DIR/socs_set"
INI_FILE="$NA_DIR/ini.txt"
OPTIMIZED_SOURCE="$NA_DIR/optimized_source.illum"
COST_CSV="$NA_DIR/cost.csv"
LOG_CSV="$NA_DIR/log.csv"
BLURRED_SOURCE="$NA_DIR/optimized_source_blurred.illum"
MSOCS_DIR="$NA_DIR/msocs"
OPC_LAYOUT="$NA_DIR/opc_output.oas"

# run_opc が作成する try_<tag> ディレクトリ
OPC_TRY_DIR="$OPC_WORK_DIR/$LAYOUT_ORG_NAME_DASH/try_${OPC_TAG}"

mkdir -p "$NA_DIR"

# ========== Step 1: ini (upstream) ==========
echo "=== Step 1: generate ini (NA=$TEST_NA) ==="
if [ -f "$INI_FILE" ]; then
    echo "  ini already exists, skipping: $INI_FILE"
else
    generate_ini "$TEST_NA" "$INI_FILE"
    echo "  wrote: $INI_FILE"
fi
echo ""

# ========== Step 2: SOCS (upstream) ==========
echo "=== Step 2: SOCS generation ==="
if [ -d "$SOCS_DIR" ]; then
    echo "  SOCS set already exists, skipping: $SOCS_DIR"
else
    echo "  output: $SOCS_DIR"
    run_make_socs "$TEST_NA" "$INI_FILE" "$SOCS_DIR"
fi
echo ""

# ========== Step 3: source optimization (upstream) ==========
echo "=== Step 3: source optimization ==="
if [ -f "$OPTIMIZED_SOURCE" ]; then
    echo "  optimized source already exists, skipping: $OPTIMIZED_SOURCE"
else
    echo "  layout:        $LAYOUT_INPUT"
    echo "  input source:  $SOURCE_INPUT"
    echo "  output source: $OPTIMIZED_SOURCE"
    run_srcoptim "$SOCS_DIR" "$LAYOUT_INPUT" "$SOURCE_INPUT" \
                 "$OPTIMIZED_SOURCE" "$COST_CSV" "$LOG_CSV" "test-opc"
    FINAL_COST=$(get_final_cost "$COST_CSV")
    echo "$FINAL_COST" > "$NA_DIR/final_cost.txt"
    echo "  final cost: $FINAL_COST"
fi
echo ""

# ========== Step 4: blur (upstream, optional) ==========
echo "=== Step 4: illum blur ==="
MSOCS_INPUT_SOURCE="$OPTIMIZED_SOURCE"
if has_blur; then
    if [ -f "$BLURRED_SOURCE" ]; then
        echo "  blurred source already exists, skipping: $BLURRED_SOURCE"
    else
        generate_blurred_illum "$OPTIMIZED_SOURCE" "$INI_FILE" "$BLURRED_SOURCE"
        echo "  wrote: $BLURRED_SOURCE"
    fi
    MSOCS_INPUT_SOURCE="$BLURRED_SOURCE"
else
    echo "  blur disabled, using optimized source directly"
fi
echo ""

# ========== Step 5: MSOCS generation (upstream) ==========
echo "=== Step 5: MSOCS generation ==="
if [ -d "$MSOCS_DIR" ]; then
    echo "  MSOCS already exists, skipping: $MSOCS_DIR"
else
    echo "  input illum: $MSOCS_INPUT_SOURCE"
    echo "  output:      $MSOCS_DIR"
    run_make_msocs "$MSOCS_INPUT_SOURCE" "$INI_FILE" "$TEST_NA" "$MSOCS_DIR"
fi
echo ""

# ========== Step 6: OPC run (target) ==========
echo "=== Step 6: OPC run ==="
if [ "$FORCE" = true ]; then
    if [ -d "$OPC_TRY_DIR" ]; then
        echo "  --force: removing existing OPC try dir: $OPC_TRY_DIR"
        rm -rf "$OPC_TRY_DIR"
    fi
    if [ -f "$OPC_LAYOUT" ]; then
        rm -f "$OPC_LAYOUT"
    fi
fi

if [ -f "$OPC_LAYOUT" ]; then
    echo "  OPC output layout already exists, skipping: $OPC_LAYOUT"
    echo "  use --force to regenerate."
else
    echo "  MSOCS dir:    $MSOCS_DIR"
    echo "  OPC try dir:  $OPC_TRY_DIR"
    echo "  output layout: $OPC_LAYOUT"
    run_opc "$MSOCS_DIR" "$OPC_LAYOUT" "$OPC_TAG"
fi

echo ""
echo "=============================================="
echo "OPC test done"
echo "=============================================="
echo "OPC output layout: $OPC_LAYOUT"
echo "OPC try dir:       $OPC_TRY_DIR"
