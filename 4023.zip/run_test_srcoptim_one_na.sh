#!/bin/bash
#
# Test script that runs the source optimization part of run_smo.sh
# for a single NA value.
#
# Flow:
#   1. Generate an ini file for the given NA
#   2. Generate the SOCS set (skipped if it already exists)
#   3. Run srcOptim (skipped if optimized_source.illum already exists,
#      unless --force is specified)
#
# Usage: ./run_test_srcoptim_one_na.sh [options]
#   --na <val>         NA value to test (default: 1.20)
#   --kernel_num <N>   SOCS kernel count (default: 100)
#   --m3d_so           enable M3D mode for source optimization
#   --mask_kikaku <s>  mask specification (default: 4kikaku)
#   --layout <file>    input layout (default: LAYOUT_ORIGINAL)
#   --input_source <f> initial illum for srcOptim (default: INITIAL_SOURCE)
#   --max_iter <N>     srcOptim max iterations (default: setup.sh value)
#   --gradient_method <N>  gradient method (default: setup.sh value)
#   --optimizer <str>  optimizer (default: setup.sh value)
#   -j <N>             OpenMP threads (default: setup.sh value)
#   --np <N>           MPI ranks (default: setup.sh value)
#   --force            remove existing srcOptim output and regenerate
#

set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd)

# ========== Load libraries ==========
source "$SCRIPT_DIR/smo_lib/setup.sh"
source "$SCRIPT_DIR/smo_lib/helpers.sh"
source "$SCRIPT_DIR/smo_lib/srcoptim.sh"

# ========== Test defaults ==========
TEST_NA=1.20
FORCE=false
LAYOUT_INPUT="$LAYOUT_ORIGINAL"
SOURCE_INPUT="$INITIAL_SOURCE"

# Override WORK_DIR so the test does not touch the real smo_work
WORK_DIR="$SCRIPT_DIR/test_srcoptim_one_na_work"

# ========== Parse options ==========
while [[ $# -gt 0 ]]; do
    case $1 in
        --na)              TEST_NA="$2";          shift 2 ;;
        --kernel_num)      KERNEL_NUM="$2";       shift 2 ;;
        --m3d_so)          M3D_SO=1;              shift ;;
        --mask_kikaku)     MASK_KIKAKU="$2";      shift 2 ;;
        --layout)          LAYOUT_INPUT="$2";     shift 2 ;;
        --input_source)    SOURCE_INPUT="$2";     shift 2 ;;
        --max_iter)        MAX_ITER="$2";         shift 2 ;;
        --gradient_method) GRADIENT_METHOD="$2";  shift 2 ;;
        --optimizer)       OPTIMIZER="$2";        shift 2 ;;
        -j)                OPENMP_NUM="$2";       shift 2 ;;
        --np)              MPI_NP="$2";           shift 2 ;;
        --force)           FORCE=true;            shift ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# ========== Info banner ==========
echo "=============================================="
echo "srcOptim test (single NA)"
echo "=============================================="
echo "Project root:     $PROJECT_ROOT"
echo "Script dir:       $SCRIPT_DIR"
echo "Test NA:          $TEST_NA"
echo "Kernel num:       $KERNEL_NUM"
echo "Layout:           $LAYOUT_INPUT"
echo "Input source:     $SOURCE_INPUT"
echo "Source config:    $SOURCE_CONFIG"
echo "PWC config:       $PWC_CONFIG"
echo "EVP:              $EVP"
echo "INI template:     $INI_TEMPLATE"
echo "Optimizer:        $OPTIMIZER"
echo "Gradient method:  $GRADIENT_METHOD"
echo "Max iterations:   $MAX_ITER"
echo "OpenMP threads:   $OPENMP_NUM"
echo "MPI ranks:        $MPI_NP"
echo "Mode (SO):        $([ "$M3D_SO" = "1" ] && echo M3D || echo M2D)"
if [ "$M3D_SO" = "1" ]; then
    echo "Mask kikaku:      $MASK_KIKAKU"
fi
echo "Work dir:         $WORK_DIR"
echo "=============================================="
echo ""

# ========== Prepare output dir ==========
NA_STR=$(printf "%.6f" "$TEST_NA")
NA_DIR="$WORK_DIR/na_${NA_STR}"
SOCS_DIR="$NA_DIR/socs_set"
INI_FILE="$NA_DIR/ini.txt"
OUTPUT_SOURCE="$NA_DIR/optimized_source.illum"
COST_CSV="$NA_DIR/cost.csv"
LOG_CSV="$NA_DIR/log.csv"

mkdir -p "$NA_DIR"

# ========== Step 1: ini (upstream) ==========
echo "=== Step 1: generate ini (NA=$TEST_NA) ==="
if [ -f "$INI_FILE" ]; then
    echo "  ini already exists, skipping: $INI_FILE"
else
    generate_ini "$TEST_NA" "$INI_FILE"
    echo "  wrote: $INI_FILE"
fi
echo ""

# ========== Step 2: SOCS (upstream) ==========
echo "=== Step 2: SOCS generation ==="
if [ -d "$SOCS_DIR" ]; then
    echo "  SOCS set already exists, skipping: $SOCS_DIR"
else
    echo "  output: $SOCS_DIR"
    run_make_socs "$TEST_NA" "$INI_FILE" "$SOCS_DIR"
fi
echo ""

# ========== Step 3: source optimization (target) ==========
echo "=== Step 3: source optimization ==="
if [ "$FORCE" = true ] && [ -f "$OUTPUT_SOURCE" ]; then
    echo "  --force: removing existing srcOptim outputs"
    rm -f "$OUTPUT_SOURCE" "$COST_CSV" "$LOG_CSV" \
          "$NA_DIR/optimized_source.ppm" \
          "$NA_DIR/final_cost.txt"
fi

if [ -f "$OUTPUT_SOURCE" ]; then
    echo "  optimized source already exists, skipping: $OUTPUT_SOURCE"
    echo "  use --force to regenerate."
else
    echo "  layout:        $LAYOUT_INPUT"
    echo "  input source:  $SOURCE_INPUT"
    echo "  output source: $OUTPUT_SOURCE"
    run_srcoptim "$SOCS_DIR" "$LAYOUT_INPUT" "$SOURCE_INPUT" \
                 "$OUTPUT_SOURCE" "$COST_CSV" "$LOG_CSV" "test-srcoptim"

    # Record final cost for convenience
    FINAL_COST=$(get_final_cost "$COST_CSV")
    echo "$FINAL_COST" > "$NA_DIR/final_cost.txt"
    echo "  final cost: $FINAL_COST"
fi

echo ""
echo "=============================================="
echo "srcOptim test done"
echo "=============================================="
echo "output source: $OUTPUT_SOURCE"
echo "cost csv:      $COST_CSV"
echo "log csv:       $LOG_CSV"
if [ -f "$NA_DIR/final_cost.txt" ]; then
    echo "final cost:    $(cat "$NA_DIR/final_cost.txt")"
fi
