#!/bin/bash
#
# Test script that runs just the SOCS generation part of run_smo.sh
# for a single NA value.
#
# Flow:
#   1. Generate an ini file for the given NA
#   2. Call run_make_socs to produce the SOCS set
#
# Usage: ./run_test_socs_one_na.sh [options]
#   --na <val>        NA value to test (default: 1.20)
#   --kernel_num <N>  SOCS kernel count (default: 100)
#   --m3d_so          enable M3D mode for source optimization
#   --mask_kikaku <s> mask specification (default: 4kikaku)
#   --force           remove existing output dir and regenerate
#

set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
PROJECT_ROOT=$(cd "$SCRIPT_DIR/../.." && pwd)

# ========== Load libraries ==========
source "$SCRIPT_DIR/smo_lib/setup.sh"
source "$SCRIPT_DIR/smo_lib/helpers.sh"
source "$SCRIPT_DIR/smo_lib/srcoptim.sh"

# ========== Test defaults ==========
TEST_NA=1.20
FORCE=false

# Override WORK_DIR so the test does not touch the real smo_work
WORK_DIR="$SCRIPT_DIR/test_socs_one_na_work"

# ========== Parse options ==========
while [[ $# -gt 0 ]]; do
    case $1 in
        --na)          TEST_NA="$2";          shift 2 ;;
        --kernel_num)  KERNEL_NUM="$2";       shift 2 ;;
        --m3d_so)      M3D_SO=1;              shift ;;
        --mask_kikaku) MASK_KIKAKU="$2";      shift 2 ;;
        --force)       FORCE=true;            shift ;;
        *)
            echo "Unknown option: $1" >&2
            exit 1
            ;;
    esac
done

# ========== Info banner ==========
echo "=============================================="
echo "SOCS generation test (single NA)"
echo "=============================================="
echo "Project root:     $PROJECT_ROOT"
echo "Script dir:       $SCRIPT_DIR"
echo "Test NA:          $TEST_NA"
echo "Kernel num:       $KERNEL_NUM"
echo "Source config:    $SOURCE_CONFIG"
echo "PWC config:       $PWC_CONFIG"
echo "INI template:     $INI_TEMPLATE"
echo "Mode (SO):        $([ "$M3D_SO" = "1" ] && echo M3D || echo M2D)"
if [ "$M3D_SO" = "1" ]; then
    echo "Mask kikaku:      $MASK_KIKAKU"
fi
echo "Work dir:         $WORK_DIR"
echo "=============================================="
echo ""

# ========== Prepare output dir ==========
NA_STR=$(printf "%.6f" "$TEST_NA")
NA_DIR="$WORK_DIR/na_${NA_STR}"
SOCS_DIR="$NA_DIR/socs_set"

if [ "$FORCE" = true ] && [ -d "$NA_DIR" ]; then
    echo "Removing existing output dir: $NA_DIR"
    rm -rf "$NA_DIR"
fi

mkdir -p "$NA_DIR"

# ========== Step 1: generate ini ==========
echo "=== Step 1: generate ini (NA=$TEST_NA) ==="
INI_FILE="$NA_DIR/ini.txt"
generate_ini "$TEST_NA" "$INI_FILE"
echo "  wrote: $INI_FILE"
echo ""

# ========== Step 2: SOCS generation ==========
echo "=== Step 2: SOCS generation ==="
if [ -d "$SOCS_DIR" ]; then
    echo "  SOCS set already exists, skipping: $SOCS_DIR"
    echo "  use --force to regenerate."
else
    echo "  output: $SOCS_DIR"
    run_make_socs "$TEST_NA" "$INI_FILE" "$SOCS_DIR"
fi

echo ""
echo "=============================================="
echo "SOCS generation test done"
echo "=============================================="
echo "output: $SOCS_DIR"
