#!/bin/bash
#
# smo_lib/helpers.sh - utility functions
#

# Print a prominent start banner (goes to stderr so it is visible
# even when called inside $(...) command substitution).
# Usage: banner_start <label> [extra_info ...]
banner_start() {
    local label="$1"
    shift
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    {
        echo ""
        echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
        echo ">>> [$ts] START: $label"
        for info in "$@"; do
            echo ">>>   $info"
        done
        echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    } >&2
}

# Print a prominent done banner with elapsed time.
# Usage: banner_end <label> <start_epoch> [extra_info ...]
banner_end() {
    local label="$1"
    local start_epoch="$2"
    shift 2
    local ts end_epoch elapsed
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    end_epoch=$(date +%s)
    elapsed=$((end_epoch - start_epoch))
    local mm=$((elapsed / 60))
    local ss=$((elapsed % 60))
    {
        echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
        echo "<<< [$ts] DONE : $label  (elapsed ${mm}m ${ss}s)"
        for info in "$@"; do
            echo "<<<   $info"
        done
        echo "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"
        echo ""
    } >&2
}

# Plain info message (stderr).
log_info() {
    echo "$@" >&2
}

# Generate an ini file for the given NA
generate_ini() {
    local na_val="$1"
    local output_ini="$2"
    sed "s/^NA .*/NA ${na_val}/" "$INI_TEMPLATE" > "$output_ini"
}

# Extract the final total_cost value from a cost.csv
get_final_cost() {
    local cost_csv="$1"
    grep "^total_cost," "$cost_csv" | head -1 | cut -d',' -f2
}

# Check whether source_config has a src_blur setting
has_blur() {
    grep -q '^src_blur ' "$SOURCE_CONFIG" 2>/dev/null
}

# Generate a blurred .illum file (only if src_blur is configured)
generate_blurred_illum() {
    local input_illum="$1"
    local ini_file="$2"
    local output_illum="$3"

    if has_blur; then
        log_info "  [blur] $input_illum -> $output_illum"
        python3 "$BLUR_ILLUM" \
            -f "$input_illum" \
            -g "$SOURCE_CONFIG" \
            --ini "$ini_file" \
            -o "$output_illum"
    else
        cp "$input_illum" "$output_illum"
    fi
}
