#!/bin/bash
#
# smo_lib/srcoptim.sh - SOCS generation + source optimization (bsub/LSF)
#

# SOCS generation
run_make_socs() {
    local na_val="$1"
    local ini_file="$2"
    local socs_dir="$3"

    local m3d_opts=""
    if [ "$M3D_SO" = "1" ]; then
        m3d_opts="--m3d --mask_kikaku $MASK_KIKAKU"
    fi

    python3 "$MAKE_SOCS" \
        --source "$SOURCE_CONFIG" \
        --pwc "$PWC_CONFIG" \
        --ini "$ini_file" \
        -o "$socs_dir" \
        --kernel_num "$KERNEL_NUM" \
        -j 1 \
        -q LITHOALL \
        --parallel \
        --max_jobs 16 \
        $m3d_opts \
        --debug
}

# Generate the shell script used to run srcOptim inside the LSF job
_generate_srcoptim_script() {
    local script_path="$1"
    local socs_dir="$2"
    local layout="$3"
    local input_source="$4"
    local output_source="$5"
    local cost_csv="$6"
    local log_csv="$7"

    cat > "$script_path" << SCRIPT_EOF
#!/bin/bash
set -e

# Build the MPI run command
if [ -n "\$LSB_DJOB_HOSTFILE" ]; then
    NP=\$(cat "\$LSB_DJOB_HOSTFILE" | wc -l)
    RUNCMD="mpirun -bootstrap lsf -np \$NP $SRCOPTIM"
elif [ "$MPI_NP" -gt 1 ]; then
    RUNCMD="mpirun -np $MPI_NP $SRCOPTIM"
else
    RUNCMD="$SRCOPTIM"
fi

\$RUNCMD \\
    -l "$layout" \\
    -s "$socs_dir" \\
    -g "$SOURCE_CONFIG" \\
    -f "$input_source" \\
    -p "$PWC_CONFIG" \\
    -e "$EVP" \\
    -o "$output_source" \\
    --brightfield \\
    --cost_output "$cost_csv" \\
    --log_output "$log_csv" \\
    --optimizer "$OPTIMIZER" \\
    --max_iter "$MAX_ITER" \\
    --gradient_method "$GRADIENT_METHOD" \\
    --sliceLevelRounds 400 \\
    --exp_fill_penalty \\
    --fill_penalty_k 10 \\
    --weight_fill 10 \\
    --lbfgs_memory 16 \\
    --lbfgs_window 5 \\
    --max_cost_reduction 0.3 \\
    -j "$OPENMP_NUM" \\
    --verbose \\
    --anchor_clips 0 \\
    --layer "$LAYOUT_LAYER" \\
    --round_conv_window 3
SCRIPT_EOF
    chmod +x "$script_path"
}

# Extract the LSF job id from bsub output
_extract_jobid() {
    # bsub output looks like: "Job <12345> is submitted to queue <OPCALL>."
    sed -n 's/.*Job <\([0-9]*\)>.*/\1/p'
}

# Wait for the LSF job to finish, printing periodic progress updates
_wait_for_job() {
    local jobid="$1"
    local tag="$2"

    local start_epoch
    start_epoch=$(date +%s)
    echo "  [$tag] job submitted: JobID=$jobid, waiting for completion..." >&2

    local last_report=0
    local report_interval=30  # progress interval in seconds
    # UNKNOWN/empty を「完了」と解釈するのは、job が一度でも実状態
    # (PEND/RUN/DONE 等) で観測された後だけに限定する。
    # 投入直後のスケジューラ登録遅延で UNKNOWN が返っても
    # 早期に return しないようにするため。
    local job_seen=false
    local unknown_since=0
    local unknown_grace=60  # job_seen 前に UNKNOWN 継続を許容する秒数
    while true; do
        local status
        status=$(bjobs -noheader -o "stat" "$jobid" 2>/dev/null || echo "UNKNOWN")
        case "$status" in
            DONE)
                local elapsed=$(( $(date +%s) - start_epoch ))
                echo "  [$tag] job DONE: JobID=$jobid (elapsed $((elapsed/60))m $((elapsed%60))s)" >&2
                return 0
                ;;
            EXIT)
                echo "  [$tag] job EXIT (failed): JobID=$jobid" >&2
                return 1
                ;;
            UNKNOWN|"")
                if [ "$job_seen" = true ]; then
                    # 実状態観測済み → 履歴から flush された完了と解釈
                    echo "  [$tag] job status UNKNOWN after seen: JobID=$jobid (assuming done)" >&2
                    return 0
                fi
                # まだ一度も観測できていない: スケジューラ登録遅延の可能性あり
                if [ "$unknown_since" -eq 0 ]; then
                    unknown_since=$(date +%s)
                fi
                local unknown_elapsed=$(( $(date +%s) - unknown_since ))
                if [ "$unknown_elapsed" -ge "$unknown_grace" ]; then
                    echo "  [$tag] job never seen by bjobs within ${unknown_grace}s: JobID=$jobid" >&2
                    echo "  [$tag] (assuming flushed-done; will verify output file)" >&2
                    return 0
                fi
                # grace 期間中は sleep して再試行
                ;;
            *)
                job_seen=true
                unknown_since=0
                ;;
        esac

        # Periodic progress update
        local now elapsed
        now=$(date +%s)
        elapsed=$((now - start_epoch))
        if [ $((elapsed - last_report)) -ge "$report_interval" ]; then
            echo "  [$tag] ... $status  (elapsed $((elapsed/60))m $((elapsed%60))s)  JobID=$jobid" >&2
            last_report=$elapsed
        fi

        sleep 10
    done
}

# Run source optimization (submit bsub job and wait for completion)
run_srcoptim() {
    local socs_dir="$1"
    local layout="$2"
    local input_source="$3"
    local output_source="$4"
    local cost_csv="$5"
    local log_csv="$6"
    local tag="${7:-srcOptim}"

    local work_dir
    work_dir=$(dirname "$output_source")

    # Generate the run script
    local run_script="$work_dir/run_srcoptim.sh"
    _generate_srcoptim_script "$run_script" \
        "$socs_dir" "$layout" "$input_source" "$output_source" "$cost_csv" "$log_csv"

    # Submit job via bsub
    local bsub_log="$work_dir/srcoptim_bsub.log"
    local bsub_output
    bsub_output=$(bsub \
        -n "$MPI_NP" \
        -R "span[ptile=1]" \
        -q OPCALL \
        -J "smo_srcoptim_${tag}" \
        -o "$bsub_log" \
        "$run_script" 2>&1)

    local jobid
    jobid=$(echo "$bsub_output" | _extract_jobid)

    if [ -z "$jobid" ]; then
        echo "  ERROR: bsub failed: $bsub_output" >&2
        return 1
    fi

    _wait_for_job "$jobid" "$tag"

    # Check that the output file was produced.
    # NFS attribute cache の都合で、別ノードで書かれた直後は
    # 提出ノードから即座に見えないことがあるのでリトライする。
    local check_retries=30
    local check_interval=2
    local output_dir
    output_dir=$(dirname "$output_source")
    local attempt
    for (( attempt = 0; attempt < check_retries; ++attempt )); do
        if [ -f "$output_source" ]; then
            break
        fi
        # NFS sync を促すためディレクトリを stat/ls する
        ls -la "$output_dir" >/dev/null 2>&1 || true
        sleep "$check_interval"
    done

    if [ ! -f "$output_source" ]; then
        echo "  ERROR: optimized source not found after $((check_retries * check_interval))s: $output_source" >&2
        echo "  check log: $bsub_log" >&2
        return 1
    fi
}
