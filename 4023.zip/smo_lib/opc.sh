#!/bin/bash
#
# smo_lib/opc.sh - MSOCS generation + OPC run
#

# MSOCS generation
run_make_msocs() {
    local illum_file="$1"
    local ini_file="$2"
    local na_val="$3"
    local output_msocs="$4"

    log_info "  [MSOCS] generate: illum=$illum_file, ini=$ini_file, NA=$na_val -> $output_msocs"
    mkdir -p "$output_msocs"

    # 3番目の位置引数は「ファイル接頭辞(prefix)」で、
    # ツールが <prefix>.socs / <prefix>.log/ などを sibling として生成する。
    # prefix を絶対パスにするとパス長の都合でツールが正常動作しないため、
    # 出力ディレクトリに cd してから相対 prefix を渡す。
    # illum / ini は絶対パスで渡されている前提。
    if [ "$M3D_OPC" = "1" ]; then
        (
            cd "$output_msocs"
            "$MAKETCC_M3DMTCC3" \
                -n 8 \
                -o 16 \
                -q OPCALL \
                -s "$illum_file" "$ini_file" "srcOptim.msocs" "$CGRP"
        )
    else
        (
            cd "$output_msocs"
            "$MAKETCC_MTCC3" \
                -n 8 \
                -o 16 \
                -q OPCALL \
                -s "$illum_file" "$ini_file" "srcOptim.msocs"
        )
    fi
}

# OPC run
# Copy the template dir, patch M3D on/off + layout name, drop MSOCS in place, then execute
run_opc() {
    local msocs_dir="$1"
    local layout_out="$2"
    local loop="$3"

    local opc_dir="$OPC_WORK_DIR/$LAYOUT_ORG_NAME_DASH"
    local try_dir="$opc_dir/try_${loop}"
    local template_src="$OPC_WORK_DIR/org/mytry"

    log_info "  [OPC] copy template: $template_src -> $try_dir"
    mkdir -p "$opc_dir"
    cp -r "$template_src" "$try_dir"

    # M3D on/off の切り替え
    if [ "$M3D_OPC" = "1" ]; then
        log_info "  [OPC] enable M3D in $try_dir"
        find "$try_dir" -type f -exec sed -i 's/M3D off/M3D on/g' {} \;
    else
        log_info "  [OPC] disable M3D in $try_dir"
        find "$try_dir" -type f -exec sed -i 's/M3D on/M3D off/g' {} \;
    fi

    # レイアウト文字列置換 (hoge.gds -> $LAYOUT_ORG_NAME)
    # LAYOUT_ORG_NAME にスラッシュが含まれる可能性があるため sed 区切り文字は | を使う
    log_info "  [OPC] replace layout: hoge.gds -> $LAYOUT_ORG_NAME"
    find "$try_dir" -type f -exec sed -i "s|hoge.gds|$LAYOUT_ORG_NAME|g" {} \;

    # MSOCS コピー (単一ファイル srcOptim.msocs)
    log_info "  [OPC] copy MSOCS: $msocs_dir/srcOptim.msocs -> $try_dir/TCC/srcOptim.msocs"
    cp "$msocs_dir/srcOptim.msocs" "$try_dir/TCC/srcOptim.msocs"

    # OPC 実行 (サブシェル内で cd → 終了後は自動的に元のディレクトリに戻る)
    log_info "  [OPC] run: cd $try_dir && ./run.csh"
    (
        cd "$try_dir"
        ./run.csh
    )

    # 結果レイアウトを smo 作業ディレクトリにコピー
    local opc_output="$try_dir/tko_sub_dir1/tk_lcc.oas"
    if [ ! -f "$opc_output" ]; then
        echo "  ERROR: OPC output not found: $opc_output" >&2
        return 1
    fi

    log_info "  [OPC] output: $opc_output -> $layout_out"
    cp "$opc_output" "$layout_out"
}
