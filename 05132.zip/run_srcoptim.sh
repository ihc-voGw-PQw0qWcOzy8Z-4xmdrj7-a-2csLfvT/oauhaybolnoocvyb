#!/bin/bash
#
# run_srcoptim.sh
#
# srcOptim を 1 回実行するラッパー。tmp0507/run_srcoptim_one.sh をベースに、
# tmp0512 で追加した機能 (tolerance / NILS / BT/BFS / 正則化) と
# M3D 切替を加えた。
#
# 使い方:
#   # ローカル実行 (テスト用)
#   ./run_srcoptim.sh -s <socs_dir> -l <layout> -f <input_source> -o <output_source> ...
#
#   # LSF (bsub) 経由で本番投入
#   ./run_srcoptim.sh --bsub -n 4 -q OPCALL \
#       -s ./socs_set -l Layout/foo.oas \
#       -f in/initial_source.illum -o ./optimized_source.illum
#
# 動作:
#   1. socs_dir/.ready の存在を確認
#   2. srcOptim 起動用の wrapper script を生成
#      - LSF 内では LSB_DJOB_HOSTFILE から MPI np を自動算出
#      - LSF 外ではローカル実行 (MPI_NP=1 ならそのまま、>1 なら mpirun)
#   3. --bsub なら bsub 投入 → bjobs で完了待ち
#      そうでなければそのまま wrapper を起動
#   4. optimized_source.illum / cost.csv / log.csv を出力
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ===== Defaults =====
SRCOPTIM="$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim"
SOURCE_CONFIG="$SCRIPT_DIR/../tmp0507/in/source_config.txt"
PWC_CONFIG="$SCRIPT_DIR/../tmp0507/in/pwc_config.txt"
EVP=""
LAYER="0/0"

# LSF / MPI
USE_BSUB=0
MPI_NP=1
QUEUE="OPCALL"
JOB_NAME=""

# srcOptim 主要パラメータ
OPTIMIZER="lbfgs"
GRADIENT_METHOD=2
MAX_ITER=200
OPENMP_NUM=16

EPE_POWER_SCHEDULE="2,4,6,8"
ADAPT_P_SCHEDULE="1.0,3.0,5.0,7.0"
ADAPT_FLOOR_SCHEDULE="0.5,0.1,0.01,0.001"

SA_AMPLITUDE_INIT=0.03
SA_COOLING=0.85
SA_MAX_ROUNDS=20
SA_ALL_STAGES=1
SA_SEED=1

SLICE_METHOD="minmax"
SLICE_OBJECTIVE="max_abs_epe"
SLICE_PWC_MODE="all"
SLICELEVEL_ROUNDS=30

ROUND_CONV_WINDOW=3
ROUND_CONV_TOL=1e-6
LBFGS_MEMORY=20
LBFGS_WINDOW=15
LBFGS_REL_TOL=1e-6
LBFGS_MIN_ITER=20
EARLY_STOP_PATIENCE=20
EARLY_STOP_TOL=1e-6
GRAD_TOL=1e-4

MIN_INTENSITY=0.0
MAX_INTENSITY=2.0
MIN_FILL_RATIO=0.07
WEIGHT_FILL=10
FILL_PENALTY_K=10

# Brightfield/Darkfield
BRIGHTFIELD=1   # 1=bright, 0=dark

# === tmp0512 追加機能のデフォルト（0 なら wrapper 行に出力しない）===
TOLERANCE=""                  # 空文字 = evp.csv の tolerance 列を使う
WEIGHT_NILS=0
NILS_MIN=2.0
NILS_CD_REF=0.022
WEIGHT_BT=0
WEIGHT_BFS=0
BT_POWER=2
BFS_POWER=2
BT_PWC_POS=""                 # 空文字 = auto
BT_PWC_NEG=""
BFS_PWC_NOM=""
PAIR_CLIPS=""                 # 空文字 = 全 clip
REGULARIZATION="none"
REGULARIZATION_WEIGHT=0

# 必須引数
SOCS_DIR=""
LAYOUT=""
INPUT_SOURCE=""
OUTPUT_SOURCE=""
COST_CSV=""
LOG_CSV=""

usage() {
    cat << EOF
Usage: $0 -s <socs_dir> -l <layout> -f <input_source> -o <output_source> [options]

Required:
  -s, --socs DIR              SOCS cache directory (must contain .ready)
  -l, --layout FILE           layout (.gds / .oas)
  -f, --input-source FILE     initial source .illum
  -o, --output-source FILE    output optimized source .illum

LSF (bsub) options:
      --bsub                  submit to LSF instead of running locally
  -n, --np N                  MPI ranks (= bsub -n) (default: $MPI_NP)
  -q, --queue NAME            LSF queue (default: $QUEUE)
      --job-name NAME         bsub -J name (default: srcoptim_<basename>)

Common options:
  -e, --evp FILE              evaluation points CSV
  -p, --pwc FILE              pwc config (default: $PWC_CONFIG)
  -g, --source-config FILE    source config (default: $SOURCE_CONFIG)
      --layer SPEC            srcOptim --layer (default: $LAYER)
      --brightfield           (default)
      --darkfield
      --cost-output FILE      cost.csv path (default: alongside output)
      --log-output FILE       log.csv path  (default: alongside output)
      --srcoptim PATH         override srcOptim binary path

srcOptim tuning:
      --optimizer NAME        lbfgs | adam (default: $OPTIMIZER)
      --max-iter N            (default: $MAX_ITER)
  -j, --openmp N              OpenMP threads (default: $OPENMP_NUM)
      --epe-power-schedule CSV       (default: $EPE_POWER_SCHEDULE)
      --adapt-p-schedule CSV         (default: $ADAPT_P_SCHEDULE)
      --adapt-floor-schedule CSV     (default: $ADAPT_FLOOR_SCHEDULE)
      --sa-seed N             (default: $SA_SEED)
      --sa-max-rounds N       (default: $SA_MAX_ROUNDS)
      --slicelevel-rounds N   (default: $SLICELEVEL_ROUNDS)
      --grad-tol VAL          (default: $GRAD_TOL)

Tolerance (重要):
      --tolerance VAL         全評価点の EPE 許容値 [um]
                              空 = evp.csv の tolerance 列を使う (default)
                              calcMargin の --tolerance と一致させると整合的

NILS penalty:
      --weight-nils VAL       NILS ペナルティ重み (0=無効, default: 0)
      --nils-min VAL          NILS 下限 (default: $NILS_MIN)
      --nils-cd-ref VAL       NILS 参照 CD [um] (default: $NILS_CD_REF)

BT / BFS penalty:
      --weight-bt VAL         BT 重み (0=無効, default: 0)
      --weight-bfs VAL        BFS 重み (0=無効, default: 0)
      --bt-power N            (default: $BT_POWER)
      --bfs-power N           (default: $BFS_POWER)
      --bt-pwc-pos N          Fp PWC index (auto if empty)
      --bt-pwc-neg N          Fn PWC index (auto if empty)
      --bfs-pwc-nom N         Nom PWC index (auto if empty)
      --pair-clips CSV        適用 clip ID (default: 全 clip)

Regularization:
      --regularization TYPE       none|laplacian|l2|tv|isolated (default: none)
      --regularization-weight VAL (default: 0)

  -h, --help                  show this help
EOF
}

# ===== Parse args =====
while [ $# -gt 0 ]; do
    case "$1" in
        -s|--socs)                  SOCS_DIR="$2"; shift 2;;
        -l|--layout)                LAYOUT="$2"; shift 2;;
        -f|--input-source)          INPUT_SOURCE="$2"; shift 2;;
        -o|--output-source)         OUTPUT_SOURCE="$2"; shift 2;;
        --bsub)                     USE_BSUB=1; shift;;
        -n|--np)                    MPI_NP="$2"; shift 2;;
        -q|--queue)                 QUEUE="$2"; shift 2;;
        --job-name)                 JOB_NAME="$2"; shift 2;;
        -e|--evp)                   EVP="$2"; shift 2;;
        -p|--pwc)                   PWC_CONFIG="$2"; shift 2;;
        -g|--source-config)         SOURCE_CONFIG="$2"; shift 2;;
        --layer)                    LAYER="$2"; shift 2;;
        --brightfield)              BRIGHTFIELD=1; shift;;
        --darkfield)                BRIGHTFIELD=0; shift;;
        --cost-output)              COST_CSV="$2"; shift 2;;
        --log-output)               LOG_CSV="$2"; shift 2;;
        --optimizer)                OPTIMIZER="$2"; shift 2;;
        --max-iter)                 MAX_ITER="$2"; shift 2;;
        -j|--openmp)                OPENMP_NUM="$2"; shift 2;;
        --epe-power-schedule)       EPE_POWER_SCHEDULE="$2"; shift 2;;
        --adapt-p-schedule)         ADAPT_P_SCHEDULE="$2"; shift 2;;
        --adapt-floor-schedule)     ADAPT_FLOOR_SCHEDULE="$2"; shift 2;;
        --sa-seed)                  SA_SEED="$2"; shift 2;;
        --sa-max-rounds)            SA_MAX_ROUNDS="$2"; shift 2;;
        --slicelevel-rounds)        SLICELEVEL_ROUNDS="$2"; shift 2;;
        --grad-tol)                 GRAD_TOL="$2"; shift 2;;
        --srcoptim)                 SRCOPTIM="$2"; shift 2;;
        --tolerance)                TOLERANCE="$2"; shift 2;;
        --weight-nils)              WEIGHT_NILS="$2"; shift 2;;
        --nils-min)                 NILS_MIN="$2"; shift 2;;
        --nils-cd-ref)              NILS_CD_REF="$2"; shift 2;;
        --weight-bt)                WEIGHT_BT="$2"; shift 2;;
        --weight-bfs)               WEIGHT_BFS="$2"; shift 2;;
        --bt-power)                 BT_POWER="$2"; shift 2;;
        --bfs-power)                BFS_POWER="$2"; shift 2;;
        --bt-pwc-pos)               BT_PWC_POS="$2"; shift 2;;
        --bt-pwc-neg)               BT_PWC_NEG="$2"; shift 2;;
        --bfs-pwc-nom)              BFS_PWC_NOM="$2"; shift 2;;
        --pair-clips)               PAIR_CLIPS="$2"; shift 2;;
        --regularization)           REGULARIZATION="$2"; shift 2;;
        --regularization-weight)    REGULARIZATION_WEIGHT="$2"; shift 2;;
        -h|--help)                  usage; exit 0;;
        *) echo "ERROR: unknown option: $1" >&2; usage; exit 1;;
    esac
done

# ===== Validate =====
if [ -z "$SOCS_DIR" ] || [ -z "$LAYOUT" ] || [ -z "$INPUT_SOURCE" ] || [ -z "$OUTPUT_SOURCE" ]; then
    echo "ERROR: -s, -l, -f, -o are all required" >&2
    usage; exit 1
fi

if [ ! -f "$SOCS_DIR/.ready" ]; then
    echo "ERROR: SOCS not ready (missing $SOCS_DIR/.ready)" >&2
    echo "HINT : run ./make_socs_set or check SOCS dir" >&2
    exit 1
fi

for f in "$LAYOUT" "$INPUT_SOURCE" "$SOURCE_CONFIG" "$PWC_CONFIG"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: required file not found: $f" >&2
        exit 1
    fi
done
if [ -n "$EVP" ] && [ ! -f "$EVP" ]; then
    echo "ERROR: --evp file not found: $EVP" >&2
    exit 1
fi

if [ ! -x "$SRCOPTIM" ]; then
    echo "ERROR: srcOptim binary not found / not executable: $SRCOPTIM" >&2
    exit 1
fi

# ===== Resolve output paths =====
OUT_DIR=$(dirname "$OUTPUT_SOURCE")
mkdir -p "$OUT_DIR"
[ -z "$COST_CSV" ] && COST_CSV="$OUT_DIR/cost.csv"
[ -z "$LOG_CSV" ]  && LOG_CSV="$OUT_DIR/log.csv"
[ -z "$JOB_NAME" ] && JOB_NAME="srcoptim_$(basename "$OUTPUT_SOURCE" .illum)"

# ===== 追加オプション行を組み立て (wrapper 内に埋め込む) =====
# 値が 0 や空文字なら行を追加しない（srcOptim CLI を簡潔に保つ）。
# 全行を 1 変数 EXTRA_OPTS にまとめて wrapper の所定位置に挿入する。
BF_LINE='--darkfield'
[ "$BRIGHTFIELD" = "1" ] && BF_LINE='--brightfield'

# extra options: 1 つの変数に連結。各行は "    --opt val \\\n" で終わる
EXTRA_OPTS=""
add_extra() {
    # 引数 = wrapper に書く 1 行 (末尾 \ は付けない、ここで付ける)
    EXTRA_OPTS+="    $* \\
"
}

# EVP は他のオプションと混ぜずに先頭で追加
[ -n "$EVP" ] && add_extra "-e \"$EVP\""

[ -n "$TOLERANCE" ] && add_extra "--tolerance \"$TOLERANCE\""

if awk -v w="$WEIGHT_NILS" 'BEGIN{exit !(w>0)}'; then
    add_extra "--weight_nils \"$WEIGHT_NILS\""
    add_extra "--nils_min \"$NILS_MIN\""
    add_extra "--nils_cd_ref \"$NILS_CD_REF\""
fi

if awk -v w="$WEIGHT_BT" 'BEGIN{exit !(w>0)}'; then
    add_extra "--weight_bt \"$WEIGHT_BT\""
    add_extra "--bt_power \"$BT_POWER\""
    [ -n "$BT_PWC_POS" ] && add_extra "--bt_pwc_pos \"$BT_PWC_POS\""
    [ -n "$BT_PWC_NEG" ] && add_extra "--bt_pwc_neg \"$BT_PWC_NEG\""
fi

if awk -v w="$WEIGHT_BFS" 'BEGIN{exit !(w>0)}'; then
    add_extra "--weight_bfs \"$WEIGHT_BFS\""
    add_extra "--bfs_power \"$BFS_POWER\""
    [ -n "$BFS_PWC_NOM" ] && add_extra "--bfs_pwc_nom \"$BFS_PWC_NOM\""
fi

[ -n "$PAIR_CLIPS" ] && add_extra "--pair_clips \"$PAIR_CLIPS\""

if [ "$REGULARIZATION" != "none" ] && awk -v w="$REGULARIZATION_WEIGHT" 'BEGIN{exit !(w>0)}'; then
    add_extra "--regularization \"$REGULARIZATION\""
    add_extra "--regularization_weight \"$REGULARIZATION_WEIGHT\""
fi

# ===== Generate wrapper script =====
WRAPPER="$OUT_DIR/run_srcoptim_wrapper.sh"
BSUB_LOG="$OUT_DIR/srcoptim_bsub.log"

cat > "$WRAPPER" << SCRIPT_EOF
#!/bin/bash
set -e

if [ -n "\$LSB_DJOB_HOSTFILE" ]; then
    NP=\$(wc -l < "\$LSB_DJOB_HOSTFILE")
    RUNCMD="mpirun -bootstrap lsf -np \$NP $SRCOPTIM"
elif [ "$MPI_NP" -gt 1 ]; then
    RUNCMD="mpirun -np $MPI_NP $SRCOPTIM"
else
    RUNCMD="$SRCOPTIM"
fi

\$RUNCMD \\
    -l "$LAYOUT" \\
    -s "$SOCS_DIR" \\
    -g "$SOURCE_CONFIG" \\
    -f "$INPUT_SOURCE" \\
    -p "$PWC_CONFIG" \\
    -o "$OUTPUT_SOURCE" \\
    $BF_LINE \\
    --cost_output "$COST_CSV" \\
    --log_output "$LOG_CSV" \\
    --optimizer "$OPTIMIZER" \\
    --max_iter "$MAX_ITER" \\
    --gradient_method "$GRADIENT_METHOD" \\
    --layer "$LAYER" \\
    --epe_power_schedule "$EPE_POWER_SCHEDULE" \\
    --adaptive_weight_p_schedule "$ADAPT_P_SCHEDULE" \\
    --adaptive_weight_floor_schedule "$ADAPT_FLOOR_SCHEDULE" \\
    --sa_amplitude_init "$SA_AMPLITUDE_INIT" \\
    --sa_cooling "$SA_COOLING" \\
    --sa_max_rounds "$SA_MAX_ROUNDS" \\
    --sa_all_stages "$SA_ALL_STAGES" \\
    --sa_seed "$SA_SEED" \\
    --slice_method "$SLICE_METHOD" \\
    --slice_objective "$SLICE_OBJECTIVE" \\
    --slice_pwc_mode "$SLICE_PWC_MODE" \\
    --sliceLevelRounds "$SLICELEVEL_ROUNDS" \\
    --round_conv_window "$ROUND_CONV_WINDOW" \\
    --round_conv_tol "$ROUND_CONV_TOL" \\
    --lbfgs_memory "$LBFGS_MEMORY" \\
    --lbfgs_window "$LBFGS_WINDOW" \\
    --lbfgs_rel_tol "$LBFGS_REL_TOL" \\
    --lbfgs_min_iter "$LBFGS_MIN_ITER" \\
    --early_stop_patience "$EARLY_STOP_PATIENCE" \\
    --early_stop_tol "$EARLY_STOP_TOL" \\
    --grad_tol "$GRAD_TOL" \\
    --min_intensity "$MIN_INTENSITY" \\
    --max_intensity "$MAX_INTENSITY" \\
    --min_fill_ratio "$MIN_FILL_RATIO" \\
    --weight_fill "$WEIGHT_FILL" \\
    --exp_fill_penalty \\
    --fill_penalty_k "$FILL_PENALTY_K" \\
${EXTRA_OPTS}    -j "$OPENMP_NUM" \\
    --verbose
SCRIPT_EOF
chmod +x "$WRAPPER"

# ===== Log header =====
echo "[run_srcoptim] socs    = $SOCS_DIR"
echo "[run_srcoptim] layout  = $LAYOUT"
echo "[run_srcoptim] input   = $INPUT_SOURCE"
echo "[run_srcoptim] output  = $OUTPUT_SOURCE"
echo "[run_srcoptim] cost    = $COST_CSV"
echo "[run_srcoptim] log     = $LOG_CSV"
echo "[run_srcoptim] wrapper = $WRAPPER"
[ -n "$TOLERANCE" ] && echo "[run_srcoptim] tolerance = $TOLERANCE"
awk -v w="$WEIGHT_NILS" 'BEGIN{exit !(w>0)}' \
    && echo "[run_srcoptim] NILS    = weight=$WEIGHT_NILS, min=$NILS_MIN, cd_ref=$NILS_CD_REF"
awk -v w="$WEIGHT_BT" 'BEGIN{exit !(w>0)}' \
    && echo "[run_srcoptim] BT      = weight=$WEIGHT_BT, power=$BT_POWER"
awk -v w="$WEIGHT_BFS" 'BEGIN{exit !(w>0)}' \
    && echo "[run_srcoptim] BFS     = weight=$WEIGHT_BFS, power=$BFS_POWER"
[ -n "$PAIR_CLIPS" ] && echo "[run_srcoptim] pair_clips = $PAIR_CLIPS"

T0=$(date +%s)

if [ "$USE_BSUB" = "1" ]; then
    # ===== LSF (bsub) =====
    echo "[run_srcoptim] submitting to LSF: queue=$QUEUE, -n $MPI_NP, job=$JOB_NAME"
    OUT_MSG=$(bsub \
        -n "$MPI_NP" \
        -R "span[ptile=1]" \
        -q "$QUEUE" \
        -J "$JOB_NAME" \
        -o "$BSUB_LOG" \
        "$WRAPPER" 2>&1)
    JOBID=$(echo "$OUT_MSG" | sed -n 's/.*Job <\([0-9]*\)>.*/\1/p')
    if [ -z "$JOBID" ]; then
        echo "ERROR: bsub failed: $OUT_MSG" >&2
        exit 1
    fi
    echo "[run_srcoptim] submitted: JobID=$JOBID, log=$BSUB_LOG"

    # bjobs で完了待ち (run_srcoptim_one.sh と同じパターン)
    JOB_SEEN=false
    UNKNOWN_SINCE=0
    UNKNOWN_GRACE=60
    LAST_REPORT=0
    REPORT_INTERVAL=30
    while true; do
        STATUS=$(bjobs -noheader -o "stat" "$JOBID" 2>/dev/null || echo "UNKNOWN")
        case "$STATUS" in
            DONE)
                E=$(( $(date +%s) - T0 ))
                echo "[run_srcoptim] job DONE (elapsed $((E/60))m $((E%60))s)"
                break
                ;;
            EXIT)
                echo "ERROR: job EXIT (failed). JobID=$JOBID, log=$BSUB_LOG" >&2
                exit 1
                ;;
            UNKNOWN|"")
                if [ "$JOB_SEEN" = true ]; then
                    echo "[run_srcoptim] job status UNKNOWN after seen: assuming done"
                    break
                fi
                [ "$UNKNOWN_SINCE" -eq 0 ] && UNKNOWN_SINCE=$(date +%s)
                if [ $(( $(date +%s) - UNKNOWN_SINCE )) -ge "$UNKNOWN_GRACE" ]; then
                    echo "[run_srcoptim] job never seen by bjobs (assuming flushed-done)"
                    break
                fi
                ;;
            *)
                JOB_SEEN=true
                UNKNOWN_SINCE=0
                ;;
        esac

        E=$(( $(date +%s) - T0 ))
        if [ $((E - LAST_REPORT)) -ge "$REPORT_INTERVAL" ]; then
            echo "[run_srcoptim] ... $STATUS  (elapsed $((E/60))m $((E%60))s)"
            LAST_REPORT=$E
        fi
        sleep 10
    done

    # NFS sync: output ファイル出現を待つ
    for i in $(seq 1 30); do
        [ -f "$OUTPUT_SOURCE" ] && break
        ls -la "$OUT_DIR" >/dev/null 2>&1 || true
        sleep 2
    done
else
    # ===== ローカル実行 =====
    echo "[run_srcoptim] running locally (use --bsub to submit to LSF)..."
    "$WRAPPER"
fi

ELAPSED=$(( $(date +%s) - T0 ))

# ===== Final cost (best effort) =====
if [ ! -f "$OUTPUT_SOURCE" ]; then
    echo "ERROR: optimized source not produced: $OUTPUT_SOURCE" >&2
    [ "$USE_BSUB" = "1" ] && echo "       check bsub log: $BSUB_LOG" >&2
    exit 1
fi

FINAL=""
if [ -f "$COST_CSV" ]; then
    FINAL=$(grep "^total_cost," "$COST_CSV" | head -1 | cut -d',' -f2)
fi
echo "[run_srcoptim] DONE in ${ELAPSED}s"
[ -n "$FINAL" ] && echo "[run_srcoptim] total_cost = $FINAL"
echo "[run_srcoptim] output     = $OUTPUT_SOURCE"
