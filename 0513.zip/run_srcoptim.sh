#!/bin/bash
# run_srcoptim.sh
#
# srcOptim を呼ぶラッパー。
#  - ローカル単体 / ローカル MPI / LSF (bsub) を切り替え可能
#  - tolerance / NILS / BT/BFS / 各種重み等をオプション指定
#  - wrapper script を生成して LSF へ投入 (--bsub)
# tmp0507/run_srcoptim_one.sh の LSF 機能を取り込み、tmp0512 用のオプションも追加。

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ===== バイナリパス =====
SRCOPTIM="$PROJECT_ROOT/build/src/bin/srcOptim/srcOptim"

# ===== LSF / MPI =====
USE_BSUB=0
MPI_NP=1
QUEUE="OPCALL"
JOB_NAME=""

# ===== デフォルト =====
LAYOUT=""
EVP=""
SOURCE_INIT=""
SOURCE_CONFIG=""
PWC=""
SOCS_DIR=""
OUTPUT=""
OUTPUT_DIR=""
RESIST_MODEL=""

LAYER="0/0"
BRIGHTFIELD=1
OPENMP_NUM=8

# 最適化基本パラメータ (tmp0507/run_srcoptim_one.sh の既定値に揃える)
OPTIMIZER="lbfgs"
GRADIENT_METHOD=2
MAX_ITER=200
SLICELEVEL_ROUNDS=30
ROUND_CONV_WINDOW=3
ROUND_CONV_TOL="1e-6"
LBFGS_MEMORY=20
LBFGS_WINDOW=15
LBFGS_REL_TOL="1e-6"
LBFGS_MIN_ITER=20
EARLY_STOP_PATIENCE=20
EARLY_STOP_TOL="1e-6"
GRAD_TOL="1e-4"

# Box / fill
MIN_INTENSITY=0.0
MAX_INTENSITY=2.0
MIN_FILL_RATIO=0.07
WEIGHT_FILL=10
EXP_FILL=1                  # 1=use exp penalty
FILL_PENALTY_K=10

# Multi-Stage / IRLS / SA
EPE_POWER_SCHEDULE="2,4,6,8"
ADAPT_P_SCHEDULE="1.0,3.0,5.0,7.0"
ADAPT_FLOOR_SCHEDULE="0.5,0.1,0.01,0.001"
SA_AMPLITUDE_INIT=0.03
SA_COOLING=0.85
SA_MAX_ROUNDS=20
SA_ALL_STAGES=1
SA_SEED=1

# slice level
SLICE_METHOD="minmax"
SLICE_OBJECTIVE="max_abs_epe"
SLICE_PWC_MODE="all"

# tolerance グローバル (calcMargin と整合させる用)
TOLERANCE="-1"              # -1 = use evp.csv tolerance column

# NILS
WEIGHT_NILS=0
NILS_MIN=2.0
NILS_CD_REF=0.022

# BT/BFS
WEIGHT_BT=0
WEIGHT_BFS=0
BT_POWER=2
BFS_POWER=2
BT_PWC_POS=-1
BT_PWC_NEG=-1
BFS_PWC_NOM=-1
PAIR_CLIPS=""

# 正則化
REG_TYPE="none"
REG_WEIGHT=0.0

# 出力
VERBOSE=1
DRY_RUN=0

usage() {
    cat << 'EOF'
Usage: run_srcoptim.sh [options]

Required:
  -l, --layout FILE              レイアウト (.gds/.oas)
  -e, --evp FILE                 evp.csv
  -f, --source FILE              初期 source illum
  -g, --source_config FILE       source_config.txt
  -p, --pwc FILE                 pwc_config.txt (gen_pwc.py で生成 OK)
  -s, --socs DIR                 SOCS set ディレクトリ (make_socs_set_v2.py で生成済み)
  -o, --output FILE              出力 illum
      --output_dir DIR           cost/log 出力先 (default: --output のディレクトリ)

LSF / MPI (default: ローカル単体実行):
      --bsub                     LSF (bsub) へ投入。wrapper script 経由
  -n, --np N                     MPI ランク数 (default: 1)
                                 1=単体、>1=mpirun -np N (ローカル) or bsub -n N
  -q, --queue NAME               LSF queue (default: OPCALL、--bsub 時のみ)
      --job_name NAME            LSF ジョブ名 (default: srcoptim_<output_base>)

Image calc:
      --layer L/D[,L/D]          default: 0/0
      --brightfield              (default)
      --darkfield
      --resistModel FILE         resistModel
  -j, --openmp N                 (default: 8)

Optimizer (Multi-Stage + IRLS + SA、tmp0507 の既定値):
      --max_iter N               (default: 200)
      --epe_power_schedule CSV   (default: 2,4,6,8)
      --adapt_p_schedule CSV     (default: 1.0,3.0,5.0,7.0)
      --adapt_floor_schedule CSV (default: 0.5,0.1,0.01,0.001)
      --sa_amplitude_init V      (default: 0.03)
      --sa_max_rounds N          (default: 20)
      --sa_all_stages 0|1        (default: 1)
      --sa_seed N                (default: 1)
      --slicelevel_rounds N      (default: 30)
      --round_conv_window N      (default: 3)
      --lbfgs_memory N           (default: 20)
      --lbfgs_min_iter N         (default: 20)
      --early_stop_patience N    (default: 20)
      --grad_tol V               (default: 1e-4)

Constraints / fill:
      --min_intensity V          (default: 0.0)
      --max_intensity V          (default: 2.0)
      --min_fill_ratio V         (default: 0.07)
      --weight_fill V            (default: 10)
      --exp_fill 0|1             (default: 1)
      --fill_penalty_k V         (default: 10)

Tolerance (重要):
      --tolerance V              全評価点の EPE 許容値 [um] (-1=use evp.csv の列)
                                 calcMargin の --tolerance と一致させると整合的

NILS penalty:
      --weight_nils V            NILS ペナルティ重み (0=無効, default: 0)
      --nils_min V               NILS 下限 (default: 2.0)
      --nils_cd_ref V            NILS 参照 CD [um] (default: 0.022 = 22nm)

BT (Bossung Tilt) / BFS (Best Focus Shift):
      --weight_bt V              BT 重み (0=無効, default: 0)
      --weight_bfs V             BFS 重み (0=無効, default: 0)
      --bt_power N               (default: 2)
      --bfs_power N              (default: 2)
      --bt_pwc_pos N             Fp PWC index (-1=auto)
      --bt_pwc_neg N             Fn PWC index (-1=auto)
      --bfs_pwc_nom N            Nom PWC index (-1=auto)
      --pair_clips CSV           適用 clip ID (default: 全 clip)

Regularization:
      --regularization TYPE      none|laplacian|l2|tv|isolated (default: none)
      --regularization_weight V  (default: 0)

Other:
      --verbose / --quiet
      --dry_run                  実行コマンドを表示するだけ
  -h, --help

Example:
  ./run_srcoptim.sh \
      --layout in/out.oas \
      --evp in/ep.csv \
      --source in/initial_source.illum \
      --source_config ../tmp0507/in/source_config.txt \
      --pwc eval_arraypitch2/pwc_a90.txt \
      --socs eval_arraypitch2/socs_set_srcoptim_a90 \
      --output eval_arraypitch2/opt.illum \
      --layer 1/1 \
      --tolerance 0.0035 \
      --weight_nils 5 \
      --weight_bt 1 --weight_bfs 1
EOF
}

# ===== Parse args =====
while [ $# -gt 0 ]; do
    case "$1" in
        -l|--layout)            LAYOUT="$2"; shift 2;;
        -e|--evp)               EVP="$2"; shift 2;;
        -f|--source)            SOURCE_INIT="$2"; shift 2;;
        -g|--source_config)     SOURCE_CONFIG="$2"; shift 2;;
        -p|--pwc)               PWC="$2"; shift 2;;
        -s|--socs)              SOCS_DIR="$2"; shift 2;;
        -o|--output)            OUTPUT="$2"; shift 2;;
        --output_dir)           OUTPUT_DIR="$2"; shift 2;;
        --resistModel)          RESIST_MODEL="$2"; shift 2;;
        --layer)                LAYER="$2"; shift 2;;
        --brightfield)          BRIGHTFIELD=1; shift;;
        --darkfield)            BRIGHTFIELD=0; shift;;
        -j|--openmp)            OPENMP_NUM="$2"; shift 2;;

        --bsub)                 USE_BSUB=1; shift;;
        -n|--np)                MPI_NP="$2"; shift 2;;
        -q|--queue)             QUEUE="$2"; shift 2;;
        --job_name)             JOB_NAME="$2"; shift 2;;

        --max_iter)             MAX_ITER="$2"; shift 2;;
        --epe_power_schedule)   EPE_POWER_SCHEDULE="$2"; shift 2;;
        --adapt_p_schedule)     ADAPT_P_SCHEDULE="$2"; shift 2;;
        --adapt_floor_schedule) ADAPT_FLOOR_SCHEDULE="$2"; shift 2;;
        --sa_amplitude_init)    SA_AMPLITUDE_INIT="$2"; shift 2;;
        --sa_cooling)           SA_COOLING="$2"; shift 2;;
        --sa_max_rounds)        SA_MAX_ROUNDS="$2"; shift 2;;
        --sa_all_stages)        SA_ALL_STAGES="$2"; shift 2;;
        --sa_seed)              SA_SEED="$2"; shift 2;;
        --slicelevel_rounds)    SLICELEVEL_ROUNDS="$2"; shift 2;;
        --round_conv_window)    ROUND_CONV_WINDOW="$2"; shift 2;;
        --round_conv_tol)       ROUND_CONV_TOL="$2"; shift 2;;
        --lbfgs_memory)         LBFGS_MEMORY="$2"; shift 2;;
        --lbfgs_window)         LBFGS_WINDOW="$2"; shift 2;;
        --lbfgs_rel_tol)        LBFGS_REL_TOL="$2"; shift 2;;
        --lbfgs_min_iter)       LBFGS_MIN_ITER="$2"; shift 2;;
        --early_stop_patience)  EARLY_STOP_PATIENCE="$2"; shift 2;;
        --early_stop_tol)       EARLY_STOP_TOL="$2"; shift 2;;
        --grad_tol)             GRAD_TOL="$2"; shift 2;;

        --min_intensity)        MIN_INTENSITY="$2"; shift 2;;
        --max_intensity)        MAX_INTENSITY="$2"; shift 2;;
        --min_fill_ratio)       MIN_FILL_RATIO="$2"; shift 2;;
        --weight_fill)          WEIGHT_FILL="$2"; shift 2;;
        --exp_fill)             EXP_FILL="$2"; shift 2;;
        --fill_penalty_k)       FILL_PENALTY_K="$2"; shift 2;;

        --tolerance)            TOLERANCE="$2"; shift 2;;

        --weight_nils)          WEIGHT_NILS="$2"; shift 2;;
        --nils_min)             NILS_MIN="$2"; shift 2;;
        --nils_cd_ref)          NILS_CD_REF="$2"; shift 2;;

        --weight_bt)            WEIGHT_BT="$2"; shift 2;;
        --weight_bfs)           WEIGHT_BFS="$2"; shift 2;;
        --bt_power)             BT_POWER="$2"; shift 2;;
        --bfs_power)            BFS_POWER="$2"; shift 2;;
        --bt_pwc_pos)           BT_PWC_POS="$2"; shift 2;;
        --bt_pwc_neg)           BT_PWC_NEG="$2"; shift 2;;
        --bfs_pwc_nom)          BFS_PWC_NOM="$2"; shift 2;;
        --pair_clips)           PAIR_CLIPS="$2"; shift 2;;

        --regularization)       REG_TYPE="$2"; shift 2;;
        --regularization_weight) REG_WEIGHT="$2"; shift 2;;

        --verbose)              VERBOSE=1; shift;;
        --quiet)                VERBOSE=0; shift;;
        --dry_run)              DRY_RUN=1; shift;;
        -h|--help)              usage; exit 0;;
        *) echo "ERROR: unknown option: $1" >&2; usage; exit 1;;
    esac
done

# ===== 必須チェック =====
for var in LAYOUT EVP SOURCE_INIT SOURCE_CONFIG PWC SOCS_DIR OUTPUT; do
    if [ -z "${!var}" ]; then
        echo "ERROR: required --${var,,} missing" >&2
        usage; exit 1
    fi
done
for f in "$LAYOUT" "$EVP" "$SOURCE_INIT" "$SOURCE_CONFIG" "$PWC"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: file not found: $f" >&2; exit 1
    fi
done
if [ ! -d "$SOCS_DIR" ]; then
    echo "ERROR: SOCS dir not found: $SOCS_DIR" >&2; exit 1
fi
if [ ! -x "$SRCOPTIM" ]; then
    echo "ERROR: srcOptim not built: $SRCOPTIM" >&2
    echo "       cd $PROJECT_ROOT/build && make srcOptim" >&2
    exit 1
fi

# ===== 出力先 =====
if [ -z "$OUTPUT_DIR" ]; then
    OUTPUT_DIR=$(dirname "$OUTPUT")
fi
mkdir -p "$OUTPUT_DIR"
OUT_BASE=$(basename "$OUTPUT" .illum)
COST_CSV="$OUTPUT_DIR/${OUT_BASE}_cost.csv"
LOG_CSV="$OUTPUT_DIR/${OUT_BASE}_log.csv"
RUN_LOG="$OUTPUT_DIR/${OUT_BASE}_run.log"

# ===== コマンド構築 =====
CMD=("$SRCOPTIM"
    -l "$LAYOUT"
    -s "$SOCS_DIR"
    -g "$SOURCE_CONFIG"
    -f "$SOURCE_INIT"
    -p "$PWC"
    -e "$EVP"
    -o "$OUTPUT"
    --cost_output "$COST_CSV"
    --log_output "$LOG_CSV"
    --optimizer "$OPTIMIZER"
    --max_iter "$MAX_ITER"
    --gradient_method "$GRADIENT_METHOD"
    --layer "$LAYER"
    --epe_power_schedule "$EPE_POWER_SCHEDULE"
    --adaptive_weight_p_schedule "$ADAPT_P_SCHEDULE"
    --adaptive_weight_floor_schedule "$ADAPT_FLOOR_SCHEDULE"
    --sa_amplitude_init "$SA_AMPLITUDE_INIT"
    --sa_cooling "$SA_COOLING"
    --sa_max_rounds "$SA_MAX_ROUNDS"
    --sa_all_stages "$SA_ALL_STAGES"
    --sa_seed "$SA_SEED"
    --slice_method "$SLICE_METHOD"
    --slice_objective "$SLICE_OBJECTIVE"
    --slice_pwc_mode "$SLICE_PWC_MODE"
    --sliceLevelRounds "$SLICELEVEL_ROUNDS"
    --round_conv_window "$ROUND_CONV_WINDOW"
    --round_conv_tol "$ROUND_CONV_TOL"
    --lbfgs_memory "$LBFGS_MEMORY"
    --lbfgs_window "$LBFGS_WINDOW"
    --lbfgs_rel_tol "$LBFGS_REL_TOL"
    --lbfgs_min_iter "$LBFGS_MIN_ITER"
    --early_stop_patience "$EARLY_STOP_PATIENCE"
    --early_stop_tol "$EARLY_STOP_TOL"
    --grad_tol "$GRAD_TOL"
    --min_intensity "$MIN_INTENSITY"
    --max_intensity "$MAX_INTENSITY"
    --min_fill_ratio "$MIN_FILL_RATIO"
    --weight_fill "$WEIGHT_FILL"
    --fill_penalty_k "$FILL_PENALTY_K"
    -j "$OPENMP_NUM"
)

if [ "$BRIGHTFIELD" = "1" ]; then
    CMD+=(--brightfield)
else
    CMD+=(--darkfield)
fi
if [ "$EXP_FILL" = "1" ]; then
    CMD+=(--exp_fill_penalty)
fi
if [ "$VERBOSE" = "1" ]; then
    CMD+=(--verbose)
fi
if [ -n "$RESIST_MODEL" ]; then
    CMD+=(--resistModel "$RESIST_MODEL")
fi

# Tolerance (-1 ならスキップ = evp.csv 使用)
if [ "$TOLERANCE" != "-1" ]; then
    CMD+=(--tolerance "$TOLERANCE")
fi

# NILS
if awk -v w="$WEIGHT_NILS" 'BEGIN{exit !(w>0)}'; then
    CMD+=(--weight_nils "$WEIGHT_NILS"
          --nils_min "$NILS_MIN"
          --nils_cd_ref "$NILS_CD_REF")
fi

# BT / BFS
if awk -v w="$WEIGHT_BT" 'BEGIN{exit !(w>0)}'; then
    CMD+=(--weight_bt "$WEIGHT_BT" --bt_power "$BT_POWER")
    [ "$BT_PWC_POS" != "-1" ] && CMD+=(--bt_pwc_pos "$BT_PWC_POS")
    [ "$BT_PWC_NEG" != "-1" ] && CMD+=(--bt_pwc_neg "$BT_PWC_NEG")
fi
if awk -v w="$WEIGHT_BFS" 'BEGIN{exit !(w>0)}'; then
    CMD+=(--weight_bfs "$WEIGHT_BFS" --bfs_power "$BFS_POWER")
    [ "$BFS_PWC_NOM" != "-1" ] && CMD+=(--bfs_pwc_nom "$BFS_PWC_NOM")
fi
if [ -n "$PAIR_CLIPS" ]; then
    CMD+=(--pair_clips "$PAIR_CLIPS")
fi

# Regularization
if [ "$REG_TYPE" != "none" ] && awk -v w="$REG_WEIGHT" 'BEGIN{exit !(w>0)}'; then
    CMD+=(--regularization "$REG_TYPE" --regularization_weight "$REG_WEIGHT")
fi

# ===== Job name (LSF 用) =====
[ -z "$JOB_NAME" ] && JOB_NAME="srcoptim_$(basename "$OUTPUT" .illum)"
BSUB_LOG="$OUTPUT_DIR/${OUT_BASE}_bsub.log"

# ===== コマンド前置 (mpirun / bsub の準備) =====
# (a) LSF (bsub) モード: wrapper script を生成して bsub
# (b) ローカル MPI モード: mpirun -np N で起動 (MPI_NP>1 時)
# (c) ローカル単体モード: そのまま実行 (MPI_NP=1)

echo "[run_srcoptim] mode:"
if [ "$USE_BSUB" = "1" ]; then
    echo "    LSF (bsub) -n $MPI_NP -q $QUEUE -J $JOB_NAME"
elif [ "$MPI_NP" -gt 1 ]; then
    echo "    Local MPI: mpirun -np $MPI_NP"
else
    echo "    Local single process"
fi
echo "[run_srcoptim] command:"
printf '  %q' "${CMD[@]}"; echo
echo "[run_srcoptim] outputs:"
echo "    optim source: $OUTPUT"
echo "    cost      :  $COST_CSV"
echo "    log       :  $LOG_CSV"
echo "    run log   :  $RUN_LOG"
[ "$USE_BSUB" = "1" ] && echo "    bsub log  :  $BSUB_LOG"

if [ "$DRY_RUN" = "1" ]; then
    echo "[run_srcoptim] dry_run mode, skipping execution"
    exit 0
fi

T0=$(date +%s)

if [ "$USE_BSUB" = "1" ]; then
    # ===== LSF (bsub) 投入 =====
    # wrapper script を作って bsub。LSF 内では LSB_DJOB_HOSTFILE から
    # MPI np を自動計算 (tmp0507/run_srcoptim_one.sh と同じパターン)。
    WRAPPER="$OUTPUT_DIR/${OUT_BASE}_wrapper.sh"
    {
        echo "#!/bin/bash"
        echo "set -e"
        echo ""
        echo "if [ -n \"\$LSB_DJOB_HOSTFILE\" ]; then"
        echo "    NP=\$(wc -l < \"\$LSB_DJOB_HOSTFILE\")"
        echo "    RUNCMD=\"mpirun -bootstrap lsf -np \$NP\""
        echo "elif [ \"$MPI_NP\" -gt 1 ]; then"
        echo "    RUNCMD=\"mpirun -np $MPI_NP\""
        echo "else"
        echo "    RUNCMD=\"\""
        echo "fi"
        echo ""
        # quote each arg
        printf '\\$RUNCMD'
        for arg in "${CMD[@]}"; do
            printf ' %q' "$arg"
        done
        printf '\n'
    } > "$WRAPPER"
    chmod +x "$WRAPPER"

    echo "[run_srcoptim] wrapper: $WRAPPER"
    echo "[run_srcoptim] submitting to LSF..."
    OUT_MSG=$(bsub \
        -n "$MPI_NP" \
        -R "span[ptile=1]" \
        -q "$QUEUE" \
        -J "$JOB_NAME" \
        -o "$BSUB_LOG" \
        "$WRAPPER" 2>&1)
    JOBID=$(echo "$OUT_MSG" | sed -n 's/.*Job <\([0-9]*\)>.*/\1/p')
    if [ -z "$JOBID" ]; then
        echo "ERROR: bsub failed: $OUT_MSG" >&2; exit 1
    fi
    echo "[run_srcoptim] submitted: JobID=$JOBID, log=$BSUB_LOG"

    # bjobs で完了待ち (tmp0507/run_srcoptim_one.sh のロジックを移植)
    JOB_SEEN=false
    UNKNOWN_SINCE=0
    UNKNOWN_GRACE=60
    LAST_REPORT=0
    REPORT_INTERVAL=30
    while true; do
        STATUS=$(bjobs -noheader -o "stat" "$JOBID" 2>/dev/null || echo "UNKNOWN")
        case "$STATUS" in
            DONE)
                E=$(( $(date +%s) - T0 ))
                echo "[run_srcoptim] job DONE (elapsed $((E/60))m $((E%60))s)"
                RC=0
                break ;;
            EXIT)
                echo "ERROR: job EXIT (failed). JobID=$JOBID, log=$BSUB_LOG" >&2
                RC=1
                break ;;
            UNKNOWN|"")
                if [ "$JOB_SEEN" = true ]; then
                    echo "[run_srcoptim] job status UNKNOWN after seen: assuming done"
                    RC=0
                    break
                fi
                [ "$UNKNOWN_SINCE" -eq 0 ] && UNKNOWN_SINCE=$(date +%s)
                if [ $(( $(date +%s) - UNKNOWN_SINCE )) -ge "$UNKNOWN_GRACE" ]; then
                    echo "[run_srcoptim] job never seen by bjobs (assuming flushed-done)"
                    RC=0
                    break
                fi
                ;;
            *)
                JOB_SEEN=true
                UNKNOWN_SINCE=0
                ;;
        esac
        E=$(( $(date +%s) - T0 ))
        if [ $((E - LAST_REPORT)) -ge "$REPORT_INTERVAL" ]; then
            echo "[run_srcoptim] ... $STATUS  (elapsed $((E/60))m $((E%60))s)"
            LAST_REPORT=$E
        fi
        sleep 10
    done

    # NFS 同期待ち
    if [ "$RC" = "0" ]; then
        for i in $(seq 1 30); do
            [ -f "$OUTPUT" ] && break
            ls -la "$OUTPUT_DIR" >/dev/null 2>&1 || true
            sleep 2
        done
        # bsub のログを RUN_LOG にコピー
        [ -f "$BSUB_LOG" ] && cp "$BSUB_LOG" "$RUN_LOG" 2>/dev/null || true
    fi
elif [ "$MPI_NP" -gt 1 ]; then
    # ===== ローカル MPI 実行 =====
    mpirun -np "$MPI_NP" "${CMD[@]}" 2>&1 | tee "$RUN_LOG"
    RC=${PIPESTATUS[0]}
else
    # ===== ローカル単体実行 =====
    "${CMD[@]}" 2>&1 | tee "$RUN_LOG"
    RC=${PIPESTATUS[0]}
fi

ELAPSED=$(( $(date +%s) - T0 ))
echo "[run_srcoptim] done in ${ELAPSED}s (rc=$RC)"
exit $RC
