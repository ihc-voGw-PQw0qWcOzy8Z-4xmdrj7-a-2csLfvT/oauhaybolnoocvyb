#!/usr/bin/env python3
"""view_margin.py

calcMargin が出力した grid.csv を読み込み、

  - プロセスウィンドウ図 (横軸 defocus[nm], 縦軸 dose[%]):
      OK 領域境界 (等高線) + max|EPE| ヒートマップ + 内接楕円
      --per_evp <file> 指定時は cutline 別の OK 境界線も重ねて描画
  - ED プロット (横軸 DoF[nm], 縦軸 EL[%]):
      内接楕円中心を共有する「PW に内接する軸並行楕円」の
      (DoF, EL) フロンティア曲線

を 2 つの subplot として表示・PNG 保存する。

Usage:
    python3 view_margin.py [grid.csv] [-o margin_plot.png]
    python3 view_margin.py [grid.csv] --per_evp per_evp.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse


# ----------------------------------------------------------------------
# データ読み込み
# ----------------------------------------------------------------------
def load_grid(path: Path):
    """grid.csv → (defocus[nD], dose[nE], ok[nE,nD], epe[nE,nD])"""
    rows = list(csv.DictReader(open(path)))
    defocus = np.array(sorted({float(r["defocus_nm"]) for r in rows}))
    dose = np.array(sorted({float(r["dose_pct"]) for r in rows}))
    nD = len(defocus)
    nE = len(dose)

    d_index = {float(d): i for i, d in enumerate(defocus)}
    e_index = {float(e): j for j, e in enumerate(dose)}

    ok = np.zeros((nE, nD), dtype=bool)
    epe = np.zeros((nE, nD), dtype=float)
    for r in rows:
        i = d_index[float(r["defocus_nm"])]
        j = e_index[float(r["dose_pct"])]
        ok[j, i] = bool(int(r["ok"]))
        epe[j, i] = float(r["maxAbsEpe_um"])

    return defocus, dose, ok, epe


# ----------------------------------------------------------------------
# カットラインペア別集計 (per_evp.csv)
# ----------------------------------------------------------------------
# cutlineID とペア内ロールの対応:
#   X 方向ペア = cl_xl (role 0) + cl_xr (role 1)
#   Y 方向ペア = cl_yb (role 0) + cl_yt (role 1)
# delta_CD は EvpData::buildCutlinePairs と同じく「EPE1 + EPE2」で計算する。
_PAIR_MAP = {
    "cl_xl": ("X", 0),
    "cl_xr": ("X", 1),
    "cl_yb": ("Y", 0),
    "cl_yt": ("Y", 1),
}


def load_per_evp_by_pair(path: Path, defocus: np.ndarray, dose: np.ndarray):
    """per_evp.csv をカットラインペア単位で集計する。

    Returns:
        dict pair_key -> {
            "delta_cd": ndarray[nE, nD]  各点での |EPE1 + EPE2|
            "max_abs":  ndarray[nE, nD]  各点での max(|EPE1|, |EPE2|)
            "tol":      float            ペア内最大 tolerance
        }
        pair_key = "{direction}_clip{clipID}" (例: "X_clip0", "Y_clip6")
    """
    rows = list(csv.DictReader(open(path)))
    nD = len(defocus); nE = len(dose)
    d_index = {float(d): i for i, d in enumerate(defocus)}
    e_index = {float(e): j for j, e in enumerate(dose)}

    # accumulator: (clipID, direction) -> {(j, i): [epe_point1, epe_point2], ...}
    pair_data: dict = {}
    pair_tol: dict = {}

    for r in rows:
        cl = r["cutlineID"]
        if cl not in _PAIR_MAP:
            continue
        direction, role = _PAIR_MAP[cl]
        clip_id = int(r["clipID"])
        pair_key = (clip_id, direction)

        i = d_index[float(r["defocus_nm"])]
        j = e_index[float(r["dose_pct"])]
        epe = float(r["epe_um"])
        tol = float(r["tolerance_um"])

        slot = pair_data.setdefault(pair_key, {})
        slot.setdefault((j, i), [None, None])[role] = epe
        if tol > pair_tol.get(pair_key, 0.0):
            pair_tol[pair_key] = tol

    pair_metrics: dict = {}
    for (clip_id, direction), grid in pair_data.items():
        label = f"{direction}_clip{clip_id}"
        dcd = np.full((nE, nD), np.nan)
        mab = np.full((nE, nD), np.nan)
        for (j, i), (e1, e2) in grid.items():
            if e1 is None or e2 is None:
                continue
            dcd[j, i] = abs(e1 + e2)
            mab[j, i] = max(abs(e1), abs(e2))
        pair_metrics[label] = {
            "delta_cd": dcd,
            "max_abs": mab,
            "tol": pair_tol[(clip_id, direction)],
        }
    return pair_metrics


# ----------------------------------------------------------------------
# 軸並行楕円フィッティング
# ----------------------------------------------------------------------
def b_max_for(a: float, cx: float, cy: float,
              ng_d: np.ndarray, ng_e: np.ndarray,
              dose_min: float, dose_max: float) -> float:
    """中心 (cx, cy)・defocus 半径 a を固定したとき、楕円が NG 点を含まない
    最大の dose 半径 b を返す。

    NG 点 (d_k, e_k) に対して、楕円外側条件:
        ((d_k - cx)/a)² + ((e_k - cy)/b)² >= 1
    を全 NG 点について満たすこと。

    左辺第一項を s = ((d_k-cx)/a)² とおき:
      - s >= 1 の NG 点: 楕円外なので b に制約を与えない
      - s <  1 の NG 点: b² <= (e_k-cy)² / (1 - s)
    より、b の上限 = sqrt(min over NG 点) を返す。

    さらに dose の物理範囲も上限とする。
    """
    phys_b_limit = max(cy - dose_min, dose_max - cy)
    if a <= 1e-9:
        # a → 0 の極限: 楕円は defocus = cx の縦線。
        # defocus が cx と同じ列にある NG 点が dose 方向距離 = b の上限を決める。
        same_d = np.isclose(ng_d, cx)
        if not np.any(same_d):
            return phys_b_limit
        dy = np.abs(ng_e[same_d] - cy)
        return min(float(dy.min()), phys_b_limit)
    dx_norm_sq = ((ng_d - cx) / a) ** 2  # shape (n_ng,)
    inside_x = dx_norm_sq < 1.0
    if not np.any(inside_x):
        # 全 NG 点が楕円の外 (defocus 方向で)。dose 範囲のみが上限
        return phys_b_limit
    dy_sq = (ng_e[inside_x] - cy) ** 2
    s = dx_norm_sq[inside_x]
    # (e_k - cy)² / (1 - s) の最小 sqrt
    denom = 1.0 - s
    b_sq_upper = dy_sq / denom
    b_upper = np.sqrt(b_sq_upper.min())
    # dose 物理範囲でも制約
    return min(float(b_upper), phys_b_limit)


def fit_max_inscribed_ellipse(defocus, dose, ok, n_a_samples: int = 200):
    """OK 領域に内接する軸並行楕円のうち、面積最大のものを返す。

    Returns:
        (cx, cy, a, b) または None (OK 領域が空)
    """
    nE, nD = ok.shape
    if not np.any(ok):
        return None

    DD, EE = np.meshgrid(defocus, dose)
    ng_d = DD[~ok]
    ng_e = EE[~ok]
    dose_min = float(dose.min())
    dose_max = float(dose.max())
    defocus_min = float(defocus.min())
    defocus_max = float(defocus.max())

    best = None  # (cx, cy, a, b, area)

    # OK 点を中心候補にする
    for j_c, e in enumerate(dose):
        for i_c, d in enumerate(defocus):
            if not ok[j_c, i_c]:
                continue
            cx, cy = float(d), float(e)
            a_max = max(cx - defocus_min, defocus_max - cx)
            if a_max <= 0:
                continue

            a_samples = np.linspace(a_max / n_a_samples, a_max, n_a_samples)
            for a in a_samples:
                b = b_max_for(a, cx, cy, ng_d, ng_e, dose_min, dose_max)
                if b <= 0:
                    continue
                area = a * b
                if best is None or area > best[4]:
                    best = (cx, cy, a, b, area)

    if best is None:
        return None
    cx, cy, a, b, _ = best
    return cx, cy, a, b


# ----------------------------------------------------------------------
# ED プロット用フロンティア
# ----------------------------------------------------------------------
def ed_frontier(defocus, dose, ok, cx: float, cy: float, n_samples: int = 200):
    """中心 (cx, cy) を共有する軸並行楕円について、PW に内接する
    (DoF, EL) = (2a, 2b) のフロンティアを返す。

    a を 0 から a_max まで動かし、各 a で b の最大値を計算する。
    """
    DD, EE = np.meshgrid(defocus, dose)
    ng_d = DD[~ok]
    ng_e = EE[~ok]
    dose_min = float(dose.min())
    dose_max = float(dose.max())
    defocus_min = float(defocus.min())
    defocus_max = float(defocus.max())

    a_max = max(cx - defocus_min, defocus_max - cx)
    # b_max_for は a≤1e-9 の場合 cx 上の NG 点までの dose 距離を返す。
    a_values = np.linspace(0.0, a_max, n_samples)
    b_values = np.zeros_like(a_values)
    for k, a in enumerate(a_values):
        b_values[k] = b_max_for(a, cx, cy, ng_d, ng_e, dose_min, dose_max)

    # フロンティアは「(a, b) のうち、a を大きくしたら b は単調減少」になる集合の境界。
    # a 降順から見て b の累積最大を取れば「a が k 以上の領域での実現可能 b の上限」が
    # 得られ、それが (a, b) パレート前線になる。
    b_pareto = np.maximum.accumulate(b_values[::-1])[::-1]
    return 2.0 * a_values, 2.0 * b_pareto  # (DoF, EL)


# ----------------------------------------------------------------------
# プロット
# ----------------------------------------------------------------------
def plot_pw(ax, defocus, dose, ok, epe, ellipse,
            pair_metrics=None, pair_mode: str = "delta_cd"):
    """プロセスウィンドウ図を描画。

    pair_metrics が与えられた場合、カットラインペア (X_clipN / Y_clipN) ごとの
    OK 境界を破線で重ねる。pair_mode で OK 判定の指標を切り替える:
        "delta_cd": |EPE1 + EPE2| < tol  (CD ずれが許容範囲)
        "max_abs" : max(|EPE1|, |EPE2|) < tol  (両端位置が個別に許容範囲)
    """
    DD, EE = np.meshgrid(defocus, dose)
    from matplotlib.lines import Line2D

    # max|EPE| をカラーマップ (μm → nm 表示にすると読みやすい)
    epe_nm = epe * 1000.0
    pcm = ax.pcolormesh(DD, EE, epe_nm, shading="nearest",
                        cmap="RdYlBu_r", vmin=0.0, vmax=float(epe_nm.max()))
    cbar = plt.colorbar(pcm, ax=ax, label="max|EPE| [nm]")
    cbar.ax.tick_params(labelsize=9)

    # 全 evp の OK 領域境界 (黒, 太め)
    ax.contour(DD, EE, ok.astype(float), levels=[0.5],
               colors="black", linewidths=2.0)

    # カットラインペア別の OK 領域境界 (色別)
    if pair_metrics:
        if pair_mode not in ("delta_cd", "max_abs"):
            pair_mode = "delta_cd"
        cmap = plt.get_cmap("tab10")
        legend_handles = []
        # ペア名でソートして色割当てを安定化
        for idx, label in enumerate(sorted(pair_metrics.keys())):
            data = pair_metrics[label]
            metric = data[pair_mode]
            tol = data["tol"] if data["tol"] > 0 else 1e9
            # NaN (= 片方の evp が欠損) は NG 扱いにしたいので大きい値で埋める
            metric_filled = np.where(np.isnan(metric), 1e9, metric)
            ok_pair = metric_filled < tol
            color = cmap(idx)
            ax.contour(DD, EE, ok_pair.astype(float), levels=[0.5],
                       colors=[color], linewidths=1.4, linestyles="--")
            legend_handles.append(Line2D([0], [0], color=color, linestyle="--",
                                          linewidth=1.4, label=label))
        if legend_handles:
            legend_handles.insert(0, Line2D([0], [0], color="black",
                                             linewidth=2.0, label="all evp"))
            ax.legend(handles=legend_handles, loc="lower right",
                      fontsize=8, framealpha=0.85,
                      title=f"OK by pair ({pair_mode})", title_fontsize=8)

    # 内接楕円
    if ellipse is not None:
        cx, cy, a, b = ellipse
        ell = Ellipse((cx, cy), 2 * a, 2 * b,
                      fill=False, edgecolor="red", linewidth=2.0)
        ax.add_patch(ell)
        ax.plot(cx, cy, "r+", markersize=10)

    ax.set_xlabel("Defocus [nm]")
    ax.set_ylabel("Dose [%]")
    title = "Process Window"
    if ellipse is not None:
        title += (f"\ninscribed ellipse: DoF={2*ellipse[2]:.1f} nm, "
                  f"EL={2*ellipse[3]:.1f} %")
    ax.set_title(title)
    ax.grid(True, alpha=0.3)


def plot_ed(ax, dof_curve, el_curve, ellipse):
    # フロンティア曲線
    ax.plot(dof_curve, el_curve, "b-", linewidth=2, label="ED frontier")
    ax.fill_between(dof_curve, 0, el_curve, alpha=0.25, color="C0")

    # 内接楕円の代表点 (面積最大の (DoF, EL))
    if ellipse is not None:
        cx, cy, a, b = ellipse
        ax.plot(2 * a, 2 * b, "r*", markersize=14, label="max-area ellipse")

    ax.set_xlabel("DoF [nm]")
    ax.set_ylabel("EL [%]")
    ax.set_xlim(left=0)
    ax.set_ylim(bottom=0)
    ax.grid(True)
    ax.legend(loc="upper right")
    ax.set_title("ED Plot")


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("grid", nargs="?", default="grid.csv",
                        help="calcMargin grid CSV (default: grid.csv)")
    parser.add_argument("-o", "--output", default="margin_plot.png",
                        help="output PNG (default: margin_plot.png)")
    parser.add_argument("--no_show", action="store_true",
                        help="skip plt.show() (PNG だけ作る)")
    parser.add_argument("--n_a", type=int, default=200,
                        help="ED frontier sampling resolution")
    parser.add_argument("--per_evp", default="",
                        help="per_evp.csv を読んでカットラインペア別 OK 境界線を重ねる")
    parser.add_argument("--pair_mode", default="max_abs",
                        choices=["max_abs", "delta_cd"],
                        help="ペア OK 判定指標 (default: max_abs = "
                             "max(|EPE1|,|EPE2|) — all_evp 境界と包含関係になる)")
    args = parser.parse_args()

    grid_path = Path(args.grid)
    if not grid_path.exists():
        print(f"ERROR: not found: {grid_path}", file=sys.stderr)
        return 1

    defocus, dose, ok, epe = load_grid(grid_path)
    n_ok = int(ok.sum())
    print(f"grid: {len(defocus)} defocus × {len(dose)} dose, OK={n_ok}/{ok.size}")

    pair_metrics = None
    if args.per_evp:
        per_evp_path = Path(args.per_evp)
        if not per_evp_path.exists():
            print(f"WARNING: per_evp file not found: {per_evp_path}", file=sys.stderr)
        else:
            pair_metrics = load_per_evp_by_pair(per_evp_path, defocus, dose)
            print(f"loaded per_evp: {len(pair_metrics)} cutline pairs "
                  f"(mode={args.pair_mode})")
            for label in sorted(pair_metrics.keys()):
                data = pair_metrics[label]
                metric = data[args.pair_mode]
                tol = data["tol"]
                ok_count = int(np.nansum(metric < tol)) if tol > 0 else 0
                total = int(np.sum(~np.isnan(metric)))
                print(f"  {label}: tol={tol*1000:.3f} nm, "
                      f"OK={ok_count}/{total}")

    ellipse = fit_max_inscribed_ellipse(defocus, dose, ok)
    if ellipse is None:
        print("WARNING: no OK region found, ellipse omitted")
        dof_curve = np.array([0.0])
        el_curve = np.array([0.0])
    else:
        cx, cy, a, b = ellipse
        print(f"max inscribed ellipse: center=({cx:.2f}, {cy:.2f}), "
              f"DoF=2a={2*a:.2f} nm, EL=2b={2*b:.2f} %, "
              f"area={2*a * 2*b:.2f} (nm × %)")
        dof_curve, el_curve = ed_frontier(defocus, dose, ok, cx, cy,
                                           n_samples=args.n_a)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.5, 6.0))
    plot_pw(ax1, defocus, dose, ok, epe, ellipse,
            pair_metrics=pair_metrics, pair_mode=args.pair_mode)
    plot_ed(ax2, dof_curve, el_curve, ellipse)
    fig.tight_layout()

    fig.savefig(args.output, dpi=120)
    print(f"saved: {args.output}")
    if not args.no_show:
        plt.show()

    return 0


if __name__ == "__main__":
    sys.exit(main())
