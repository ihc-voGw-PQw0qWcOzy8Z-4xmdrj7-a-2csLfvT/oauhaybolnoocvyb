#!/bin/bash
# run_margin.sh
#
# 最適化済み光源 (.illum) に対して EL-DoF マージンを計算し、PNG で表示する。
# SOCS が未生成なら make_socs_for_margin.py で自動生成する。
#
# 処理フロー:
#   1. socs_dir が未指定または .ready が無い場合 → make_socs_for_margin.py で生成
#   2. calcMargin で grid.csv / per_evp.csv / cost.csv / PPM 出力
#   3. view_margin.py で margin_plot.png を生成 (横軸 defocus / 縦軸 dose の
#      Process Window + 内接楕円 + カットラインペア別境界 + ED プロット)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# ===== ツールパス =====
CALCMARGIN="$PROJECT_ROOT/build/src/bin/calcMargin/calcMargin"
MAKE_SOCS_PY="$PROJECT_ROOT/mkSocsSet/make_socs_for_margin.py"
VIEW_MARGIN_PY="$SCRIPT_DIR/view_margin.py"
MTCCPATH_DEFAULT="/home/masaki/myspace/tools/kdr"

# ===== デフォルト =====
SOURCE_ILLUM="$SCRIPT_DIR/optimized_source.illum"
LAYOUT="$SCRIPT_DIR/in/LMH.oas"
EVP="$SCRIPT_DIR/in/evp_0_6.csv"
INI="$SCRIPT_DIR/in/ini.txt"
SOCS_DIR="$SCRIPT_DIR/socs_margin"

OUTPUT_DIR="$SCRIPT_DIR"

# Process window グリッド
DEFOCUS_MIN=-140
DEFOCUS_MAX=140
DEFOCUS_STEP=14
DOSE_MIN=-20
DOSE_MAX=20
DOSE_STEP=2

# 計測
TOLERANCE=0.005     # μm = 5 nm
LAYER="0/0"
BRIGHTFIELD=1       # 1=bright, 0=dark
KERNEL_NUM=30
OPENMP_NUM=8

# 再生成オプション
REBUILD_SOCS=0
NO_SHOW=0
PAIR_MODE="max_abs"

# slice level (空なら calcMargin が auto)
SLICE_LEVEL=""

# M3D 関連
USE_M3D=0
CGRP_X="0.5"
CGRP_Y="0.5"
CGRP_XY="0.5:0.5"
CGRP_FILE=""

usage() {
    cat << EOF
Usage: $0 [options]

Input files (default は tmp0512 用):
  -f, --source FILE        optimized .illum  (default: $SOURCE_ILLUM)
  -l, --layout FILE        OASIS/GDS layout  (default: $LAYOUT)
  -e, --evp FILE           evp.csv           (default: $EVP)
  -i, --ini FILE           base ini.txt for SOCS生成 (default: $INI)

SOCS:
  -s, --socs_dir DIR       SOCS directory    (default: $SOCS_DIR)
                           無ければ make_socs_for_margin.py で自動生成
      --rebuild_socs       既存 SOCS を強制再生成
      --kernel_num N       (default: $KERNEL_NUM)
      --mtcc_path DIR      MTCCPATH (default: $MTCCPATH_DEFAULT)
      --m3d                M3D 用 SOCS を生成 (maketcc_m3d + maketcc_cgrp)
                           default は M2D (maketcc3)
      --cgrp_x VAL         maketcc_cgrp --x (default: $CGRP_X、M3D 時のみ)
      --cgrp_y VAL         maketcc_cgrp --y (default: $CGRP_Y)
      --cgrp_xy VAL        maketcc_cgrp --xy (default: $CGRP_XY)
      --cgrp_file FILE     既存 CGRP を再利用 (空=自動生成)

Grid:
      --defocus_min NM     (default: $DEFOCUS_MIN)
      --defocus_max NM     (default: $DEFOCUS_MAX)
      --defocus_step NM    (default: $DEFOCUS_STEP)
      --dose_min PCT       (default: $DOSE_MIN)
      --dose_max PCT       (default: $DOSE_MAX)
      --dose_step PCT      (default: $DOSE_STEP)

Calc:
      --tolerance UM       EPE 許容値 [μm] (default: $TOLERANCE = 5nm)
      --slice_level VAL    閾値固定 (default: auto)
      --layer L/D[,L/D]    (default: $LAYER)
      --brightfield        (default: bright)
      --darkfield
  -j, --openmp N           OpenMP threads (default: $OPENMP_NUM)

Output:
  -o, --output_dir DIR     出力先 (default: $OUTPUT_DIR)
      --no_show            view_margin.py の plt.show() を抑制
      --pair_mode MODE     max_abs (default) | delta_cd

  -h, --help               このヘルプを表示
EOF
}

# ===== 引数パース =====
while [ $# -gt 0 ]; do
    case "$1" in
        -f|--source)        SOURCE_ILLUM="$2"; shift 2;;
        -l|--layout)        LAYOUT="$2"; shift 2;;
        -e|--evp)           EVP="$2"; shift 2;;
        -i|--ini)           INI="$2"; shift 2;;
        -s|--socs_dir)      SOCS_DIR="$2"; shift 2;;
        --rebuild_socs)     REBUILD_SOCS=1; shift;;
        --kernel_num)       KERNEL_NUM="$2"; shift 2;;
        --mtcc_path)        MTCCPATH_DEFAULT="$2"; shift 2;;
        --m3d)              USE_M3D=1; shift;;
        --cgrp_x)           CGRP_X="$2"; shift 2;;
        --cgrp_y)           CGRP_Y="$2"; shift 2;;
        --cgrp_xy)          CGRP_XY="$2"; shift 2;;
        --cgrp_file)        CGRP_FILE="$2"; shift 2;;
        --defocus_min)      DEFOCUS_MIN="$2"; shift 2;;
        --defocus_max)      DEFOCUS_MAX="$2"; shift 2;;
        --defocus_step)     DEFOCUS_STEP="$2"; shift 2;;
        --dose_min)         DOSE_MIN="$2"; shift 2;;
        --dose_max)         DOSE_MAX="$2"; shift 2;;
        --dose_step)        DOSE_STEP="$2"; shift 2;;
        --tolerance)        TOLERANCE="$2"; shift 2;;
        --slice_level)      SLICE_LEVEL="$2"; shift 2;;
        --layer)            LAYER="$2"; shift 2;;
        --brightfield)      BRIGHTFIELD=1; shift;;
        --darkfield)        BRIGHTFIELD=0; shift;;
        -j|--openmp)        OPENMP_NUM="$2"; shift 2;;
        -o|--output_dir)    OUTPUT_DIR="$2"; shift 2;;
        --no_show)          NO_SHOW=1; shift;;
        --pair_mode)        PAIR_MODE="$2"; shift 2;;
        -h|--help)          usage; exit 0;;
        *) echo "ERROR: unknown option: $1" >&2; usage; exit 1;;
    esac
done

# ===== 入力チェック =====
for f in "$SOURCE_ILLUM" "$LAYOUT" "$EVP"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: required file not found: $f" >&2
        exit 1
    fi
done
if [ ! -x "$CALCMARGIN" ]; then
    echo "ERROR: calcMargin binary not found / not executable: $CALCMARGIN" >&2
    echo "       cd $PROJECT_ROOT/build && make calcMargin" >&2
    exit 1
fi
if [ ! -x "$MAKE_SOCS_PY" ]; then
    chmod +x "$MAKE_SOCS_PY" 2>/dev/null || true
fi
if [ ! -f "$VIEW_MARGIN_PY" ]; then
    echo "ERROR: view_margin.py not found: $VIEW_MARGIN_PY" >&2
    exit 1
fi

mkdir -p "$OUTPUT_DIR"

OUT_MARGIN="$OUTPUT_DIR/margin.csv"
OUT_GRID="$OUTPUT_DIR/grid.csv"
OUT_PER_EVP="$OUTPUT_DIR/per_evp.csv"
OUT_PPM="$OUTPUT_DIR/heatmap.ppm"
OUT_PPM_OK="$OUTPUT_DIR/ok_map.ppm"
OUT_PNG="$OUTPUT_DIR/margin_plot.png"

# ===== Step 1: SOCS 準備 =====
NEED_GEN=0
if [ "$REBUILD_SOCS" = "1" ]; then
    NEED_GEN=1
elif [ ! -d "$SOCS_DIR" ] || [ ! -f "$SOCS_DIR/.ready" ]; then
    NEED_GEN=1
fi

if [ "$NEED_GEN" = "1" ]; then
    if [ ! -f "$INI" ]; then
        echo "ERROR: --ini is required when generating SOCS (not found: $INI)" >&2
        exit 1
    fi
    echo "[run_margin] Step 1: generating SOCS files in $SOCS_DIR"
    echo "  source = $SOURCE_ILLUM"
    echo "  ini    = $INI"
    echo "  defocus = [$DEFOCUS_MIN, $DEFOCUS_MAX] step $DEFOCUS_STEP nm"

    if [ "$REBUILD_SOCS" = "1" ]; then
        rm -rf "$SOCS_DIR"
    fi

    M3D_OPTS=()
    if [ "$USE_M3D" = "1" ]; then
        M3D_OPTS+=(--m3d --cgrp_x "$CGRP_X" --cgrp_y "$CGRP_Y" --cgrp_xy "$CGRP_XY")
        [ -n "$CGRP_FILE" ] && M3D_OPTS+=(--cgrp_file "$CGRP_FILE")
        echo "[run_margin]  mode = M3D (maketcc_m3d, cgrp x=$CGRP_X y=$CGRP_Y xy=$CGRP_XY)"
    else
        echo "[run_margin]  mode = M2D (maketcc3)"
    fi

    export MTCCPATH="$MTCCPATH_DEFAULT"
    python3 "$MAKE_SOCS_PY" \
        --source "$SOURCE_ILLUM" \
        --ini "$INI" \
        --output "$SOCS_DIR" \
        --defocus_min "$DEFOCUS_MIN" \
        --defocus_max "$DEFOCUS_MAX" \
        --defocus_step "$DEFOCUS_STEP" \
        --kernel_num "$KERNEL_NUM" \
        --openmp_num "$OPENMP_NUM" \
        "${M3D_OPTS[@]}"
else
    echo "[run_margin] Step 1: reusing existing SOCS in $SOCS_DIR"
fi

# ===== Step 2: calcMargin =====
echo "[run_margin] Step 2: running calcMargin"
echo "  grid = ${DEFOCUS_MIN}..${DEFOCUS_MAX}@${DEFOCUS_STEP} nm × ${DOSE_MIN}..${DOSE_MAX}@${DOSE_STEP} %"
echo "  tolerance = $TOLERANCE μm"

BF_OPT="--brightfield"
[ "$BRIGHTFIELD" = "0" ] && BF_OPT="--darkfield"

SLICE_OPT=""
[ -n "$SLICE_LEVEL" ] && SLICE_OPT="--sliceLevel $SLICE_LEVEL"

T0=$(date +%s)
"$CALCMARGIN" \
    -s "$SOCS_DIR" \
    -l "$LAYOUT" \
    -e "$EVP" \
    -o "$OUT_MARGIN" \
    --grid_output "$OUT_GRID" \
    --per_evp_output "$OUT_PER_EVP" \
    --ppm_output "$OUT_PPM" \
    --ppm_ok_output "$OUT_PPM_OK" \
    --defocus_min "$DEFOCUS_MIN" \
    --defocus_max "$DEFOCUS_MAX" \
    --defocus_step "$DEFOCUS_STEP" \
    --dose_min "$DOSE_MIN" \
    --dose_max "$DOSE_MAX" \
    --dose_step "$DOSE_STEP" \
    --tolerance "$TOLERANCE" \
    --layer "$LAYER" \
    $BF_OPT \
    $SLICE_OPT \
    -j "$OPENMP_NUM"
ELAPSED=$(( $(date +%s) - T0 ))
echo "[run_margin] calcMargin done in ${ELAPSED}s"

# ===== Step 3: view_margin.py =====
echo "[run_margin] Step 3: rendering plot"
VIEW_OPT=""
[ "$NO_SHOW" = "1" ] && VIEW_OPT="$VIEW_OPT --no_show"
python3 "$VIEW_MARGIN_PY" "$OUT_GRID" \
    -o "$OUT_PNG" \
    --per_evp "$OUT_PER_EVP" \
    --pair_mode "$PAIR_MODE" \
    $VIEW_OPT

echo ""
echo "===== Margin summary ====="
cat "$OUT_MARGIN"
echo "=========================="
echo "outputs:"
echo "  margin.csv   = $OUT_MARGIN"
echo "  grid.csv     = $OUT_GRID"
echo "  per_evp.csv  = $OUT_PER_EVP"
echo "  heatmap.ppm  = $OUT_PPM"
echo "  ok_map.ppm   = $OUT_PPM_OK"
echo "  plot PNG     = $OUT_PNG"
