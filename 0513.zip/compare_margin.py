#!/usr/bin/env python3
"""compare_margin.py

複数の calcMargin grid.csv を 1 枚に重ねて比較するスクリプト。

  - 左: Process Window (max|EPE| ヒートマップは描かず、各 grid の OK 境界線
        を色違いで重ねる。スマイルカーブの形状比較に最適)
  - 右: ED Plot (各 grid の ED frontier を色違いで重ね、--target_dof /
        --target_el で目標点を ★ プロット)

楕円中心の位置に惑わされず、ED 上の目標達成と frontier の位置で
最適化結果を比較するのが本ツールの目的。

Usage:
    python3 compare_margin.py grid1.csv:Label1 grid2.csv:Label2 [...] \
        --target_dof 130 --target_el 8.5 -o compare.png

    # ラベルを省略するとファイル親ディレクトリ名が使われる
    python3 compare_margin.py margin_a/grid.csv margin_b/grid.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

# view_margin.py から ED フロンティア計算を流用 (同一ディレクトリにある想定)
sys.path.insert(0, str(Path(__file__).resolve().parent))
from view_margin import load_grid, fit_max_inscribed_ellipse, ed_frontier  # noqa: E402


def parse_input(s: str):
    """'path:label' 形式または 'path' を (Path, label) に分解。
    label 省略時は親ディレクトリ名を使う。
    """
    if ":" in s:
        path_str, label = s.split(":", 1)
    else:
        path_str = s
        label = Path(path_str).parent.name or Path(path_str).stem
    return Path(path_str), label


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="+",
                        help="grid.csv path (path:label 形式可、最大 8 個推奨)")
    parser.add_argument("--target_dof", type=float, default=None,
                        help="目標 DoF [nm]、指定で ED プロット上に ★ 表示")
    parser.add_argument("--target_el", type=float, default=None,
                        help="目標 EL [%%]")
    parser.add_argument("--n_a", type=int, default=200,
                        help="ED フロンティアの a サンプル数 (default: 200)")
    parser.add_argument("-o", "--output", default="compare_margin.png",
                        help="出力 PNG (default: compare_margin.png)")
    parser.add_argument("--no_show", action="store_true",
                        help="画面表示せず PNG だけ作る")
    parser.add_argument("--ellipse_center", default="auto",
                        choices=["auto", "target", "zero"],
                        help="ED frontier の中心。auto=最大面積楕円, "
                             "target=目標点, zero=(0,0) (default: auto)")
    args = parser.parse_args()

    if args.target_dof is not None and args.target_el is None:
        print("ERROR: --target_dof と --target_el は両方指定してください", file=sys.stderr)
        return 1

    # 入力を読み込み
    cases = []  # list of dict
    for s in args.inputs:
        path, label = parse_input(s)
        if not path.exists():
            print(f"ERROR: not found: {path}", file=sys.stderr)
            return 1
        defocus, dose, ok, epe = load_grid(path)
        cases.append({
            "path": path,
            "label": label,
            "defocus": defocus,
            "dose": dose,
            "ok": ok,
            "epe": epe,
        })
    n_cases = len(cases)
    print(f"loaded {n_cases} cases")

    # 楕円中心の決定
    centers = []
    for case in cases:
        if args.ellipse_center == "zero":
            center = (0.0, 0.0)
        elif args.ellipse_center == "target":
            if args.target_dof is None:
                # target が無ければ auto に落ちる
                el = fit_max_inscribed_ellipse(case["defocus"], case["dose"], case["ok"])
                center = (el[0], el[1]) if el is not None else (0.0, 0.0)
            else:
                center = (0.0, 0.0)  # 目標点中心は (DoF/2, EL/2) ではなく光源中心
        else:  # auto
            el = fit_max_inscribed_ellipse(case["defocus"], case["dose"], case["ok"])
            center = (el[0], el[1]) if el is not None else (0.0, 0.0)
            case["ellipse_params"] = el
        centers.append(center)

    # ED frontier 計算
    for i, case in enumerate(cases):
        cx, cy = centers[i]
        dof, el = ed_frontier(case["defocus"], case["dose"], case["ok"],
                              cx, cy, n_samples=args.n_a)
        case["ed_dof"] = dof
        case["ed_el"] = el
        case["ellipse_center"] = (cx, cy)

    # 統計を表示
    print()
    print(f"{'Label':<24} {'DoF[nm]':>8} {'EL[%]':>7} {'Area':>8} {'Center(DoF,EL)':>18} {'OK/441':>8}")
    print("-" * 80)
    for case in cases:
        el = case.get("ellipse_params")
        ok_count = int(case["ok"].sum())
        total = case["ok"].size
        if el is not None:
            cx, cy, a, b = el
            print(f"{case['label'][:24]:<24} {2*a:>8.1f} {2*b:>7.2f} "
                  f"{2*a*2*b:>8.0f} ({cx:>+5.1f}, {cy:>+5.1f}){'':<5} {ok_count:>4}/{total}")
        else:
            print(f"{case['label'][:24]:<24} {'-':>8} {'-':>7} {'-':>8} {'-':>18} {ok_count:>4}/{total}")
    print()

    # 描画
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

    cmap = plt.get_cmap("tab10")
    from matplotlib.lines import Line2D
    legend_handles_pw = []

    # 左: PW プロット (各 case の OK 境界を色違いで重ねる)
    for i, case in enumerate(cases):
        DD, EE = np.meshgrid(case["defocus"], case["dose"])
        color = cmap(i % 10)
        ax1.contour(DD, EE, case["ok"].astype(float), levels=[0.5],
                    colors=[color], linewidths=1.8)
        legend_handles_pw.append(Line2D([0], [0], color=color, linewidth=1.8,
                                         label=case["label"]))

    # 目標点 (DoF=130, EL=8.5) を PW 上にプロット (横軸が defocus なので
    #  ±DoF/2, ±EL/2 の長方形コーナーを表示するのが筋)
    if args.target_dof is not None:
        # 矩形コーナー (4 点)
        td2 = args.target_dof / 2.0
        te2 = args.target_el / 2.0
        rect_x = [-td2, td2, td2, -td2, -td2]
        rect_y = [-te2, -te2, te2, te2, -te2]
        ax1.plot(rect_x, rect_y, "k--", linewidth=1.5,
                 label=f"target box ({args.target_dof}×{args.target_el})")
        legend_handles_pw.append(
            Line2D([0], [0], color="black", linestyle="--", linewidth=1.5,
                   label=f"target {args.target_dof}nm × {args.target_el}%"))

    ax1.set_xlabel("Defocus [nm]")
    ax1.set_ylabel("Dose [%]")
    ax1.set_title("Process Window: OK boundaries overlaid")
    ax1.grid(True, alpha=0.3)
    ax1.legend(handles=legend_handles_pw, loc="lower right", fontsize=9)

    # 右: ED プロット (各 case の frontier 重ね)
    legend_handles_ed = []
    for i, case in enumerate(cases):
        color = cmap(i % 10)
        ax2.plot(case["ed_dof"], case["ed_el"], color=color, linewidth=2.0)
        ax2.fill_between(case["ed_dof"], 0, case["ed_el"], color=color, alpha=0.10)
        # ellipse 中心の代表点 (DoF=2a, EL=2b) を ★
        el = case.get("ellipse_params")
        if el is not None:
            _, _, a, b = el
            ax2.plot(2 * a, 2 * b, marker="*", color=color, markersize=14,
                     markeredgecolor="black", markeredgewidth=0.8)
        legend_handles_ed.append(
            Line2D([0], [0], color=color, linewidth=2.0, label=case["label"]))

    # 目標点を ED プロットに追加
    if args.target_dof is not None:
        ax2.plot(args.target_dof, args.target_el, marker="P",
                 markersize=18, color="red", markeredgecolor="black",
                 markeredgewidth=1.0, zorder=5)
        legend_handles_ed.append(
            Line2D([0], [0], marker="P", linestyle="", color="red",
                   markeredgecolor="black", markersize=12,
                   label=f"target ({args.target_dof}nm, {args.target_el}%)"))

    ax2.set_xlabel("DoF [nm]")
    ax2.set_ylabel("EL [%]")
    ax2.set_xlim(left=0)
    ax2.set_ylim(bottom=0)
    ax2.grid(True)
    ax2.set_title("ED Plot: frontier comparison")
    ax2.legend(handles=legend_handles_ed, loc="upper right", fontsize=9)

    fig.tight_layout()
    fig.savefig(args.output, dpi=120)
    print(f"saved: {args.output}")

    if not args.no_show:
        plt.show()

    return 0


if __name__ == "__main__":
    sys.exit(main())
