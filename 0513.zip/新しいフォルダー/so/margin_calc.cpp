/*!
 * @file margin_calc.cpp
 * @brief EL-DoF マージン計測の実装
 */

#include "margin_calc.h"
#include "socs_config.h"
#include "epe_newton.h"
#include <tkk/lithoKernel/ccalcs_m3d.h>
#include <tkk/lithoKernel/cresistImage.h>
#include <tkk/lithoKernel/util.h>
#include <tkk/resistModel6/cResistModel.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stack>
#include <stdexcept>

#ifdef _OPENMP
#include <omp.h>
#endif

namespace so {

MarginCalculator::MarginCalculator() {}
MarginCalculator::~MarginCalculator() {}

std::string MarginCalculator::makeSocsPath(double defocus) const {
    // pattern (例: "socs_d%d.socs") の %d に整数 nm を挿入
    char buf[512];
    std::snprintf(buf, sizeof(buf), m_options.socsFilePattern.c_str(),
                  static_cast<int>(std::round(defocus)));
    return m_socsDir + "/" + std::string(buf);
}

std::map<int, FrequencyImage> MarginCalculator::computeImagesForDefocus(
    const std::string& socsPath) {

    std::map<int, FrequencyImage> result;
    if (!m_evpData) return result;
    if (!std::filesystem::exists(socsPath)) {
        throw std::runtime_error("SOCS file not found: " + socsPath);
    }

    const auto& clips = m_evpData->showClips();

    // SOCS から光学パラメータ取得 (Lx, Ly, NA, lambda)
    OpticalParams optical = SocsFile::readOpticalParams(socsPath);
    double Lx = optical.Lx;
    double Ly = optical.Ly;
    if (Lx <= 0.0 || Ly <= 0.0) {
        throw std::runtime_error("Invalid Lx/Ly from SOCS: " + socsPath);
    }

    int dimx = m_options.dimx;
    int dimy = m_options.dimy;
    if (dimx == 0 || dimy == 0) {
        // calcImg のデフォルト: 4 * floor(L_max * 2 * NA / λ) + 2
        double Lmax = std::max(Lx, Ly);
        int dDefault = 4 * static_cast<int>(std::floor(Lmax * 2.0 * optical.NA / optical.lambda)) + 2;
        if (dimx == 0) dimx = dDefault;
        if (dimy == 0) dimy = dDefault;
    }
    int dimx0 = (m_options.dimx0 > 0) ? m_options.dimx0 : dimx;
    int dimy0 = (m_options.dimy0 > 0) ? m_options.dimy0 : dimy;

    // resistModel の用意 (calcImg と同じく無ければデフォルト)
    std::string resistModelPath = m_options.resistModelFile;
    if (resistModelPath.empty() || !std::filesystem::exists(resistModelPath)) {
        // 一時ディレクトリにデフォルト resistModel を作る
        static const std::string defaultPath = "/tmp/calcMargin_default_resistModel.info";
        if (!std::filesystem::exists(defaultPath)) {
            std::ofstream ofs(defaultPath);
            ofs << "IntensityWeight 1" << std::endl;
        }
        resistModelPath = defaultPath;
    }

    // 外部ライブラリの冗長な出力を抑制（ccalcs_m3d など）
    std::streambuf* origCoutBuf = std::cout.rdbuf();
    std::streambuf* origCerrBuf = std::cerr.rdbuf();
    std::ofstream nullStream("/dev/null");
    std::cout.rdbuf(nullStream.rdbuf());
    std::cerr.rdbuf(nullStream.rdbuf());

    try {
        // SOCS 1 個から ccalcs_m3d を 1 つ作る (defocus 毎に呼ばれるのでキャッシュ不要)
        auto* MCALCS = new lithoKernel::ccalcs_m3d;
        MCALCS->set_dimx0(dimx0);
        MCALCS->set_dimy0(dimy0);
        MCALCS->set_dimx1(dimx);
        MCALCS->set_dimy1(dimy);
        MCALCS->set_kernel_num(m_options.kernelNum);
        MCALCS->set_flag_binary(m_options.binary ? 1 : 0);
        MCALCS->set_flag_brightfield(m_options.brightfield ? 1 : 0);
        MCALCS->set_socs(socsPath, false, 0);

        auto* resist = new resistModel6::cResistModelList(resistModelPath);

        std::vector<std::pair<int, int>> layers = m_options.layers;
        if (layers.empty()) layers.emplace_back(0, 0);

        // clip ごとに OASIS を読んで calc_image
        for (size_t ci = 0; ci < clips.size(); ++ci) {
            const auto& clip = clips[ci];
            double cx = clip.cx;
            double cy = clip.cy;

            constexpr double margin = 0.125;
            lithoGtl::Polygons PMain, PSraf;

            auto [layer_main, datatype_main] = layers[0];
            // OASIS 読み込みは exit() する可能性があるので stderr/stdout を一時的に戻す
            std::cout.rdbuf(origCoutBuf);
            std::cerr.rdbuf(origCerrBuf);
            PMain.read_oasis(m_layoutFile.c_str(), m_options.cellname,
                             layer_main, datatype_main,
                             cx - Lx / 2.0 - margin, cy - Ly / 2.0 - margin,
                             cx + Lx / 2.0 + margin, cy + Ly / 2.0 + margin);
            for (size_t li = 1; li < layers.size(); ++li) {
                auto [layer_sraf, datatype_sraf] = layers[li];
                PSraf.read_oasis(m_layoutFile.c_str(), m_options.cellname,
                                 layer_sraf, datatype_sraf,
                                 cx - Lx / 2.0 - margin, cy - Ly / 2.0 - margin,
                                 cx + Lx / 2.0 + margin, cy + Ly / 2.0 + margin);
            }
            std::cout.rdbuf(nullStream.rdbuf());
            std::cerr.rdbuf(nullStream.rdbuf());

            PMain.shift_double(-cx, -cy);
            PMain.window_double(-Lx / 2.0, -Ly / 2.0, Lx / 2.0, Ly / 2.0);
            PSraf.shift_double(-cx, -cy);
            PSraf.window_double(-Lx / 2.0, -Ly / 2.0, Lx / 2.0, Ly / 2.0);

            auto* m_pattern = new lithoKernel::cResistImage(MCALCS, resist);
            std::vector<std::complex<double>> fResistImage = m_pattern->calc_image(PMain, PSraf);
            lithoKernel::fftshift2d(fResistImage);
            delete m_pattern;

            FrequencyImage freqImg;
            freqImg.initialize(dimx, dimy, Lx, Ly);
            freqImg.setData(std::move(fResistImage));
            result[clip.clipID] = std::move(freqImg);
        }

        delete resist;
        delete MCALCS;

    } catch (...) {
        std::cout.rdbuf(origCoutBuf);
        std::cerr.rdbuf(origCerrBuf);
        throw;
    }

    std::cout.rdbuf(origCoutBuf);
    std::cerr.rdbuf(origCerrBuf);

    return result;
}

double MarginCalculator::autoSliceLevel(
    const std::map<int, FrequencyImage>& imagesNominal) {

    if (!m_evpData || imagesNominal.empty()) return 0.3;

    // 全評価点での強度の平均を初期範囲の中心に使う
    double sumI = 0.0;
    int countI = 0;
    for (const auto& clip : m_evpData->showClips()) {
        auto it = imagesNominal.find(clip.clipID);
        if (it == imagesNominal.end()) continue;
        for (const auto* ep : clip.evalPoints) {
            auto pv = it->second.evalAt(ep->px, ep->py);
            sumI += pv.intensity;
            countI++;
        }
    }
    double avgI = (countI > 0) ? sumI / countI : 0.5;

    // 探索範囲
    double a = avgI * 0.5;
    double b = avgI * 1.5;
    if (m_options.sliceLevelHint > 0.0) {
        a = std::max(a, m_options.sliceLevelHint - avgI * 0.3);
        b = std::min(b, m_options.sliceLevelHint + avgI * 0.3);
    }

    // 黄金分割探索: max|EPE| を最小化する閾値を探す
    auto evalFunc = [&](double slice) -> double {
        double maxAbs = 0.0;
        for (const auto& clip : m_evpData->showClips()) {
            auto it = imagesNominal.find(clip.clipID);
            if (it == imagesNominal.end()) continue;
            for (const auto* ep : clip.evalPoints) {
                auto r = calcEpeNewton(it->second, ep->px, ep->py, ep->degree, slice);
                double eff = std::max(0.0, std::abs(r.epe) - ep->tolerance);
                if (eff > maxAbs) maxAbs = eff;
            }
        }
        return maxAbs;
    };

    const double phi = (std::sqrt(5.0) - 1.0) / 2.0;
    double c = b - phi * (b - a);
    double d = a + phi * (b - a);
    double fc = evalFunc(c);
    double fd = evalFunc(d);

    for (int iter = 0; iter < 50; ++iter) {
        if (fc < fd) {
            b = d;
            d = c;
            fd = fc;
            c = b - phi * (b - a);
            fc = evalFunc(c);
        } else {
            a = c;
            c = d;
            fc = fd;
            d = a + phi * (b - a);
            fd = evalFunc(d);
        }
        if (std::abs(b - a) < 1e-8) break;
    }
    return (a + b) / 2.0;
}

MarginResult MarginCalculator::calculate() {
    MarginResult result;
    if (!m_evpData) {
        throw std::runtime_error("EvpData not set");
    }
    if (m_options.defocusList.empty() || m_options.doseList.empty()) {
        throw std::runtime_error("defocusList / doseList not set");
    }

    result.nDefocus = static_cast<int>(m_options.defocusList.size());
    result.nDose = static_cast<int>(m_options.doseList.size());
    result.defocusList = m_options.defocusList;
    result.doseList = m_options.doseList;
    result.grid.resize(result.nDefocus * result.nDose);

#ifdef _OPENMP
    if (m_options.numThreads > 0) {
        omp_set_num_threads(m_options.numThreads);
    }
#endif

    // sliceLevel 決定 (中央 defocus の nominal 画像で auto 探索 or 入力値を使用)
    int midIdx = result.nDefocus / 2;
    double nominalDefocus = m_options.defocusList[midIdx];
    auto nominalImages = computeImagesForDefocus(makeSocsPath(nominalDefocus));

    double sliceLevel = m_options.sliceLevel;
    if (sliceLevel < 0.0) {
        sliceLevel = autoSliceLevel(nominalImages);
        std::cerr << "[MarginCalc] auto sliceLevel = " << sliceLevel
                  << " (nominal defocus = " << nominalDefocus << " nm)" << std::endl;
    } else {
        std::cerr << "[MarginCalc] sliceLevel = " << sliceLevel << " (specified)" << std::endl;
    }
    result.sliceLevel = sliceLevel;

    const auto& clips = m_evpData->showClips();

    // defocus ループ。各 defocus で SOCS から画像を作り、dose ループで EPE 評価
    for (int i = 0; i < result.nDefocus; ++i) {
        double defocus = m_options.defocusList[i];
        std::cerr << "[MarginCalc] defocus = " << defocus << " nm  ("
                  << (i + 1) << "/" << result.nDefocus << ")" << std::endl;

        std::map<int, FrequencyImage> baseImages;
        if (std::abs(defocus - nominalDefocus) < 1e-9 && !nominalImages.empty()) {
            baseImages = std::move(nominalImages);  // 中央 defocus は再利用
        } else {
            baseImages = computeImagesForDefocus(makeSocsPath(defocus));
        }

        // dose は画像の単純スケールで反映できるので、defocus 1 回の SOCS で全 dose 評価可能
        for (int j = 0; j < result.nDose; ++j) {
            double dose = m_options.doseList[j];
            double scale = 1.0 + dose / 100.0;

            MarginGridPoint pt;
            pt.defocus = defocus;
            pt.dose = dose;
            pt.maxAbsEpe = 0.0;
            pt.ok = true;
            pt.newtonFailCount = 0;
            pt.worstClipID = -1;
            pt.worstEvpIndex = -1;

            // 各 clip × evp で EPE 計算
            int evpGlobalIdx = -1;
            for (const auto& clip : clips) {
                auto it = baseImages.find(clip.clipID);
                if (it == baseImages.end()) continue;

                // dose スケール: 画像を直接スケールせず、scale 後の sliceLevel を等価に変える
                // (画像 I_scaled = I * scale で sliceLevel を t とすると、
                //  EPE 評価は I_scaled - t = 0 ⇔ I - t/scale = 0 と同値)
                // よって sliceLevel を t/scale に変える方が安価 (画像コピー不要)
                double effectiveSlice = sliceLevel / scale;

                for (const auto* ep : clip.evalPoints) {
                    ++evpGlobalIdx;
                    auto r = calcEpeNewton(it->second, ep->px, ep->py, ep->degree, effectiveSlice);
                    double absEpe = std::abs(r.epe);
                    if (!r.converged) pt.newtonFailCount++;

                    // 評価点ごとの tolerance: グローバル指定 > 0 なら上書き
                    double tol = (m_options.globalTolerance >= 0.0)
                                 ? m_options.globalTolerance
                                 : ep->tolerance;
                    if (absEpe > tol) {
                        pt.ok = false;
                    }
                    if (absEpe > pt.maxAbsEpe) {
                        pt.maxAbsEpe = absEpe;
                        pt.worstClipID = clip.clipID;
                        pt.worstEvpIndex = evpGlobalIdx;
                    }

                    if (m_options.exportPerEvp) {
                        MarginEvpDetail detail;
                        detail.gridIdx = i * result.nDose + j;
                        detail.defocus = defocus;
                        detail.dose = dose;
                        detail.evpIndex = evpGlobalIdx;
                        detail.clipID = clip.clipID;
                        detail.px = ep->px;
                        detail.py = ep->py;
                        detail.degree = ep->degree;
                        detail.epe = r.epe;
                        detail.tolerance = tol;
                        detail.inside = (absEpe <= tol);
                        detail.converged = r.converged;
                        detail.cutlineID = ep->cutlineID;
                        result.perEvp.push_back(std::move(detail));
                    }
                }
            }

            result.grid[i * result.nDose + j] = pt;
        }
    }

    // 最大内接矩形を抽出
    findMaxRectangle(result.grid, result.nDefocus, result.nDose,
                     result.defocusList, result.doseList, result);

    return result;
}

void MarginCalculator::findMaxRectangle(
    const std::vector<MarginGridPoint>& grid,
    int nDefocus, int nDose,
    const std::vector<double>& defocusList,
    const std::vector<double>& doseList,
    MarginResult& result) {

    // OK ビットマップ (nDefocus 行 × nDose 列)。
    // 行ごとに「下に連続する OK セル数」のヒストグラム H[i][j] を作る
    // (最後の行から上に向かって累積)。
    // その後、各行の H に対して「最大ヒストグラム矩形」を計算し全行で最大値を取る。
    if (nDefocus == 0 || nDose == 0) return;

    std::vector<std::vector<int>> H(nDefocus, std::vector<int>(nDose, 0));
    for (int j = 0; j < nDose; ++j) {
        for (int i = nDefocus - 1; i >= 0; --i) {
            bool ok = grid[i * nDose + j].ok;
            if (!ok) {
                H[i][j] = 0;
            } else if (i == nDefocus - 1) {
                H[i][j] = 1;
            } else {
                H[i][j] = H[i + 1][j] + 1;
            }
        }
    }

    // 物理単位での 1 ステップあたりの幅 (グリッドが等間隔と仮定)
    double dDefocus = (nDefocus > 1) ? std::abs(defocusList[1] - defocusList[0]) : 1.0;
    double dDose = (nDose > 1) ? std::abs(doseList[1] - doseList[0]) : 1.0;

    double bestArea = 0.0;
    int bestI0 = -1, bestI1 = -1, bestJ0 = -1, bestJ1 = -1;

    // 各行 i の H[i] に対して largest rectangle in histogram (stack 法)
    for (int i = 0; i < nDefocus; ++i) {
        std::vector<int>& h = H[i];
        std::stack<int> st;
        for (int j = 0; j <= nDose; ++j) {
            int cur = (j == nDose) ? 0 : h[j];
            while (!st.empty() && h[st.top()] > cur) {
                int top = st.top(); st.pop();
                int left = st.empty() ? -1 : st.top();
                int width = j - left - 1;       // [left+1 .. j-1]
                int height = h[top];            // defocus 方向のステップ数
                // 物理単位での面積: width * dDose * height * dDefocus
                double area = static_cast<double>(width) * dDose
                            * static_cast<double>(height) * dDefocus;
                // 面積比較は「セル中心定義」(width-1)*dDose*(height-1)*dDefocus でも
                // よいが、退化矩形 (1×N, N×1) も拾えるよう「セル幅定義」のままにし、
                // 最後に bestDof/bestEl のみ (n-1) で換算する。
                // 結果の順位付けは両者で一致する。
                if (area > bestArea) {
                    bestArea = area;
                    bestJ0 = left + 1;
                    bestJ1 = j - 1;
                    bestI0 = i;
                    bestI1 = i + height - 1;
                }
            }
            st.push(j);
        }
    }

    if (bestArea > 0.0 && bestI0 >= 0 && bestJ0 >= 0) {
        // セル中心定義: n セルで覆う defocus 範囲幅 = (n-1) × step。
        // (n × step) は「セル幅で測った被覆面積」だが、PW の慣用表現としては
        // 「最遠 2 セル中心の差」がリソグラフィ業界の標準。)
        int defocusSteps = bestI1 - bestI0 + 1;
        int doseSteps = bestJ1 - bestJ0 + 1;
        result.bestDof = static_cast<double>(std::max(0, defocusSteps - 1)) * dDefocus;
        result.bestEl = static_cast<double>(std::max(0, doseSteps - 1)) * dDose;
        result.bestArea = result.bestDof * result.bestEl;
        result.bestCenterDefocus = (defocusList[bestI0] + defocusList[bestI1]) / 2.0;
        result.bestCenterDose = (doseList[bestJ0] + doseList[bestJ1]) / 2.0;
        result.bestDefocusStart = bestI0;
        result.bestDefocusEnd = bestI1;
        result.bestDoseStart = bestJ0;
        result.bestDoseEnd = bestJ1;
    } else {
        result.bestDof = 0.0;
        result.bestEl = 0.0;
        result.bestArea = 0.0;
    }
}

void MarginCalculator::savePpm(const std::string& path, const MarginResult& result,
                                const std::string& mode) {
    if (result.nDefocus == 0 || result.nDose == 0) return;

    // 画像サイズ: 各セルを cellPx × cellPx に拡大表示
    // 軸定義: X 軸 = defocus (左→右 が defocus 増加方向)
    //         Y 軸 = dose    (上→下 が dose 減少方向; 数学グラフと同じく上=+)
    constexpr int cellPx = 16;
    int W = result.nDefocus * cellPx;
    int H = result.nDose * cellPx;

    std::vector<unsigned char> img(3 * W * H, 0);

    // max|EPE| のスケール (mode = "epe")
    double maxEpe = 0.0;
    for (const auto& pt : result.grid) {
        if (pt.maxAbsEpe > maxEpe) maxEpe = pt.maxAbsEpe;
    }
    if (maxEpe <= 0.0) maxEpe = 1e-9;

    auto writePixel = [&](int x, int y, unsigned char r, unsigned char g, unsigned char b) {
        if (x < 0 || x >= W || y < 0 || y >= H) return;
        int idx = 3 * (y * W + x);
        img[idx + 0] = r;
        img[idx + 1] = g;
        img[idx + 2] = b;
    };

    for (int i = 0; i < result.nDefocus; ++i) {
        int xStart = i * cellPx;
        for (int j = 0; j < result.nDose; ++j) {
            // Y 軸を反転: j=0 (dose 最小値) を画像下端、j=nDose-1 を上端に
            int yStart = (result.nDose - 1 - j) * cellPx;
            const auto& pt = result.grid[i * result.nDose + j];

            unsigned char r = 0, g = 0, b = 0;
            if (mode == "ok") {
                // OK = 緑, NG = 赤
                if (pt.ok) { r = 0; g = 200; b = 0; }
                else       { r = 200; g = 0; b = 0; }
            } else {
                // epe mode: 値を [0, maxEpe] で正規化し、OK は青→緑、NG は黄→赤
                double t = std::min(1.0, pt.maxAbsEpe / maxEpe);
                if (pt.ok) {
                    // 青(低EPE) → 緑(高EPE within tol)
                    r = 0;
                    g = static_cast<unsigned char>(150 + 105 * t);
                    b = static_cast<unsigned char>(255 * (1.0 - t));
                } else {
                    // 黄(borderline NG) → 赤(深刻NG)
                    r = 255;
                    g = static_cast<unsigned char>(200 * (1.0 - t));
                    b = 0;
                }
            }

            for (int dy = 0; dy < cellPx; ++dy) {
                for (int dx = 0; dx < cellPx; ++dx) {
                    writePixel(xStart + dx, yStart + dy, r, g, b);
                }
            }
        }
    }

    std::ofstream ofs(path, std::ios::binary);
    if (!ofs.is_open()) {
        throw std::runtime_error("Failed to open PPM file for writing: " + path);
    }
    ofs << "P6\n" << W << " " << H << "\n255\n";
    ofs.write(reinterpret_cast<const char*>(img.data()),
              static_cast<std::streamsize>(img.size()));
}

} // namespace so
