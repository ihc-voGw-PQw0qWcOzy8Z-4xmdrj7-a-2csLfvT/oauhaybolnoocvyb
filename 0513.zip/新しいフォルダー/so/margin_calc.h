/*!
 * @file margin_calc.h
 * @brief EL-DoF マージン計測
 *
 * 最適化済み光源 (全体) + defocus 毎の SOCS + マスクから、
 * defocus × dose の 2D Process Window を構築し、
 * 全評価点で |EPE| < tolerance を満たす領域の最大内接矩形を抽出する。
 *
 * 想定する SOCS は、make_socs_for_margin.py 等で
 * 「光源全体 (.illum) + defocus_i」毎に 1 個生成された TCC/SOCS ファイル群。
 * srcOptim 用の「点光源 × defocus」SOCS とは別物。
 */

#ifndef SO_MARGIN_CALC_H
#define SO_MARGIN_CALC_H

#include <so/types.h>
#include <so/frequency_image.h>
#include <so/evp_data.h>
#include <string>
#include <vector>

namespace so {

/*!
 * @brief Process Window グリッド上の 1 点
 */
struct MarginGridPoint {
    double defocus = 0.0;       ///< [nm]
    double dose = 0.0;          ///< [%] dose 補正（0=nominal）
    double maxAbsEpe = 0.0;     ///< [μm] 全評価点での max|EPE|
    bool ok = false;            ///< 全評価点で |EPE| < tolerance_i
    int worstClipID = -1;       ///< max|EPE| を取った評価点の clip ID
    int worstEvpIndex = -1;     ///< 〃 evp index（EvpData::showEvalPoints 上）
    int newtonFailCount = 0;    ///< Newton 法が収束しなかった評価点数
};

/*!
 * @brief 評価点別 EPE の詳細（per_evp.csv 用）
 */
struct MarginEvpDetail {
    int gridIdx = -1;           ///< MarginResult::grid のインデックス
    double defocus = 0.0;
    double dose = 0.0;
    int evpIndex = -1;
    int clipID = -1;
    double px = 0.0;
    double py = 0.0;
    double degree = 0.0;
    double epe = 0.0;
    double tolerance = 0.0;
    bool inside = false;
    bool converged = true;
    std::string cutlineID;      ///< evp.csv の cutlineID 列（"nan" の場合もある）
};

/*!
 * @brief マージン計測オプション
 */
struct MarginOptions {
    std::vector<double> defocusList;    ///< [nm]
    std::vector<double> doseList;       ///< [%]

    /// SOCS ファイル名のフォーマット ("d%g" → printf 形式; 整数 nm)
    /// 例: "socs_d%d.socs" → defocus=-100nm の SOCS = "socs_d-100.socs"
    std::string socsFilePattern = "socs_d%d.socs";

    double sliceLevel = -1.0;           ///< -1 で auto
    double sliceLevelHint = -1.0;       ///< sliceLevel auto 探索の初期値ヒント

    /// -1 で evp.csv の tolerance を使う。>=0 で全評価点を上書き
    double globalTolerance = -1.0;

    int numThreads = 1;
    bool brightfield = false;
    bool binary = false;
    int dimx0 = 0, dimy0 = 0;
    int dimx = 0, dimy = 0;
    int kernelNum = 0;
    std::vector<std::pair<int, int>> layers;
    std::string cellname;
    std::string resistModelFile;

    /// per_evp.csv は数百〜数千行 × グリッド点数で膨大になるため、デフォルト OFF
    bool exportPerEvp = false;
};

/*!
 * @brief マージン計測結果
 */
struct MarginResult {
    std::vector<MarginGridPoint> grid;  ///< defocus × dose の 2D（行優先: i*nDose+j）
    int nDefocus = 0;
    int nDose = 0;
    std::vector<double> defocusList;
    std::vector<double> doseList;

    /// 自動決定された sliceLevel (入力で >=0 ならそのまま)
    double sliceLevel = 0.0;

    // 最大内接矩形 (OK 領域の中で面積最大の軸並行矩形)
    double bestDof = 0.0;              ///< [nm] 矩形の defocus 方向幅
    double bestEl = 0.0;               ///< [%] 矩形の dose 方向幅
    double bestArea = 0.0;             ///< bestDof × bestEl
    double bestCenterDefocus = 0.0;    ///< [nm]
    double bestCenterDose = 0.0;       ///< [%]
    int bestDefocusStart = -1;         ///< OK 矩形の defocus index 範囲
    int bestDefocusEnd = -1;
    int bestDoseStart = -1;
    int bestDoseEnd = -1;

    std::vector<MarginEvpDetail> perEvp;  ///< exportPerEvp=true 時のみ充填
};

/*!
 * @brief マージン計測クラス
 */
class MarginCalculator {
public:
    MarginCalculator();
    ~MarginCalculator();

    void setSocsDir(const std::string& dir) { m_socsDir = dir; }
    void setLayoutFile(const std::string& path) { m_layoutFile = path; }
    void setEvpData(const EvpData* evpData) { m_evpData = evpData; }
    void setOptions(const MarginOptions& opts) { m_options = opts; }

    /*!
     * @brief マージン計測を実行
     */
    MarginResult calculate();

    /*!
     * @brief OK 領域の中で面積最大の軸並行矩形を抽出 (histogram-based, O(MN))
     *
     * @param grid grid[i*nDose+j].ok を参照
     * @param nDefocus row 数 (defocus 軸)
     * @param nDose col 数 (dose 軸)
     * @param defocusList defocus 値リスト (nDefocus 個)
     * @param doseList dose 値リスト (nDose 個)
     * @param[out] result MarginResult の bestXxx を更新
     */
    static void findMaxRectangle(const std::vector<MarginGridPoint>& grid,
                                 int nDefocus, int nDose,
                                 const std::vector<double>& defocusList,
                                 const std::vector<double>& doseList,
                                 MarginResult& result);

    /*!
     * @brief PPM ヒートマップ画像を保存
     *
     * max|EPE| を色相にマップ：OK 領域は緑系、NG 領域は赤系。
     * 軸ラベルは画像内には描かない（CSV 側で参照する想定）。
     *
     * @param path 保存先 PPM パス
     * @param result マージン結果
     * @param mode "epe" (max|EPE| ヒートマップ) または "ok" (OK/NG 2値)
     */
    static void savePpm(const std::string& path, const MarginResult& result,
                        const std::string& mode = "epe");

private:
    std::string m_socsDir;
    std::string m_layoutFile;
    const EvpData* m_evpData = nullptr;
    MarginOptions m_options;

    /*!
     * @brief 指定 defocus の SOCS と全 clip から、clipID → FrequencyImage の写像を作る
     */
    std::map<int, FrequencyImage> computeImagesForDefocus(
        const std::string& socsPath);

    /*!
     * @brief socsFilePattern と defocus から SOCS ファイルパスを組み立てる
     */
    std::string makeSocsPath(double defocus) const;

    /*!
     * @brief sliceLevel 自動決定 (nominal defocus + nominal dose で max|EPE| 最小化)
     *
     * 中央値に近い defocus の SOCS を使い、dose=0 で全評価点の max|EPE| が最小に
     * なる sliceLevel を黄金分割探索で見つける。
     */
    double autoSliceLevel(const std::map<int, FrequencyImage>& imagesNominal);
};

} // namespace so

#endif // SO_MARGIN_CALC_H
