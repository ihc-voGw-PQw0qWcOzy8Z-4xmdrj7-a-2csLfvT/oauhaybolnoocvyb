/*!
 * @file main.cpp
 * @brief calcMargin - EL-DoF マージン計測ツール
 *
 * 最適化済み光源 (全体) + defocus 毎の SOCS + マスクから、
 * defocus × dose の 2D Process Window を構築し、
 * 全評価点で |EPE| < tolerance を満たす領域の最大内接矩形を抽出する。
 *
 * 想定 SOCS: maketcc3 -pnt_source=opt_source.illum で defocus 毎に生成された SOCS。
 *            srcOptim 用の「点光源 × defocus」per-point SOCS とは別。
 */

#include <getopt.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include <so/evp_data.h>
#include <so/margin_calc.h>
#include <so/types.h>

namespace {

void printHelp(const char* programName) {
    std::cerr << "calcMargin - EL-DoF margin calculator (Process Window analysis)\n\n";
    std::cerr << "Usage:\n";
    std::cerr << "  " << programName << " -s <socs_dir> -l <layout> -e <evp.csv> -o <margin.csv> [options]\n\n";
    std::cerr << "Required:\n";
    std::cerr << "  -s, --socs_dir <dir>          Directory with per-defocus SOCS files\n";
    std::cerr << "  -l, --layout <file>           OASIS / GDS layout\n";
    std::cerr << "  -e, --evp <file>              Evaluation points CSV\n";
    std::cerr << "  -o, --output <file>           margin summary CSV\n\n";
    std::cerr << "Grid options:\n";
    std::cerr << "  --defocus_min <nm>            Defocus minimum (default: -100)\n";
    std::cerr << "  --defocus_max <nm>            Defocus maximum (default: +100)\n";
    std::cerr << "  --defocus_step <nm>           Defocus step (default: 10)\n";
    std::cerr << "  --defocus_list <csv>          Override defocus list (e.g. \"-100,-50,0,50,100\")\n";
    std::cerr << "  --dose_min <%>                Dose minimum [%] (default: -10)\n";
    std::cerr << "  --dose_max <%>                Dose maximum [%] (default: +10)\n";
    std::cerr << "  --dose_step <%>               Dose step [%] (default: 1)\n";
    std::cerr << "  --dose_list <csv>             Override dose list\n";
    std::cerr << "  --socs_pattern <fmt>          printf-style filename pattern (default: socs_d%d.socs)\n";
    std::cerr << "                                %d is replaced by integer nm defocus value.\n\n";
    std::cerr << "EPE / threshold:\n";
    std::cerr << "  --sliceLevel <val>            slice threshold (default: auto golden-section)\n";
    std::cerr << "  --sliceLevelHint <val>        hint for auto slice search\n";
    std::cerr << "  --tolerance <um>              override per-evp tolerance from evp.csv (μm)\n\n";
    std::cerr << "Image calc:\n";
    std::cerr << "  --resistModel <file>          resistModel file (default: IntensityWeight 1)\n";
    std::cerr << "  --dim0 <int>                  small calc dim (default: from SOCS)\n";
    std::cerr << "  --dim <int>                   large calc dim (default: from SOCS)\n";
    std::cerr << "  --kernel <int>                number of SOCS kernels (0 = use all)\n";
    std::cerr << "  --layer <L/D,...>             layer/datatype pairs (default: 0/0)\n";
    std::cerr << "  --cellname <name>             cell name (default: empty)\n";
    std::cerr << "  --brightfield                 bright field (default: dark field)\n";
    std::cerr << "  --darkfield                   dark field (default)\n\n";
    std::cerr << "Output:\n";
    std::cerr << "  --grid_output <file>          full grid CSV (defocus,dose,maxAbsEpe,ok,...)\n";
    std::cerr << "  --per_evp_output <file>       per-evp detail CSV (large)\n";
    std::cerr << "  --ppm_output <file>           PPM heatmap of max|EPE| (with best-rectangle border)\n";
    std::cerr << "  --ppm_ok_output <file>        PPM OK/NG bitmap\n";
    std::cerr << "  -j, --jobs <int>              OpenMP threads (default: 1)\n";
    std::cerr << "  -h, --help                    Show this help\n";
}

std::vector<double> parseDoubleList(const std::string& s) {
    std::vector<double> out;
    std::stringstream ss(s);
    std::string tok;
    while (std::getline(ss, tok, ',')) {
        if (tok.empty()) continue;
        out.push_back(std::stod(tok));
    }
    return out;
}

std::vector<double> makeRange(double lo, double hi, double step) {
    std::vector<double> out;
    if (step <= 0.0) return out;
    // 軽い丸めを入れて (lo, lo+step, ..., hi) の端を取りこぼさないようにする
    double eps = step * 1e-6;
    for (double v = lo; v <= hi + eps; v += step) {
        out.push_back(v);
    }
    return out;
}

void writeMarginCsv(const std::string& path, const so::MarginResult& r) {
    std::ofstream ofs(path);
    ofs << "# EL-DoF Margin Summary\n";
    ofs << "key,value\n";
    ofs << "sliceLevel," << r.sliceLevel << "\n";
    ofs << "best_DoF_nm," << r.bestDof << "\n";
    ofs << "best_EL_pct," << r.bestEl << "\n";
    ofs << "best_area," << r.bestArea << "\n";
    ofs << "best_center_defocus_nm," << r.bestCenterDefocus << "\n";
    ofs << "best_center_dose_pct," << r.bestCenterDose << "\n";
    ofs << "nDefocus," << r.nDefocus << "\n";
    ofs << "nDose," << r.nDose << "\n";
    int okCount = 0;
    for (const auto& pt : r.grid) if (pt.ok) okCount++;
    ofs << "ok_count," << okCount << "\n";
    ofs << "total_grid_points," << r.grid.size() << "\n";
}

void writeGridCsv(const std::string& path, const so::MarginResult& r) {
    std::ofstream ofs(path);
    ofs << "defocus_nm,dose_pct,maxAbsEpe_um,ok,worstClipID,worstEvpIndex,newtonFailCount\n";
    for (int i = 0; i < r.nDefocus; ++i) {
        for (int j = 0; j < r.nDose; ++j) {
            const auto& pt = r.grid[i * r.nDose + j];
            ofs << pt.defocus << "," << pt.dose << ","
                << pt.maxAbsEpe << "," << (pt.ok ? 1 : 0) << ","
                << pt.worstClipID << "," << pt.worstEvpIndex << ","
                << pt.newtonFailCount << "\n";
        }
    }
}

void writePerEvpCsv(const std::string& path, const so::MarginResult& r) {
    std::ofstream ofs(path);
    ofs << "gridIdx,defocus_nm,dose_pct,evpIndex,clipID,cutlineID,px,py,degree,epe_um,tolerance_um,inside,converged\n";
    for (const auto& d : r.perEvp) {
        ofs << d.gridIdx << "," << d.defocus << "," << d.dose << ","
            << d.evpIndex << "," << d.clipID << ","
            << d.cutlineID << ","
            << d.px << "," << d.py << "," << d.degree << ","
            << d.epe << "," << d.tolerance << ","
            << (d.inside ? 1 : 0) << "," << (d.converged ? 1 : 0) << "\n";
    }
}

} // namespace

int main(int argc, char** argv) {
    std::cerr << "===============================================" << std::endl;
    std::cerr << "calcMargin - EL-DoF Margin Calculator" << std::endl;
    std::cerr << "===============================================" << std::endl;

    std::cerr << std::fixed << std::setprecision(6);

    std::string socsDir;
    std::string layoutFile;
    std::string evpFile;
    std::string outputFile;
    std::string gridOutputFile;
    std::string perEvpOutputFile;
    std::string ppmOutputFile;
    std::string ppmOkOutputFile;

    so::MarginOptions opts;
    double defocusMin = -100.0, defocusMax = 100.0, defocusStep = 10.0;
    double doseMin = -10.0, doseMax = 10.0, doseStep = 1.0;
    int flagBrightfield = 0;

    static struct option longopts[] = {
        {"help", no_argument, nullptr, 'h'},
        {"socs_dir", required_argument, nullptr, 's'},
        {"layout", required_argument, nullptr, 'l'},
        {"evp", required_argument, nullptr, 'e'},
        {"output", required_argument, nullptr, 'o'},
        {"jobs", required_argument, nullptr, 'j'},

        {"defocus_min", required_argument, nullptr, 0},
        {"defocus_max", required_argument, nullptr, 0},
        {"defocus_step", required_argument, nullptr, 0},
        {"defocus_list", required_argument, nullptr, 0},
        {"dose_min", required_argument, nullptr, 0},
        {"dose_max", required_argument, nullptr, 0},
        {"dose_step", required_argument, nullptr, 0},
        {"dose_list", required_argument, nullptr, 0},
        {"socs_pattern", required_argument, nullptr, 0},

        {"sliceLevel", required_argument, nullptr, 0},
        {"sliceLevelHint", required_argument, nullptr, 0},
        {"tolerance", required_argument, nullptr, 0},

        {"resistModel", required_argument, nullptr, 0},
        {"dim0", required_argument, nullptr, 0},
        {"dim", required_argument, nullptr, 0},
        {"kernel", required_argument, nullptr, 0},
        {"layer", required_argument, nullptr, 0},
        {"cellname", required_argument, nullptr, 0},
        {"brightfield", no_argument, &flagBrightfield, 1},
        {"darkfield", no_argument, &flagBrightfield, 0},

        {"grid_output", required_argument, nullptr, 0},
        {"per_evp_output", required_argument, nullptr, 0},
        {"ppm_output", required_argument, nullptr, 0},
        {"ppm_ok_output", required_argument, nullptr, 0},
        {nullptr, 0, nullptr, 0}
    };

    int ch, optionIndex;
    while ((ch = getopt_long(argc, argv, "hs:l:e:o:j:", longopts, &optionIndex)) != -1) {
        switch (ch) {
            case 'h': printHelp(argv[0]); return 0;
            case 's': socsDir = optarg; break;
            case 'l': layoutFile = optarg; break;
            case 'e': evpFile = optarg; break;
            case 'o': outputFile = optarg; break;
            case 'j': opts.numThreads = std::atoi(optarg); break;
            case 0: {
                const char* name = longopts[optionIndex].name;
                if (!strcmp(name, "defocus_min")) defocusMin = std::atof(optarg);
                else if (!strcmp(name, "defocus_max")) defocusMax = std::atof(optarg);
                else if (!strcmp(name, "defocus_step")) defocusStep = std::atof(optarg);
                else if (!strcmp(name, "defocus_list")) opts.defocusList = parseDoubleList(optarg);
                else if (!strcmp(name, "dose_min")) doseMin = std::atof(optarg);
                else if (!strcmp(name, "dose_max")) doseMax = std::atof(optarg);
                else if (!strcmp(name, "dose_step")) doseStep = std::atof(optarg);
                else if (!strcmp(name, "dose_list")) opts.doseList = parseDoubleList(optarg);
                else if (!strcmp(name, "socs_pattern")) opts.socsFilePattern = optarg;
                else if (!strcmp(name, "sliceLevel")) opts.sliceLevel = std::atof(optarg);
                else if (!strcmp(name, "sliceLevelHint")) opts.sliceLevelHint = std::atof(optarg);
                else if (!strcmp(name, "tolerance")) opts.globalTolerance = std::atof(optarg);
                else if (!strcmp(name, "resistModel")) opts.resistModelFile = optarg;
                else if (!strcmp(name, "dim0")) opts.dimx0 = opts.dimy0 = std::atoi(optarg);
                else if (!strcmp(name, "dim")) opts.dimx = opts.dimy = std::atoi(optarg);
                else if (!strcmp(name, "kernel")) opts.kernelNum = std::atoi(optarg);
                else if (!strcmp(name, "cellname")) opts.cellname = optarg;
                else if (!strcmp(name, "layer")) {
                    std::stringstream ss(optarg);
                    std::string layerDatatype;
                    while (std::getline(ss, layerDatatype, ',')) {
                        size_t pos = layerDatatype.find('/');
                        if (pos != std::string::npos) {
                            int L = std::stoi(layerDatatype.substr(0, pos));
                            int D = std::stoi(layerDatatype.substr(pos + 1));
                            opts.layers.emplace_back(L, D);
                        }
                    }
                }
                else if (!strcmp(name, "grid_output")) gridOutputFile = optarg;
                else if (!strcmp(name, "per_evp_output")) {
                    perEvpOutputFile = optarg;
                    opts.exportPerEvp = true;
                }
                else if (!strcmp(name, "ppm_output")) ppmOutputFile = optarg;
                else if (!strcmp(name, "ppm_ok_output")) ppmOkOutputFile = optarg;
                break;
            }
            case '?':
            default:
                printHelp(argv[0]);
                return 1;
        }
    }

    opts.brightfield = (flagBrightfield == 1);

    if (socsDir.empty() || layoutFile.empty() || evpFile.empty() || outputFile.empty()) {
        std::cerr << "Error: Missing required arguments\n" << std::endl;
        printHelp(argv[0]);
        return 1;
    }

    // defocus / dose リストを設定
    if (opts.defocusList.empty()) {
        opts.defocusList = makeRange(defocusMin, defocusMax, defocusStep);
    }
    if (opts.doseList.empty()) {
        opts.doseList = makeRange(doseMin, doseMax, doseStep);
    }
    if (opts.defocusList.empty() || opts.doseList.empty()) {
        std::cerr << "Error: empty defocus or dose list" << std::endl;
        return 1;
    }

    std::cerr << "defocus list: " << opts.defocusList.size() << " points ["
              << opts.defocusList.front() << " .. " << opts.defocusList.back() << "] nm\n";
    std::cerr << "dose list:    " << opts.doseList.size() << " points ["
              << opts.doseList.front() << " .. " << opts.doseList.back() << "] %\n";
    std::cerr << "SOCS pattern: " << opts.socsFilePattern << " in " << socsDir << "\n";

    try {
        // evp.csv 読み込み
        std::cerr << "Loading evp: " << evpFile << std::endl;
        so::EvpData evpData;
        evpData.load(evpFile);
        std::cerr << "  clips: " << evpData.showClipCount() << std::endl;

        // 計算実行
        auto t0 = std::chrono::high_resolution_clock::now();

        so::MarginCalculator calc;
        calc.setSocsDir(socsDir);
        calc.setLayoutFile(layoutFile);
        calc.setEvpData(&evpData);
        calc.setOptions(opts);
        so::MarginResult result = calc.calculate();

        auto t1 = std::chrono::high_resolution_clock::now();
        double elapsed = std::chrono::duration<double>(t1 - t0).count();

        // 結果サマリ表示
        std::cerr << "\n===============================================" << std::endl;
        std::cerr << "Margin calculation completed!" << std::endl;
        std::cerr << "-----------------------------------------------" << std::endl;
        std::cerr << "  Elapsed:        " << elapsed << " sec" << std::endl;
        std::cerr << "  SliceLevel:     " << result.sliceLevel << std::endl;
        std::cerr << "  Best DoF:       " << result.bestDof << " nm" << std::endl;
        std::cerr << "  Best EL:        " << result.bestEl << " %" << std::endl;
        std::cerr << "  Best area:      " << result.bestArea << " (nm * %)" << std::endl;
        std::cerr << "  Best center:    defocus=" << result.bestCenterDefocus
                  << " nm, dose=" << result.bestCenterDose << " %" << std::endl;
        int okCount = 0;
        for (const auto& pt : result.grid) if (pt.ok) okCount++;
        std::cerr << "  OK grid points: " << okCount << " / " << result.grid.size() << std::endl;
        std::cerr << "-----------------------------------------------" << std::endl;

        // 出力
        std::cerr << "Writing margin summary to: " << outputFile << std::endl;
        writeMarginCsv(outputFile, result);

        if (!gridOutputFile.empty()) {
            std::cerr << "Writing grid CSV to: " << gridOutputFile << std::endl;
            writeGridCsv(gridOutputFile, result);
        }
        if (!perEvpOutputFile.empty()) {
            std::cerr << "Writing per-evp CSV to: " << perEvpOutputFile
                      << " (" << result.perEvp.size() << " rows)" << std::endl;
            writePerEvpCsv(perEvpOutputFile, result);
        }
        if (!ppmOutputFile.empty()) {
            std::cerr << "Writing PPM heatmap to: " << ppmOutputFile << std::endl;
            so::MarginCalculator::savePpm(ppmOutputFile, result, "epe");
        }
        if (!ppmOkOutputFile.empty()) {
            std::cerr << "Writing OK/NG PPM to: " << ppmOkOutputFile << std::endl;
            so::MarginCalculator::savePpm(ppmOkOutputFile, result, "ok");
        }

        std::cerr << "===============================================" << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}
